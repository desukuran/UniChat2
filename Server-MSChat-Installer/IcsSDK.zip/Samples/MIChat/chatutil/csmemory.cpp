//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "..\inc\csmemory.h"
#include "..\inc\cldbg.h"

#ifdef DEBUG

	#include "..\inc\cslock.h"

	size_t	g_cbAlloc=0;

	CRITICAL_SECTION g_csAlloc;
	
	void InitLeakCheck(void)
	{
		::InitializeCriticalSection(&g_csAlloc);
	}

	void ReleaseLeakCheck(void)
	{
		::DeleteCriticalSection(&g_csAlloc);
	}

	void ClearLeakCount(void)
	{
		::EnterCriticalSection(&g_csAlloc);
		g_cbAlloc = 0;
		::LeaveCriticalSection(&g_csAlloc);
	}

	void UpPvAlloc(void* pv)
	{
		::EnterCriticalSection(&g_csAlloc);
		g_cbAlloc += (size_t)::LocalSize((HLOCAL)pv);
		::LeaveCriticalSection(&g_csAlloc);
	}	

	void UpCbAlloc(size_t cb)
	{
		::EnterCriticalSection(&g_csAlloc);
		g_cbAlloc += cb;
		::LeaveCriticalSection(&g_csAlloc);
	}	

	void DownCbAlloc(void* pv)
	{ 
		Assert(pv);
		::EnterCriticalSection(&g_csAlloc);
		if (g_cbAlloc > 0)
		{
			g_cbAlloc -= (size_t)::LocalSize((HLOCAL)pv);
		}
		::LeaveCriticalSection(&g_csAlloc);
	}	

	void CheckForLeaks(TCHAR* pszApp)
	{
		if (0 < g_cbAlloc)
		{
			TCHAR	szAlert[256];

			wsprintf(szAlert, "%s: %d bytes leaked!", pszApp, g_cbAlloc);
			AssertSz(0, szAlert);
		}
	}

	#define UpAllocPv(pv)	UpPvAlloc(pv)
	#define UpAllocCb(cb)	UpCbAlloc(cb)
	#define DownAlloc(pv)	DownCbAlloc(pv)

#else

	#define UpAllocPv(pv)
	#define UpAllocCb(cb)
	#define DownAlloc(pv) 

#endif

//--------------------------------------------------------------------------------------------
// OPERATORS
//--------------------------------------------------------------------------------------------

void* MemoryAlloc(size_t cb)
{
#ifdef DEBUG
	PVOID	pv = ::LocalAlloc(LPTR, cb);
	
	UpAllocPv(pv);

	return pv;
#else
	return ::LocalAlloc(LPTR, cb);
#endif
}

void MemoryDeAlloc(void* pv)
{
	DownAlloc(pv);
	::LocalFree(pv);
}
