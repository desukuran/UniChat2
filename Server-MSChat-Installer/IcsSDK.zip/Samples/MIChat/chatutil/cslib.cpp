//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "..\inc\cslib.h"
#include "..\inc\cldbg.h"

// Duplicate the given string
BOOL FSzDuplicateA(CHAR* psz, CHAR** ppszCopy)
{
	Assert(psz);
	Assert(ppszCopy);

	*ppszCopy	= NULL;
	// Allocate enough memory for a copy
	int cb			= GetCbSz(psz) + sizeof(CHAR);
	CHAR* pszTemp	= new CHAR[cb];
	if (!pszTemp)
	{
		AssertGLE(FALSE);
		return FALSE;
	}

	::CopyMemory((PVOID)pszTemp, (PVOID)psz, cb);
	*ppszCopy = pszTemp;

	return TRUE;
}

// Copy a stream of bytes as an SZ
BOOL FSzCopyBufAsSzA(BYTE* psb, DWORD dwcb, CHAR** ppszCopy)
{
	Assert(psb);
	Assert(ppszCopy);
	// And now make a new one
	BYTE* pb = new BYTE[dwcb + sizeof(CHAR)];
	if (NULL == pb)
	{
		AssertGLE(FALSE);
		return FALSE;
	}

	*ppszCopy = (CHAR*)pb;
	// Copy the buffer
	::CopyMemory((PVOID)pb, (PVOID)psb, dwcb);
	// We keep a NULL terminated name
	pb += dwcb;
	*((CHAR*)pb) = '\0';

	return TRUE;
}

BOOL FSzDuplicateW(WCHAR* psz, WCHAR** ppszCopy)
{
	Assert(psz);
	Assert(ppszCopy);

	*ppszCopy	= NULL;
	// Allocate enough memory for a copy
	int cb = GetCbSz(psz) + sizeof(WCHAR);
	WCHAR* pszTemp = new WCHAR[cb];
	if (!pszTemp)
	{
		AssertGLE(FALSE);
		return FALSE;
	}

	::CopyMemory((PVOID)pszTemp, (PVOID)psz, cb);
	*ppszCopy = pszTemp;

	return TRUE;
}

// Copy a stream of bytes as an SZ
BOOL FSzCopyBufAsSzW(BYTE* psb, DWORD dwcb, WCHAR** ppszCopy)
{
	Assert(psb);
	Assert(ppszCopy);
	// And now make a new one
	BYTE*	pb = new BYTE[dwcb + sizeof(WCHAR)];
	if (NULL == pb)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	*ppszCopy = (WCHAR*)pb;
	// Copy the buffer
	::CopyMemory((PVOID)pb, (PVOID)psb, dwcb);
	// We keep a NULL terminated name
	pb += dwcb;
	*((WCHAR *)pb) = '\0';

	return TRUE;
}

// String Lengths
int CChSz(CHAR* psz)
{
	if (psz)
	{
		return lstrlen(psz);
	}
	return 0;
}

int CChSz(WCHAR* psz)
{
	if (psz)
	{
		return lstrlenW(psz);
	}
	return 0;
}

int	GetCbSz(CHAR* psz)
{
	if (psz)
	{
		return (sizeof(CHAR) * (lstrlen(psz)));
	}
	return 0;
}

int GetCbSz(WCHAR* psz)
{
	if (psz)
	{
		return (sizeof(WCHAR) * (lstrlenW(psz)));
	}
	return 0;
}

void CopyBytes(BYTE** ppbCopy, BYTE* pbSrc, int cbData, BOOL fNull, BOOL fAnsi)
{
	Assert(ppbCopy && pbSrc);

	BYTE* pbCopy = *ppbCopy;
	::CopyMemory((PVOID)pbCopy, (PVOID)pbSrc, cbData);
	pbCopy += cbData;
	if (fNull)
	{
		if (fAnsi)				 // null terminate the alias
		{
			*((CHAR*)pbCopy) = '\0';
		}
		else
		{
			*((WCHAR*)pbCopy) = '\0';
		}
		++pbCopy;
	}
	*ppbCopy = pbCopy;
}
