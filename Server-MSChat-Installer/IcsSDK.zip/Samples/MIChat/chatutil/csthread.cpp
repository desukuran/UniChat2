//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "..\inc\csthread.h"
#include "..\inc\cldbg.h"

const DWORD		DWTIMEOUT = 30000;	// default timeout of 30 seconds (30,000 millis)

//////////////////////////////////////////////////////////////////////////////////
//
CSSystemObj::CSSystemObj(void)
{
	m_handle = NULL;
}

CSSystemObj::~CSSystemObj(void)
{
	CloseHandle();
}

DWORD CSSystemObj::DwWaitForObject(DWORD dwTimeOut)
{
	if (!m_handle)
	{
		return WAIT_FAILED;
	}
	
	return ::WaitForSingleObject(m_handle, dwTimeOut);
}

void CSSystemObj::CloseHandle(void)
{
	if (m_handle)
	{
		::CloseHandle(m_handle);
		m_handle = NULL;
	}
}

//////////////////////////////////////////////////////////////////////////////////
// CSThread
CSThread::CSThread(void)
		: CSSystemObj()
{
	m_dwID = 0;
}

CSThread::~CSThread(void)
{
	if (FIsThreadActive())
	{
		StopThread();
	}
}

BOOL CSThread::FIsThreadActive(void)
{
	if (!m_handle)
	{
		return FALSE;
	}
	
	DWORD	dwExit;

	if (!FGetExitCode(&dwExit))
	{
		AssertGLE(FALSE);
		return FALSE;
	}

	return (STILL_ACTIVE == dwExit);
}

BOOL CSThread::FGetExitCode(DWORD* pdw)
{
	Assert(pdw);

	return ::GetExitCodeThread(m_handle, pdw);
}

BOOL CSThread::FCreateThread(LPTHREAD_START_ROUTINE lpProc, LPVOID lpParam)
{
	Assert(lpProc && lpParam);
	if (m_handle)
	{
		return TRUE;
	}

	m_handle =	::CreateThread(NULL, 0, lpProc, lpParam, 0, &m_dwID);
	if (NULL == m_handle)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

// WARNING: Call this as a last resort
BOOL CSThread::FTerminateThread(void)
{
	return ::TerminateThread(m_handle, FALSE);
}

void CSThread::StopThread(void)
{
	if (NULL == m_handle)
	{
		return;
	}

	if (WAIT_OBJECT_0 != DwWaitForThread(DWTIMEOUT))
	{
		AssertSz(0, "Thread Hung! Terminating");
		// This is ugly,  but its the only thing left to do!
		FTerminateThread();
	}
	CloseThreadHandle();
}

//////////////////////////////////////////////////////////////////////////////////
// CSEvent
CSEvent::CSEvent(void)
	:CSSystemObj()
{
}

CSEvent::~CSEvent(void)
{
}

BOOL CSEvent::FCreate(TCHAR* pszName)
{
	if (m_handle)
	{
		return TRUE;
	}

	m_handle = ::CreateEvent(NULL, FALSE, FALSE, pszName);
	if (NULL == m_handle)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

//////////////////////////////////////////////////////////////////////////////////
// CSMutex
CSMutex::CSMutex(void)
	:CSSystemObj()
{
}

CSMutex::~CSMutex(void)
{
}

BOOL CSMutex::FCreate(TCHAR* pszName)
{
	if (m_handle)
	{
		return TRUE;
	}

	m_handle = ::CreateMutex(NULL, TRUE, pszName);
	if (NULL == m_handle)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	
	return TRUE;
}

