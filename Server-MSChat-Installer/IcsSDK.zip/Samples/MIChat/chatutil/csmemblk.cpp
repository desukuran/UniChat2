//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "..\inc\memblock.h"
#include "..\inc\cldbg.h"

////////////////////////////////////////////////////////////////////////////////////////////
// Create a new memory block and chain it in
CMemoryBlockChain::CMemoryBlockChain(void)
{
	m_pmbNext = NULL;
}

CMemoryBlockChain::~CMemoryBlockChain(void)
{
	if (m_pmbNext)
	{
		FreeBlockAndChain();
	}
}

PMEM_BLOCK CMemoryBlockChain::PmbCreate(DWORD dwcb)
{
	Assert(dwcb);

	// Allocate a new block. Allocate the byte count requested by the user plus enough
	// space for the Memory Block header.
	PMEM_BLOCK pmb = (PMEM_BLOCK) new BYTE[sizeof(MEM_BLOCK) + dwcb];
	if (NULL == pmb)
	{
		AssertGLE(FALSE);
		return NULL;
	}
	// Chain the block in
	pmb->m_pmbNext = m_pmbNext;
	m_pmbNext = pmb;
	return pmb;
}

// Free this block and all its linked blocks
void CMemoryBlockChain::FreeBlockAndChain(void)     
{
	PMEM_BLOCK	pmb = m_pmbNext;
	PMEM_BLOCK	pmbNext;

	while (pmb)
	{
		// Save the link to the next block in the chain
		pmbNext = pmb->m_pmbNext;
		// delete this block
		delete [] (BYTE*)pmb;
		// Next in the chain
		pmb = pmbNext;
	} 
	m_pmbNext = NULL;
}

////////////////////////////////////////////////////////////////////////////////////////////
// The Heap
CHeap::CHeap(DWORD dwcBlocksGrow,DWORD dwcbBlock)
{
	m_cBlocksGrow	= dwcBlocksGrow;
	m_cbBlock		= dwcbBlock;
	m_pFreeList		= NULL;
}

CHeap::~CHeap(void)
{
	CleanUp();
}

void CHeap::CleanUp(void)
{
	m_pFreeList = NULL;
	m_memChain.FreeBlockAndChain();
}

BYTE* CHeap::Alloc(void)
{
	CMemBlock* pBlock;
	// Do we have any free nodes? If not, allocate a new block from the OS
	if (!m_pFreeList)
	{
		// add another block. This will ZERO out everything
		PMEM_CHAIN	pmc = m_memChain.PmbCreate(m_cbBlock * m_cBlocksGrow);
		if (!pmc)
		{
			return NULL;
		}
		// Add new nodes to free list.. chain them in.
		pBlock	= (CMemBlock*)pmc->PvData();
		for (DWORD c = 0; c < m_cBlocksGrow; ++c)
		{
			pBlock->SetNext(m_pFreeList);
			m_pFreeList = pBlock;
			pBlock = (CMemBlock*)(((BYTE*)pBlock) + m_cbBlock);
		}
	}
	Assert(m_pFreeList); 
	// Take a node from the front of the free list and use it
	pBlock		= m_pFreeList;
	m_pFreeList	= pBlock->PNext();
	pBlock->SetNext(NULL);

	return (BYTE*)pBlock;
}

void CHeap::Free(BYTE* pb)
{
	Assert(pb);
	// Return the node to the FREE pool
	CMemBlock* pBlock = (CMemBlock*)pb;
	pBlock->SetNext(m_pFreeList);
	m_pFreeList	= pBlock;
}
