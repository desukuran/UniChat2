//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "..\inc\csrw.h"
#include "..\inc\cldbg.h"

CSReadWrite::CSReadWrite(void)
{
	m_cReaders = 0;
	m_hEvent = NULL;
}

CSReadWrite::~CSReadWrite(void)
{
	// Free any blocked threads
	if (m_hEvent)
	{
		::SetEvent(m_hEvent);
		::CloseHandle(m_hEvent);
	}
}

BOOL CSReadWrite::FInitReadWrite(void)
{
	// Create a MANUAL Reset Event
	m_hEvent = ::CreateEvent(NULL, TRUE, TRUE, NULL);
	if (!m_hEvent)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;	
}

BOOL CSReadWrite::FWaitForEvent(void)
{
	switch (::WaitForSingleObject(m_hEvent, INFINITE))
	{
	default:
		break;
	
	case WAIT_FAILED:
	case WAIT_ABANDONED:
	case WAIT_TIMEOUT:
		AssertGLE(FALSE);
		return FALSE;
	}

	return TRUE;
}

void CSReadWrite::ReadLock(void)
{		 
	// we want to block reads if (a) a writer is waiting to write (b) there is a writer writing.
	// But once we get in.. we want to get in long enough to up the reader count and set the event..
	m_csWrite.Lock();
	// And now grab the CS to the current reader count
	m_csRead.Lock();
	// If somebody is already reading, then we know that we have already grabbed
	// the write synchroization object. Otherwise,  we must wait till the writer is done
	if (0 == m_cReaders)
	{
		::ResetEvent(m_hEvent);		// readers are reading now..
	}

	++m_cReaders;
	
	m_csRead.Unlock();
	m_csWrite.Unlock();
}

void CSReadWrite::ReadUnlock(void)
{
	m_csRead.Lock();
	
	--m_cReaders;
	if (0 == m_cReaders)
	{
		::SetEvent(m_hEvent); // no more readers
	}
	m_csRead.Unlock();
}

void CSReadWrite::WriteLock(void)
{
	m_csWrite.Lock();	// claim write access..or request it

	FWaitForEvent();	// wait till all readers are done
}

void CSReadWrite::WriteUnlock(void)
{
	m_csWrite.Unlock();	// done with writing
}
