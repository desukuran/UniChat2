//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "ictree.h"

///////////////////////////////////////////////////////////////////////////////////////////
CChatTreeView::CChatTreeView(void)
		: CChatChildWnd()
{
	m_himl		= NULL;
	m_hRoot		= NULL;
	m_hChannel	= NULL;
	m_hUsers	= NULL;
	::ZeroMemory(&m_rgiImg, sizeof(int) * CIMAGESTREE);
	InitCommonControls();	// ensures that the common control dynamic-link library (DLL) is loaded.
}

CChatTreeView::~CChatTreeView(void)
{
	FCleanUp();
}

BOOL CChatTreeView::FCleanUp(void)
{
	if (m_himl)
	{
		::ImageList_Destroy(m_himl);
		m_himl = NULL;
	}
	return TRUE;
}

LRESULT CALLBACK ChildTreeViewWndProc(HWND, UINT, WPARAM, LPARAM);

BOOL CChatTreeView::FInit(HWND hWnd)
{
	if (hWnd)
	{
		Assert(NULL == m_hWnd);
		m_hWnd = hWnd;
	}
	// Load bitmaps
	if (!m_ccbitmap.FLoad(HInstance(m_hWnd)))
	{
		return FALSE;
	}
	SetWindowProc(ChildTreeViewWndProc);

	// Init the tree view image list
	return FInitImageList();
}

BOOL CChatTreeView::FCreate(HWND hWndParent, int idCmd, RECT* prc)
{
	InitCommonControls();

	if (!CChatChildWnd::FCreate(hWndParent, idCmd, prc, WC_TREEVIEW, 
						WS_CHILD | WS_VISIBLE | WS_VSCROLL | 
						TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS, 
						0, NULL))
	{
		return FALSE;
	}
	::SetWindowLong(m_hWnd, GWL_USERDATA, (LONG)this);
	return FInit(NULL);
}

int CChatTreeView::IGetCount(void)
{
	Lock();
	int c = (int)SendMessage(TVM_GETCOUNT);
	Unlock();
	return c;
}

BOOL CChatTreeView::FAddRoot(TCHAR *szRoot)
{
	Assert(szRoot);

	m_hRoot = HtiAddItem(NULL, m_rgiImg[IIMGWORLD], 1, NULL, szRoot);
	if (!m_hRoot || !FAddChatFolder() || !FAddUserFolder())
	{
		return FALSE;
	}
	return FExpandNode(m_hRoot);
}

BOOL CChatTreeView::FAddChatFolder(void)
{
	m_hChannel = HtiAddItem(m_hRoot, m_rgiImg[IIMGFOLDER], 1, NULL, SzGet(IDS_FIND_ALLCHATS));
	return (NULL != m_hChannel);
}

BOOL CChatTreeView::FAddUserFolder(void)
{
	m_hUsers = HtiAddItem(m_hRoot, m_rgiImg[IIMGFOLDER], 1, NULL, SzGet(IDS_FIND_NAMES));
	return (NULL != m_hUsers);
}

BOOL CChatTreeView::FIsFolder(HTREEITEM hItem)
{
	// This is good enough for now. We may want to set Flags on each folder, and our needs would
	// demand SMALL allocations (8 bytes). But that would mean writing a more efficient memory 
	// allocator than Windows, which has an overhead of 16 bytes for allocation! 
	return (hItem == m_hRoot || hItem == HtiChannel() || hItem == HtiUsers());
}

BOOL CChatTreeView::FAddChannel(PICS_PROPERTY picsProperty, DWORD dwMode, HTREEITEM htiParent)
{
	Assert(picsProperty && m_hChannel);
	
	// Tag the node
	if (FAILED(picsProperty->HrSetPrivateData((PVOID)CHANNELNODE)))
	{
		AssertSz(0, "HrSetPrivateData");
		return FALSE;
	}
	// Add the channel name..
	if (!htiParent)
	{
		htiParent = HtiChannel();
	}
	int iImg = (dwMode & CS_CHANNEL_PROTECTED)	? m_rgiImg[IIMGCHATPRIV] : m_rgiImg[IIMGCHANNEL];
	HTREEITEM hItemChan = HtiAddItem(htiParent, iImg, 1, picsProperty);
	return (NULL != hItemChan);
}

BOOL CChatTreeView::FAddMember(PICS_PROPERTY picsProperty, DWORD dwMode, HTREEITEM htiParent)
{
	Assert(picsProperty && htiParent);
	// Tag the node
	if (FAILED(picsProperty->HrSetPrivateData((PVOID)MEMBERNODE)))
	{
		AssertSz(0, "HrSetPrivateData");
		return FALSE;
	}
	// set the image appropriately
	int iImg;
	
	if (dwMode & CS_MEMBER_HOST)
	{
		iImg = m_rgiImg[IIMGHOST];
	}
	else if (dwMode & CS_MEMBER_SPEAKER)
	{
		iImg = m_rgiImg[IIMGSPEAKER];
	}
	else
	{
		iImg = m_rgiImg[IIMGSPECTATOR];
	}
	return (NULL != HtiAddItem(htiParent, iImg, 0, picsProperty));
}

BOOL CChatTreeView::FAddUser(PICS_PROPERTY picsProperty)
{
	Assert(m_hUsers);
	// Tag the node
	if (FAILED(picsProperty->HrSetPrivateData((PVOID)USERNODE)))
	{
		AssertSz(0, "HrSetPrivateData");
		return FALSE;
	}
	return (NULL != HtiAddItem(m_hUsers, m_rgiImg[IIMGMEMBER], 0, picsProperty));
}
	
BOOL CChatTreeView::FIsMember(HTREEITEM htiItem)
{
	if (FIsFolder(htiItem))
	{
		return FALSE;
	}
	return FIsMember(PicsPropertyGet(htiItem));
}

BOOL CChatTreeView::FIsMember(PICS_PROPERTY picsProperty)
{
	return FIsNode(picsProperty, MEMBERNODE);
}

BOOL CChatTreeView::FIsChannel(HTREEITEM htiItem)
{
	if (FIsFolder(htiItem))
	{
		return FALSE;
	}
	return FIsChannel(PicsPropertyGet(htiItem));
}

BOOL CChatTreeView::FIsChannel(PICS_PROPERTY picsProperty)
{
	return FIsNode(picsProperty, CHANNELNODE);
}

BOOL CChatTreeView::FIsUser(HTREEITEM htiItem)
{
	if (FIsFolder(htiItem))
	{
		return FALSE;
	}
	return FIsUser(PicsPropertyGet(htiItem));
}

BOOL CChatTreeView::FIsUser(PICS_PROPERTY picsProperty)
{
	return FIsNode(picsProperty, USERNODE);
}

BOOL CChatTreeView::FIsNode(PICS_PROPERTY picsProperty, int iSrcType)
{
	Assert(picsProperty);

	int		iNodeType;
	HRESULT hr = picsProperty->HrGetPrivateData((PVOID*)&iNodeType);
	if (FAILED(hr))
	{
		AssertSz(0, "HrGetPrivateData");
		return FALSE;
	}
	return (0 != (iNodeType & iSrcType));
}

BOOL CChatTreeView::FExpandChats(void)
{
	// Make sure the Root is expanded
	FExpandNode(m_hRoot);
	return FExpandNode(HtiChannel());
}

BOOL CChatTreeView::FExpandUsers(void)
{
	FExpandNode(m_hRoot);
	return FExpandNode(HtiUsers());
}

BOOL CChatTreeView::FExpandNode(HTREEITEM hItem)
{
	BOOL	fRet = FALSE;
	if (hItem)
	{
		Lock();
		fRet = SendMessage(TVM_EXPAND, (WPARAM)TVE_EXPAND, (LPARAM)hItem);
		Unlock();
	}
	return fRet;
}

BOOL CChatTreeView::FDeleteAll(void)
{
	BOOL	fRet = FALSE;

	Lock();
	if (m_hRoot)
	{
		// Clean up the everything
		fRet = FDeleteItem(m_hRoot);
		m_hRoot = NULL;
	}
	Unlock();

	return fRet;
}

BOOL CChatTreeView::FDeleteAllChannels(void)
{
	BOOL	fRet = FALSE;

	Lock();
	if (m_hChannel)
	{
		// Clean up the channel node. Remove everything
		fRet = FDeleteItem(m_hChannel);
		m_hChannel = NULL;
	}
	Unlock();
	return fRet;
}

BOOL CChatTreeView::FDeleteAllUsers(void)
{
	BOOL	fRet = FALSE;

	Lock();
	if (m_hUsers)
	{
		// Clean up the channel node. Remove everything
		fRet = FDeleteItem(m_hUsers);
		m_hUsers = NULL;
	}
	Unlock();
	return fRet;
}

BOOL CChatTreeView::FDeleteAllChildren(HTREEITEM htiParent)
{
	Assert(htiParent);

	HTREEITEM	hItem;
	// Get the first child
	while (1)
	{
		hItem = HtiGetChild(htiParent);
		if (!hItem)
			break;
		FDeleteItem(hItem);	// delete it
	}
	return TRUE;

}

PICS_PROPERTY CChatTreeView::PicsPropertyGet(HTREEITEM hItem)
{
	Assert(hItem);

	TV_ITEM tvItem;
	PICS_PROPERTY picsProp = NULL;

	tvItem.hItem = hItem;
	tvItem.mask = TVIF_PARAM;	// this will cause the tree control to return our property

	Lock();
	if (SendMessage(TVM_GETITEM, (LPARAM) &tvItem))
	{
		picsProp = (PICS_PROPERTY) tvItem.lParam;
	}
	Unlock();

	return picsProp;
}

BOOL CChatTreeView::FSetPicsProperty(HTREEITEM hItem, PICS_PROPERTY picsProperty)
{
	Assert(hItem && picsProperty);

	TV_ITEM tvItem;
	BOOL	fRet;

	tvItem.hItem	= hItem;
	tvItem.mask		= TVIF_PARAM; // this will cause the tree control to return our property
	tvItem.lParam	= (LPARAM)picsProperty;
	
	Lock();	
	fRet =  (-1 != SendMessage(TVM_SETITEM, (LPARAM) &tvItem));
	Unlock();

	return fRet;
}

HTREEITEM CChatTreeView::HtiAddItem(HTREEITEM htiParent, int iImage, int cChildren, 
									PICS_PROPERTY picsProperty, TCHAR* psz)
{
	Assert(m_hWnd);

	BOOL			fRet = FALSE;
    TV_ITEM			tvi; 
    TV_INSERTSTRUCT tvins; 
	HTREEITEM		hPrev;

	if (picsProperty)
	{
		picsProperty->AddRef();
	}

	tvi.mask = TVIF_HANDLE | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM | TVIF_TEXT |
				TVS_HASBUTTONS | TVIF_CHILDREN;

	tvi.pszText			= (NULL == psz) ? LPSTR_TEXTCALLBACK : psz;
	tvi.cchTextMax		= 256;
	tvi.iImage			= iImage;
	tvi.iSelectedImage	= iImage;
	tvi.cChildren		= cChildren;
	tvi.lParam			= (LPARAM)picsProperty;

    tvins.item = tvi; 
	tvins.hParent = htiParent;
    tvins.hInsertAfter = (NULL == psz) ? TVI_SORT : TVI_FIRST;

	Lock();

    hPrev = (HTREEITEM) SendMessage(TVM_INSERTITEM, (LPARAM)(LPTV_INSERTSTRUCT)&tvins); 
	
	Unlock();
	
	if (!hPrev)
	{
		AssertGLE(FALSE);
		if (picsProperty)
		{
			picsProperty->Release();
		}
	}
	return hPrev;
}

// public
BOOL CChatTreeView::FDeleteItem(HTREEITEM hItem)
{
	Assert(hItem);
	BOOL	fRet = TRUE;
	// remove it from the tree
	Lock();
	//fRet = SendMessage(TVM_DELETEITEM, (LPARAM)hItem);
	PostMessage(TVM_DELETEITEM, (LPARAM)hItem);
	Unlock();

	return fRet;
}

// Redraw this item
BOOL CChatTreeView::FRedrawItem(HTREEITEM hItem)
{
	Assert(hItem);

	TV_ITEM tvItem;
	BOOL	fRet;

	tvItem.hItem	= hItem;
	tvItem.mask		= TVIF_TEXT; // this will cause the tree control to return our property
	tvItem.pszText	= LPSTR_TEXTCALLBACK;
	
	Lock();
	fRet =  (-1 != SendMessage(TVM_SETITEM, (LPARAM) &tvItem));
	Unlock();

	return fRet;
}

// Return a string for the tree view control to display
BOOL CChatTreeView::FInitImageList(void)
{
	// Init the tree view image list
	m_himl = ImageList_Create(16, 16, 0, CIMAGESTREE, 0);
    if (!m_himl) 
	{
		AssertGLE(FALSE);
        return FALSE; 
	}
	// Add bitmaps. 
	m_rgiImg[IIMGCHANNEL]	= ImageList_Add(m_himl, m_ccbitmap.HBitmapChat(),		NULL);
	m_rgiImg[IIMGMEMBER]	= ImageList_Add(m_himl, m_ccbitmap.HBitmapMember(),		NULL);
	m_rgiImg[IIMGWORLD]		= ImageList_Add(m_himl, m_ccbitmap.HBitmapWorld(),		NULL);
	m_rgiImg[IIMGHOST]		= ImageList_Add(m_himl, m_ccbitmap.HBitmapHost(),		NULL);
	m_rgiImg[IIMGSPEAKER]	= ImageList_Add(m_himl, m_ccbitmap.HBitmapPart(),		NULL);
	m_rgiImg[IIMGSPECTATOR]	= ImageList_Add(m_himl, m_ccbitmap.HBitmapSpec(),		NULL);
	m_rgiImg[IIMGFOLDER]	= ImageList_Add(m_himl, m_ccbitmap.HBitmapFolder(),		NULL);
	m_rgiImg[IIMGCHATPRIV]	= ImageList_Add(m_himl, m_ccbitmap.HBitmapChatPriv(),	NULL);
	// make sure we got everything
	for (int i = 0; i < CIMAGESTREE; ++i)
	{
		if (-1 == m_rgiImg[i])
		{
			AssertGLE(FALSE);
			goto LError;
		}
	}
	// Attach the image list
	SendMessage(TVM_SETIMAGELIST, (WPARAM)TVSIL_NORMAL, (LPARAM)m_himl);

	return TRUE;

LError:
	FCleanUp();
	
	return FALSE;
}

TCHAR* CChatTreeView::SzGet(int idStr)
{
	return GetSz(HInstance(m_hWnd), idStr);
}

///////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK ChildTreeViewWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CChatTreeView*	pctv;

	LONG lData = GetWindowLong(hWnd, GWL_USERDATA);
	Assert(0xffffffff != lData);
	if (0 != lData)
	{
		pctv = (CChatTreeView*)lData;
		if (uMsg == WM_RBUTTONDOWN)
		{
			// act like an LBUTTONDOWN--select the hit element
			TV_HITTESTINFO	hit;
			HTREEITEM		hitem;

			hit.pt.x = LOWORD(lParam);
			hit.pt.y = HIWORD(lParam);
			hitem = TreeView_HitTest(hWnd, &hit);
			if (hitem)
			{
				TreeView_Select(hWnd, hitem, TVGN_CARET);
			}
		}
		LONG lRes = pctv->LrCallWindowProc(uMsg, wParam, lParam);
		return lRes;
	}
	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}
