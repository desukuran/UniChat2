//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICFIND__
#define __ICFIND__

#include "icinc.h"
#include "icpane.h"
#include "ictree.h"
#include "icref.h"
#include "icwizard.h"

const int CCHMAXTREEVIEW	= 512;	// this is the hugest string we will support in our tree view

//
// Pane with find information
class CChatFindPane : public CChatPane, public CRefCount
{
friend	LRESULT CALLBACK TreeViewWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
//
// interfaces
public:
	CChatFindPane(void);
	~CChatFindPane(void);

	BOOL		FInsertChannel(PICS_PROPERTY picsProperty);
	BOOL		FInsertMember(PICS_PROPERTY picsProperty);
	BOOL		FInsertUser(PICS_PROPERTY picsProperty);

	BOOL		FLookUpError(void);
	BOOL		FNoDataOnLookUp(void);

	BOOL		FGotFirstChannel(void);
	BOOL		FGotFirstMember(void);
	BOOL		FGotFirstUser(void);

	BOOL		FGotAllChannels(void);
	BOOL		FGotAllMembers(void);
	BOOL		FGotAllUsers(void);

	BOOL		FUpdateProperty(PICS_PROPERTY picsProperty);

	BOOL		FAutoJoinChannel(TCHAR* szName);

	CChatTreeView* PTreeView(void)	{ return &m_cctv; }

	virtual	void	Free(void)	{ delete this; }
	BOOL		FWaiting(void);
	BOOL		FDisablePane(void);

protected:
	virtual BOOL		FInitElements(void);
	virtual BOOL		FHandleWMSize(WPARAM wParam, LPARAM lParam);

	LRESULT		LHandleNotify(LPARAM lParam);
	BOOL		FDoContextMenu(short x, short y);

	TCHAR*		PszGetDisplaySz(PICS_PROPERTY picsProperty, DWORD dwIndex, TCHAR* szConvert);

protected:
	LRESULT		LGetDispInfo(TV_DISPINFO* ptvInfo);
	LRESULT		LGetMemberDispInfo(TV_DISPINFO* ptvInfo, PICS_PROPERTY picsProperty);
	LRESULT		LDeleteItem(LPNM_TREEVIEW ptv);
	LRESULT		LItemExpanded(LPNM_TREEVIEW ptv);
	BOOL		FFolderItemExpanded(HTREEITEM htiItem);

	void		SetWaiting(BOOL fWait);

	BOOL		FForcedExpand(void);
	void		SetForcedExpand(BOOL fForce);

	BOOL		FDoneLookup(void);
	DWORD		DwGetNodeType(PICS_PROPERTY picsProperty);

	BOOL		FAddChannel(PICS_PROPERTY picsProperty);
	BOOL		FAddMember(PICS_PROPERTY picsProperty);
	BOOL		FAddChannelMember(PICS_PROPERTY picsProperty, int index, BOOL fMember=FALSE);

	BOOL		FGotAll(HTREEITEM htiParent);
//
// Data
protected:
	CChatTreeView	m_cctv;		// the find pane contains this control
	//
	// Cursors when doing lookups against the server
	HCURSOR			m_hCursor;
	HCURSOR			m_hCursorWait;
	//
	// State information
	HTREEITEM		m_hCurItem;	// the item currently open or being expanded.
	BOOL			m_fWaiting;	// are we waiting for the server to reply
	BOOL			m_fForceExpand;	// is this expand forced?
	//
	// Keep these cached to make redraws faster/easy
	TCHAR			m_szDisplay[CCHMAXTREEVIEW];
	TCHAR			m_szConvert[MAX_PATH];
	TCHAR			m_szConvert1[MAX_PATH];
	CS_PROPDATA		m_csPropData;
	//
	// Useful critical section
	CS_LOCK			m_csMod;
};

//
// Dialogs that do finds
class CFindDlg : public CChatPropertyPage
{
friend BOOL CALLBACK FindDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
friend BOOL CALLBACK FindMemberDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
//
// Interfaces
public:
	CFindDlg(void);
	~CFindDlg(void);

	BOOL	FFindDlg(HWND hWndParent);
	BOOL	FFindMemberDlg(HWND hWndParent);
	
	TCHAR*	SzFind(void)	{ return m_szFind; }

	DWORD	DwMax(void)		{ return m_dwMax; }
	DWORD	DwMin(void)		{ return m_dwMin; }
	BOOL	FContains(void)	{ return m_fContains; }

	virtual	void	Free(void)	{ delete this; }

protected:
	BOOL	FInitFindDlg(HWND hDlg);
	BOOL	FNotifyFind(HWND hDlg, LPARAM lParam);
	BOOL	FGetFindParams(HWND hDlg);

	BOOL	FInitFindMemberDlg(HWND hDlg);
	BOOL	FNotifyFindMember(HWND hDlg, LPARAM lParam);
	BOOL	FGetFindMemberParams(HWND hDlg);
protected:
	TCHAR	m_szFind[CS_CCHMAX_QUERY_STRING + 1];
	DWORD	m_dwMax;
	DWORD	m_dwMin;
	BOOL	m_fContains;
};

#endif
