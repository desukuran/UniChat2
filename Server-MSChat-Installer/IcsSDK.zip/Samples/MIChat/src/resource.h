//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ichat.rc
//
#define IDS_LBL_LOGINNICK               109
#define IDS_LBL_NICKBAK                 110
#define IDS_LBL_CONNECT                 111
#define IDS_CONSETTINGS                 112
#define IDD_CANCELDLG                   125
#define IDR_ACCELERATORMIC              126
#define IDD_INVITE                      127
#define IDS_ERR_NOWHISPER               251
#define IDS_ERR_SOMENOWHISPER           252
#define IDS_F1HELP                      301
#define IDS_SSFINDCHANNELS              302
#define IDS_ERR_CANTKILLSELF            550
#define IDS_ERR_MAKESELFSPEC            551
#define IDS_ERR_MAKESELFSPEAKER         552
#define IDS_ERR_BADCHATNAME             553
#define IDS_CHANNELPROPSDLG             701
#define IDS_THISCHAT                    702
#define IDS_ERR_NOAUTHENTICATE          703
#define IDS_ERR_NOANONYMOUS             704
#define IDS_ERR_AUTHNOTAVAIL            704
#define IDS_ERR_NOAUTHASK               705
#define IDS_ERR_NOANONASK               706
#define IDS_ERR_SERVERFULL              707
#define IDS_ERR_NOLIMIT                 708
#define IDS_CURUSERCOUNT                709
#define IDS_ERR_AUTHONLY                710
#define IDS_ERR_CONNSETTINGS            711
#define IDS_ERR_NICKTOOLONG             712
#define IDS_ERR_IGNORESELF              713
#define IDS_ERR_IGNOREHOST              714
#define IDS_CHANMODECHANGED             715
#define IDS_OPTIONSDLGTITLE             716
#define IDS_SAVEBEFOREEXIT              717
#define IDS_ERR_KICKED                  718
#define IDS_ERR_SELFWHISPER             719
#define IDS_NICKNAME                    720
#define IDS_WHISPERNOTAVAIL             721
#define IDS_NOTHINGTOSEND               722
#define IDC_LBLNICK                     1042
#define IDC_LBLACTION                   1043
#define IDC_CONNECT                     1044
#define IDC_SETTINGS                    1045
#define IDC_LBLNICKBAK                  1046
#define IDC_CHECKCONFIRMNICK            1046
#define IDC_CHKINVITEONLY               1048
#define IDC_CHKTOPICOP                  1049
#define IDC_CHKAUTHENTICATE             1050
#define IDC_CHKWHISPER                  1051
#define IDC_CHKREALNAME                 1052
#define IDC_CHKMODERATED                1053
#define IDC_LBLCHANNELTYPE              1054
#define IDC_CHECKANON                   1055
#define IDC_EDITMEMLIMIT                1056
#define IDC_CHKLIMITUSER                1057
#define IDC_LBLCURRENTCOUNT             1058
#define IDC_EDITCHANPASS                1060
#define IDC_LBLPASS                     1061
#define IDC_LBLCHATNAME                 1062
#define IDC_LBLFROM                     1063
#define IDC_CHKJOIN                     1066
#define IDC_CHKLEAVE                    1067
#define IDC_CHKBLANKLINE                1068
#define IDC_CHKSAVE                     1069
#define IDC_CHKINVITE                   1070
#define IDC_BTNURL                      1071
#define IDC_EDITNICKBAK                 4103
#define IDC_EDITUSERPASS                4112
#define IDD_LOGINOPTIONS                4301
#define IDD_CHANNELADVANCED             4302
#define IDD_USERPROPS                   4303
#define IDD_OPTIONS                     4304
#define IDC_GETUSERPROPS                40004
#define IDC_GETUSERREALNAME             40005
#define IDC_INVITE                      40006
#define IDC_INVITEUSER                  40007
#define IDC_USEROPTIONS                 40008
#define IDC_BAN                         40009
#define IDC_UNBAN                       40010
#define IDC_KILLUSER                    40011
#define ID_MEMBER_DONTBAN               40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1072
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
