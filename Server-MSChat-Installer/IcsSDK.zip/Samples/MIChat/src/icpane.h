//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICPANE__
#define __ICPANE__

#include "icinc.h"

// Generic Pane in Chat
class CChatPane : public CChatChildWnd
{
	friend	LRESULT CALLBACK PaneWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CChatPane(void);
	~CChatPane(void);

	BOOL		FCreate(HWND hWndParent, int idCtl, RECT* prc, BOOL fBorder=TRUE, BOOL fPopUp=FALSE);
	BOOL		FCreateOverlap(HWND hWndParent, RECT* prc);

	void			SetParentPane(CChatPane* pcpParent)	{ m_pcpParent = pcpParent; }
	virtual	HWND	HWndSetFocus(void)	{ return ::SetFocus(m_hWnd); }
protected:
	virtual BOOL	FInitElements(void)	{ return TRUE; }
	virtual BOOL	FHandleWMSize(WPARAM wParam, LPARAM lParam)	{ return FALSE; } // not handled by default
	virtual BOOL	FHandleMsgFromChild(UINT uMsg, WPARAM wParam, LPARAM lParam)
						{ return FGiveMsgToParent(uMsg, wParam, lParam); }
	BOOL			FGiveMsgToParent(UINT uMsg, WPARAM wParam, LPARAM lParam);
// Data
protected:
	CChatPane*	m_pcpParent;
};
			
#endif	
