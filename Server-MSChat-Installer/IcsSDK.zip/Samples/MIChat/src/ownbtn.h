//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICOWNBTN__
#define __ICOWNBTN__

#include "icinc.h"

// A simple button with a special font
class CFontButton:public CChatChildWnd
{
// Interfaces
public:
	CFontButton(void);
	~CFontButton(void);
	BOOL			FCreate(HWND hWndParent,int idCtl,RECT *prc,BOOL fDefault);
protected:
	virtual void	GetFont(HFONT hFont)	{ return; }
//	Data
protected:
	HFONT			m_hFont;
};

// A simple button that is drawn with non-default light font
class CLiteFontButton:public CFontButton
{
// Interfaces
protected:
	virtual void	GetFont(HFONT hFont);			
};

// A simple button that is drawn with non-default heavy font
class CHeavyFontButton : public CFontButton
{
// Interfaces
protected:
	virtual void	GetFont(HFONT hFont);			
};

// A color button. It displays a current color on its face, and when clicked, pops up 
// a choose color dialog
// NOTE: this assumes that the button already exists.. example in a dialog
class CColorButton
{
	friend LRESULT CALLBACK ColorButtonProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CColorButton(void);
	~CColorButton(void);
	BOOL			FInit(HWND hDlg, int idBtn);
	void			SetColor(COLORREF cRef);
	COLORREF		ColorRef(void)	{ return m_cRef; }
	HBRUSH			HBrush(void)	{ return m_hBrush; }
	BOOL			FCreateBrush(COLORREF cRef);
	BOOL			FDrawButton(LPARAM lParam, BOOL fMouse);
	BOOL			FDoPopUp(void);

	LRESULT			LCallWindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
//	Data
protected:
	WNDPROC			m_wndProc;		// cause we subclass the original button
	HWND			m_hWnd;
	COLORREF		m_cRef;
	RECT			m_rc;
	HBRUSH			m_hBrush;
	HBRUSH			m_hBlack;
	BOOL			m_fButton;
};

#endif
