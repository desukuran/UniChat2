//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icinc.h"
#include "icref.h"

CRefCount::CRefCount(void)
{
	m_lRef = 1;
}

CRefCount::~CRefCount(void)
{
	AssertSz(m_lRef == 0,"Not all objects released");
}

void CRefCount::AddRef(void)
{
	LONG lRef = ::InterlockedIncrement(&m_lRef);
	// We have a bug if somebody is trying to increment the ref count FROM ZERO or lower..
	// NOTE: the constructor sets the ref count to 1
	AssertSz(lRef > 0,"Stop calling AddRef()!");
}

void CRefCount::Release(void)
{
	LONG lRef = ::InterlockedDecrement(&m_lRef);
	if (0 == lRef)
	{
		Free();
	}
	// We have a bug if the Ref count goes BELOW Zero
	AssertSz(lRef >= 0,"Too many calls to Release()");
}
