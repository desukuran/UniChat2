//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icbitmap.h"

#define OBM_CHECK           32760

void Delete(HBITMAP hbmp)
{
	if (hbmp)
	{
		::DeleteObject((HBITMAP)hbmp);
	}
}

LONG		CChatBitmaps::m_lRef		= 0;	// no usage = count == 0
HBITMAP		CChatBitmaps::m_hbmpHost	= NULL;	// host 	
HBITMAP		CChatBitmaps::m_hbmpPart	= NULL;	// participant
HBITMAP		CChatBitmaps::m_hbmpSpec	= NULL;	// spectator	
HBITMAP		CChatBitmaps::m_hbmpMem		= NULL;	// member
HBITMAP		CChatBitmaps::m_hbmpWorld	= NULL; // chat universe
HBITMAP		CChatBitmaps::m_hbmpChat	= NULL; // single chat
HBITMAP		CChatBitmaps::m_hbmpFolder	= NULL; // folder
HBITMAP		CChatBitmaps::m_hbmpChatPriv = NULL; // private chat
CS_LOCK		CChatBitmaps::m_csBitmap;

CChatBitmaps::~CChatBitmaps(void)
{	
	m_csBitmap.Lock();	// ::EnterCriticalSection
	
	--m_lRef;
	if (0 == m_lRef)
	{
		// No more users of this object. Clean up
		::Delete((HBITMAP)m_hbmpHost);		m_hbmpHost = NULL;
		::Delete((HBITMAP)m_hbmpPart);		m_hbmpPart = NULL;
		::Delete((HBITMAP)m_hbmpSpec);		m_hbmpSpec = NULL;
		::Delete((HBITMAP)m_hbmpMem);		m_hbmpMem = NULL;
		::Delete((HBITMAP)m_hbmpWorld);		m_hbmpWorld = NULL;
		::Delete((HBITMAP)m_hbmpChat);		m_hbmpChat = NULL;
		::Delete((HBITMAP)m_hbmpFolder);	m_hbmpFolder = NULL;
		::Delete((HBITMAP)m_hbmpChatPriv);	m_hbmpChatPriv = NULL;
	}

	m_csBitmap.Unlock();	// ::LeaveCriticalSection
}

BOOL CChatBitmaps::FLoad(HINSTANCE hInst)
{
	Assert(hInst);

	BOOL	fRet = FALSE;

	m_csBitmap.Lock();
	// Up the ref count
	m_lRef++;
	if (1 == m_lRef)
	{
		// First user. Load bitmaps
		Assert(!m_hbmpHost && !m_hbmpSpec && !m_hbmpPart && !m_hbmpMem);
		
		m_hbmpHost		= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_HOST));
		m_hbmpPart		= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_PARTICIPANT));
		m_hbmpSpec		= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_SPECTATOR));
		m_hbmpMem		= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_MEMBER));
		m_hbmpWorld		= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_WORLD));
		m_hbmpChat		= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_CHAT));
		m_hbmpFolder	= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_FOLDER));
		m_hbmpChatPriv	= ::LoadBitmap(hInst, MAKEINTRESOURCE(IDB_CHATPRIV));
		if (	NULL == m_hbmpHost 
			|| 	NULL == m_hbmpPart 
			|| 	NULL == m_hbmpSpec
			||	NULL == m_hbmpMem
			||	NULL == m_hbmpWorld
			||	NULL == m_hbmpChat
			||	NULL == m_hbmpFolder
			||	NULL == m_hbmpChatPriv)
		{
			AssertGLE(FALSE);
			goto LReturn;
		}
	}
	fRet = TRUE;

LReturn:
	m_csBitmap.Unlock();

	return fRet;
}

BOOL CChatBitmaps::FDrawModeBitmap(HDC hDC, RECT* prc, PICS_MEMBER picsMem)
{
	Assert(hDC);
	Assert(prc);
	
	HBITMAP hbmp = NULL;
	
	if (NOERROR == picsMem->HrIsMemberHost())
	{
		hbmp = m_hbmpHost;
	}
	else if (NOERROR == picsMem->HrIsMemberSpeaker())
	{
		hbmp = m_hbmpPart;	// participant
	}
	else 
	{
		hbmp = m_hbmpSpec;	// spectator
	}

	if (NULL == hbmp)
	{
		Assert(FALSE);
		return FALSE;
	}
	return FDrawBitmap(hDC, prc, hbmp);
}

// protected
BOOL CChatBitmaps::FDrawBitmap(HDC hDC, RECT* prc, HBITMAP hbmp)
{
	Assert(hDC && prc && hbmp);

	BOOL		fRet = FALSE;
	
	HBITMAP hbmpOld = NULL;
	// Create a compatible bitmap for bitblt
	HDC hdcBitmap = ::CreateCompatibleDC(hDC);
	if (NULL == hdcBitmap)
	{
		AssertGLE(FALSE);
		goto LReturn;
	}
	// Select the bitmap into the bitmap device context.
	hbmpOld = (HBITMAP)::SelectObject(hdcBitmap, hbmp);
	if (!::BitBlt(hDC, prc->left, prc->top, prc->right - prc->left, prc->bottom - prc->top, 
				hdcBitmap,  0,  0,  SRCCOPY))
	{
		AssertGLE(FALSE);
		goto LReturn;
	}
	fRet = TRUE;

LReturn:
	if (hdcBitmap)
	{
		::SelectObject(hdcBitmap,  hbmpOld);
		::DeleteDC(hdcBitmap);
	}
	return fRet;
}
