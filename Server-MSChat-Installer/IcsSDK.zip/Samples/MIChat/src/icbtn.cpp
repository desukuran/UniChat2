//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icbtn.h"
#include "icuser.h"
#include "icmain.h"

#define DXBTNEXTRA 		30	// plus size of Send text
#define DYBTNEXTRA		4
#define DLEFTBTNGAP		3	// gap between button and its horizontal sides
#define DRIGHTBTNGAP	4

// Button Window Pane
CChatBtnPane::CChatBtnPane(void)
		:CChatPane()
{
}

CChatBtnPane::~CChatBtnPane(void)
{
}

BOOL CChatBtnPane::FInitElements(void)
{
	RECT	rc, rcBtn;
	// Override with out member proc
	SetWindowProc(BtnWndProc);
	// Create a Send Button. Initially, with a width == to the pane
	if (!FGetClientRect(&rc))
	{
		return FALSE;
	}

	if (!m_clfb.FCreate(m_hWnd, IDC_SEND, &rc, TRUE))
	{
		return FALSE;
	}
	// Set the window text
	if (!m_clfb.FSetWindowName(IDS_SENDBTN))
	{
		return FALSE;
	}
	// Create a whisper button
	if (!m_clfbWhisper.FCreate(m_hWnd, IDC_WHISPER, &rc, TRUE))
	{
		return FALSE;
	}
	// Set the window text
	if (!m_clfbWhisper.FSetWindowName(IDS_WHISPERBTN))
	{
		return FALSE;
	}
	// Now determine which button has a wider text extent. Then make both the same
	// size == that of the wider one
	SIZE	size1, size2;

	if (!m_clfb.FGetTextExtent(IDS_SENDBTN, &size1))
	{
		return FALSE;
	}
	if (!m_clfbWhisper.FGetTextExtent(IDS_WHISPERBTN, &size2))
	{
		return FALSE;
	}
	m_sizeExtent = (size2.cx > size1.cx) ? size2 : size1;
	m_sizeExtent.cy	+= DYBTNEXTRA;
	m_sizeExtent.cx	+= DXBTNEXTRA;
	// Set Button Pane to have a width == the Send Button.
	// Also center the button.
	if (!FGetClientRect(&rc))
	{
		return FALSE;
	}
	::CopyMemory(&rcBtn, &rc, sizeof(RECT));
	if (!FGetSendBtnRect(&rcBtn))
	{
		return FALSE;
	}
	if (!m_clfb.FMoveWindow(&rcBtn))
	{
		return FALSE;
	}

	::CopyMemory(&rcBtn, &rc, sizeof(RECT));
	if (!FGetWhisperBtnRect(&rcBtn))
	{
		return FALSE;
	}
	if (!m_clfbWhisper.FMoveWindow(&rcBtn))
	{
		return FALSE;
	}
	// Map our coordinates to the parent windows.. and then move ourselves also
	// Make the pane a bit larger than the button on it.
	rc.right	= DLEFTBTNGAP + DRIGHTBTNGAP + (rcBtn.right - rcBtn.left);
	rc.bottom	= (rcBtn.bottom - rcBtn.top);

	::MapWindowPoints(m_hWnd, m_hWndParent, (LPPOINT)&rc, 2);

	return FMoveWindow(&rc);
}

BOOL CChatBtnPane::FHandleWMSize(WPARAM wParam, LPARAM lParam)
{		
	// The mother pane got moved. Now we gotta move the babies
	RECT	rc;
	
	// Have to reposition the button 
	rc.top		= 0;
	rc.left		= 0;
	rc.right	= LOWORD(lParam);
	rc.bottom	= HIWORD(lParam);
	if (!FGetSendBtnRect(&rc))
	{
		return FALSE;
	}

	if (!m_clfb.FMoveWindow(&rc) /*|| !m_clfb.FRedrawWindow() */)
	{
		return FALSE;
	}
	
	rc.top		= 0;
	rc.left		= 0;
	rc.right	= LOWORD(lParam);
	rc.bottom	= HIWORD(lParam);
	if (!FGetWhisperBtnRect(&rc))
	{
		return FALSE;
	}

	if (!m_clfbWhisper.FMoveWindow(&rc) /*|| !m_clfbWhisper.FRedrawWindow() */)
	{
		return FALSE;
	}
	
	return FRedrawWindow();
}

BOOL CChatBtnPane::FGetSendBtnRect(RECT *prc)
{
	Assert(prc);
	//
	// Figure out how much space the text would really occupy
	// NOW, SINCE THE WHISPER button is bigger, we'll use that!
	//
	prc->left	= DLEFTBTNGAP + ((prc->right - prc->left) - m_sizeExtent.cx)/2;
	prc->right	= prc->left + m_sizeExtent.cx - DRIGHTBTNGAP;
	prc->top	= ((prc->bottom - prc->top)/2) - (m_sizeExtent.cy + 4);
	prc->bottom	= prc->top  + m_sizeExtent.cy + 2;

	return TRUE;
}

BOOL CChatBtnPane::FGetWhisperBtnRect(RECT *prc)
{
	Assert(prc);

	prc->left	= DLEFTBTNGAP + ((prc->right - prc->left) - m_sizeExtent.cx)/2;
	prc->right	= prc->left + m_sizeExtent.cx - DRIGHTBTNGAP;
	prc->top	= ((prc->bottom - prc->top)/2) + 2;
	prc->bottom	= prc->top  + m_sizeExtent.cy + 2;

	return TRUE;
}

BOOL CChatBtnPane::FEnableSendButton(BOOL fEnable)
{
	return m_clfb.FEnableWindow(fEnable);
}	
						
BOOL CChatBtnPane::FEnableWhisperButton(BOOL fEnable)
{
	return m_clfbWhisper.FEnableWindow(fEnable && FIsMicSocket());
}

BOOL CChatBtnPane::FEnableButtons(BOOL fEnable)
{
	FEnableSendButton(fEnable);
	FEnableWhisperButton(fEnable);	

	return TRUE;
}

LRESULT CALLBACK BtnWndProc(HWND hWnd, UINT	uMsg, WPARAM wParam, LPARAM	lParam)
{
	
	CChatBtnPane* pcbp = (CChatBtnPane*)::GetWindowLong(hWnd, GWL_USERDATA);
	
	if (pcbp)
	{
		switch(uMsg)
		{
		default:
			break;
		
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			default:
				break;

			case IDC_SEND:
			case IDC_WHISPER:
				Assert(pcbp);
				return pcbp->FGiveMsgToParent(uMsg, wParam, lParam);		
			}
		}
		return pcbp->LrCallWindowProc(uMsg, wParam, lParam);
	}

	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}

