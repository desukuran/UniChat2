//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icmain.h"
#include "icchan.h"
#include "icwizard.h"
#include "icprop.h"

//--------------------------------------------------------------------------------------------
static BOOL FGetPcc(HWND hDlg, UINT uMsg, LPARAM lParam, CCreateChannel **ppcc);

BOOL CALLBACK ChannelNameDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ChannelClashDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ChannelTypeDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ChannelAdvancedDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK JoinChannelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ChangeTopicDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

////////////////////////////////////////////////////////////////////////////////////////////
CCreateChannel::CCreateChannel(void)
	: CChatPropertyPage()
{
	m_szName[0]		= '\0';
	m_szTopic[0]	= '\0';
	m_szPass[0]		= '\0';
	m_dwType		= CS_CHANNEL_PUBLIC;
	m_dwFlags		= CS_CHANNEL_FLAG_MICONLY;
	m_bCreateFlags	= CS_CHANNEL_CREATE_JOIN;
	m_fFinish		= FALSE;
	m_fProp			= FALSE;
	m_fIsHost		= TRUE;
	m_fIsMicSocket	= FIsMicSocket();
	m_dwcUser		= 0;
}

CCreateChannel::~CCreateChannel(void)
{
}

BOOL CCreateChannel::FCreateChannelDlg(HWND hWndParent)
{
	Assert(hWndParent);
	
	m_dwType = CS_CHANNEL_PUBLIC;
	// Init the property sheet. 3 Pages
	if (	!FInit(hWndParent, 3, PSH_NOAPPLYNOW, IDS_CREATECHANNELDLG)
		||	!FAddPage(IDD_CHANNELNAME, ChannelNameDlgProc, (LPARAM)this)
		||	!FAddPage(IDD_CHANNELTYPE, ChannelTypeDlgProc, (LPARAM)this)
		||	!FAddPage(IDD_CHANNELADVANCED, ChannelAdvancedDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Display and do the Wizard. Note, this will return ONLY when the Wizard is DONE
	return FShow();
}

BOOL CCreateChannel::FJoinChannelDlg(HWND hWndParent)
{
	Assert(hWndParent);
	// Init the Dialog. 1 page for now
	m_dwType = 0;
	if (	!FInit(hWndParent, 1, PSH_NOAPPLYNOW, IDS_JOINCHANNELDLG)
		||	!FAddPage(IDD_JOINCHANNEL, JoinChannelDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Display and do the dialog. Note, this will return ONLY when the Wizard is DONE
	return FShow();
}

BOOL CCreateChannel::FChannelPropertyDlg(HWND hWndParent, PICS_CHANNEL pChannel)
{
	Assert(hWndParent && pChannel);

	if (	FAILED(pChannel->HrGetType(&m_dwType))
		||	FAILED(pChannel->HrGetType(&m_dwFlags))
		||	FAILED(pChannel->HrGetUserCount(&m_dwcUser)))
	{
		return FALSE;
	}
	m_fProp = TRUE;

	PICS_MEMBER pMem;

	if (FAILED(pChannel->HrGetMe(&pMem)))
	{
		return FALSE;
	}
	
	m_fIsHost = (NOERROR == pMem->HrIsMemberHost());
	pMem->Release();
	// Init the property sheet. 2 Pages
	if (	!FInit(hWndParent, 2, PSH_NOAPPLYNOW, IDS_CHANNELPROPSDLG)
		||	!FAddPage(IDD_CHANNELTYPE, ChannelTypeDlgProc, (LPARAM)this)
		||	!FAddPage(IDD_CHANNELADVANCED, ChannelAdvancedDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Display and do the Wizard. Note, this will return ONLY when the Wizard is DONE
	if (FShow() && m_fIsHost)
	{
		// If the user clicked OK, update type only if they are hosts
		return TRUE;
	}
	return FALSE;
}

BOOL CCreateChannel::FInitChannelNameDlg(HWND hDlg)
{
	Assert(hDlg);
	// Its ok for centering to fail
	FCenter(hDlg);
	// Hide checkbox for IRC
	if (!m_fIsMicSocket)
	{
		FShowControl(hDlg, IDC_CHECKIRC, FALSE);
		// This will give us IRC verification
		::CheckDlgButton(hDlg, IDC_CHECKIRC, BST_CHECKED);
	}
	// Limit text and so forth
	if (!FSetMicOnly(hDlg))
	{
		return FALSE;
	}
	return FEditBoxLimitText(hDlg, IDC_EDITCHANNELTOPIC, CS_CCHMAX_MIC_TOPIC);
}

BOOL CCreateChannel::FSetMicOnly(HWND hDlg)
{
	BOOL fMicOnly = (0 == IsDlgButtonChecked(hDlg, IDC_CHECKIRC));

	Assert(hDlg);
	// Limit text and so forth
	FEditBoxLimitText(hDlg, IDC_EDITCHANNELNAME, 
					fMicOnly ? CS_CCHMAX_MIC_CHANNEL : CS_CCHMAX_IRC_CHANNEL);
	// Get whatever is already in there and append a # sign on it.. if IRC

	if (!fMicOnly)
	{
		TCHAR szTemp[256];
		TCHAR* sz = &szTemp[1];
		::GetWindowText(HWndGetDlgItem(hDlg, IDC_EDITCHANNELNAME), sz, 255);
		if ('#' == *sz || '@' == *sz)
		{
			return TRUE;
		}
		// Prepend a #..
		szTemp[0] = '#';
		::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITCHANNELNAME), szTemp);
	}
	
	return TRUE;
}

BOOL CCreateChannel::FGetChannelNameParams(HWND hDlg)
{
	BOOL		fMicOnly;
	BOOL		fLocal;
	HRESULT		hr;
	// Get the user name
	if (!FGetText(hDlg, IDC_EDITCHANNELNAME, IDS_ERR_NOCHANNELNAME, (TCHAR*)&m_szName, 
				CS_CCHMAX_IRC_CHANNEL + 1))
	{
		goto LError;
	}
	// Get the MIC only check box
	fMicOnly = (0 == IsDlgButtonChecked(hDlg, IDC_CHECKIRC));
	fLocal = (fMicOnly) ? FALSE : ('&' == *m_szName);
	// verify the name
	hr = ::HrVerifyCreateChannelNameA(m_szName, fMicOnly, fLocal);
	if (FAILED(hr))
	{
		// FIX ME - for MIC ONLY CHAT
		::FHandleChatSockErrors(hDlg, hr);
		goto LError;
	}
	
	if (fMicOnly)
	{
		m_dwFlags |= CS_CHANNEL_FLAG_MICONLY;
	}
	else
	{
		m_dwFlags &= ~CS_CHANNEL_FLAG_MICONLY;
	}
	if (fLocal)
	{
		m_dwFlags |= CS_CHANNEL_FLAG_LOCAL;
	}
	else
	{
		m_dwFlags &= ~CS_CHANNEL_FLAG_LOCAL;
	}
	// Get the topic name
	if (!FGetText(hDlg, IDC_EDITCHANNELTOPIC, -1, (TCHAR *)&m_szTopic, CS_CCHMAX_MIC_TOPIC + 1))
	{
		goto LError;
	}

	return TRUE;

LError:
	FSelectPage(hDlg, 0);
	return FALSE;
}

BOOL CCreateChannel::FNotifyChannelName(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, FALSE);
		break;

	case PSN_APPLY:
		::SetWindowLong(hDlg, DWL_MSGRESULT, 
						FGetChannelNameParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		break;
	}

	return fRet;
}

BOOL CCreateChannel::FInitChannelTypeDlg(HWND hDlg)
{
	Assert(hDlg);
	
	if (m_fProp)
	{
		::SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLCHANNELTYPE), GetSz(HInstance(hDlg), IDS_THISCHAT));
	}
	// Pick MIC by default
	if (m_dwType & CS_CHANNEL_PROTECTED)
	{
		::CheckDlgButton(hDlg, IDC_RADIOPROTECTED, BST_CHECKED);
	}
	else if (m_dwType & CS_CHANNEL_PRIVATE)
	{
		::CheckDlgButton(hDlg, IDC_RADIOPRIVATE, BST_CHECKED);
	}
	else
	{
		::CheckDlgButton(hDlg, IDC_RADIOPUBLIC, BST_CHECKED);
	}
	
	if (m_fProp)
	{
		TCHAR szBuf[256];
		
		::wsprintf(szBuf, GetSz(HInstGet(), IDS_CURUSERCOUNT), m_dwcUser);
		SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLCURRENTCOUNT), szBuf);
		m_dwcUser = 0;
	}
	else
	{
		if (m_dwcUser > 0)
		{
			::CheckDlgButton(hDlg, IDC_CHKLIMITUSER, BST_CHECKED);
			::SetDlgItemInt(hDlg, IDC_EDITMEMLIMIT, (UINT)m_dwcUser, FALSE);
		}
	}
	// Disable everything if we are not hosts
	if (!m_fIsHost)
	{
		FEnableControl(hDlg, IDC_RADIOPUBLIC, FALSE);
		FEnableControl(hDlg, IDC_RADIOPRIVATE, FALSE);
		FEnableControl(hDlg, IDC_RADIOPROTECTED, FALSE);
		FEnableControl(hDlg, IDC_CHKLIMITUSER, FALSE);
		FEnableControl(hDlg, IDC_EDITMEMLIMIT, FALSE);
	}
	// Disable the memlimit edit box till the limit user box is checked
	FEnableControl(hDlg, IDC_EDITMEMLIMIT, ::IsDlgButtonChecked(hDlg, IDC_CHKLIMITUSER));
	
	return TRUE;
}

BOOL CCreateChannel::FGetChannelTypeParams(HWND hDlg)
{
	if (::IsDlgButtonChecked(hDlg, IDC_RADIOPROTECTED))
	{
		m_dwType |= CS_CHANNEL_PROTECTED;
		m_dwType &= ~(CS_CHANNEL_PRIVATE | CS_CHANNEL_PUBLIC);
	}
	else if (::IsDlgButtonChecked(hDlg, IDC_RADIOPRIVATE))
	{
		m_dwType |= CS_CHANNEL_PRIVATE;
		m_dwType &= ~(CS_CHANNEL_PROTECTED | CS_CHANNEL_PUBLIC);
	}
	else
	{
		m_dwType |= CS_CHANNEL_PUBLIC;
		m_dwType &= ~(CS_CHANNEL_PROTECTED | CS_CHANNEL_PRIVATE);
	}
	
	BOOL fTranslate;

	if (::IsDlgButtonChecked(hDlg, IDC_CHKLIMITUSER))
	{
		int iRet = (int)::GetDlgItemInt(hDlg, IDC_EDITMEMLIMIT, &fTranslate, TRUE);
		if (iRet <= 0)
		{
			FDoErrorAndSetFocus(hDlg, IDC_EDITMEMLIMIT, IDS_ERR_NOLIMIT);
			FSelectPage(hDlg, 1);
			return FALSE;
		}
		m_dwcUser = (DWORD)iRet;
	}
	else
	{
		m_dwcUser = 0;
	}
	return TRUE;
}

BOOL CCreateChannel::FNotifyChannelType(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, FALSE);
		break;

	case PSN_APPLY:
		::SetWindowLong(hDlg, DWL_MSGRESULT,
						FGetChannelTypeParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		break;
	}

	return fRet;
}

BOOL CCreateChannel::FInitChannelAdvancedDlg(HWND hDlg)
{
	Assert(hDlg);
	
	if (m_fIsMicSocket)
	{
		if (m_dwFlags & CS_CHANNEL_FLAG_AUTHONLY)
		{
			::CheckDlgButton(hDlg, IDC_CHKAUTHENTICATE, BST_CHECKED);
		}
		if (m_fProp)
		{
			FEnableControl(hDlg, IDC_CHKAUTHENTICATE, FALSE);
		}

		if (m_dwType & CS_CHANNEL_REALNAME)
		{
			::CheckDlgButton(hDlg, IDC_CHKREALNAME, BST_CHECKED);
		}

		if (m_dwType & CS_CHANNEL_NOWHISPER)
		{
			::CheckDlgButton(hDlg, IDC_CHKWHISPER, BST_CHECKED);
		}
	}
	else
	{
		FEnableControl(hDlg, IDC_CHKAUTHENTICATE, FALSE);
		FEnableControl(hDlg, IDC_CHKREALNAME, FALSE);
		FEnableControl(hDlg, IDC_CHKWHISPER, FALSE);
	}
	if (m_dwType & CS_CHANNEL_INVITELIST)
	{
		::CheckDlgButton(hDlg, IDC_CHKINVITEONLY, BST_CHECKED);
	}
	if (m_dwType & CS_CHANNEL_TOPICOP)
	{
		::CheckDlgButton(hDlg, IDC_CHKTOPICOP, BST_CHECKED);
	}
	if (m_dwType & CS_CHANNEL_MODERATED)
	{
		::CheckDlgButton(hDlg, IDC_CHKMODERATED, BST_CHECKED);
	}
	if (!m_fProp)
	{
		FGetText(hDlg, IDC_EDITCHANPASS, -1, (TCHAR *)&m_szPass, CS_CCHMAX_CHANNEL_PASS + 1);
	}
	if (m_fProp)
	{
		FShowControl(hDlg, IDC_EDITCHANPASS, FALSE);
		FShowControl(hDlg, IDC_LBLPASS, FALSE);
	}
	else
	{
		FEditBoxLimitText(hDlg, IDC_EDITCHANPASS, CS_CCHMAX_CHANNEL_PASS);
	}
	// Disable everything if we are not hosts
	if (!m_fIsHost)
	{
		FEnableControl(hDlg, IDC_CHKAUTHENTICATE, FALSE);
		FEnableControl(hDlg, IDC_CHKREALNAME, FALSE);
		FEnableControl(hDlg, IDC_CHKWHISPER, FALSE);
		FEnableControl(hDlg, IDC_CHKINVITEONLY, FALSE);
		FEnableControl(hDlg, IDC_CHKTOPICOP, FALSE);
		FEnableControl(hDlg, IDC_CHKMODERATED, FALSE);
	}
	return TRUE;
}

BOOL CCreateChannel::FNotifyChannelAdvanced(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, FALSE);
		break;

	case PSN_APPLY:
		::SetWindowLong(hDlg, DWL_MSGRESULT, 
						FGetChannelAdvancedParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		break;
	}
	return fRet;
}

BOOL CCreateChannel::FGetChannelAdvancedParams(HWND hDlg)
{
	if (IsDlgButtonChecked(hDlg, IDC_CHKAUTHENTICATE))
		m_dwFlags |= CS_CHANNEL_FLAG_AUTHONLY;
	else
		m_dwFlags &= ~CS_CHANNEL_FLAG_AUTHONLY;

	if (IsDlgButtonChecked(hDlg, IDC_CHKINVITEONLY))
		m_dwType |= CS_CHANNEL_INVITELIST;
	else
		m_dwType &= ~CS_CHANNEL_INVITELIST;

	if (IsDlgButtonChecked(hDlg, IDC_CHKREALNAME))
		m_dwType |= CS_CHANNEL_REALNAME;
	else
		m_dwType &= ~CS_CHANNEL_REALNAME;

	if (IsDlgButtonChecked(hDlg, IDC_CHKWHISPER))
		m_dwType |= CS_CHANNEL_NOWHISPER;
	else
		m_dwType &= ~CS_CHANNEL_NOWHISPER;

	if (IsDlgButtonChecked(hDlg, IDC_CHKTOPICOP))
		m_dwType |= CS_CHANNEL_TOPICOP;
	else
		m_dwType &= ~CS_CHANNEL_TOPICOP;

	if (IsDlgButtonChecked(hDlg, IDC_CHKMODERATED))
		m_dwType |= CS_CHANNEL_MODERATED;
	else
		m_dwType &= ~CS_CHANNEL_MODERATED;
	
	if (!m_fProp)
		FGetText(hDlg, IDC_EDITCHANPASS, -1, (TCHAR*)&m_szPass, CS_CCHMAX_CHANNEL_PASS + 1);

	return TRUE;
}

BOOL CCreateChannel::FInitJoinChannelDlg(HWND hDlg)
{
	Assert(hDlg);
	// Its ok for centering to fail
	FCenter(hDlg);
	// Limit text and so forth
	if (!FEditBoxLimitText(hDlg, IDC_EDITCHANNELNAME, CS_CCHMAX_MIC_CHANNEL))
	{
		return FALSE;
	}
	return FEditBoxLimitText(hDlg, IDC_EDITPASSWORD, CS_CCHMAX_CHANNEL_PASS);
}

BOOL CCreateChannel::FGetJoinChannelParams(HWND hDlg)
{
	// Get the user name
	if (!FGetText(hDlg, IDC_EDITCHANNELNAME, IDS_ERR_NOCHANNELNAME, (TCHAR*)&m_szName, 
				CS_CCHMAX_MIC_CHANNEL + 1))
	{
		goto LError;
	}
	// Get the topic name
	if (!FGetText(hDlg, IDC_EDITPASSWORD, -1, (TCHAR *)&m_szPass, CS_CCHMAX_CHANNEL_PASS + 1))
	{
		goto LError;
	}

	return TRUE;

LError:
	return FALSE;
}

BOOL CCreateChannel::FNotifyJoinChannel(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, FALSE);
		break;

	case PSN_APPLY:
		::SetWindowLong(hDlg, DWL_MSGRESULT, 
						FGetJoinChannelParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
	}

	return fRet;
}

////////////////////////////////////////////////////////////////////////////////////////////
static BOOL FGetPcc(HWND hDlg, UINT uMsg, LPARAM lParam, CCreateChannel** ppcc)
{
	Assert(ppcc);

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE*	ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		*ppcc = (CCreateChannel*)ppsp->lParam; 
		SetWindowLong(hDlg, DWL_USER, (LONG)*ppcc);
	}
	else
	{
		*ppcc = (CCreateChannel*)::GetWindowLong(hDlg, DWL_USER);
	}

	return (NULL != *ppcc);
}

////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK ChannelNameDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CCreateChannel*		pcl;
	BOOL				fRet;

	if (!FGetPcc(hDlg, uMsg, lParam, &pcl))
	{
		return FALSE;
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcl->FInitChannelNameDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcl->FNotifyChannelName(hDlg, lParam);
		break;

	case WM_COMMAND:
		
		switch (LOWORD(wParam))
		{
		default:
			break;

		case IDC_CHECKIRC:
			pcl->FSetMicOnly(hDlg);
			break;

		case ID_SETFOCUS:
			pcl->SetFocus(hDlg, (int) lParam);
			break;
		}
		break;
	}  
	
	return fRet;
} 

////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK ChannelTypeDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CCreateChannel*		pcl;
	BOOL				fRet;

	if (!FGetPcc(hDlg, uMsg, lParam, &pcl))
	{
		return FALSE;
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcl->FInitChannelTypeDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcl->FNotifyChannelType(hDlg, lParam);
		break;

	case WM_COMMAND:
		
		switch (LOWORD(wParam))
		{
		default:
			break;
			
		case IDC_CHKLIMITUSER:
			FEnableControl(hDlg, IDC_EDITMEMLIMIT, ::IsDlgButtonChecked(hDlg, IDC_CHKLIMITUSER));
			break;

		case ID_SETFOCUS:
			pcl->SetFocus(hDlg, (int) lParam);
			break;
		}
		break;
	}  
	
	return fRet;
} 

////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK ChannelAdvancedDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CCreateChannel*		pcl;
	BOOL				fRet;

	if (!FGetPcc(hDlg, uMsg, lParam, &pcl))
	{
		return FALSE;
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:	
		fRet = !pcl->FInitChannelAdvancedDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcl->FNotifyChannelAdvanced(hDlg, lParam);
		break;

	case WM_COMMAND:
		if (ID_SETFOCUS == LOWORD(wParam))
		{
			pcl->SetFocus(hDlg, (int) lParam);
		}
		break;
	}  
	
	return fRet;
} 

////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK JoinChannelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CCreateChannel*		pcl;
	BOOL				fRet;

	if (!FGetPcc(hDlg, uMsg, lParam, &pcl))
	{
		return FALSE;
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcl->FInitJoinChannelDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcl->FNotifyJoinChannel(hDlg, lParam);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case ID_SETFOCUS:
			pcl->SetFocus(hDlg, (int) lParam);
			break;

		case ID_FINISHWIZ:
			pcl->m_fFinish = TRUE;
			pcl->PressWizButton(hDlg, PSBTN_OK);
			break;

		case ID_CANCELWIZ:
			// Put up an alert
			HRESULT	hr;

			hr = (HRESULT) lParam;

			if (!FHandleChatSockErrors(hDlg, hr))
			{
				pcl->PressWizButton(hDlg, PSBTN_CANCEL);
			}
			break;
		}
		fRet = TRUE;
		break;
	}  
	return fRet;
} 

////////////////////////////////////////////////////////////////////////////////////////////
// TOPIC DIALOGS
BOOL FSetTopic(HWND hWndParent, PICS_CHANNEL pChannel)
{	
	Assert(pChannel);

	BYTE*	pbTopic;
	BOOL	fAnsi;
	TCHAR	szTopic[256];
	TCHAR*	pszTopic = NULL;
	CChangeTopic*	pcct;

	if (FAILED(pChannel->HrGetTopic(&pbTopic, &fAnsi)))
	{
		AssertSz(0, "HrGetName");
		return FALSE;
	}

#ifndef UNICODE
	if (fAnsi)
	{
		pszTopic = (TCHAR*)pbTopic;
	}
	else 
	{
		if (!FWideCharToAnsi((WCHAR*)pbTopic, (TCHAR*)&szTopic, 256))
		{
			AssertSz(0, "FWideCharToAnsi");
			return FALSE;
		}
		pszTopic = (TCHAR*)&szTopic;
	}
	// Do the dialog
	pcct = new CChangeTopic;
	if (!pcct)
	{
		AssertGLE(FALSE);
		DoOOM();
		return FALSE;
	}
	
	BOOL	fRet = FALSE;

	SetDisableAll(TRUE);
	fRet = pcct->FChangeTopicDlg(hWndParent, pszTopic);
	SetDisableAll(FALSE);

	if (fRet)
	{
		fRet = (SUCCEEDED(pChannel->HrSetTopicA(pcct->PszTopic())));
	}
	
	pcct->Release();
#else
	AssertSz(0, "No UNICODE code");
#endif
	return fRet;
}

////////////////////////////////////////////////////////////////////////////////////////////
CChangeTopic::CChangeTopic(void)
	: CChatWizard()
{
	m_szTopic[0]	= '\0';
}

CChangeTopic::~CChangeTopic(void)
{
}

BOOL CChangeTopic::FChangeTopicDlg(HWND hWndParent, TCHAR* psz)
{
	Assert(hWndParent && psz);
	// Copy the current topic
	::lstrcpy(m_szTopic, psz);
	// Init the Wizard. 1 page for now
	if (!FInit(hWndParent, 1))
	{
		return FALSE;
	}
	// Add Wizard pages
	if (!FAddPage(IDD_CHANGETOPIC, ChangeTopicDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Display and do the Wizard. Note, this will return ONLY when the Wizard is DONE
	return FShow();
}

BOOL CChangeTopic::FInitChangeTopicDlg(HWND hDlg)
{
	Assert(hDlg);
	// Its ok for centering to fail
	FCenter(hDlg);
	// Limit text and so forth
	if (!FEditBoxLimitText(hDlg, IDC_EDITNEWTOPIC, CS_CCHMAX_MIC_TOPIC))
	{
		return FALSE;
	}
	// Set the previous topic
	return  ::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITOLDTOPIC), (TCHAR*)&m_szTopic);
}

BOOL CChangeTopic::FGetTopicParams(HWND hDlg)
{
	// Get the topic. Empty topic names are ok
	return FGetText(hDlg, IDC_EDITNEWTOPIC, -1, (TCHAR*)&m_szTopic, CS_CCHMAX_MIC_TOPIC + 1);
}

BOOL CChangeTopic::FNotifyChangeTopic(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR*	pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_WIZFINISH:
		FGetTopicParams(hDlg);
		break;

	case PSN_SETACTIVE:
		SetFinishText(hDlg, IDS_OK);
		break;
	}

	return fRet;
}

////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK ChangeTopicDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CChangeTopic*	pct;
	BOOL			fRet;

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE*	ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		pct = (CChangeTopic*)ppsp->lParam; 
		SetWindowLong(hDlg, DWL_USER, (LONG)pct);
	}
	else
	{
		pct = (CChangeTopic*)GetWindowLong(hDlg, DWL_USER);
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pct->FInitChangeTopicDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pct->FNotifyChangeTopic(hDlg, lParam);
		break;

	case WM_COMMAND:
		if (ID_SETFOCUS == LOWORD(wParam))
		{
			pct->SetFocus(hDlg, (int)lParam);
		}
		break;
	}  
	
	return fRet;
} 

////////////////////////////////////////////////////////////////////////////////////////////
// INVITATIONS TO CHATS
HRESULT HrHandleInvite(HWND hWndParent, PCS_MSGBASE pMsg)
{
	if (FIgnoreInvites())
	{
		return NOERROR;
	}

	CInvite* pci = new CInvite;
	if (!pci)
	{
		AssertGLE(FALSE);
		return E_OUTOFMEMORY;
	}
	PCS_MSGINVITE pInvite = MSGBASE_TO_MSG(pMsg, PCS_MSGINVITE);
	// Do the dialog
	BOOL fRet = pci->FInviteDlg(hWndParent, pInvite->picsInvite);
	if (fRet)
	{
		HRESULT hr = (pInvite->picsInvite)->HrJoinChannel();
		if (FAILED(hr))
		{
			FHandleChatSockErrors(hWndParent, hr);
		}
	}
	pci->Release();
	return NOERROR;
}

////////////////////////////////////////////////////////////////////////////////////////////
CInvite::CInvite(void)
	: CChatWizard()
{
	m_pInvite	= NULL;
}

CInvite::~CInvite(void)
{	
	Destroy();
}

void CInvite::Destroy(void)
{
	if (m_pInvite)
	{
		m_pInvite->Release();
	}
}

BOOL CInvite::FInviteDlg(HWND hWndParent, PICS_INVITATION pInvite)
{
	Assert(hWndParent && pInvite && !m_pInvite && !m_hDlg);
	
	BOOL fRet = FALSE;
	// keep the invitation
	m_pInvite = pInvite;
	m_pInvite->AddRef();
	// Init the Wizard. 1 page for now
	if (!FInit(hWndParent, 1))
	{
		goto LReturn;
	}
	// Add Wizard pages
	if (!FAddPage(IDD_INVITE, InviteDlgProc, (LPARAM)this))
	{
		goto LReturn;
	}
	// Display and do the Wizard. Note, this will return ONLY when the Wizard is DONE
	fRet = FShow();

LReturn:
	return fRet;
}

BOOL CInvite::FInitInviteDlg(HWND hDlg)
{
	Assert(hDlg);

	FCenter(hDlg);
	// Set the channel name and the recipient. If Unicode, then ignore this invite
	BYTE*	pbName;
	BYTE*	pbSender;
	BOOL	fAnsi;

 #ifndef UNICODE
	
	CHAR	szName[256];
	CHAR	szSender[64];
	CHAR*	szChan;
	CHAR*	szFrom;

	if (FAILED(m_pInvite->HrGetChannelName(&pbName, &fAnsi)))
	{
		return FALSE;
	}

	if (fAnsi)
	{
		szChan = (CHAR*)pbName;
	}
	else
	{
		if (!FWideCharToAnsi((WCHAR*)pbName, (TCHAR*)&szName, 256))
		{
			AssertSz(0, "FWideCharToAnsi");
			return FALSE;
		}
		szChan = (TCHAR*)&szName;
	}

	if (FAILED(m_pInvite->HrGetSender(&pbSender, &fAnsi)))
	{
		return FALSE;
	}

	if (fAnsi)
	{
		szFrom = (CHAR*)pbSender;
	}
	else
	{
		if (!FWideCharToAnsi((WCHAR*)pbSender, (TCHAR*)&szSender, 64))
		{
			AssertSz(0, "FWideCharToAnsi");
			return FALSE;
		}
		szFrom = (TCHAR*)&szSender;
	}
	// Set labels
	::SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLCHATNAME), szChan);
	::SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLFROM), szFrom);

#else
	AssertSz(0, "No UNICODE code");
#endif

	return TRUE;
}

BOOL CInvite::FNotifyInvite(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;

	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_WIZFINISH:
		break;

	case PSN_SETACTIVE:
		SetFinishText(hDlg, IDC_JOINCHANNEL);
		break;
	}

	return fRet;
}

BOOL CALLBACK InviteDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CInvite*	pct;
	BOOL		fRet;

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE* ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		pct = (CInvite*)ppsp->lParam; 
		SetWindowLong(hDlg, DWL_USER, (LONG)pct);
	}
	else
	{
		pct = (CInvite*)GetWindowLong(hDlg, DWL_USER);
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pct->FInitInviteDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pct->FNotifyInvite(hDlg, lParam);
		break;

	case WM_COMMAND:
		if (ID_SETFOCUS == LOWORD(wParam))
		{
			pct->SetFocus(hDlg, (int)lParam);
		}
		break;
	}  
	return fRet;
}
