//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICPROP__
#define __ICPROP__

#include "icinc.h"
#include "ichistry.h"
#include "icinst.h"
#include "icwizard.h"
#include "ownbtn.h"

BOOL ParsePropertyData(PCS_MSGBASE pcsMsg, CUIRichEdit *pui, HWND hWndParent);
BOOL FListAllChannels(PICS pics, DWORD dwcUserMin, DWORD dwcUserMax, TCHAR *szFind, BOOL fContains);
BOOL FListAllMembersInChannel(PICS pics, PICS_PROPERTY picsProp, DWORD dwIndex);
BOOL FListAllUsers(PICS pics, TCHAR *szFind);

BOOL FGetLatestPropsChannel(PICS pics, PICS_PROPERTY picsProp, DWORD dwIndex);
BOOL FGetMemberPropsFromBrowser(HWND hWndParent, PICS_PROPERTY picsProp, BOOL fUser);
BOOL FGetRealNameFromBrowser(PICS pics, PICS_PROPERTY picsProp);

BOOL FSetAway(HWND hWndParent, PICS pSock);
BOOL FDoOptionsDlg(HWND hWndParent, PUSEROPTIONS puo);
BOOL FLoadUserOptions(PUSEROPTIONS puserOptions);
BOOL FIgnoreInvites(void);

#ifdef NOTNOW
////////////////////////////////////////////////////////////////////////////////////////
// AWAY PROPERTY
class CSetAway : public CChatWizard
{
friend BOOL CALLBACK SetAwayDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CSetAway(void);
	~CSetAway(void);

	BOOL	FSetAwayDlg(HWND hWndParent, BOOL fAway);

	TCHAR*	PszAway(void)	{ return m_szAway; }
	BOOL	FAway(void)		{ return m_fAway; }

	virtual	void	Free(void)		{ delete this; }
protected:
	BOOL	FInitSetAwayDlg(HWND hDlg);
	BOOL	FNotifySetAway(HWND hDlg, LPARAM lParam);
	BOOL	FGetSetAwayParams(HWND hDlg);
protected:
	TCHAR	m_szAway[CS_CCHMAX_MIC_AWAYMSG + 1];
	BOOL	m_fAway;
};

#endif

////////////////////////////////////////////////////////////////////////////////////////
// MEMBER properties
class CMemberProps : public CChatWizard
{
friend BOOL CALLBACK MemPropsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CMemberProps(int idDlg = IDD_MEMBERPROPS);
	~CMemberProps(void);

	BOOL	FMemberPropDlg(HWND hWndParent, PICS_MEMBER* prgMem, int cMem, PICS_PROPERTY picsProp=NULL);
	BOOL	FSetProps(HWND hDlg);

	virtual	void	Free(void)	{ delete this; }
protected:
	BOOL	FInitMemProps(HWND hDlg);
	BOOL	FInitSingleMemProps(HWND hDlg);
	BOOL	FNotify(HWND hDlg, LPARAM lParam);

protected:
	TCHAR			m_szYes[32];
	TCHAR			m_szNo[32];
	PICS_MEMBER*	m_prgMem;
	PICS_PROPERTY	m_picsProp;
	int				m_cMem;
	int				m_idDlg;
};

////////////////////////////////////////////////////////////////////////////////////////
// Options
class COptionsDlg : public CChatPropertyPage
{
friend BOOL CALLBACK UserOptionsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	COptionsDlg(void);
	~COptionsDlg(void);

	BOOL	FOptionsDlg(HWND hWndParent, PUSEROPTIONS puserOptions);

virtual	void	Free(void) { delete this; }

protected:
	BOOL	FInitOptionsDlg(HWND hDlg);
	BOOL	FNotifyOptions(HWND hDlg, LPARAM lParam);
	BOOL	FGetOptionsParams(HWND hDlg);

protected:
	USEROPTIONS m_userOptions;
	CColorButton m_ccbURL;
	CColorButton m_ccbText;
	CColorButton m_ccbBak;
};

#endif


