//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICINCS__
#define __ICINCS__

#include "icchild.h"
#include "icutil.h"
#include "icuser.h"
#include "resource.h"
#include "ichatmsg.h"

// values that give the status of a particular command
const int CMD_BAD		= 0;
const int CMD_ACTIVE	= 1;	// bit set if active, 0 otherwise
const int CMD_CHECK		= 2;	// bit set if checked, 0 otherwise

const DWORD	CBMAXSEND	= sizeof(TCHAR) * 255;	// limit on the Send buffer

//--------------------------------------------------------------------------------------------
class	CMember;
class	CRefCount;

typedef	CMember		IC_MEMBER;
typedef CRefCount	IC_REFCOUNT;

typedef struct UserOptions
{
	BOOL		fNotifyJoin;	// notify when users join
	BOOL		fNotifyLeave;	// notify when users leave
	BOOL		fAutoSave;
	BOOL		fBlankLine;
	BOOL		fIgnoreInvite;
	COLORREF 	cRefURL;
} USEROPTIONS, *PUSEROPTIONS;

#ifndef _DEBUG
	#define DebugMessageType(a, b)
#else
	void DebugMessageType(LPCSTR title, CSMSG_TYPE c);
#endif

#endif

