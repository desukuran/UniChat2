//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICWIZARD__
#define __ICWIZARD__

#include "icinc.h"
#include "icref.h"

class		CChatPropertyPage;
class		CChatWizard;

typedef CChatPropertyPage	IC_PROPERTY;
typedef	CChatWizard			IC_WIZARD;

//--------------------------------------------------------------------------------------------
class CChatPropertyPage : public CRefCount
{
// Interfaces
public:
	CChatPropertyPage(void);
	~CChatPropertyPage(void);
	BOOL		FInit(HWND hWndParent, UINT cPages, DWORD dwFlags, int idStrTitle, UINT nStartPage=0);
	BOOL		FAddPage(int idDlg, DLGPROC dlgProc, LPARAM lParam);
	BOOL		FShow(void);
	void		Reset(void);
	BOOL		FCenter(HWND hDlg);

	virtual	void	StopDialog(BOOL fCancel, HRESULT hr);
	void		PressWizButton(HWND hDlg, int idBtn);

	BOOL		FSelectPage(HWND hDlg, int index);
protected:
	void		DeleteAllPages(void);

	int			FDoErrorAndSetFocus(HWND hDlg, int idCtl, int idErr);
	BOOL		FGetText(HWND hDlg, int idCtl, int idErr, TCHAR *psz, DWORD cch);

	void		SetFocus(HWND hDlg, int idCtl);
	void		SendSetFocus(HWND hDlg, int idCtl);
// Data
protected:
	PROPSHEETHEADER 	m_psh;

	UINT		m_cPages;
	HINSTANCE	m_hInst;
	HWND		m_hDlg;
};

// Wizards are simply special Property sheets
class CChatWizard : public CChatPropertyPage
{
// Interfaces
public:
	BOOL		FInit(HWND hWndParent, UINT cPages)
					{ return CChatPropertyPage::FInit(hWndParent, cPages, PSH_WIZARD, -1); }
	void		SetWizButtons(HWND hDlg, DWORD dwFlags);
	void		SetFinishText(HWND hDlg, int idStr);
};

#endif


