//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icmemlst.h"
#include "icmain.h"
#include "ichistry.h"
#include "icprop.h"

// List Box pane
CChatListPane::CChatListPane(void)
	: CChatPane()
{
}

CChatListPane::~CChatListPane(void)
{
}

BOOL CChatListPane::FAddMember(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	PCS_MSGMEMBER pMsgMem = (PCS_MSGMEMBER)(pcsMsg + 1);
	Assert(pMsgMem->picsMember);
	// Allocate a new member
	CMember* pMem = NULL;

#ifdef NOTNOW
	pMem = new CMember;
	if (!pMem)
	{
		AssertGLE(FALSE);
		DoOOM();
		return FALSE;
	}
#endif
	// Up the ref count, since we are going to hold on to this pointer
	(pMsgMem->picsMember)->AddRef();
	// Plug it into the list box
	if (!m_cclb.FAddItem(pMsgMem->picsMember, pMem))
	{
		(pMsgMem->picsMember)->Release();	// no longer need the extra ref
#ifdef NOTNOW	
		delete pMem;
#endif
		return FALSE;
	}
	return TRUE;	
}

BOOL CChatListPane::FDelMember(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	PCS_MSGMEMBER pMsgMem = (PCS_MSGMEMBER)(pcsMsg + 1);
	Assert(pMsgMem->picsMember);
	
	if (!m_cclb.FDeleteItem(pMsgMem->picsMember))
	{
		AssertSz(0, "FDeleteItem");
	}
	return TRUE;
}

BOOL CChatListPane::FUpdateMember(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	PCS_MSGMEMBER pMsgMem = (PCS_MSGMEMBER)(pcsMsg + 1);

	if (!m_cclb.FUpdateItem(pMsgMem->picsMember))
	{
		AssertSz(0, "FUpdateItem");
	}
	return TRUE;	
}

BOOL CChatListPane::FUpdateNick(PCS_MSGBASE pcsMsg)
{
	if (FDelMember(pcsMsg))
	{
		return FAddMember(pcsMsg);
	}
	return FALSE;
}

BOOL CChatListPane::FFreeAllMembers(void)
{
	PICS_MEMBER pcm;
	
	while (NULL != (pcm = m_cclb.PicsMemberGet(0)))
	{
		m_cclb.FDeleteItem(pcm);
	}
	return TRUE;
}

BOOL CChatListPane::FChangeStatus(PICS_MEMBER pcsMem, int idCmd, PICS_CHANNEL pChan)
{
	HRESULT	hr;
	BOOL	fHostAlert = TRUE;
	TCHAR	szMemName[256];

	Assert(pcsMem);
	
	switch (idCmd)
	{
	default:
		return FALSE;

	case IDC_MAKESPECTATOR:
		hr = pcsMem->HrMakeSpectator();
		AssertSz(SUCCEEDED(hr), "HrMakeSpectator");
		break;

	case IDC_MAKESPEAKER:
		hr = pcsMem->HrMakeSpeaker();
		AssertSz(SUCCEEDED(hr), "HrMakeSpeaker");
		break;

	case IDC_MAKEHOST:
		hr = pcsMem->HrMakeHost();
		AssertSz(SUCCEEDED(hr), "HrMakeHost");
		break;

	case IDC_EJECTMEMBER:
		hr = pcsMem->HrCloseA(NULL);
		AssertSz(SUCCEEDED(hr), "HrClose");
		break;
	
	case IDC_IGNORE:
		if (NOERROR == pcsMem->HrIsMemberHost())
		{
			if (fHostAlert)
			{
				fHostAlert = FALSE;
				FDoAlert(m_hWnd, IDS_ERR_IGNOREHOST, ALERT_WARNING);
			}
		}
		else
		{
			hr = pcsMem->HrSetIgnoreMember(TRUE);
			m_cclb.FUpdateItem(pcsMem);
		}
		break;

	case IDC_DONTIGNORE:
		hr = pcsMem->HrSetIgnoreMember(FALSE);
		m_cclb.FUpdateItem(pcsMem);
		break;

	case IDC_GETREALNAME:
		hr = pcsMem->HrGetRealNameA();
		AssertSz(SUCCEEDED(hr), "HrGetRealName");
		break;
	
	case IDC_BAN:
	case IDC_UNBAN:
		Assert(pChan);

		hr = pChan->HrBanMemberMaskA(PszGetName(pcsMem, &szMemName[0]), IDC_BAN == idCmd);
		break;
	
	case IDC_KILLUSER:
		PICS			pics;
		CS_KILLINFO		csKillInfo;
		
		::ZeroMemory(&csKillInfo, sizeof(CS_KILLINFO));
		csKillInfo.dwcb = sizeof(CS_KILLINFO);
		csKillInfo.pvNick = PszGetName(pcsMem, &szMemName[0]);

		pics = PChatSocket();
		if (pics)
		{
			hr = pics->HrKillUserA(&csKillInfo);
			pics->Release();
		}
		break;
	}
	return TRUE; 
}

BOOL CChatListPane::FChannelModeChange(PICS_CHANNEL pChannel)
{
	// If the channel is now NOWHISPER, disable whisper buttons
	DWORD dwMode;

	if (FAILED(pChannel->HrGetType(&dwMode)))
	{
		return FALSE;
	}
	if (!FIsMicSocket() && 0 != (dwMode & CS_CHANNEL_MODERATED))
	{
		return m_cclb.FRedrawWindow();
	}
	return TRUE;
}

BOOL CChatListPane::FChangeMemberStatus(int idCmd, PICS_CHANNEL pChan)
{
	int			index, cSel;
	int*		prgSel;
	PICS_MEMBER	pcsMem;
	BOOL		fRet = FALSE;
	PICS_MEMBER pMem = NULL;
	BOOL		fDoUs = FALSE; // we always want to change ourselves last.
							// otherwise. you make yourself a spectator.. and then 
							// try to make other people spectators....
	// in case we need to check that we are not accidently damaging ourselves!
	HRESULT hr = pChan->HrGetMe(&pMem);
	if (FAILED(hr))
	{
		AssertSz(0, "HrGetMem");
		return FALSE;
	}

	//m_cclb.Lock();
	prgSel = NULL;
	if (!m_cclb.FGetSelection(&prgSel, &cSel))
	{
		goto LReturn;
	}
	
	for (index = 0; index < cSel;++index)
	{
		pcsMem = m_cclb.PicsMemberGet(prgSel[index]);
		if (pcsMem)
		{
			if (pMem == pcsMem)
			{
				fDoUs = TRUE;
			}
			else
			{
				FChangeStatus(pcsMem, idCmd, pChan);
			}
		}
	}

	fRet = TRUE;

	if (fDoUs)
	{
		switch (idCmd)
		{
		default:
			break;

		case IDC_MAKESPECTATOR:
			if (IDYES == FDoAlert(m_hWnd, IDS_ERR_MAKESELFSPEC, ALERT_YESNO))
			{
				FChangeStatus(pMem, idCmd);
			}
			break;

		case IDC_MAKESPEAKER:
			if (IDYES == FDoAlert(m_hWnd, IDS_ERR_MAKESELFSPEAKER, ALERT_YESNO))
			{
				FChangeStatus(pMem, idCmd);
			}
			break;

		case IDC_EJECTMEMBER:
			FDoAlert(m_hWnd, IDS_ERR_CANTKILLSELF, ALERT_WARNING);
			break;
		
		case IDC_IGNORE:
			FDoAlert(m_hWnd, IDS_ERR_IGNORESELF, ALERT_WARNING);
			break;

		case IDC_GETREALNAME:
			FChangeStatus(pMem, idCmd);
			break;
		}
	}

LReturn:
	if (prgSel)
	{
		delete [] prgSel;
	}
	if (pMem)
	{
		pMem->Release();
	}
	//m_cclb.Unlock();
	return fRet;
}

BOOL CChatListPane::FWhisperToMembers(int idCmd, PICS_CHANNEL pChan, TCHAR* pszSend, CChatHistoryPane* pHist)
{
	Assert(pszSend && pChan && pHist);

	int				index, cSel, iMem;
	int*			prgSel;
	PICS_MEMBER		pcsMem;
	HRESULT			hr = NOERROR;
	BOOL			fRet = FALSE;
	PICS_MEMBER*	prgMem = NULL;
	PICS_MEMBER		pMem = NULL;
	BOOL			fNoWhisper = FALSE;
	BOOL			fSelfWhisper = FALSE;

	// we need to check if we should give ourselves a copy of any msg we sent
	hr = pChan->HrGetMe(&pMem);
	if (FAILED(hr))
	{
		AssertSz(0, "HrGetMem");
		return FALSE;
	}
	//m_cclb.Lock();
	prgSel = NULL;
	if (!m_cclb.FGetSelection(&prgSel, &cSel))	  // get the list box selection
	{
		goto LReturn;
	}
	Assert(cSel > 0 && cSel <= CS_CMAX_WHISPERMEMBERS);
	// Make an array of members..
	prgMem = new PICS_MEMBER[cSel];
	if (!prgMem)
	{
		AssertGLE(FALSE);
		DoOOM();
		goto LReturn;
	}
	// Copy the member pointers
	iMem = 0;
	for (index = 0; index < cSel; ++index)
	{
		pcsMem = m_cclb.PicsMemberGet(prgSel[index]);
		if (!pcsMem || (pMem == pcsMem))
		{
			// skip this guy
			fSelfWhisper = TRUE;
			continue;
		}
		// Only whisper if they take whispers
		if (NOERROR == pcsMem->HrDoesMemberTakeWhisper())
		{
			prgMem[iMem] = pcsMem;
			++iMem;
		}
		else
		{
			// Somebody doesn't take whispers
			fNoWhisper = TRUE;
		}
	}
	// Send the msg, but only if there is anybody worth sending to..
	if (iMem > 0)
	{
		fRet = (SUCCEEDED(pChan->HrSendTextListA(pszSend, prgMem, iMem)));
	}
	else if (fSelfWhisper)
	{
		FDoAlert(m_hWnd, IDS_ERR_SELFWHISPER, ALERT_WARNING);
	}
	// echo to ourselves. 
	pHist->FInsertWhisper(pMem, iMem, prgMem, pszSend, TRUE);
	// Alert the user if somebody doesn't take whispers
	if (fNoWhisper)
	{
		FDoAlert(m_hWnd, IDS_ERR_SOMENOWHISPER, ALERT_WARNING);
	}
LReturn:
	if (prgSel)
	{
		delete [] prgSel;
	}
	if (prgMem)
	{
		delete [] prgMem;
	}
	if (pMem)
	{
		pMem->Release();
	}
	//m_cclb.Unlock();

	return fRet;
}

BOOL CChatListPane::FShowMemberProps(void)
{
	int				index, cSel, iMem;
	PICS_MEMBER		pcsMem;
	HRESULT			hr = NOERROR;
	BOOL			fRet = FALSE;
	PICS_MEMBER*	prgMem = NULL;

	CMemberProps* pcmp = new CMemberProps;
	if (!pcmp)
	{
		AssertGLE(FALSE);
		DoOOM();
		return FALSE;
	}
	// BUILD a list of members whose properties we should view
	//m_cclb.Lock();

	int* prgSel = NULL;
	if (!m_cclb.FGetSelection(&prgSel, &cSel))	  // get the list box selection
	{
		//m_cclb.Unlock();
		goto LReturn;
	}
	Assert(cSel > 0);
	// Make an array of members..
	prgMem = new PICS_MEMBER[cSel];
	if (!prgMem)
	{
		AssertGLE(FALSE);
		DoOOM();
		//m_cclb.Unlock();
		goto LReturn;
	}
	// Copy the member pointers
	iMem = 0;
	for (index = 0; index < cSel; ++index)
	{
		pcsMem = m_cclb.PicsMemberGet(prgSel[index]);
		if (!pcsMem)
		{
			// skip this guy
			continue;
		}
		pcsMem->AddRef(); // since we are passing pointers, up the ref count
		prgMem[iMem] = pcsMem;
		++iMem;
	}
	//m_cclb.Unlock();
	// Pop up the dialog. 
	SetDisableAll(TRUE);
	fRet = pcmp->FMemberPropDlg(HWndFore(), prgMem, iMem);
	SetDisableAll(FALSE);

LReturn:
	if (pcmp)
	{
		pcmp->Release();
	}

	if (prgSel)
	{
		delete [] prgSel;
	}
	if (prgMem)
	{
		for (index = 0; index < cSel;++index)
		{
			pcsMem = prgMem[index];
			if (pcsMem)
			{
				pcsMem->Release();
			}
		}
		delete [] prgMem;
	}

	return fRet;
}

BOOL CChatListPane::FInitElements(void)
{
	// Override the current wnd proc
	SetWindowProc(ListBoxWndProc);
	// Create the list box
	return m_cclb.FCreate(m_hWnd, ID_MEMLISTBOX, NULL);
}

BOOL CChatListPane::FHandleWMSize(WPARAM wParam, LPARAM lParam)
{
	// Parent window got resized. Resize child list box
	RECT	rc;
	
	rc.top		= 0;
	rc.left		= 0;
	rc.right	= LOWORD(lParam);
	rc.bottom	= HIWORD(lParam);

	if (!m_cclb.FMoveWindowNoUpdate(&rc))
	{
		return FALSE;
	}

	return m_cclb.FRedrawWindow();
}

extern CIChatMain gciChat;

BOOL CChatListPane::FDoContextMenu(short xPos, short yPos)
{
	RECT	rect;
	int		iSel;
	RECT	rectItem;
	
	HMENU hmenu = gciChat.Hmenu(imenuMember);
	
	// if we got this via shift-f10, the position is bogus and we should adjust.
	if (xPos == -1 || yPos == -1)
	{
		GetWindowRect(m_cclb.HWnd(), &rect);
		if (m_cclb.SendMessage(LB_GETSELCOUNT))
		{
			// there are items selected.  find a good one and put the menu there.
			iSel = m_cclb.SendMessage(LB_GETANCHORINDEX);
			m_cclb.SendMessage(LB_GETITEMRECT, iSel, (LPARAM)&rectItem);
			xPos = (short)(((rectItem.right - rectItem.left) / 2) + rect.left);
			yPos = (short)(((rectItem.bottom - rectItem.top) / 2) + rect.top);
		}
		else
		{
			// no selection--put it in the top of the window.
			xPos = (short)rect.left;
			yPos = (short)rect.top;
		}
	}
	TrackPopupMenu(hmenu, TPM_LEFTALIGN | TPM_LEFTBUTTON, xPos, yPos, 0, m_hWndParent, NULL);
	return TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK ListBoxWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CChatListPane*	pclp;
	
	LONG lData = GetWindowLong(hWnd, GWL_USERDATA);
	Assert(0xffffffff != lData);
	if (0 != lData)
	{
		pclp = (CChatListPane*)lData;
		switch (uMsg)
		{
		default:
			break;

		case WM_COMMAND:
			switch (HIWORD(wParam))
			{
			case LBN_DBLCLK:
				return pclp->FShowMemberProps();
					
			default:
				break;
			}
			switch (LOWORD(wParam))
			{
			default:
				break;

			case IDC_SEND:
			case IDC_WHISPER:
			case IDC_TABKEY:
			case IDC_TABKEYSHIFT:
				return pclp->FGiveMsgToParent(WM_COMMAND, wParam, 0);
			}
			break;

		case WM_CONTEXTMENU:
			return pclp->FDoContextMenu((short)LOWORD(lParam), (short)HIWORD(lParam));

		case WM_MEASUREITEM:
			return (pclp->m_cclb).FMeasureItem(hWnd, (LPMEASUREITEMSTRUCT)lParam);

		case WM_DRAWITEM:
			return (pclp->m_cclb).FDrawItem((LPDRAWITEMSTRUCT)lParam);

		case WM_COMPAREITEM:
			return (pclp->m_cclb).FCompareItem((LPCOMPAREITEMSTRUCT)lParam);

		case WM_DELETEITEM:
			PICS_MEMBER pMem;

			pMem = (PICS_MEMBER) (((LPDELETEITEMSTRUCT)lParam)->itemData);
			return (pclp->m_cclb).FFreeItem(pMem);
		}
		return pclp->LrCallWindowProc(uMsg, wParam, lParam);
	}

	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}
