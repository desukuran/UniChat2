//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICTREE__
#define __ICTREE__

#include "icinc.h"
#include "icbitmap.h"
#include "icmember.h"

//--------------------------------------------------------------------------------------------
// CONSTANTS
//--------------------------------------------------------------------------------------------
// Used to tag nodes
const int 	ROOTNOTE			= 0x0000;
const int	CHANNELNODE			= 0x0001;
const int	MEMBERNODE			= 0x0002;
const int	FOLDERNODE			= 0x0004;
const int	USERNODE			= 0x0008;
// Used to mark a parent node as having had its children "looked" up
const int	NODELOOKEDUP		= 0x0100;
// Indexes into Image Array
const int	CIMAGESTREE			= 8;
const int	IIMGWORLD			= 0;
const int	IIMGCHANNEL			= 1;
const int	IIMGMEMBER			= 2;
const int	IIMGHOST			= 3;
const int	IIMGSPEAKER			= 4;
const int	IIMGSPECTATOR		= 5;
const int	IIMGFOLDER			= 6;
const int	IIMGCHATPRIV		= 7;

//--------------------------------------------------------------------------------------------
// Chat Tree View controls
class CChatTreeView : public CChatChildWnd
{
// Interfaces
public:
	CChatTreeView(void);
	~CChatTreeView(void);

	BOOL			FInit(HWND hWndParent);
	BOOL			FCreate(HWND hWndParent, int idCmd, RECT* prc);

	HTREEITEM		HtiRoot(void)		{ return m_hRoot; }

	HTREEITEM		HtiChannel(void)	{ return m_hChannel; }
	HTREEITEM		HtiUsers(void)		{ return m_hUsers; }

	BOOL			FAddRoot(TCHAR* szRoot);
	BOOL			FAddChatFolder(void);
	BOOL			FAddUserFolder(void);
	BOOL			FAddChannel(PICS_PROPERTY picsProperty, DWORD dwMode, HTREEITEM htiParent=NULL);
	BOOL			FAddMember(PICS_PROPERTY picsProperty, DWORD dwMode, HTREEITEM hItemParent);
	BOOL			FAddUser(PICS_PROPERTY picsProperty);

	BOOL			FIsFolder(HTREEITEM hItem);
	BOOL			FIsMember(PICS_PROPERTY picsProperty);
	BOOL			FIsMember(HTREEITEM htiItem);
	BOOL			FIsChannel(PICS_PROPERTY picsProperty);
	BOOL			FIsChannel(HTREEITEM htiItem);
	BOOL			FIsUser(PICS_PROPERTY picsProperty);
	BOOL			FIsUser(HTREEITEM htiItem);

	BOOL			FExpandRoot(void) { return FExpandNode(m_hRoot); }
	BOOL			FExpandChats(void);
	BOOL			FExpandUsers(void);
	BOOL			FExpandNode(HTREEITEM hItem);

	
	BOOL			FDeleteItem(HTREEITEM hItem);
	BOOL			FDeleteAll(void);
	BOOL			FDeleteAllChannels(void);
	BOOL			FDeleteAllUsers(void);
	BOOL			FDeleteAllChildren(HTREEITEM htiParent);

	HTREEITEM		HtiAddItem(HTREEITEM htiParent, int iImage, int cChildren, 
							PICS_PROPERTY picsProperty, TCHAR* psz=NULL);
	HTREEITEM		HtiGetChild(HTREEITEM htiParent)
					{ return (HTREEITEM) SendMessage(TVM_GETNEXTITEM, (WPARAM)TVGN_CHILD, (LPARAM)htiParent); }
	HTREEITEM		HtiGetSelection(void)
					{ return TreeView_GetSelection(m_hWnd); }

	void			Lock(void)		{ /* m_csMod.Lock(); */ return; }
	void			Unlock(void)	{ /* m_csMod.Unlock(); */ return; }
	int				IGetCount(void);

	BOOL			FIsRoot(HTREEITEM hItem)
					{
						if (m_hRoot)
							return (hItem == m_hRoot);
						return FALSE;
					}
	PICS_PROPERTY	PicsPropertyGet(HTREEITEM hItem);
	BOOL			FSetPicsProperty(HTREEITEM hItem, PICS_PROPERTY picsProperty);
	BOOL			FRedrawItem(HTREEITEM hItem);

protected:
	BOOL			FCleanUp(void);
	BOOL			FInitImageList(void);
	
	BOOL			FIsNode(PICS_PROPERTY picsProperty, int iSrcType);
	TCHAR*			SzGet(int idStr);
// Data
protected:
	CChatBitmaps	m_ccbitmap;		// object that manages chat bitmaps
	HIMAGELIST		m_himl;			// image list

	int				m_rgiImg[CIMAGESTREE];		// images used by the tree
	// Handles
	HTREEITEM		m_hRoot;		// the root item
	HTREEITEM		m_hChannel;		// channels live under here
	HTREEITEM		m_hUsers;		// users live under here
	// LOCKs.. multi-thread danger
	CS_LOCK			m_csMod;
};

#endif
