//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICLSTBOX__
#define __ICLSTBOX__

#include "icinc.h"
#include "icpane.h"
#include "icbitmap.h"
#include "icmember.h"

//
// Chat List boxes are owner draw
class CChatListBox : public CChatPane
{
friend LRESULT CALLBACK ChildListBoxWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CChatListBox(void);
	~CChatListBox(void);

	BOOL			FInit(HWND hWndParent);
	BOOL			FCreate(HWND hWndParent, int idCmd, RECT* prc);

	int				FCompareItem(LPCOMPAREITEMSTRUCT lpci);

	int				FMeasureItem(HWND hWnd, LPMEASUREITEMSTRUCT lpmi);
	int				FDrawItem(LPDRAWITEMSTRUCT lpdi);

	BOOL			FAddItem(PICS_MEMBER pcm, CMember* pMember);
	BOOL			FDeleteItem(PICS_MEMBER pcm);
	BOOL			FUpdateItem(PICS_MEMBER pcm);
	PICS_MEMBER		PicsMemberGet(int index);
	CMember*		PCMemberGet(PICS_MEMBER pcm);

	int				IGetCount(void);
	int				IGetSelCount(void);
	BOOL			FGetSelection(int** pprgSel, int* pcMem);
	BOOL			SelectItem(int index);

	LRESULT			IFindMember(PICS_MEMBER pcm);
	BOOL			FFreeItem(PICS_MEMBER pcm);
protected:

	virtual BOOL	FInitExtra(void)	{ return TRUE; }
	virtual	BOOL	FDrawExtra(LPDRAWITEMSTRUCT lpdi, RECT* prc, CMember* pcm);
	BOOL			FMakeStrikeFont(void);
	TCHAR*			PszGetName(PICS_MEMBER pcm, TCHAR* psz);

// Data
protected:
	CChatBitmaps	m_ccbitmap;			// object that manages chat bitmaps
	HFONT			m_hfontStrikeOut;
	//
	// Keep these cached to make Unicode/Ansi conversion easy
	//
	TCHAR			m_szConvert1[CS_CCHMAX_MIC_USERNAME + 1];
	TCHAR			m_szConvert2[CS_CCHMAX_MIC_USERNAME + 1];
};

#endif
