//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICUSER__
#define __ICUSER__

// USER
#define USER_HSPLITDONE				5000
#define USER_VSPLITDONE				USER_HSPLITDONE + 1
#define USER_MAX					5999

// BITMAPS
#define IDB_HOST                        108 
#define IDB_PARTICIPANT                 109
#define IDB_SPECTATOR                   110
#define IDB_TOOLBAR                     111
#define IDB_AWAY						112
#define IDB_MEMBER						113
#define IDB_WORLD                       114
#define IDB_FOLDER                      115
#define IDB_CHAT                        116
#define IDB_MSN                         117
#define IDB_CHATPRIV					118

// CURSORS
#define IDC_CURSORHAND                  124

// MENUS

// File Menu
// NOTE!  Menu items (at least the ones that have toolbar buttons) must now
// have corresponding strings with the SAME NUMBER as their ids (this is to
// make tool tip support a billion times easier).  The way I'm doing this
// is to simply use the IDC_FOO constant in the string table as well; just
// make sure you add a string for every menu item you add.  Also, don't make
// the number above 300 unless you also rearrange the string table...
#define IDC_FILEMENUFIRST				1
#define	IDC_EXIT						1
#define IDC_LOGIN						2
#define IDC_SEND						3
#define IDC_SAVE						5
#define IDC_SAVEAS						6
#define IDC_FAVPLACES					7

#define	IDC_LEAVECHANNEL				IDC_FAVPLACES + 1
#define IDC_SETAWAY						IDC_LEAVECHANNEL + 1

#define IDC_SHORTCUT					IDC_SETAWAY + 1
#define IDC_CONSETTINGS					IDC_SHORTCUT + 1	
#define IDC_FILEMENULAST				IDC_CONSETTINGS

// Edit Menu
#define IDC_EDITFIRST					25
#define IDC_CUT							25
#define IDC_COPY						IDC_CUT + 1
#define IDC_PASTE						IDC_COPY + 1
#define IDC_SELECTALL					IDC_PASTE + 1
#define IDC_CLEAR						IDC_SELECTALL + 1
#define IDC_CLEARHISTORY				IDC_CLEAR + 1
#define IDC_INSERTURL					IDC_CLEARHISTORY + 1
#define IDC_EDITLAST					IDC_INSERTURL
// View menu
#define IDC_VIEWFIRST					50
#define IDC_SHOWSPECTATOR				IDC_VIEWFIRST
#define IDC_DONTIGNORE					IDC_SHOWSPECTATOR + 1
#define IDC_IGNORE						IDC_DONTIGNORE	+ 1
#define IDC_VIEWTOOLBAR					IDC_IGNORE + 1
#define IDC_VIEWFINDPANE				IDC_VIEWTOOLBAR + 1
#define IDC_VIEWSTATUSBAR				IDC_VIEWFINDPANE + 1
#define IDC_VIEWLAST					IDC_VIEWSTATUSBAR				
// Member menu
#define IDC_MEMBERMENUFIRST				75
#define	IDC_MAKESPECTATOR				75
#define	IDC_MAKESPEAKER					IDC_MAKESPECTATOR + 1
#define IDC_MAKEHOST					IDC_MAKESPEAKER + 1
#define IDC_EJECTMEMBER					IDC_MAKEHOST + 1
#define IDC_WHISPER						IDC_EJECTMEMBER + 1
#define IDC_GETMEMPROPS					IDC_WHISPER + 1
#define IDC_GETREALNAME					IDC_GETMEMPROPS + 1
#define IDC_MEMBERMENULAST				IDC_GETREALNAME	

// Channel menu
#define IDC_CREATECHANNEL				100
#define IDC_CREATECHAT					IDC_CREATECHANNEL + 1
#define IDC_JOINCHANNEL					IDC_CREATECHAT + 1
#define IDC_CHANGETOPIC					IDC_JOINCHANNEL + 1
#define IDC_LISTCHANNELS				IDC_CHANGETOPIC + 1
#define IDC_LISTUSERS					IDC_LISTCHANNELS + 1
#define IDC_NOWHISPER					IDC_LISTUSERS + 1		
#define IDC_CHANNELPROPS				IDC_NOWHISPER + 1
// Help Menu
#define IDC_HELPMENU					150
#define IDC_ABOUT						IDC_HELPMENU + 1
#define IDC_HELPTOPICS					IDC_ABOUT + 1

// individual popup menu ids
#define IDM_POPUPS						180

// OTHER DEFINES
#define ID_MSG							1002
#define ID_MEMBER						1003
#define ID_TOOLBAR						1004
#define ID_HISTORY						1005
#define ID_SENDBUFFER					1006
#define ID_SENDSUBPANE					1007
#define ID_SENDBTNBAR					1008
#define ID_MEMLISTBOX					1009
#define ID_SETFOCUS						1010
#define ID_FINISHWIZ					1011
#define ID_CANCELWIZ					1012
#define	ID_GETUIPTR						1013
#define ID_FINDTREEVIEW					1014
#define ID_FIND							1015
#define ID_HSPLITTER					1016				
#define ID_VPLITTER						1017				
#define ID_LVPLITTER					1018				
#define ID_STATUSBAR					1019

// STRINGS
// NOTE!  For tool tip support, the range of 0-300 is reserved for tool tip
// strings.  Make sure any new strings you add are outside that range!

#define IDS_STRING_FIRST				400

#define IDS_SENDBTN                     IDS_STRING_FIRST +   1
#define IDS_APPTITLE                    IDS_STRING_FIRST +   2
#define IDS_ERR_GENERIC					IDS_STRING_FIRST +   3
#define IDS_ERR_REDOSETUP				IDS_STRING_FIRST +   4
#define IDS_SAVEFILTER					IDS_STRING_FIRST +   5
#define IDS_UNTITLED					IDS_STRING_FIRST +   6
#define IDS_WHISPERBTN					IDS_STRING_FIRST +   7
#define	IDS_OK							IDS_STRING_FIRST +   8
#define IDS_BROWSER						IDS_STRING_FIRST +   9
#define IDS_YES							IDS_STRING_FIRST +  10
#define IDS_NO							IDS_STRING_FIRST +  11
#define IDS_HOST						IDS_STRING_FIRST +  12
#define IDS_SPECTATOR					IDS_STRING_FIRST +  13
#define IDS_SPEAKER						IDS_STRING_FIRST +  14

#define IDS_ERR_NOSERVERNAME			IDS_STRING_FIRST + 100
#define IDS_ERR_NOUSERNAME				IDS_ERR_NOSERVERNAME + 1
#define IDS_ERR_NOPASS					IDS_ERR_NOUSERNAME + 1
#define IDS_SECONDS						IDS_ERR_NOPASS + 1
#define IDS_ERR_NAMEINUSE				IDS_SECONDS + 1
#define IDS_ERR_ILLEGALUSER				IDS_ERR_NAMEINUSE + 1	   // 105
#define IDS_ERR_LOGOFFOK				IDS_ERR_ILLEGALUSER + 1				
#define IDS_ERR_ILLEGALNAME				IDS_ERR_LOGOFFOK + 1
#define	IDS_ERR_NONICK					IDS_ERR_ILLEGALNAME + 1

#define IDS_ERR_CONNECT					IDS_STRING_FIRST + 120
#define IDS_ERR_SERVERNOTFOUND			IDS_ERR_CONNECT + 1
#define IDS_ERR_NOTCONNECTED			IDS_ERR_SERVERNOTFOUND + 1
#define IDS_ERR_LINEDROPPED				IDS_ERR_NOTCONNECTED + 1
#define IDS_ERR_CONNECT_TIMEOUT			IDS_ERR_LINEDROPPED + 1
#define IDS_ERR_HOSTHUNGUP				IDS_ERR_CONNECT_TIMEOUT + 1
			
#define	IDS_ERR_ALREADYONCHANNEL		IDS_STRING_FIRST + 135
#define	IDS_ERR_CHANNELFULL				IDS_ERR_ALREADYONCHANNEL + 1
#define IDS_ERR_NOCHANNELNAME			IDS_ERR_CHANNELFULL + 1
#define IDS_ERR_ALREADYEXISTS			IDS_ERR_NOCHANNELNAME + 1
#define IDS_ERR_CHANNELNOTFOUND			IDS_ERR_ALREADYEXISTS + 1
#define IDS_ERR_CHANNELINVITEONLY		IDS_ERR_CHANNELNOTFOUND + 1		//140
#define IDS_ERR_CHANNELPASSWORD			IDS_ERR_CHANNELINVITEONLY + 1
#define IDS_ERR_CHANNELCHARS_IRC		IDS_ERR_CHANNELPASSWORD + 1
#define IDS_ERR_CHANNELFIRSTCHAR		IDS_ERR_CHANNELCHARS_IRC + 1
#define IDS_ERR_CHATGONE				IDS_ERR_CHANNELFIRSTCHAR + 1
#define IDS_ERR_MEMBERGONE				IDS_ERR_CHATGONE + 1			// 145
#define IDS_CREATECHANNELDLG			IDS_ERR_MEMBERGONE + 1
#define IDS_JOINCHANNELDLG				IDS_CREATECHANNELDLG + 1
#define IDS_ERR_BANNED					IDS_JOINCHANNELDLG + 1				
#define IDS_ERR_TOOMANYCHANNELS			IDS_ERR_BANNED + 1				// 149

#define IDS_ERR_NOTOPIC					IDS_STRING_FIRST + 175

#define IDS_ERR_NOAWAYTEXT				IDS_STRING_FIRST + 180

#define IDS_FIND_ALLCHATS				IDS_STRING_FIRST + 200
#define IDS_FIND_MEMBER					IDS_FIND_ALLCHATS + 1				
#define IDS_FIND_DLGTITLE				IDS_FIND_MEMBER + 1
#define IDS_ERR_FINDMINMAX				IDS_FIND_DLGTITLE + 1
#define IDS_ERR_NOCHATSFOUND			IDS_ERR_FINDMINMAX + 1
#define	IDS_ERR_CHATPROTECTED			IDS_ERR_NOCHATSFOUND + 1
#define	IDS_FIND_MEMBERDLGTITLE			IDS_ERR_CHATPROTECTED + 1
#define IDS_FIND_NAMES					IDS_FIND_MEMBERDLGTITLE + 1
#define IDS_ERR_NOUSERSFOUND			IDS_FIND_NAMES + 1

#define IDS_ERR_SELECTWHISPER			IDS_STRING_FIRST + 250
#define IDS_ERR_TOOMANYWHISPER			IDS_STRING_FIRST + 251

#define IDS_GET_REALNAME				IDS_STRING_FIRST + 300

// Font Page
#define IDD_PAGEFONT	               	2000
#define IDC_CBFONT                      IDD_PAGEFONT + 1
#define IDC_EDITSAMPLEFONT              IDC_CBFONT + 1
#define IDC_CBSIZE                      IDC_EDITSAMPLEFONT + 1
#define IDC_CBELEMENT					IDC_CBSIZE + 1
// Color Page
#define IDD_PAGECOLOR					2100
#define IDC_COLOR                       IDD_PAGECOLOR + 1
#define IDC_COLORBAK                   	IDC_COLOR + 1
#define IDC_CBELEMENTCOLOR				IDC_COLORBAK + 1
#define IDC_EDITSAMPLECOLOR             IDC_CBELEMENTCOLOR + 1
// Font AND Color. For Text.
#define	IDD_MEMBERFONTCOLOR				2200
#define IDC_CBMEMBERFONT                IDD_MEMBERFONTCOLOR + 1
#define IDC_CBMEMBERSIZE                IDC_CBMEMBERFONT + 1
#define IDC_MEMBERCOLOR                 IDC_CBMEMBERSIZE + 1
#define IDC_CBMEMBER              		IDC_MEMBERCOLOR + 1
#define IDC_EDITSAMPLEMEMBER            IDC_CBMEMBER + 1
#define IDC_BTNRESET					IDC_EDITSAMPLEMEMBER + 1			
//	Member alarms
#define IDD_PAGEMEMPROPS				2300
#define	IDC_CHECKBEEPMSG				IDD_PAGEMEMPROPS + 1
#define	IDC_RADIONEXTMSG				IDC_CHECKBEEPMSG + 1
#define	IDC_RADIOALLMSG					IDC_RADIONEXTMSG + 1
#define	IDC_CHECKBEEPLEAVE				IDC_RADIOALLMSG + 1
#define IDC_EDITMSGCONTAINS				IDC_CHECKBEEPLEAVE + 1
#define IDC_CHECKBEEPTEXT  				IDC_EDITMSGCONTAINS + 1
#define	IDC_BTNCLEARALL	 				IDC_CHECKBEEPTEXT + 1
#define IDC_CHECKBOLDTEXT				IDC_BTNCLEARALL + 1
#define	IDS_ERRNOFILTERTEXT				IDC_CHECKBOLDTEXT + 1
#define IDC_AUTOSENDMSG	   				IDS_ERRNOFILTERTEXT + 1
#define IDC_AUTOSENDLEAVE  				IDC_AUTOSENDMSG + 1
// Global alarms
#define IDD_PAGEPROPS					2400
#define IDC_CHECKBEEPJOIN				IDD_PAGEPROPS + 1
#define	IDC_CHECKNAMEDMEMBER			IDC_CHECKBEEPJOIN + 1
#define IDC_EDITNAMEDMEMBER				IDC_CHECKNAMEDMEMBER + 1
#define IDC_AUTOSENDMSGJOIN				IDC_EDITNAMEDMEMBER + 1
// Whisper Window
#define IDD_WHISPERWINDOW				2500
#define IDC_WHISPERCONTROL				IDD_WHISPERWINDOW + 1
// Away commands
#define IDC_AWAY						2600
#define IDC_SHOWAWAY					IDC_AWAY + 1
#define IDS_SSSHOWAWAY					IDC_SHOWAWAY + 1
// CREATE CHANNEL WIZARD
#define IDD_CHANNELNAME					2700
#define IDC_EDITCHANNELNAME				IDD_CHANNELNAME + 1
#define IDC_EDITCHANNELTOPIC			IDC_EDITCHANNELNAME + 1
#define IDC_CHECKIRC                    IDC_EDITCHANNELTOPIC + 1

#define IDD_CHANNELTYPE					2710
#define IDC_RADIOPUBLIC                 IDD_CHANNELTYPE + 1
#define IDC_RADIOPRIVATE                IDC_RADIOPUBLIC + 1
#define IDC_RADIOPROTECTED              IDC_RADIOPRIVATE + 1
#define IDC_BTNADVANCED                 IDC_RADIOPROTECTED + 1

#define IDD_CHANNELNAMECLASH            2720
#define IDC_RADIOAUTOJOIN               IDD_CHANNELNAMECLASH + 1
#define IDC_RADIOALWAYSCREATE           IDC_RADIOAUTOJOIN + 1
#define IDC_RADIONEWNAME                IDC_RADIOALWAYSCREATE + 1					
// JOIN CHANNEL WIZARD
#define IDD_JOINCHANNEL                 2800
// CHANGE TOPIC
#define IDD_CHANGETOPIC					2820
#define IDC_EDITNEWTOPIC				IDD_CHANGETOPIC + 1
#define IDC_EDITOLDTOPIC				IDC_EDITNEWTOPIC + 1
// SET AWAY
#define IDD_SETAWAY						2830
#define IDC_CHKAWAY                     IDD_SETAWAY + 1
#define IDC_EDITAWAYTEXT				IDC_CHKAWAY + 1
// FINDS
#define IDD_FINDEASY					2900
#define IDC_EDITFINDCHANNEL				IDD_FINDEASY + 1
#define IDC_EDITFINDMAXUSER				IDC_EDITFINDCHANNEL + 1
#define IDC_EDITFINDMINUSER				IDC_EDITFINDMAXUSER + 1
#define IDC_RADIOCONTAINS               IDC_EDITFINDMINUSER + 1
#define IDC_RADIOEQUALS					IDC_RADIOCONTAINS + 1

#define IDD_FINDMEMBER					3000
#define IDC_EDITFINDMEMBER				IDD_FINDMEMBER + 1
// Shortcuts
#define IDC_SENDSHORTCUT				3100
// PROPERTY SHEET DIALOGS
#define	IDS_PROPERTYCAPTION				3200
#define IDS_PROPERTYCUSTOMIZE			IDS_PROPERTYCAPTION + 1
// Auto Messages
#define IDD_AUTOMESSAGE					4000
#define IDC_EDITMESSAGE					IDD_AUTOMESSAGE + 1	
#define IDC_LISTMSG						IDC_EDITMESSAGE + 1
#define IDC_NEW	   						IDC_LISTMSG + 1
#define IDC_DELETE						IDC_NEW + 1
#define IDC_CHANGE						IDC_DELETE + 1
#define IDC_AUTOMESSAGE					IDC_CHANGE + 1
#define IDC_LABEL						IDC_AUTOMESSAGE + 1
#define IDC_BTNSEND 					IDC_LABEL + 1
#define IDC_INSERT						IDC_BTNSEND + 1
// LOGIN WIZARD
#define IDD_SERVER                      4100
#define IDC_CBSERVER                    IDD_SERVER + 1
#define IDC_EDITNICK                    IDC_CBSERVER + 1

#define IDD_USERPASS                    4110
#define IDC_EDITUSERNAME                IDD_USERPASS + 1
#define IDC_EDITPASSWORD                IDC_EDITUSERNAME + 1

#define IDD_LOGINGIN                    4120
#define IDC_LBLSERVERNAME               IDD_LOGINGIN + 1
#define IDC_LBLSECS                     IDC_LBLSERVERNAME + 1
// ABOUT BOX
#define IDD_ABOUTMIC                    4200
// KEYBOARD navigation
#define IDC_TABKEY						6000
#define IDC_TABKEYSHIFT					IDC_TABKEY + 1
// MEMBER PROPERTIES
#define IDD_MEMBERPROPS                 4300
#define IDC_LBLAUTH                     IDD_MEMBERPROPS + 1
#define IDC_LBLNOWHISPER                IDC_LBLAUTH + 1
#define IDC_COMBOMEMBERS                IDC_LBLNOWHISPER + 1
#define IDC_LBLIRCUSER                  IDC_COMBOMEMBERS + 1
#define IDC_LBLSTATUS                   IDC_LBLIRCUSER + 1
// Color commands
#define ID_FORMAT_FONT_COLOR_AUTO       10000
#define ID_FORMAT_FONT_COLOR_01         ID_FORMAT_FONT_COLOR_AUTO + 1
#define ID_FORMAT_FONT_COLOR_02         ID_FORMAT_FONT_COLOR_01 + 1
#define ID_FORMAT_FONT_COLOR_03         ID_FORMAT_FONT_COLOR_02 + 1
#define ID_FORMAT_FONT_COLOR_04         ID_FORMAT_FONT_COLOR_03 + 1
#define ID_FORMAT_FONT_COLOR_05         ID_FORMAT_FONT_COLOR_04 + 1
#define ID_FORMAT_FONT_COLOR_06         ID_FORMAT_FONT_COLOR_05 + 1
#define ID_FORMAT_FONT_COLOR_07         ID_FORMAT_FONT_COLOR_06 + 1
#define ID_FORMAT_FONT_COLOR_08         ID_FORMAT_FONT_COLOR_07 + 1
#define ID_FORMAT_FONT_COLOR_09         ID_FORMAT_FONT_COLOR_08 + 1
#define ID_FORMAT_FONT_COLOR_10         ID_FORMAT_FONT_COLOR_09 + 1
#define ID_FORMAT_FONT_COLOR_11         ID_FORMAT_FONT_COLOR_10 + 1
#define ID_FORMAT_FONT_COLOR_12         ID_FORMAT_FONT_COLOR_11 + 1
#define ID_FORMAT_FONT_COLOR_13         ID_FORMAT_FONT_COLOR_12 + 1
#define ID_FORMAT_FONT_COLOR_14         ID_FORMAT_FONT_COLOR_13 + 1
#define ID_FORMAT_FONT_COLOR_15         ID_FORMAT_FONT_COLOR_14 + 1
#define ID_FORMAT_FONT_COLOR_16         ID_FORMAT_FONT_COLOR_15 + 1
//
// UI Elements
#define IDS_HISTORYWINDOW	   			ID_FORMAT_FONT_COLOR_16 + 1
#define IDS_SENDWINDOW	 				IDS_HISTORYWINDOW + 1
#define	IDS_WHISPERWINDOW				IDS_SENDWINDOW + 1
// Property commands
#define ID_PROPUPDATESAMPLE				2100
// Common
#define IDC_CHAT                        65535
#define IDC_STATIC                      -1

// These are reserved for CHATSOCK MESSAGES
#define ID_MSG_CHATSOCK					WM_USER + 1

#endif
