//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICCHILD__
#define __ICCHILD__

#include "icinc.h"

class CChatChildWnd
{
// Interfaces
public:
	CChatChildWnd(void);
	~CChatChildWnd(void);

	HWND			HWnd(void)			{ return m_hWnd; }
	HWND			HWndParent(void)	{ return m_hWndParent; }

	BOOL			FCreate(HWND hWndParent, int idCtl, RECT* prc, TCHAR* pszClass, WNDPROC pwp)
					{
						return FCreate(hWndParent, idCtl, prc, pszClass, 
									WS_CHILD | WS_VISIBLE, WS_EX_CLIENTEDGE, pwp);
					}
	BOOL			FCreateNoEdge(HWND hWndParent, int idCtl, RECT* prc, TCHAR* pszClass, WNDPROC pwp)
					{
						return FCreate(hWndParent, idCtl, prc, pszClass, 
									WS_CHILD | WS_VISIBLE, 0, pwp);
					}
	BOOL			FCreatePopUp(HWND hWndParent, int idCtl, RECT* prc, TCHAR* pszClass, WNDPROC pwp)
					{
						return FCreate(hWndParent, idCtl, prc, pszClass, 
									WS_POPUP | WS_VISIBLE, WS_EX_CLIENTEDGE, pwp);
					}
	BOOL			FCreate(HWND hWndParent, int idCtl, RECT* prc,
							TCHAR* pszClass, DWORD dwStyle, DWORD dwExStyle, WNDPROC pwp);

	BOOL			FSetWindowName(TCHAR* pszName);
	BOOL			FSetWindowName(int idName);

	void			SetWindowProc(WNDPROC wndProc);
	LRESULT			LrCallWindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	BOOL			FDestroyWindow(void);
	void			ShowWindow(void);
	void			HideWindow(void);
	BOOL			FEnableWindow(BOOL fEnable);
	HWND			HWndSetFocus(void)
					{
						Assert(m_hWnd);
						return ::SetFocus(m_hWnd);
					}

	BOOL			FMoveWindow(RECT* prc);
	BOOL			FMoveWindowNoUpdate(RECT* prc);
	BOOL			FSetWindowText(TCHAR* psz);
	BOOL			FIsVisible(void)
					{
						if (m_hWnd)
						{
							return ::IsWindowVisible(m_hWnd);
						}
						return FALSE;
					}

	BOOL			FRedrawWindow(void);

	BOOL			FGetClientRect(RECT* prc);
	BOOL			FGetWindowRect(RECT* prc);

	LONG			LGetWidth(void);
	LONG			LGetHeight(void);
	BOOL			FGetTextExtent(int idString, SIZE* psize, HWND hWnd=NULL);

	LRESULT			SendMessage(UINT uMsg);
	LRESULT			SendMessage(UINT uMsg, WPARAM wParam);
	LRESULT			SendMessage(UINT uMsg, LPARAM lParam);
	LRESULT			SendMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

	LRESULT			PostMessage(UINT uMsg);
	LRESULT			PostMessage(UINT uMsg, WPARAM wParam);
	LRESULT			PostMessage(UINT uMsg, LPARAM lParam);
	LRESULT			PostMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

protected:
	BOOL			FRegisterClass(HWND	hWndParent, WNDPROC pwp);
	void			UnregisterClass(void);
// Data
protected:
	HWND			m_hWnd;			// Le Pane.
	HWND			m_hWndParent;
	WNDPROC			m_wndProc;		// we subclass the chat pane

	BOOL			m_fRegistered;	// did this object register a class?
	TCHAR*			m_pszClass;
};
	 
#endif
