//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICLISTPANE__
#define __ICLISTPANE__

#include "icinc.h"
#include "icpane.h"
#include "iclstbox.h"
#include "ichistry.h"

//--------------------------------------------------------------------------------------------
// Pane with Member list box
class CChatListPane : public CChatPane
{
	friend	LRESULT CALLBACK ListBoxWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// interfaces
public:
	CChatListPane(void);
	~CChatListPane(void);
		
	BOOL		FAddMember(PCS_MSGBASE pcsMsg);
	BOOL		FDelMember(PCS_MSGBASE pcsMsg);
	BOOL		FUpdateMember(PCS_MSGBASE pcsMsg);
	BOOL		FUpdateNick(PCS_MSGBASE pcsMsg);
	BOOL		FChannelModeChange(PICS_CHANNEL pChannel);

	BOOL		FFreeAllMembers(void);

	int			IGetSelCount(void)	{ return m_cclb.IGetSelCount(); }
	
	BOOL		FChangeMemberStatus(int idCmd, PICS_CHANNEL pChan);
	BOOL		FWhisperToMembers(int idCmd, PICS_CHANNEL pChan, TCHAR* pszSend, CChatHistoryPane* pHist);
	BOOL		FShowMemberProps(void);
	
	BOOL		FDoContextMenu(short xPos, short yPos);

	CChatListBox*	PListBox(void)	{ return &m_cclb; }
	
	BOOL		FChangeStatus(PICS_MEMBER pcsMem, int idCmd, PICS_CHANNEL pChan=NULL);
protected:
	virtual BOOL	FInitElements(void);
	virtual BOOL	FHandleWMSize(WPARAM wParam, LPARAM lParam);

// Data
protected:
	CChatListBox	m_cclb;		// the chat list pane contains a list box 	
};

#endif
