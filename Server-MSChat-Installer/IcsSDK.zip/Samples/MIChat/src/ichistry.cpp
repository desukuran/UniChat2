//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "ichistry.h"
#include "icutil.h"
#include "icmain.h"

//////////////////////////////////////////////////////////////////////////////////////
// History Window Pane
CChatHistoryPane::CChatHistoryPane(void)
		: CChatPane()
{
	m_pszText = NULL;
	m_fBlank = FALSE;
}

CChatHistoryPane::~CChatHistoryPane(void)
{
	if (m_pszText)
	{
		delete [] m_pszText;
	}
}

BOOL CChatHistoryPane::FInitElements(void)
{
	// Override with out member proc
	SetWindowProc(HistoryWndProc);

	m_pszText = new TCHAR[CS_CCBMAX_MIC_MSG + 1];
	if (!m_pszText)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Init rich edit
	if (m_ui.FCreate(m_hWnd, ID_HISTORY, NULL))
	{
		// indent everything
		m_ui.IndentText(200);

		return TRUE;
	}
	
	return FALSE;
}

BOOL CChatHistoryPane::FHandleWMSize(WPARAM wParam, LPARAM lParam)
{
	// The mother pane got moved. Now we gotta move the babies
	RECT	rc;

	rc.left		= rc.top = 0;
	rc.right	= LOWORD(lParam);
	rc.bottom	= HIWORD(lParam);

	return m_ui.FMoveWindow(&rc);
}

// ANSI ONLY
BOOL CChatHistoryPane::FHandleMsg(PCS_MSGBASE pcsMsg, PICS_CHANNEL picsChannel)
{
	Assert(pcsMsg && picsChannel);

	BOOL	fRet = FALSE;
	BOOL	fScroll;

	PCS_MSG pMsg = (PCS_MSG)(pcsMsg + 1);
	if (!pMsg->pbData)
	{
		Assert(FALSE);
		return FALSE;
	}
	// If the focus is not in the history window,  then auto scroll it
	fScroll = (m_ui.HWnd() != GetFocus());
	return FInsertMsg(
					pMsg->picsFrom,			// the sender
					(CHAR *)pMsg->pbData, 	// the message to display
					picsChannel, 			// if it was from a channel
					fScroll, 				// auto scroll?
					(CSMSG_FLAG_WHISPER == pcsMsg->csMsgFlag) // was it a whisper
					);
}

BOOL CChatHistoryPane::FHandleWhisper(PCS_MSGBASE pcsMsg, PICS_CHANNEL picsChannel)
{
	Assert(pcsMsg && picsChannel);

	PCS_MSGWHISPER	pMsg;
	PCS_MSG			pMsgData;
	BOOL	fRet = FALSE;
	BOOL	fScroll;

	pMsg = (PCS_MSGWHISPER) (pcsMsg + 1);
	if (!pMsg->pcsMsg || !pMsg->prgMember || 0 == pMsg->dwcMem)
	{
		Assert(FALSE);
		return FALSE;
	}
	
	pMsgData = pMsg->pcsMsg;
	// If the focus is not in the history window,  then auto scroll it
	fScroll = (m_ui.HWnd() != GetFocus());

	return FInsertWhisper(
						pMsgData->picsFrom, 		// who is the msg from
						pMsg->dwcMem, 				// sent to how many members
						pMsg->prgMember, 			// the member list it was sent to
						(CHAR *)pMsgData->pbData, 	// the msg
						fScroll						// scroll?
						);
}

BOOL CChatHistoryPane::FInsertWhisper(PICS_MEMBER picsFrom, DWORD dwcMem, 
									PICS_MEMBER* prgMember, TCHAR* psz, BOOL fScroll)
{
	Assert(prgMember && psz);

	PICS_MEMBER pMem;
	DWORD	iMem;
	BOOL	fRet = FALSE;
	// Are we ignoring the bloke?
	if (NOERROR == picsFrom->HrIsMemberIgnored())
	{
		return TRUE;
	}

	if (dwcMem <= 0)
	{
		return FALSE;	// nothing to do
	}
	
	// Save current selection
	m_ui.SaveAndMoveSel();
	// Insert sender's name
	m_ui.TurnOnBold();
	if (picsFrom)
	{
		FInsertUserName(picsFrom, FALSE);
	}
	// Insert whispers
	m_ui.FInsertMsg(IDS_WHISPERLIST);
	m_ui.TurnOffBold();
	// Insert user names
	for (iMem = 0; iMem < dwcMem; ++iMem)
	{
		if (iMem > 0)	// put commas after every user except the first one
		{
			m_ui.FInsertMsg(IDS_COMMA);
		}
		pMem = prgMember[iMem];
		m_ui.FInsertMsg(IDS_SPACE); // whispers are seperated by spaces
		FInsertUserName(pMem, FALSE);
	}

	m_ui.FInsertMsg(IDS_USERNAMEEND);	// end
	// Now the msg
	m_ui.InsertText(psz);
	// Carriage return
	m_ui.CarriageReturn();
	if (FBlankLine())
	{
		m_ui.CarriageReturn();	// one more blank line
	}
	// And restore our selection
	m_ui.RestoreSel();
	if (fScroll)
	{
		m_ui.AutoScrollHistory();
	}
	
	return TRUE;
}

BOOL CChatHistoryPane::FInsertMsg(PICS_MEMBER pcsMem, TCHAR* psz, PICS_CHANNEL pChannel, 
								BOOL fScroll, BOOL fWhisper, BOOL fEcho)
{
	Assert(pChannel);

	DWORD dwFlags;
	BOOL fRoomChat;
	
	// Are we ignoring the bloke?
	if (pcsMem && NOERROR == pcsMem->HrIsMemberIgnored())
	{
		return TRUE;
	}

	if (FAILED(pChannel->HrGetFlags(&dwFlags)))
	{
		AssertSz(0, "HrGetFlags");
		return FALSE;
	}
	fRoomChat = (0 != (dwFlags & CS_CHANNEL_FLAG_ROOM));

	// m_csInsert.Lock();
	// Save current selection
	m_ui.SaveAndMoveSel();
	// For ROOM chats,  we do NO formatting,  period.. let the formatting be driven by
	// the server. Unless we do an ECHO,  in which case we put in the prompt..
	if (fRoomChat)
	{
		if (fEcho)
		{
			m_ui.FInsertMsg(IDS_PROMPT);
		}
		goto LDisplay;
	}
	// Display the user name
	// If pcsMem is NULL,  this indicates that the message came from the CHANNEL..
	// usually a Channel Service!
	if (pcsMem)
	{
		if (!FInsertUserName(pcsMem, !fWhisper))
		{
			goto LReturn;
		}
	}
	else
	{
		TCHAR szChannel[CS_CCHMAX_IRC_CHANNEL + 1];
		CHAR* szName = PszGetChannelName(pChannel, &szChannel[0]);
		m_ui.TurnOnBold();
		m_ui.FInsertMsg(IDS_CHATROOM, szName);
		m_ui.TurnOffBold();
		if (!fWhisper)		// if this is a whisper,  the code below will take care of this
		{
			m_ui.FInsertMsg(IDS_USERNAMEEND);
		}
	}

	if (fWhisper)
	{
		m_ui.TurnOnBold();

		m_ui.FInsertMsg(IDS_WHISPER);
		m_ui.FInsertMsg(IDS_USERNAMEEND);
		
		m_ui.TurnOffBold();
	}

LDisplay:
	// Display the msg
	m_ui.InsertText(psz);
	// Carriage return
	m_ui.CarriageReturn();
	if (FBlankLine())
	{
		m_ui.CarriageReturn();	// one more blank line
	}
	// And restore our selection
	m_ui.RestoreSel();
	if (fScroll)
	{
		m_ui.AutoScrollHistory();
	}

LReturn:
	//m_csInsert.Unlock();
	return TRUE;
}

BOOL CChatHistoryPane::FInsertUserName(PICS_MEMBER pcm, BOOL fEnd)
{
	Assert(pcm);

	// m_csInsert.Lock();
	BOOL fHost = (pcm->HrIsMemberHost() == NOERROR);

	m_ui.TurnOnBold();
	// Display the user name
	m_ui.FInsertMsg(fHost ? IDS_HOSTNAME : IDS_MESSAGE, PszGetName(pcm));
	// Terminate the user name
	if (fEnd)
	{
		m_ui.FInsertMsg(IDS_USERNAMEEND);
	}
	
	m_ui.TurnOffBold();

	//m_csInsert.Unlock();

	return TRUE;
}

// A user joined the channel
BOOL CChatHistoryPane::FHandleAddMember(PICS_MEMBER pcm)
{
	Assert(pcm);

	return FInsertSystemMsg(IDS_ADDMEMBER, PszGetName(pcm));
}

BOOL CChatHistoryPane::FHandleDelMember(PICS_MEMBER pcm)
{
	Assert(pcm);

	return FInsertSystemMsg(IDS_DELMEMBER, PszGetName(pcm));
}

BOOL CChatHistoryPane::FHandleModeChannel(PCS_MSGBASE pcsMsg)
{
	//return FInsertSystemMsg(IDS_CHANNELMODE, NULL);
	return FALSE;
}

BOOL CChatHistoryPane::FHandleNickChange(PCS_MSGBASE pcsMsg)
{
	PCS_NEWNICK pMsg = (PCS_NEWNICK)(pcsMsg + 1);

#ifndef UNICODE
	// Ignore Unicode
	if (pMsg->fAnsi)
	{
		FInsertSystemMsg(IDS_USERNEWNICK, PszGetName(pMsg->csMsgMember.picsMember), (TCHAR*)pMsg->pvOldNick);
	}
#else
	AssertSz(0, "No UNICODE code");
#endif
	return TRUE;
}

BOOL CChatHistoryPane::FHandleModeChannel(PICS_MEMBER pcm)
{
	DWORD dwMsgID;
	PVOID pv;
	DWORD dwMode;
	DWORD dwPrevMode = 0; // previous mode
	BOOL fRet = TRUE;

	if (FAILED(pcm->HrGetMemberMode(&dwMode)))	// get current mode
	{
		AssertSz(0, "HrGetMemberMode");
		return FALSE;
	}
	
	pcm->HrGetMemberData(&pv);	// retrieve previous mode
	dwPrevMode = (DWORD)pv;
	// What changed?
	dwPrevMode ^= dwMode;
	// Did a user's speaking or host rights change?
	if (dwPrevMode & (CS_MEMBER_HOST | CS_MEMBER_SPEAKER | CS_MEMBER_SPECTATOR))
	{
		// Let the user know that somebody's priviledges changed
		if (NOERROR == pcm->HrIsMemberHost())
		{
			dwMsgID = IDS_USERISHOST;
		}
		else if (NOERROR == pcm->HrIsMemberSpeaker())
		{
			dwMsgID = IDS_USERISSPEAKER;
		}
		else 
		{
			dwMsgID = IDS_USERISSPECTATOR;	// spectator
		}
		fRet = FInsertSystemMsg(dwMsgID, PszGetName(pcm));
	}
	// Save the new mode in the member 
	pcm->HrSetMemberData((PVOID)dwMode);
		
	return fRet;
}

BOOL CChatHistoryPane::FInsertSystemMsg(DWORD dwMsgId, TCHAR *psz, TCHAR *szPrefix)
{
	// Scroll if focus is not in the History window
	BOOL fScroll = (m_ui.HWnd() != GetFocus());

	m_ui.SaveAndMoveSel();
	// insert a prefix,  if any
	if (szPrefix)
	{
		m_ui.TurnOnBold();
		m_ui.InsertText(szPrefix);
		m_ui.TurnOffBold();
	}
	// Turn on bolding
	m_ui.TurnOnBold();
	// insert text
	if (dwMsgId)
	{
		m_ui.FInsertMsg(dwMsgId, psz);
	}
	else
	{
		m_ui.InsertText(psz);
	}
	// Turn off bolding 
	m_ui.TurnOffBold();
	// Append \r\n
	m_ui.CarriageReturn();
	if (FBlankLine())
	{
		m_ui.CarriageReturn();	// one more blank line
	}
	// And restore our selection
	m_ui.RestoreSel();
	if (fScroll)
	{
		m_ui.AutoScrollHistory();
	}
	return TRUE;
}

TCHAR* CChatHistoryPane::PszGetName(PICS_MEMBER pcm)
{
	Assert(pcm);

	BOOL	fAnsi;
	BYTE*	pb;

	if (FAILED(pcm->HrGetName(&pb, &fAnsi)))
	{
		AssertSz(0, "HrGetName");
		return NULL;
	}
	// If this is an ANSI client,  convert all Unicode strings into ANSI
	// Else,  do the reverse
#ifdef UNICODE
	AssertSz(0, "Not implemented");
#else
	if (!fAnsi)	// unicode name. convert it to ansi
	{
		if (!FWideCharToAnsi((WCHAR*)pb, m_szConvert, CS_CCHMAX_MIC_USERNAME + 1))
		{
			return NULL;
		}
		return m_szConvert;
	}
#endif
	return (TCHAR*)pb;

}

BOOL CChatHistoryPane::FSave(BOOL fSaveAs)
{
	TCHAR	szFileName[MAX_PATH];
	DWORD	dwIndex;
	// If SaveAs,  or never saved,  put up the saveAs dialog
	if (fSaveAs || !m_ui.FIsSaved())
	{
		fSaveAs = TRUE;
		if (!FSaveAsDialog(HInstance(m_hWnd), m_hWndParent, (TCHAR *)szFileName, MAX_PATH, &dwIndex))
		{
			return FALSE;
		}
	}
	// Save the blighter
	if (fSaveAs)
	{
		return m_ui.FSaveAs((TCHAR*)szFileName, dwIndex);
	}
	return m_ui.FSave((TCHAR*)szFileName);
}

//////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK HistoryWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL	fRet;

	CChatHistoryPane* pchp = (CChatHistoryPane*)GetWindowLong(hWnd, GWL_USERDATA);
	if (pchp)
	{
		switch(uMsg)
		{
		default:
			break;
		
		case WM_NOTIFY:
			NMHDR*	pnhmdr;

			pnhmdr = (NMHDR*)lParam;
			switch (pnhmdr->code)
			{
			default:
				return FALSE;
			
			case EN_LINK:
				fRet = pchp->m_ui.FHandleLink((ENLINK*)lParam);
				SetWindowLong(hWnd, DWL_MSGRESULT, fRet);
				return TRUE;
			}
			break;
		
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			default:
				break;
			
			case IDC_SEND:
			case IDC_WHISPER:
			case IDC_TABKEY:
			case IDC_TABKEYSHIFT:
				return pchp->FGiveMsgToParent(WM_COMMAND, wParam, 0);
			}
			break;
		}
		return pchp->LrCallWindowProc(uMsg, wParam, lParam);
	}
	return (DefWindowProc(hWnd, uMsg, wParam, lParam));
}
