/*--------------------------------------------------------------------------*
	fontclr.h
	Copyright (c) Microsoft Corporation, 1995-96. 
	All Rights Reserved.
	
	Description:
		Routines and objects in this file maintain a font and color
		selection property sheet/dialog.
		ALL objects here are generic and can be used by ANYBODY outside
		Textchat.

	Authors:
		Started: Oct 1995, Umesh Madan
*--------------------------------------------------------------------------*/

/*---------------------------*Includes*------------------------------------*/
#ifndef __FONTCLR__
#define __FONTCLR__

#include "icinc.h"
/*---------------------------*Defines*-------------------------------------*/
#define	CCF_FONTCHG		0x0001
#define CCF_SIZECHG		0x0002
#define CCF_COLORCHG	0x0004
#define CCF_BAKCOLORCHG	0x0008
#define CCF_ALL			255

/*---------------------------*Types*---------------------------------------*/
// Format for UI Elements.
// Pass in colors, fonts and sizes in this.. to CFontColorSheet and FONTCOLORINFO
typedef struct ColorCharFormat
{
	BYTE		fModified;	// did the data in here change recently..if so, may have to redraw..
	char*		pszName;	// string used to represent this element.
	COLORREF	cref;		// default color to display. Will contain new COLORREF on return.
	COLORREF	crefBak;	// default back color
	CHARFORMAT	cformat;	// default font & size to display. Will contain new CHARFORMAT on return.
} COLORCHARFORMAT, *PCCF;

// Struct used to exchange info with CFontColorSheet
typedef struct FontColorInfo
{
	HINSTANCE	hInst;				// app/dll instance
	HWND		hWndParent;			// parent window.
	int			idDlg;				// id of the dlg/sheet to display
	int			idFontCombo;		// id of font combo box: -1 means none..
	int			idSizeCombo; 		// id of size combo box: -1 means none
	int			idBtnColor;			// id of color combo box: -1 means none..
	int			idBtnColorBak;		// id of color combo box BAK: -1 means none..
	int			idEditSample;		// id of edit text box for samples -1 means none..
	int			idElementCombo;		// ifd of elements combo box, if any.. -1 if none..
	PCCF		pccf;				// pointer to an array of element specific information..
	DWORD		dwcElements;		// how many elements...	MUST be ATLEAST 1...
	int			idElementDef;		// default element to display
} FONTCOLORINFO, *PFCI;

#ifdef NOTNOW

/*---------------------------*Public*--------------------------------------*/
COLORREF ColorRefGet(int index, BOOL fTextColor=TRUE);

/*---------------------------*Classes*--------------------------------------*/

// A class to display a color selection popup
class CColorPopUp
{
friend LRESULT CALLBACK ColorPopUpProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CColorPopUp(HINSTANCE hInst=NULL, int idColor=0);
	~CColorPopUp(void);
	BOOL			FShowPopUp(HWND hWndParent, RECT* prc, COLORREF cref);
	COLORREF		ColorRef();
	COLORREF		ColorRefBak();				
	void			SetColorRef(COLORREF cref);
	int				IdColor(void)	{ return m_idColor; }

	int				IndexColor(void)	{ return m_index; }
protected:
	BOOL			FFillColorMenu(void);
	virtual BOOL	FMeasureColorItem(HWND	hWnd, MEASUREITEMSTRUCT* pmis);
	virtual	BOOL	FDrawColorMenu(const HWND hWnd, const DRAWITEMSTRUCT* pdis) const;
	virtual	BOOL	FDrawColorName(const int xStart, const DRAWITEMSTRUCT* pdis) const;
// Data
protected:
	int				m_index;		// previous selection
	HWND			m_hWndParent;	// we need to send messages to the parent..
	int				m_idColor;		// id of first color string
	static 	int				m_i;			// global selection
	static 	HINSTANCE		m_hInst;		// instance of the application
	static 	HWND			m_hWnd;  		// Private window, to handle msgs from Menus
	static 	HMENU			m_hMenu;		// color menu
	static	DWORD			m_dwRefCount;	// ref count of usage..
};

// A class to display a color selected from CColorPopUp (below) on a standard button
// Subclasses the button id you provide in the constructor.
class CColorButton
{
	friend LRESULT CALLBACK ColorButtonProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CColorButton(int idBtn, BOOL fFore = TRUE);
	~CColorButton(void);
	BOOL			FInit(HWND hDlg);
	void			SetColor(int indexColor);
//	Data
protected:
	WNDPROC			m_wndProc;
	int				m_idBtn;
	int				m_indexColor;
	HWND			m_hWnd;
	BOOL			m_fForeOrBak;		// fore or back color?
};

// A class to display and manage a font Combo box
class CFontComboBox
{
// Interfaces
public:
	CFontComboBox(void);
	BOOL			FMakeFontComboBox(HWND hWndParent, HWND hWnd, int idCombo, int index=0);
	BOOL 			FGetFontCharFormat(CHARFORMAT* pcf);
	BOOL			FSetDefaultFont(CHARFORMAT* pcf);

	static	int CALLBACK 	FillFontNameProc(ENUMLOGFONTEX* pelfe, NEWTEXTMETRIC* pntm, int nFontType, LPARAM lParam);

protected:
	int 			FindFont(LPCSTR lpcFontName, BYTE bCharSet) const;

// Data
protected:
	HWND			m_hWnd;			// the parent window..
	HWND			m_hWndCtl;		// the combo box window..
	int				m_id;			// combo box id..
};

// A class to display Font sizes..
class CSizeComboBox
{
// Interfaces
public:
					CSizeComboBox(void);
	BOOL			FMakeSizeComboBox(HWND hWndParent, HWND hWnd, int idCombo, int index=0);
	BOOL			FGetFontSize(long* plsize);
	BOOL			FSetFontSize(long lsize);
// Data
protected:
	HWND			m_hWnd;			// the parent window..
	HWND			m_hWndCtl;		// the combo box window..
	int				m_id;			// combo box id..
};

// A class to display and manage a Font & Color property sheet.
class CFontColorSheet
{
	friend BOOL CALLBACK FontColorDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam); 
// Interfaces
public:
	CFontColorSheet(void);
	~CFontColorSheet(void); 
	BOOL			FCreateFontColorSheet(PFCI pfci);	
	int				CreateFontColorDialog(PFCI pfci);
	HPROPSHEETPAGE*	PHPropSheetPage(void)	{ m_fDelete = FALSE; return &m_hpsp; }
	HPROPSHEETPAGE	HPropSheetPage(void)	{ m_fDelete = FALSE; return m_hpsp; }
protected:
    BOOL			FInit(void);
	BOOL			FMakePropertySheet(void);

	BOOL			FFillElements(void);
	BOOL			FDoElementChange(void);
	BOOL			FDoColor(void);
	BOOL			FDoColorBak(void);
	BOOL			FColorSample(void);
	BOOL			FColorBakSample(void);
	BOOL			FFontSample(void);
	BOOL			FSizeSample(void);
// Override this to do your own drawing..
	virtual BOOL	FDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual	void	Changed(BYTE flag)	{ m_pfci->pccf[m_iElement].fModified |= flag; }
	virtual void	ResetChanged()		{ m_pfci->pccf[m_iElement].fModified = FALSE; }
	CHARFORMAT*		PCharFormat(void)	{ return (&m_pfci->pccf[m_iElement].cformat); }

private:
	BOOL			FInitCharFormat(CHARFORMAT* pcf, HWND* phWnd);
	BOOL			FElementChange(HWND hWnd);
// Data
protected:
	HWND			m_hDlg;  		// dialog 
	PFCI			m_pfci;			// info is swapped with user through this..
	int				m_iElement;		// currently selected UI element..(from drop down combo)
	int				m_iRet;			// what to return
	BOOL			m_fSheet;		// true if this is a property sheet. Currently ignored.

	BOOL			m_fDelete;		// should we delete this ourselves?
	HPROPSHEETPAGE	m_hpsp;			// handle to a created property sheet page..
	//
	// Colors, fonts and sizez
	//
	BOOL			m_fForeColor;	// pop ups for fore or bak colors?
	CColorPopUp*	m_pcpop;		// color popup
	CColorPopUp*	m_pcpopBak;		// bak color popup
	CFontComboBox*	m_pfcb;			// font combo box.
	CSizeComboBox*	m_pscb;			// size combo box
	CColorButton*	m_pcbFore;		// fore color button
	CColorButton*	m_pcbBack;		// back color button
};

// A Font and Class Dialog WITH Reset Button
class CFontColorSheetReset:public CFontColorSheet
{
// Interfaces
public:
	CFontColorSheetReset(int idBtnReset);
	// Did the user Reset?
	BOOL			FReset(void)	{ return m_fReset; }
protected:
	virtual BOOL	FDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam); 
	virtual	void	Changed(BYTE flag)	{ m_fReset = FALSE; CFontColorSheet::Changed(flag); }
protected:
	int				m_idBtnReset;
	BOOL			m_fReset;
};

#endif

#endif
