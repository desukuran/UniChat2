//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icfind.h"
#include "icmain.h"
#include "icwizard.h"

CSPROP_TYPE g_rgChannelProps[] =
{
	CSPROP_CHANNEL_CUSER, 
	CSPROP_CHANNEL_TOPIC
};

const int CRGCHANNELPROPS = 2;

CFindDlg* CFindDlgGet(HWND hDlg, UINT uMsg, LPARAM lParam);

//////////////////////////////////////////////////////////////////////////////////////
// List Box pane
CChatFindPane::CChatFindPane(void)
	:CChatPane(), CRefCount()
{
	m_hCurItem		= NULL;
	m_fWaiting		= FALSE;
	m_fForceExpand	= FALSE;
	m_hCursor		= NULL;
	m_hCursorWait	= NULL;
	SetWaiting(FALSE);
}

CChatFindPane::~CChatFindPane(void)
{
}

BOOL CChatFindPane::FInitElements(void)
{
	// Override the current wnd proc
	SetWindowProc(TreeViewWndProc);
	// Create the tree view control
	if (!m_cctv.FCreate(m_hWnd, ID_FINDTREEVIEW, NULL) || !m_cctv.FAddRoot("The Net"))
	{
		return FALSE;
	}
	// Load up the Wait Cursor
	m_hCursorWait = ::LoadCursor(NULL, IDC_WAIT);

	return (NULL != m_hCursorWait);
}

BOOL CChatFindPane::FWaiting(void)
{
	m_csMod.Lock();
	BOOL fRet = m_fWaiting;
	m_csMod.Unlock();
	return fRet;
}

void CChatFindPane::SetWaiting(BOOL fWait)
{
	m_csMod.Lock();
	m_fWaiting = fWait;
	m_csMod.Unlock();
}

BOOL CChatFindPane::FForcedExpand(void)
{
	m_csMod.Lock();
	BOOL fRet = m_fForceExpand;
	m_csMod.Unlock();
	return fRet;
}

void CChatFindPane::SetForcedExpand(BOOL fForce)
{
	m_csMod.Lock();
	m_fForceExpand = fForce;
	m_csMod.Unlock();
}

BOOL CChatFindPane::FInsertChannel(PICS_PROPERTY picsProperty)
{
	// It is possible that this is called while m_hWnd has already been destroyed.
	// This could happen because icmain, which owns ICSocket, may have an open pointer to
	// the find pane.. because we may still be receiving data from the server from a previous
	// query.
	// That is why we use this lock thing..
	BOOL fRet;
	m_csMod.Lock();
	if (m_hWnd)
	{
		fRet = FAddChannel(picsProperty);
	}
	m_csMod.Unlock();
	return fRet;
}

BOOL CChatFindPane::FInsertMember(PICS_PROPERTY picsProperty)
{
	BOOL fRet;
	m_csMod.Lock();
	if (m_hWnd)
	{
		fRet = FAddMember(picsProperty);
	}
	m_csMod.Unlock();
	return fRet;
}

BOOL CChatFindPane::FInsertUser(PICS_PROPERTY picsProperty)
{
	BOOL fRet;
	m_csMod.Lock();
	if (m_hWnd)
	{
		fRet = m_cctv.FAddUser(picsProperty);
	}
	m_csMod.Unlock();
	return fRet;
}

BOOL CChatFindPane::FAddChannel(PICS_PROPERTY picsProperty)
{
	return FAddChannelMember(picsProperty, CSINDEX_PROP_CHANNEL_MODE);
}

BOOL CChatFindPane::FAddMember(PICS_PROPERTY picsProperty)
{
	return FAddChannelMember(picsProperty, CSINDEX_PROP_MEMBER_MODE, TRUE);
}

BOOL CChatFindPane::FAddChannelMember(PICS_PROPERTY picsProperty, int index, BOOL fMember)
{
	Assert(picsProperty);

	if (FAILED(picsProperty->HrGetProperty(&m_csPropData, index)))
	{
		AssertSz(0, "HrGetProperty");
		return NULL;
	}
	
	Assert(m_csPropData.pbData && !m_csPropData.fString);
	DWORD dwMode = *((DWORD*)m_csPropData.pbData);

	if (fMember)
	{
		return m_cctv.FAddMember(picsProperty, dwMode, m_hCurItem);
	}
	return m_cctv.FAddChannel(picsProperty, dwMode);
}

BOOL CChatFindPane::FLookUpError(void)
{
	BOOL fRet;
	if (m_hCurItem)
	{
		fRet = m_cctv.FDeleteItem(m_hCurItem);
		FDoneLookup();
	}
	return fRet;
}

BOOL CChatFindPane::FNoDataOnLookUp(void)
{
	BOOL fRet = FALSE;

	m_hCurItem = NULL;
	FDoneLookup();
	return fRet;
}

BOOL CChatFindPane::FGotFirstChannel(void)
{
	// Make sure that the Channel node is collapsed
	TreeView_Expand(m_cctv.HWnd(), m_cctv.HtiChannel(), TVE_COLLAPSE | TVE_COLLAPSERESET);

	return TRUE;
}

BOOL CChatFindPane::FGotFirstMember(void)
{
	// Make sure that the Channel node is collapsed
	TreeView_Expand(m_cctv.HWnd(), m_hCurItem, TVE_COLLAPSE | TVE_COLLAPSERESET);

	return TRUE;
}

BOOL CChatFindPane::FGotFirstUser(void)
{
	// Make sure that the Channel node is collapsed
	TreeView_Expand(m_cctv.HWnd(), m_cctv.HtiUsers(), TVE_COLLAPSE | TVE_COLLAPSERESET);

	return TRUE;
}

BOOL CChatFindPane::FGotAllChannels(void)
{
	SetForcedExpand(TRUE);
	m_cctv.FExpandChats();
	SetForcedExpand(FALSE);
	
	return FGotAll(NULL);
}

BOOL CChatFindPane::FGotAllMembers(void)
{
	return FGotAll(m_hCurItem);
}

BOOL CChatFindPane::FGotAllUsers(void)
{
	SetForcedExpand(TRUE);
	m_cctv.FExpandUsers();
	SetForcedExpand(FALSE);
	return FGotAll(NULL);
}

BOOL CChatFindPane::FGotAll(HTREEITEM htiParent)
{
	// Manually expand this node
	BOOL fRet;
	if (htiParent)
	{
		SetForcedExpand(TRUE);
		fRet = m_cctv.FExpandNode(htiParent);
		SetForcedExpand(FALSE);
	}
	FDoneLookup();
	return fRet;
}

BOOL CChatFindPane::FDoneLookup(void)
{
	// Manually expand this node
	m_hCurItem = NULL;
	// No longer waiting
	SetWaiting(FALSE);
	if (m_hCursor)
	{
		SetCursor(m_hCursor);
		m_hCursor = NULL;
	}
	return TRUE;
}

DWORD CChatFindPane::DwGetNodeType(PICS_PROPERTY picsProperty)
{
	Assert(picsProperty);

	DWORD dwFlag = 0;

	if (FAILED(picsProperty->HrGetPrivateData((PVOID*)&dwFlag)))
	{
		AssertSz(0, "HrGetPrivateData");
		dwFlag = 0;
	}
	return dwFlag;
}

BOOL CChatFindPane::FUpdateProperty(PICS_PROPERTY picsProperty)
{
	DWORD	dwFlag = 0;

	if (!m_hCurItem)
	{
		return FALSE;
	}

	PICS_PROPERTY picsPropPrev = m_cctv.PicsPropertyGet(m_hCurItem);
	if (picsPropPrev)
	{
		dwFlag = DwGetNodeType(picsPropPrev);
		picsPropPrev->Release();
	}

	if (picsProperty)
	{
		if (FAILED(picsProperty->HrSetPrivateData((PVOID)dwFlag)))
		{
			AssertSz(0, "HrSetPrivateData");
		}
		picsProperty->AddRef();
	}

	if (m_cctv.FSetPicsProperty(m_hCurItem, picsProperty))
	{
		return m_cctv.FRedrawItem(m_hCurItem);
	}
	return FALSE;
}

BOOL CChatFindPane::FAutoJoinChannel(TCHAR* szName)
{
	Assert(szName);
	// Do an autojoin only if the tree view is in focus
	if (GetFocus() != m_cctv.HWnd())
	{
LManual:
		szName[0] = '\0';
		return FALSE;
	}
	// get the current selection
	HTREEITEM hItem = m_cctv.HtiGetSelection();
	if (!hItem)
	{
		goto LManual;
	}
	// Get the property. From that get the channel name, and then join 
	PICS_PROPERTY picsProp = m_cctv.PicsPropertyGet(hItem);
	// If this is not a channel node, do the regular join
	if (!picsProp || !m_cctv.FIsChannel(picsProp)) 
	{
		goto LManual;
	}

	lstrcpy(szName, PszGetDisplaySz(picsProp, CSINDEX_PROP_CHANNEL_NAME, m_szConvert));

	return TRUE;
}

BOOL CChatFindPane::FHandleWMSize(WPARAM wParam, LPARAM lParam)
{
	// Parent window got resized. Resize child list box
	RECT	rc;
	rc.top		= 0;
	rc.left		= 0;
	rc.right	= LOWORD(lParam);
	rc.bottom	= HIWORD(lParam);
	if (!m_cctv.FMoveWindowNoUpdate(&rc))
	{
		return FALSE;
	}
	m_cctv.FRedrawWindow();
	return FRedrawWindow();
}

TCHAR* CChatFindPane::PszGetDisplaySz(PICS_PROPERTY picsProperty, DWORD dwIndex, TCHAR* szConvert)
{
	Assert(picsProperty);
	// Get the data
	if (FAILED(picsProperty->HrGetProperty(&m_csPropData, dwIndex)))
	{
		AssertSz(0, "HrGetProperty");
		return NULL;
	}
	Assert(m_csPropData.pbData && m_csPropData.fString);
	// If this is an ANSI client, convert all Unicode strings into ANSI
	// Else, do the reverse
#ifdef UNICODE
	AssertSz(0, "Not implemented");
#else
	if (!m_csPropData.fAnsi)	// unicode string. convert it to ansi
	{
		if (!FWideCharToAnsi((WCHAR*)m_csPropData.pbData, (TCHAR*)&m_szConvert, MAX_PATH))
		{
			return NULL;
		}
		return m_szConvert;
	}
#endif	
	return (TCHAR*)m_csPropData.pbData;
}

// Display the member
LRESULT CChatFindPane::LGetMemberDispInfo(TV_DISPINFO* ptvInfo, PICS_PROPERTY picsProperty)
{
	Assert(ptvInfo && picsProperty);

	// Get the member name
	TCHAR* psz = PszGetDisplaySz(picsProperty, CSINDEX_PROP_MEMBER_NAME, m_szConvert);
	if (!psz)
	{
		return FALSE;
	}

	// ptvInfo->item.pszText = psz;
	::lstrcpyn(ptvInfo->item.pszText, psz, ptvInfo->item.cchTextMax);

	return TRUE;
}

LRESULT CChatFindPane::LGetDispInfo(TV_DISPINFO* ptvInfo)
{
	PICS_PROPERTY picsProperty;
	TCHAR* sz;
	TCHAR* szTopic;
	DWORD cUser;

	m_szDisplay[0] = '\0';
	picsProperty = (PICS_PROPERTY)(ptvInfo->item.lParam);
	if (!picsProperty)
	{
		return FALSE;
	}
	// Is this a channel, or a member/user?
	if (m_cctv.FIsMember(picsProperty) || m_cctv.FIsUser(picsProperty))
	{
		return LGetMemberDispInfo(ptvInfo, picsProperty);
	}
	// Display the channel
	// Get the current user count
	if (FAILED(picsProperty->HrGetProperty(&m_csPropData, CSINDEX_PROP_CHANNEL_CUSER)))
	{
		AssertSz(0, "HrGetProperty");
		return NULL;
	}
	Assert(sizeof(DWORD) == m_csPropData.dwcb);
	cUser = *((DWORD*)m_csPropData.pbData); // save it
	// Get the channel name
	sz = PszGetDisplaySz(picsProperty, CSINDEX_PROP_CHANNEL_NAME, m_szConvert);
	if (!sz)
	{
		return FALSE;
	}
	// Get the topic
	szTopic = PszGetDisplaySz(picsProperty, CSINDEX_PROP_TOPIC, m_szConvert1);
	if (!szTopic)
	{
		return FALSE;
	}
	// Build the output
	wsprintf(m_szDisplay, "%s (%d): %s", sz, cUser, szTopic);
	
	// ptvInfo->item.pszText = m_szDisplay;
	::lstrcpyn(ptvInfo->item.pszText, m_szDisplay, ptvInfo->item.cchTextMax);
	
	return TRUE;
}

LRESULT CChatFindPane::LDeleteItem(LPNM_TREEVIEW ptv)
{
	PICS_PROPERTY picsProperty = (PICS_PROPERTY)(ptv->itemOld.lParam);
	if (picsProperty)
	{
		picsProperty->Release();
	}
	
	return TRUE;
}

BOOL CChatFindPane::FFolderItemExpanded(HTREEITEM htiItem)
{
	Assert(htiItem);

	int idCmd;
	// Handle Channel Folders specially
	if (htiItem == m_cctv.HtiChannel())
	{
		idCmd = IDC_LISTCHANNELS;
	}
	else if (htiItem == m_cctv.HtiUsers())
	{
		idCmd = IDC_LISTUSERS;
	}
	else if (htiItem == m_cctv.HtiRoot())
	{
		return FALSE;
	}
	// Do a full re-list, because the user expanded a Folder
	return FGiveMsgToParent(WM_COMMAND, MAKEWPARAM(idCmd, 0), 0);
}

BOOL CChatFindPane::FDisablePane(void)
{
	// Turn the Chat Find pane into a wait machine
	m_hCursor = ::SetCursor(m_hCursorWait);
	// Disable the tree control until further notice
	SetWaiting(TRUE);

   return TRUE;
}

LRESULT CChatFindPane::LItemExpanded(LPNM_TREEVIEW ptv)
{
	Assert(ptv);

	if (FForcedExpand() && TVE_EXPAND == ptv->action)
	{
		return FALSE;
	}
	if (FWaiting())
	{
		return TRUE;	// we are waiting for data. Let the user do NOTHING
	}
	
	switch (ptv->action)
	{
	default:
		return FALSE;

	case TVE_EXPAND:
		break;
	
	case TVE_COLLAPSE:
		if (ptv->itemNew.hItem != m_cctv.HtiRoot())
		{
			TreeView_Expand(m_cctv.HWnd(), ptv->itemNew.hItem, TVE_COLLAPSE | TVE_COLLAPSERESET);
			return TRUE;
		}
		return FALSE;
	}

	if (m_cctv.FIsFolder(ptv->itemNew.hItem))
	{
		return FFolderItemExpanded(ptv->itemNew.hItem);
	}

	PICS_PROPERTY	picsProperty = m_cctv.PicsPropertyGet(ptv->itemNew.hItem);
	if (!picsProperty)
	{
		AssertSz(0, "uh oh, this shouldn't happen");
		return FALSE;
	}
	// Do a full lookup
	m_hCurItem = ptv->itemNew.hItem;	// save this.. we will want to add stuff here later
	// Disable the tree control until further notice
	FDisablePane();
	// Dispatch a property lookup
	AddRef();
	if (!::FGetLatestChannelProps(this, picsProperty, CSINDEX_PROP_ID))
	{
		Release();
		// We want to keep going..because we should at least refresh the member list.
	}
	// And dispatch the member query
	AddRef();
	if (!::FListAllMembers(this, picsProperty, CSINDEX_PROP_ID))
	{
		Release();
		SetWaiting(FALSE);
		SetCursor(m_hCursor);	// restore original
		m_hCursor = NULL;
	}
	
	return TRUE;
}

LRESULT CChatFindPane::LHandleNotify(LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	if (!pnhmdr)
	{
		AssertSz(0, "Whoa! Big trouble!");
		return FALSE;
	}
	switch (pnhmdr->code)
	{
	default:
		return FALSE;
	
	case TVN_DELETEITEM:
		return LDeleteItem((LPNM_TREEVIEW)lParam);

	case TVN_GETDISPINFO:
		return LGetDispInfo((TV_DISPINFO*)lParam);
	
	case TVN_ITEMEXPANDING:
		// we catch the expanding..and use this to generate a server query.
		// When that query succeeds, we manually expand this node
		return LItemExpanded((LPNM_TREEVIEW)lParam);
	
	case TVN_KEYDOWN:
		TV_KEYDOWN* ptvk;
		int idCmd;
		
		ptvk = ((TV_KEYDOWN*)lParam);
		Assert(ptvk);
		
		switch (ptvk->wVKey)
		{
		default:
			break;

		case VK_TAB:
		case VK_F6:
			idCmd = (::GetAsyncKeyState(VK_SHIFT) & 0x8000) ? IDC_TABKEYSHIFT : IDC_TABKEY;
			return FGiveMsgToParent(WM_COMMAND, MAKEWPARAM(idCmd, 0), 0);
		}
		break;
	}
	return fRet;
}

extern CIChatMain gciChat;

BOOL CChatFindPane::FDoContextMenu(short xPos, short yPos)
{
	// this has to be really complicated, because we need to show different menus 
	// depending on what's selected.  whee.
	HMENU		hmenu;
	RECT		rect;
	RECT		rectItem;
	HTREEITEM	hitem;
	int			imenu;
	
	// first, we need to determine which element is selected.
	hitem = TreeView_GetSelection(m_cctv.HWnd());
	if (!hitem)
	{
		return TRUE;
	}
	// next, we need to figure out what kind of item it is.  there are five cases:
	// 1) this is the root.  show no context menus.
	if (m_cctv.FIsRoot(hitem))
	{
		return TRUE;
	}
	// 2-3) chats folder or users folder
	if (hitem == m_cctv.HtiChannel())
	{
		imenu = imenuChannelFolder;
	}
	else if (hitem == m_cctv.HtiUsers())
	{
		imenu = imenuUsersFolder;
	}
	else
	{
		// 4) individual chat is selected
		if (m_cctv.FIsChannel(hitem))
		{
			imenu = imenuChannel;
		}
		else
		{
			// 5) individual member or user is selected
			if (m_cctv.FIsMember(hitem))
			{
				imenu = imenuMemBrowser;
			}
			else if (m_cctv.FIsUser(hitem))
			{
				imenu = imenuUser;
			}
			else
			{
				AssertSz(0, "Unknown tree view folder!");
			}
		}
	}
	hmenu = gciChat.Hmenu(imenu);

	// if we got this via shift-f10, the position is bogus and we should adjust.
	if (xPos == -1 || yPos == -1)
	{
		GetWindowRect(m_cctv.HWnd(), &rect);
		if (hitem)
		{
			// there's an item selected.  put the menu on it.
			TreeView_GetItemRect(m_cctv.HWnd(), hitem, &rectItem, TRUE);
			xPos = (short)(((rectItem.right - rectItem.left) / 2) + rectItem.left + rect.left);
			yPos = (short)(((rectItem.bottom - rectItem.top) / 2) + rectItem.top + rect.top);
		}
		else
		{
			// no selection--put it in the top of the window.
			xPos = (short)rect.left;
			yPos = (short)rect.top;
		}
	}
	::TrackPopupMenu(hmenu, TPM_LEFTALIGN | TPM_RIGHTBUTTON, xPos, yPos, 0, m_hWndParent, NULL);
	return TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK TreeViewWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LONG lData = ::GetWindowLong(hWnd, GWL_USERDATA);
	Assert(0xffffffff != lData);
	if (0 != lData)
	{
		CChatFindPane* pcfp = (CChatFindPane*)lData;
		switch (uMsg)
		{
		default:
			break;

		case WM_NOTIFY:
			return pcfp->LHandleNotify(lParam);

		case WM_CONTEXTMENU:
			return pcfp->FDoContextMenu((short)LOWORD(lParam), (short)HIWORD(lParam));

		case WM_CLOSE:
			// Just hide the window
			pcfp->HideWindow();
			return TRUE;
		
		case WM_DESTROY:
			// Make sure we don't destroy the window while we are using it!
			pcfp->m_csMod.Lock();
			pcfp->m_hWnd = NULL;
			pcfp->m_csMod.Unlock();
			break;
		
		case WM_SETCURSOR:
			if (pcfp->m_hCursor && pcfp->m_hCursorWait)
			{
				SetCursor(pcfp->m_hCursorWait);
				return TRUE;
			}
			break;
		}
		return pcfp->LrCallWindowProc(uMsg, wParam, lParam);
	}
	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}

//////////////////////////////////////////////////////////////////////////////////////
// FIND DIALOGS
CFindDlg::CFindDlg(void)
	: CChatPropertyPage()
{
	m_szFind[0]	= '\0';
	m_dwMax		= 100;
	m_dwMin		= 1;
	m_fContains	= TRUE;
}

CFindDlg::~CFindDlg(void)
{
}

BOOL CFindDlg::FFindDlg(HWND hWndParent)
{
	Assert(hWndParent);
	// Init the Property Sheet. 1 page for now
	// Also add the property sheet pages
	Reset();
	if (!FInit(hWndParent, 1, PSH_NOAPPLYNOW, IDS_FIND_DLGTITLE) ||
		!FAddPage(IDD_FINDEASY, FindDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Display and do the dialog. Note, this will return ONLY when the dialog is DONE
	return FShow();
}

BOOL CFindDlg::FFindMemberDlg(HWND hWndParent)
{
	Assert(hWndParent);
	// Init the Property Sheet. 1 page for now
	// Also add the property sheet pages
	Reset();
	if (!FInit(hWndParent, 1, PSH_NOAPPLYNOW, IDS_FIND_MEMBERDLGTITLE) ||
		!FAddPage(IDD_FINDMEMBER, FindMemberDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Display and do the dialog. Note, this will return ONLY when the dialog is DONE
	return FShow();
}

BOOL CFindDlg::FInitFindDlg(HWND hDlg)
{
	Assert(hDlg);
	// Its ok for centering to fail
	FCenter(hDlg);
	// Limit text and so forth.
	// FIX ME - Read this in from the Registry!
	if (!::FEditBoxLimitText(hDlg, IDC_EDITFINDCHANNEL, CS_CCHMAX_QUERY_STRING) ||
		!::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITFINDCHANNEL), (TCHAR *)m_szFind) ||
		!::SetDlgItemInt(hDlg, IDC_EDITFINDMAXUSER, (UINT)m_dwMax, FALSE) ||
		!::SetDlgItemInt(hDlg, IDC_EDITFINDMINUSER, (UINT)m_dwMin, FALSE))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

BOOL CFindDlg::FInitFindMemberDlg(HWND hDlg)
{
	Assert(hDlg);
	// Its ok for centering to fail
	FCenter(hDlg);
	// Limit text and so forth.
	// FIX ME - Read this in from the Registry!
	if (!::FEditBoxLimitText(hDlg, IDC_EDITFINDMEMBER, CS_CCHMAX_QUERY_STRING) ||
		!::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITFINDMEMBER), (TCHAR *)m_szFind))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

BOOL CFindDlg::FGetFindParams(HWND hDlg)
{
	// Get the parameters the user entered
	if (!FGetText(hDlg, IDC_EDITFINDCHANNEL, -1, (TCHAR *)&m_szFind, CS_CCHMAX_QUERY_STRING + 1))
	{
		return FALSE;
	}
	UINT uMax = ::GetDlgItemInt(hDlg, IDC_EDITFINDMAXUSER, NULL, FALSE);
	UINT uMin = ::GetDlgItemInt(hDlg, IDC_EDITFINDMINUSER, NULL, FALSE);
	if (((int)(uMax - uMin)) < 0 || (0 == uMax && 0 == uMin))
	{
		FDoErrorAndSetFocus(hDlg, IDC_EDITFINDMAXUSER, IDS_ERR_FINDMINMAX);
		return FALSE;
	}
	m_dwMin = (DWORD) uMin;
	m_dwMax = (DWORD) uMax;

	return TRUE;
}

BOOL CFindDlg::FGetFindMemberParams(HWND hDlg)
{
	// Get the parameters the user entered
	if (!FGetText(hDlg, IDC_EDITFINDMEMBER, -1, (TCHAR *)&m_szFind, CS_CCHMAX_QUERY_STRING + 1))
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CFindDlg::FNotifyFind(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, FALSE);
		break;

	case PSN_APPLY:
		::SetWindowLong(hDlg, DWL_MSGRESULT,
						FGetFindParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		break;
	}
	return fRet;
}

BOOL CFindDlg::FNotifyFindMember(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, FALSE);
		break;

	case PSN_APPLY:
		::SetWindowLong(hDlg, DWL_MSGRESULT,
						FGetFindMemberParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		break;
	}
	return fRet;
}

//////////////////////////////////////////////////////////////////////////////////////
CFindDlg* CFindDlgGet(HWND hDlg, UINT uMsg, LPARAM lParam)
{
	CFindDlg*	pcfd;

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE*	ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		pcfd = (CFindDlg*)ppsp->lParam;
		SetWindowLong(hDlg, DWL_USER, (LONG)pcfd);
	}
	else
	{
		pcfd = (CFindDlg*)GetWindowLong(hDlg, DWL_USER);
	}
	return pcfd;
}

//////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK FindDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL	fRet;
	
	CFindDlg* pcfd = CFindDlgGet(hDlg, uMsg, lParam);
	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcfd->FInitFindDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcfd->FNotifyFind(hDlg, lParam);
		break;

	case WM_COMMAND:
		if (ID_SETFOCUS == LOWORD(wParam))
		{
			pcfd->SetFocus(hDlg, (int)lParam);
		}
		break;
	}  
	return fRet;
} 

//////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK FindMemberDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL	fRet;
	
	CFindDlg* pcfd = CFindDlgGet(hDlg, uMsg, lParam);
	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcfd->FInitFindMemberDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcfd->FNotifyFindMember(hDlg, lParam);
		break;

	case WM_COMMAND:
		if (ID_SETFOCUS == LOWORD(wParam))
		{
			pcfd->SetFocus(hDlg, (int) lParam);
		}
		break;
	}  
	return fRet;
} 
