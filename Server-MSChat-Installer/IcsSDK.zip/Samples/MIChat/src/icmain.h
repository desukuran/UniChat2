//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICMAIN__
#define __ICMAIN__

#include "icinc.h"
#include "icinst.h"
#include "iclogin.h"
#include "icfind.h"
#include "icwizard.h"
#include "icque.h"

// Arbitrary limit on # of channels per ICHat instance
const DWORD	CMAXCHANNELS	= 10;
const DWORD DXTIMEOUT		= 10000;		// timeout ever 10 seconds. Increase this later

//--------------------------------------------------------------------------------------------
class CIFifo;
class CIChatMain;

typedef struct FifoData
{
	BYTE	bType;	// Type of data
	PVOID	pv;		// pointer to the object..

} FIFODATA, *PFIFODATA;

const BYTE	FIFOTYPE_FINDCHANNEL	= 1;
const BYTE	FIFOTYPE_FINDMEMBER		= 2;
const BYTE	FIFOTYPE_PROPCHANNEL	= 3;
const BYTE	FIFOTYPE_PROPMEMBER		= 4;
const BYTE	FIFOTYPE_FINDUSER		= 5;
const BYTE	FIFOTYPE_REALNAME		= 6;

//--------------------------------------------------------------------------------------------
extern CIChatMain	gciChat;		// chat globals

//////////////////////////////////////////////////////////////////////////////////////////////
// Maintains a simple FIFO
class CIFifo : public CQue
{
// Interfaces
public:
	BOOL		FAdd(BYTE bType, PVOID pv, POSITION* ppos=NULL);
	BOOL		FGet(PFIFODATA* ppfData);
	void		DeleteAt(POSITION pos);

	virtual BOOL	FFreeData(PVOID pv);
};

// The main application class.
// Everything is global here.
class CIChatMain
{
	friend LRESULT CALLBACK MicChatWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CIChatMain(void);
	~CIChatMain(void);
		
	HWND	HWnd(void)	{ return m_hWnd; }
	BOOL	FInit(HINSTANCE hInst);
	BOOL	FCreateNewChat(PICS_CHANNEL picsChannel);
	BOOL	FCloseChat(DWORD index);
	BOOL	FWaitForMsg(void);
	void	SetForeInstance(HWND hWnd);
	HWND	HWndFore(void);
	void	SetForeDialog(HWND hDlg);
	HWND	HWndForeDlg(void);

	BOOL	FDisable(void)			{ return m_fDisable; }
	void	SetDisable(BOOL fSet)	{ m_fDisable = fSet; }
	//
	// Chat sockets
	BOOL	FIsMicSocket(void)		{ return m_fMicSocket; }
	BOOL	FCloseChatSocket(void);
	BOOL	FSetChatSocket(PICS pics);
	PICS	PChatSocket(void);
	DWORD	CChats(void);

	BOOL	FListAllChannels(CChatFindPane *pcfp, CFindDlg *pcfd);
	BOOL	FListAllMembers(CChatFindPane *pcfp, PICS_PROPERTY picsProp, DWORD dwIndex);
	BOOL	FListAllUsers(CChatFindPane *pcfp, CFindDlg	*pcfd);
	BOOL	FGetLatestChannelProps(CChatFindPane *pcfp, PICS_PROPERTY picsProp, DWORD dwIndex);
	BOOL	FGetRealName(HWND hWndParent, PICS_PROPERTY picsProp);

	BOOL	FCreateNewChannel(HWND hWndParent);
	BOOL	FCreateChannel(HWND hWndParent, IC_CREATECHAN *picChan);
	BOOL	FBuildCSInfo(PCS_CINFO pcs, PIC_CREATECHAN pChan);
	BOOL	FCreateChannelFromName(HWND hWndParent, TCHAR *szName);
	BOOL	FCreateChannelFromCInfo(HWND hWndParent, PCS_CINFO pcs);

	BOOL	FJoinNewChannel(HWND hWndParent, CChatFindPane *pccfp);
	BOOL	FJoinChannel(HWND hWndParent, IC_CREATECHAN	*picChan, CChatFindPane *pccfp);
	BOOL	FBuildCJInfo(PCS_JOININFO pcs, PIC_CREATECHAN pChan);
	BOOL	FJoinChannelFromURL(HWND hWndParent, TCHAR *szURL);
	BOOL	FJoinChannelFromName(HWND hWndParent, TCHAR *szName);

	BOOL	FIsAway(void);
	void	SetIsAway(BOOL fSet);
	
	IC_WIZARD* PicWizard(void);
	void	SetWizard(IC_WIZARD *picw);
	BOOL	FStopWizard(BOOL fCancel, HRESULT hr);
	
	BOOL	FPopFifo(void);
	void	FreeFifo(void);
	PFIFODATA PFifoData(void);

	void	SetFinder(BOOL fClear=FALSE, BOOL fReset=TRUE);
	CChatFindPane* PFinder(void);
	
	HMENU	Hmenu(int imenu)	{ Assert(imenu < cmenus); return m_rghmenu[imenu]; }

protected:
	void	Quit(void);
	void	DestroyWindow(void);
	BOOL	FPostCommand(WPARAM wParam, LPARAM lParam);
	//
	// Chat sockets
	BOOL	FConnect(CHAR* szServer, UINT uFirstPage);
	BOOL	FCreateMsgThread(void);
	BOOL	FChannelOk(void);

	BOOL	FHandleQueryData(PCS_MSGBASE pcsMsg);
	BOOL	FHandlePropertyData(PCS_MSGBASE pcsMsg);
	BOOL	FHandlePropertyError(HRESULT hr);

	BOOL	FGetServerNameFromCommand(TCHAR *szCmd, TCHAR **pszServer, int *pcch);
	BOOL	FGetChannelNameFromCommand(TCHAR *szCmd, TCHAR **pszName, int *pcch);
	BOOL	FParseCommandLine(void);
	BOOL	FLaunchNewChatProcess(TCHAR *szServer, int cchServer, TCHAR *szURL);

	BOOL	FLoadMenus(void);
//
// Data
public:
	HINSTANCE		m_hInst;
	HWND			m_hWnd;		// the main, DUMMY window
	CS_LOCK			m_csData;	// critical section to protect data
	HWND			m_hWndFore;	// current foreground chat instance
	HWND			m_hDlgFore;	// current foreground chat dialog
	BOOL			m_fDisable;

	DWORD			m_cChats;	// how many windows open?
	BOOL			m_fAway;	// are we away?
	PCI_CHAT		m_prgChats[CMAXCHANNELS];
	//
	// CHAT SOCKETS
	PICS			m_pics;			// chat socket interface
	BYTE			m_bTypeLogin;	// what kind of login was this? Anonymous?
	CS_THREAD		m_msgThread;	// thread to read m_pics's msgs	
	IC_WIZARD*		m_picWizard;	// wizard currently available for notification
	BOOL			m_fMicSocket;
	//
	// FIND
	CChatFindPane*	m_pcfp;		// the find window
	CIFifo			m_fifo;
	PFIFODATA		m_pfData;
	//
	// COMAMND LINE
	TCHAR*			m_pszCmdLine;
	//
	// URL
	TCHAR*			m_szURLCopy;
	TCHAR*			m_szDefServer;	// default server, if any
	TCHAR*			m_szDefChan;	// default channel, if any
	// Context menus
	HMENU			m_hmenuPopups;
	HMENU			m_rghmenu[cmenus];
};

//--------------------------------------------------------------------------------------------
int FHandleChatSockErrors(HWND hWndParent, HRESULT hr, BOOL fMicOnly = FALSE);

inline HWND HWndDummy(void)
{
	return gciChat.HWnd();
}

inline HINSTANCE HInstGet(void)
{
	return gciChat.m_hInst;
}

inline BOOL FCreateNewChat(PICS_CHANNEL pics)
{
	return gciChat.FCreateNewChat(pics);
}

inline BOOL FCreateNewChannel(HWND hWndParent)
{
	return gciChat.FCreateNewChannel(hWndParent);
}

inline BOOL	FCreateChannel(HWND hWndParent, IC_CREATECHAN* picChan)
{
	return gciChat.FCreateChannel(hWndParent, picChan);
}

inline BOOL	FCreateChannelFromName(HWND hWndParent, TCHAR* szName)
{
	return gciChat.FCreateChannelFromName(hWndParent, szName);
}

inline BOOL FJoinNewChannel(HWND hWndParent, CChatFindPane* pccfp)
{
	return gciChat.FJoinNewChannel(hWndParent, pccfp);
}

inline BOOL FJoinChannel(HWND hWndParent, IC_CREATECHAN* picChan, CChatFindPane* pccfp)
{
	return gciChat.FJoinChannel(hWndParent, picChan, pccfp);
}

inline BOOL FJoinChannelFromURL(HWND hWndParent, TCHAR* szURL)
{
	return gciChat.FJoinChannelFromURL(hWndParent, szURL);
}

inline BOOL FJoinChannelFromName(HWND hWndParent, TCHAR* szName)
{
	return gciChat.FJoinChannelFromName(hWndParent, szName);
}

inline BOOL FCloseChat(DWORD dwID)
{
	return gciChat.FCloseChat(dwID);
}

inline BOOL FSetChatSocket(PICS pics)
{
	return gciChat.FSetChatSocket(pics);
}

inline PICS PChatSocket(void)
{
	return gciChat.PChatSocket();
}

inline BOOL FCloseChatSocket(void)
{
	return gciChat.FCloseChatSocket();
}

inline BYTE FLoginType(void)
{
	return gciChat.m_bTypeLogin;
}

inline BOOL IsLoginAnon(void)
{
	return (CS_CHANNEL_ALLOWANON == gciChat.m_bTypeLogin);
}

inline void SetForeInstance(HWND hWnd)
{
	gciChat.SetForeInstance(hWnd);
}

inline HWND HWndFore(void)
{
	return gciChat.HWndFore();
}

inline void SetForeDialog(HWND hDlg)
{
	gciChat.SetForeDialog(hDlg);
}

inline HWND HWndForeDlg(void)
{
	return gciChat.HWndForeDlg();
}

inline BOOL FDisableAll(void)
{
	return gciChat.FDisable();
}

inline void SetDisableAll(BOOL fSet)
{
	gciChat.SetDisable(fSet);
}

inline BOOL FListAllChannels(CChatFindPane* pcfp, CFindDlg* pcfd)
{
	return gciChat.FListAllChannels(pcfp, pcfd);
}

inline BOOL FListAllMembers(CChatFindPane* pcfp, PICS_PROPERTY picsProp, DWORD dwIndex)
{
	return gciChat.FListAllMembers(pcfp, picsProp, dwIndex);
}

inline BOOL FListAllUsers(CChatFindPane* pcfp, CFindDlg* pcfd)
{
	return gciChat.FListAllUsers(pcfp, pcfd);
}

inline BOOL FGetLatestChannelProps(CChatFindPane* pcfp, PICS_PROPERTY picsProp, DWORD dwIndex)
{
	return gciChat.FGetLatestChannelProps(pcfp, picsProp, dwIndex);
}

inline BOOL FGetRealName(HWND hWndParent, PICS_PROPERTY picsProp)
{
	return gciChat.FGetRealName(hWndParent, picsProp);
}

inline BOOL FIsAway(void)
{
	return gciChat.FIsAway();
}

inline void SetIsAway(BOOL fSet)
{
	gciChat.SetIsAway(fSet);
}

inline void SetWizard(IC_WIZARD* picWizard)
{
	gciChat.SetWizard(picWizard);
}

inline BOOL FIsMicSocket(void)
{
	return gciChat.FIsMicSocket();
}

#endif
