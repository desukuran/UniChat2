//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icchild.h"

////////////////////////////////////////////////////////////////////////////////////////////
CChatChildWnd::CChatChildWnd(void)
{
	m_hWnd			= NULL;
	m_hWndParent	= NULL;
	m_pszClass		= NULL;
	m_fRegistered	= FALSE;
}

CChatChildWnd::~CChatChildWnd(void)
{
	UnregisterClass();
}

BOOL CChatChildWnd::FCreate(HWND hWndParent, int idCtl, RECT* prc, TCHAR* pszClass, 
							DWORD dwStyle, DWORD dwExStyle, WNDPROC pwp)
{
	Assert(hWndParent);
	Assert(NULL == m_hWnd);

	RECT	rc;
	RECT*	prcWnd;

	m_hWndParent	= hWndParent;	
	// Register the class only if a WNDPROC has been provided.
	// No point doing it otherwise
	if (pwp)
	{
		m_pszClass = pszClass;
		if (!FRegisterClass(hWndParent, pwp))
		{
			return FALSE;
		}
	}
	// if no prc provided,  use the creating window's window rect
	if (NULL == prc)
	{
		if (!::GetClientRect(m_hWndParent, &rc))
		{
			AssertGLE(FALSE);
			return FALSE;
		}
		prcWnd = &rc;
	}
	else
	{
		prcWnd = prc;
	}
	// got all resources. now create window
	m_hWnd = ::CreateWindowEx(dwExStyle, pszClass, NULL, dwStyle, 
							prcWnd->left, prcWnd->top,
							prcWnd->right - prcWnd->left, prcWnd->bottom - prcWnd->top,
							hWndParent, (HMENU)idCtl, HInstance(hWndParent), NULL);
	if (NULL == m_hWnd)
	{
		AssertGLE(FALSE);
		UnregisterClass();
		return FALSE;
	}
	// Init the element to default fonts
	SendMessage(WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), MAKELPARAM(FALSE,  0));
	// plug a pointer of this object into this window
	::SetWindowLong(m_hWnd, GWL_USERDATA, (LONG)this);

	return TRUE;		
}

void CChatChildWnd::SetWindowProc(WNDPROC wndProc)
{
	Assert(wndProc);

	m_wndProc = (WNDPROC)::SetWindowLong(m_hWnd, GWL_WNDPROC, (LONG)wndProc);
}

LRESULT CChatChildWnd::LrCallWindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (m_wndProc)
	{
		return ::CallWindowProc(m_wndProc, m_hWnd, uMsg, wParam, lParam);
	}

	return ::DefWindowProc(m_hWnd, uMsg, wParam, lParam);
}

BOOL CChatChildWnd::FSetWindowName(TCHAR *pszName)
{
	Assert(pszName);
	Assert(m_hWnd);

	return::SetWindowText(m_hWnd, pszName);
}

BOOL CChatChildWnd::FSetWindowName(int idName)
{
	// Load the string
	Assert(m_hWnd);
	TCHAR* psz = GetSz(HInstance(m_hWnd), idName);
	if (NULL == psz)
	{
		return FALSE;
	}
	return FSetWindowName(psz);
}

BOOL CChatChildWnd::FGetTextExtent(int idString, SIZE* psize, HWND hWnd)
{
	Assert(psize);

	// Now figure out how much space the button would occupy with just the text
	if (NULL == hWnd)
	{
		hWnd = m_hWnd;
	}
	TCHAR* psz = GetSz(HInstance(hWnd), idString);
	if (NULL == psz)
	{
		return FALSE;
	}
	return ::FGetTextExtentPoint(hWnd, psz, psize);
}

BOOL CChatChildWnd::FDestroyWindow(void)
{
	if (m_hWnd)
	{
		return ::DestroyWindow(m_hWnd);
	}
	return TRUE;
}

void CChatChildWnd::ShowWindow(void)
{
	Assert(m_hWnd);

	::ShowWindow(m_hWnd, SW_SHOW);
}

void CChatChildWnd::HideWindow(void)
{
	Assert(m_hWnd);

	::ShowWindow(m_hWnd, SW_HIDE);
}

BOOL CChatChildWnd::FEnableWindow(BOOL fEnable)
{
	Assert(m_hWnd);

	return ::EnableWindow(m_hWnd, fEnable);
}
 
BOOL CChatChildWnd::FMoveWindow(RECT *prc)
{
	Assert(prc);
	Assert(m_hWnd);

	return ::MoveWindow(m_hWnd, prc->left, prc->top,
						prc->right - prc->left, prc->bottom - prc->top, TRUE);
}

BOOL CChatChildWnd::FMoveWindowNoUpdate(RECT *prc)
{
	Assert(prc);
	Assert(m_hWnd);

	return ::MoveWindow(m_hWnd, prc->left, prc->top, 
					prc->right - prc->left, prc->bottom - prc->top, FALSE);
}

BOOL CChatChildWnd::FRedrawWindow(void)
{
	// Invalidate the entire window,  then redraw it
	RECT	rc;

	if (!FGetClientRect(&rc))
	{
		return FALSE;
	}
	if (!::InvalidateRect(m_hWnd, &rc, TRUE))
	{
		return FALSE;
	}
	return ::UpdateWindow(m_hWnd);
}

BOOL CChatChildWnd::FSetWindowText(TCHAR* psz)
{
	Assert(psz);

	return ::SetWindowText(m_hWnd, psz);
}

BOOL CChatChildWnd::FGetClientRect(RECT* prc)
{
	Assert(m_hWnd);
	Assert(prc);

	if (m_hWnd)
	{
		if (!::GetClientRect(m_hWnd, prc))
		{
			AssertGLE(FALSE);
			return FALSE;
		}
	}

	return TRUE;
}

BOOL CChatChildWnd::FGetWindowRect(RECT* prc)
{
	Assert(m_hWnd);
	Assert(prc);

	if (m_hWnd)
	{
		if (!::GetWindowRect(m_hWnd, prc))
		{
			AssertGLE(FALSE);
			return FALSE;
		}
	}
	return TRUE;
}

LONG CChatChildWnd::LGetWidth(void)
{
	RECT	rc;

	if (!FGetWindowRect((LPRECT)&rc))
	{
		AssertGLE(FALSE);
		return 0;
	}
	return (rc.right - rc.left);
}

LONG CChatChildWnd::LGetHeight(void)
{
	RECT	rc;

	if (!FGetWindowRect(&rc))
	{
		return 0;
	}
	return (rc.bottom - rc.top);
}

LRESULT CChatChildWnd::SendMessage(UINT uMsg)
{
	return SendMessage(uMsg, 0, 0);
}

LRESULT CChatChildWnd::SendMessage(UINT uMsg, WPARAM wParam)
{
	return SendMessage(uMsg, wParam, 0);
}

LRESULT CChatChildWnd::SendMessage(UINT uMsg, LPARAM lParam)
{
	return SendMessage(uMsg, 0, lParam);
}

LRESULT CChatChildWnd::SendMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Assert(m_hWnd);

	if (m_hWnd)
	{
		return ::SendMessage(m_hWnd, uMsg, wParam, lParam);
	}
	return FALSE;
}

LRESULT CChatChildWnd::PostMessage(UINT uMsg)
{
	return PostMessage(uMsg, 0, 0);
}

LRESULT CChatChildWnd::PostMessage(UINT uMsg, WPARAM wParam)
{
	return PostMessage(uMsg, wParam, 0);
}

LRESULT CChatChildWnd::PostMessage(UINT uMsg, LPARAM lParam)
{
	return PostMessage(uMsg, 0, lParam);
}

LRESULT CChatChildWnd::PostMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Assert(m_hWnd);

	if (m_hWnd)
	{
		return ::PostMessage(m_hWnd, uMsg, wParam, lParam);
	}
	return FALSE;
}

// protected:
BOOL CChatChildWnd::FRegisterClass(HWND	hWndParent, WNDPROC pwp)
{
	Assert(m_pszClass);
	Assert(m_hWndParent);

	WNDCLASS  wc;

	wc.style			= 0;
	wc.lpfnWndProc		= pwp;
	wc.cbClsExtra		= 0;
	wc.cbWndExtra		= 0;
	wc.hInstance		= HInstance(hWndParent);	
	wc.hIcon			= NULL;
	wc.hCursor			= LoadCursor(NULL,  IDC_ARROW);		// Arrow by default
	wc.hbrBackground	= (HBRUSH)(COLOR_BTNFACE+1);
	wc.lpszMenuName		= NULL;
	wc.lpszClassName	= m_pszClass;
	if (RegisterClass(&wc))
	{
		m_fRegistered = TRUE;
	}

	return TRUE;
}

// protected
void CChatChildWnd::UnregisterClass(void)
{
	if (m_fRegistered)
	{
		Assert(m_hWndParent);
		::UnregisterClass(m_pszClass, HInstance(m_hWndParent));
		m_fRegistered = FALSE;
	}
}
