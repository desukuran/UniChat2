//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icque.h"

CQue::CQue(void)
	: CMtList()
{
}

CQue::~CQue(void)
{
	FRemoveAll();
}

// Initialize the message que
BOOL CQue::FInit(void)
{
	return TRUE;
}

// Enque the message
BOOL CQue::FEnQue(PVOID pv, POSITION *ppos)
{
	Assert(pv);

	POSITION pos = AddTail(pv);
	if (ppos)
	{
		*ppos = pos;
	}
	return (NULL != pos);
}

// Pop the que, and return whatever the pop contained
BOOL CQue::FDeQue(PVOID* ppv, BOOL fHead)
{
	Assert(ppv);
	
	PVOID	pv = NULL;
	BOOL	fRet = TRUE;

	m_cs.Lock();

	if (IsEmpty())
	{
		fRet = FALSE;
		goto LReturn;
	}
	else if (fHead)
	{
		pv = GetHead();
		RemoveHead();
	}
	else 
	{
		pv = GetTail();
		RemoveTail();
	}

LReturn:	
	m_cs.Unlock();

	if (ppv)
	{
		*ppv = pv;
	}
	return fRet;
}

BOOL CQue::FRemoveAll(void)
{
	PVOID	pv = NULL;

	m_cs.Lock();
	while (!IsEmpty())
	{
		pv = RemoveHead();	
		FFreeData(pv);
	}
	m_cs.Unlock();

	return NOERROR;
}
