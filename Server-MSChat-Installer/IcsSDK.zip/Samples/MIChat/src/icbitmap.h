//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICBITMAP__
#define __ICBITMAP__

#include "icinc.h"

// Generic object that loads and manages Chat Bitmaps
// WARNING: This class is meant simply to wrap GLOBAL bitmap handles.
// It is NOT multi-thread safe (except in knowing when to load/delete its resources).
class CChatBitmaps
{
// Interface
public:
	~CChatBitmaps(void);
	BOOL				FLoad(HINSTANCE hInst);
	BOOL				FDrawModeBitmap(HDC hDC, RECT* prc, PICS_MEMBER picsMem);

	HBITMAP				HBitmapHost(void)		{ return m_hbmpHost; }
	HBITMAP				HBitmapPart(void)		{ return m_hbmpPart; }
	HBITMAP				HBitmapSpec(void)		{ return m_hbmpSpec; }
	HBITMAP				HBitmapMember(void)		{ return m_hbmpMem; }
	HBITMAP				HBitmapWorld(void)		{ return m_hbmpWorld; }
	HBITMAP				HBitmapFolder(void)		{ return m_hbmpFolder; }
	HBITMAP				HBitmapChat(void)		{ return m_hbmpChat; }
	HBITMAP				HBitmapChatPriv(void)	{ return m_hbmpChatPriv; }
protected:
	BOOL				FDrawBitmap(HDC hDC, RECT* prc, HBITMAP hbmp);								
// Data
protected:
	static  LONG		m_lRef;			// ref count
	static 	HBITMAP 	m_hbmpHost;		// host 	
	static 	HBITMAP 	m_hbmpPart;		// participant
	static 	HBITMAP 	m_hbmpSpec;		// spectator	
	static	HBITMAP		m_hbmpMem;		// member - generic
	static	HBITMAP		m_hbmpWorld;	// the chat universe
	static	HBITMAP		m_hbmpChat;		// a chat
	static	HBITMAP		m_hbmpFolder;
	static	HBITMAP		m_hbmpChatPriv;

	static	CS_LOCK		m_csBitmap;		// CRITICAL_SECTION
};

#endif
