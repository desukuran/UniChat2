//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICSPLIT__
#define __ICSPLIT__

#include "icinc.h"
#include "icchild.h"

#define SPLITSIZE 			2	// Split width (should be odd)
#define DXSPLITSTEP 		6
#define DYSPLITSTEP 		4

// Types of splitters
#define HSPLITTER			0x0001
#define VSPLITTER			0x0002

// Standard splitter window
class CChatSplitterWnd : public CChatChildWnd
{
// Interfaces
friend	LRESULT CALLBACK SplitWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

public:
					CChatSplitterWnd(void);
					~CChatSplitterWnd(void);
	BOOL			FCreateHorizontal(HWND hWndParent, int idCtl, RECT* prc, RECT* prcBounds=NULL, BOOL fVisible=TRUE)
					{
						m_bType = HSPLITTER;
						return FCreate(hWndParent, idCtl, prc, prcBounds, fVisible);
					}
	BOOL			FCreateVertical(HWND hWndParent, int idCtl, RECT* prc, RECT* prcBounds=NULL, BOOL fVisible=TRUE)
					{
						m_bType = VSPLITTER;
						return FCreate(hWndParent, idCtl, prc, prcBounds, fVisible);
					}
	BOOL			FMoveSplitter(RECT* prc);
	BOOL			FSetBoundingRect(RECT* prcBounds);

	BOOL			FHandleWMKeyDown(WPARAM wParam);
	BOOL			FHandleWMMouseDown(LPARAM lParam);
	BOOL			FHandleWMMouseMove(LPARAM lParam);
	BOOL			FHandleWMMouseUp(LPARAM lParam);
	BOOL			FHandleWMSetCursor(void);

protected:
	BOOL			FCreate(HWND hWndParent, int idCtl, RECT* prc, RECT* prcBounds=NULL, BOOL fVisible=TRUE);
	BOOL			FLoadCursor(void);

	BOOL			FDrawSplitter(POINT* ppt, BOOL fErase, BOOL fOnlyErase=FALSE);
	BOOL			FPatBlt(HDC hDC, RECT* prc);

	BOOL			FGetSplitterRect(RECT* prc, POINT* ppt);
	BOOL			FGetPointOnParent(POINT* ppt);
	void			MapWindowPointsToParent(RECT* prc);
	void			AdjustPoint(POINT* ppt);
	void			GetPointFromLParam(LPARAM lParam, POINT* ppt);

	void			SendDoneToParent(void);
// Data
protected:
	BYTE			m_bType;			// H or V splitter
	HCURSOR			m_hCursor;			// cursor associatd with this splitter
	RECT			m_rcBounds;			// bounding rectangle for drags
	// used during the actual dragging of split bars
	RECT			m_rcSav;		    // saved prev location (during moves)
	BOOL			m_fDrag;			// are we doing a drag? (for mouse moves)
	// ID of this splitter
	int				m_idCtl;
};

#endif
