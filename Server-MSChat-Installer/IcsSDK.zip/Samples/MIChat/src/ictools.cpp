//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "ictools.h"

// Inherits from CChatChildWnd
/////////////////////////////////////////////////////////////////////////////////////////////
CChatToolBar::CChatToolBar(void)
		:CChatChildWnd()
{
	// Make sure the common control DLL is loaded
	InitCommonControls();
}

CChatToolBar::~CChatToolBar(void)
{
}

// Create a basic toolbar. This wraps the Win32 CreateToolbarEx API
BOOL CChatToolBar::FCreate(HWND hWndParent, int idCtl, RECT* prc,
							UINT cButtons, TBBUTTON* ptb, int cBitmaps,
							UINT idBitmap)
{
	Assert(NULL == m_hWnd);
	Assert(hWndParent);
	
	m_hWndParent	= hWndParent;
	m_hWnd			= ::CreateToolbarEx(m_hWndParent, 
									WS_CHILD | WS_VISIBLE | TBSTYLE_TOOLTIPS | TBSTYLE_WRAPABLE, 
									idCtl, cBitmaps, 
									(HINSTANCE)::GetWindowLong(m_hWndParent, GWL_HINSTANCE), 
									idBitmap, ptb, cButtons, 0, 0, 0, 0,sizeof(TBBUTTON));
	if (NULL == m_hWnd)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

// Adds buttons to the toolbar
BOOL CChatToolBar::FAddButtons(TBBUTTON *ptb, int cButtons)
{
	Assert(m_hWnd);
	Assert(ptb);
	Assert(cButtons > 0);
	
	if (!SendMessage(TB_ADDBUTTONS, (WPARAM)cButtons, (LPARAM)ptb))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	
	return TRUE;
}

// Adds a list of string IDs to the toolbar's internal cache
// These strings are then displayed in buttons as required
// Provide an array of string resource IDs and (cId) - a count.
BOOL CChatToolBar::FAddStrings(int* prgId, int cId)
{
	Assert(m_hWnd);
	Assert(prgId);
	Assert(cId > 0);

	TCHAR szBuf[256];
		
	HINSTANCE hInst = (HINSTANCE)::GetWindowLong(m_hWndParent, GWL_HINSTANCE);
	// Add strings to the toolbar, one by one
	int* piEnd = prgId + cId;
	while (prgId < piEnd)
	{
		int index;
		// Load the string
		if (!::LoadString(hInst, *prgId, szBuf, 256))
		{
			AssertGLE(FALSE);
			return FALSE;
		}
		// Give it to the toolbar
		index = SendMessage(TB_ADDSTRING, (LPARAM)szBuf);
		if (-1 == index)
		{
			AssertGLE(FALSE);
			return FALSE;
		}
		// Next string
		++prgId;
	}
	
	return TRUE;
}

BOOL CChatToolBar::FAutoSize(void)
{
	SendMessage(TB_AUTOSIZE);

	return TRUE;
}

BOOL CChatToolBar::FGetItemRect(int idItem, RECT* prc)
{
	Assert(prc);

	return SendMessage(TB_GETITEMRECT, (WPARAM)idItem, (LPARAM)prc);
}

// STATUS BAR
#define SB_SETBORDERS		(WM_USER+5)

///////////////////////////////////////////////////////////////////////////////////////////////
CChatStatusBar::CChatStatusBar(void)
		: CChatChildWnd()
{
	m_idStrPrev = -1;
	m_idStrCur = -1;
}

CChatStatusBar::~CChatStatusBar(void)
{
}

BOOL CChatStatusBar::FCreate(HWND hWndParent, int idCtl)
{
	m_hWndParent = hWndParent;
	m_hWnd	= ::CreateStatusWindow(WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP, NULL, hWndParent, idCtl);
	if (NULL == m_hWnd)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	
	int rgw[3];
	rgw[0] = 0;
	rgw[1] = -1;
	rgw[2] = 2;
	SendMessage(SB_SETBORDERS, (LPARAM)(LPINT)rgw);
	
	return FSetStatusStringDef();	
}

BOOL CChatStatusBar::FSetStatusString(int idStr, DWORD dwPart)
{
	m_idStrPrev = m_idStrCur;
	m_idStrCur = idStr;
	return SendMessage(SB_SETTEXT, (WPARAM) dwPart | SBT_NOBORDERS, 
						(LPARAM)GetSz(HInstance(m_hWndParent), idStr));
}

BOOL CChatStatusBar::FSetStatusString(TCHAR* sz, DWORD dwPart)
{
	return SendMessage(SB_SETTEXT, (WPARAM) dwPart | SBT_NOBORDERS, (LPARAM)sz);
}

BOOL CChatStatusBar::FRestoreStatusString(void)
{
	BOOL fRet = TRUE;

	int idStr = m_idStrCur;
	if (m_idStrPrev > - 1)
	{
		fRet = FSetStatusString(m_idStrPrev);
	}
	m_idStrCur = idStr;
	return fRet;
}

BOOL CChatStatusBar::FUpdateUserCount(PICS_CHANNEL pChan)
{
	TCHAR	sz[10];
	TCHAR*	szT = NULL;
	TCHAR*	(rgsz[1]);
	int		rgw[3];
	DWORD	cUser;

	if (!pChan)
	{
		return TRUE;
	}
	if (FAILED(pChan->HrGetUserCount(&cUser)))
	{
		AssertSz(0, "HrGetUserCount");
		return FALSE;
	}
	::wsprintf(sz, "%d", cUser);
	rgsz[0]=sz;
	
	if (!::FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
						FORMAT_MESSAGE_FROM_HMODULE |
						FORMAT_MESSAGE_ARGUMENT_ARRAY,
						NULL, 
						cUser > 1 ? IDS_USERCOUNT : IDS_USERCOUNTSINGLE, 
						0, (TCHAR*)&szT, 
						0, (va_list*)rgsz))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	if (szT)
	{
		RECT	rectStatus;
		SIZE	size;
		// Compute size for User Count String & reset panes
		if (!FGetClientRect(&rectStatus) || !::FGetTextExtentPoint(m_hWnd, szT, &size))
		{
			return FALSE;
		}
		SendMessage(SB_GETBORDERS, (LPARAM)(LPINT)rgw);
		
		int w = ::GetSystemMetrics(SM_CXVSCROLL);
		rgw[0]	= rectStatus.right-(size.cx+rgw[2])-w-5;
		rgw[1]	= -1;
		SendMessage(SB_SETPARTS, (WPARAM)2, (LPARAM)(LPINT)rgw);
		SendMessage(SB_SETTEXT, (WPARAM) 1, (LPARAM)szT);

		::LocalFree(szT);
	}
	return TRUE;
}
