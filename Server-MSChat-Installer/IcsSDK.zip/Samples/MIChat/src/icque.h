//------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//------------------------------------------------------------------------------

#ifndef __ICQUE__
#define __ICQUE__

#include "icinc.h"

//------------------------------------------------------------------------------
// A MULTI-THREAD SAFE Message Que.
// Also, the msgEvent ensures that only one thread at a time can Enque or Deque
//
class CQue : public CMtList
{
public:
	CQue(void);
	~CQue(void);

	BOOL			FInit(void);
	BOOL			FEnQue(PVOID pv, POSITION* ppos=NULL);
	BOOL			FDeQue(PVOID* ppv, BOOL fHead=TRUE);
	BOOL			FRemoveAll(void);
	virtual	BOOL	FFreeData(PVOID pv)		{ return TRUE; }
//
// Useful members from CMtList:
//	IsEmpty()
//	GetCount()
//
// Data
//
protected:
	CSLock			m_cs;		// critical section
};

#endif
