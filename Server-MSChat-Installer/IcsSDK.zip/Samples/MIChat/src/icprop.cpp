//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icprop.h"
#include "icmain.h"
#include "icwprop.h"
#include "icutil.h"
#include "ownbtn.h"

//--------------------------------------------------------------------------------------------
// PROTOTYPES
//--------------------------------------------------------------------------------------------
BOOL CALLBACK SetAwayDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL FDisplayRealName(HWND hWndParent, PICS_PROPERTY pProp, TCHAR *szReal);

//--------------------------------------------------------------------------------------------
// CONSTANTS
//--------------------------------------------------------------------------------------------
#ifdef NOTNOW
const TCHAR REG_SZAWAYVAL[]		= "Away";
#endif
const TCHAR *REG_SZNOTIFYJOIN	= "Join";
const TCHAR *REG_SZNOTIFYLEAVE	= "Leave";
const TCHAR *REG_SZBLANKLINE	= "Blank";
const TCHAR *REG_SZSAVE			= "Save";
const TCHAR *REG_SZINVITEIGNORE	= "Invite";
const TCHAR *REG_SZURLCOLOR		= "URL";

//--------------------------------------------------------------------------------------------
// FUNCTIONS
//--------------------------------------------------------------------------------------------
// This is ALL CODE TO TEST CHATSOCK AND THIS FEATURE
BOOL ParsePropertyData(PCS_MSGBASE pcsMsg, CUIRichEdit *pui, HWND hWndParent)
{
	Assert(pcsMsg);

	PCS_PROPERTY pcsProp = (PCS_PROPERTY)(pcsMsg + 1);
	if (!pcsProp->picsProperty)
	{
		return FALSE;
	}

	DWORD	dwc;
	if (FAILED((pcsProp->picsProperty)->HrGetCount(&dwc)))
	{
		Assert(FALSE);
		return FALSE;
	}
	
	CS_PROPDATA	cspd;
#ifdef DEBUG	
	TCHAR		szData[256];	// fix me - THESE ARE JUST FOR TESTING
	TCHAR		szType[32];
	TCHAR		szOut[512];
	BOOL		fUI;
#endif

	for (DWORD dwi = 1; dwi <= dwc; ++dwi)
	{
		if (SUCCEEDED((pcsProp->picsProperty)->HrGetProperty(&cspd, dwi)))
		{
			if (!cspd.pbData)
			{
				continue;
			}

#ifdef DEBUG
			fUI = TRUE;
			::CopyMemory(&szData, (PVOID)cspd.pbData, cspd.dwcb);
#endif
			switch (cspd.csPropType)
			{
			default:
				break;

			case CSPROP_GENERIC_TIME:
				break;

			case CSPROP_MEMBER_REALNAME:
				return FDisplayRealName(hWndParent, pcsProp->picsProperty, (TCHAR*)cspd.pbData);

			case CSPROP_CHANNEL_PASSWORD:
				break;

			case CSPROP_CHANNEL_USERMAX:
				break;

			case CSPROP_CHANNEL_SUBJECT_MIC:
				break;

			case CSPROP_CHANNEL_CHANNELGUID_MIC:
				break;

			case CSPROP_CHANNEL_SERVICEGUID_MIC:
				break;
			}
#ifdef DEBUG
			if (fUI)
			{
				wsprintf(szOut, "%s:%s ", szType, szData);
				pui->InsertText(szOut);
			}
#endif
		}
	}
	return TRUE;
}

BOOL FDisplayRealName(HWND hWndParent, PICS_PROPERTY pProp, TCHAR *szReal)
{	
	CS_PROPDATA	cspd;
	if (FAILED(pProp->HrGetProperty(&cspd, 2)))
	{
		Assert(0);
		return FALSE;
	}

	HINSTANCE hInst = HInstance(hWndParent);
	// put up the message box
	TCHAR		szOut[512];
	wsprintf(szOut, GetSz(hInst, IDS_GET_REALNAME), (TCHAR*)cspd.pbData, szReal);

	return MessageBox(hWndParent, szOut, GetSz(hInst, IDS_APPTITLE), NOTIFY_OK);
}

// IRC style /list
BOOL FListAllChannels(PICS pics, DWORD dwcUserMin, DWORD dwcUserMax, TCHAR* szFind, BOOL fContains)
{
	Assert(pics && szFind);
	
	CSPROP_OP csOp = (fContains) ? CSPROP_QUERY_CONTAINS : CSPROP_QUERY_EQUAL;
	
	//if (pics->HrIsMicSocket())
	HRESULT hr = pics->HrListAllChannelsA(dwcUserMin, dwcUserMax, szFind, csOp);
	pics->Release();

	return (SUCCEEDED(hr));
}

// List all users  - WHO
BOOL FListAllUsers(PICS pics, TCHAR *szFind)
{
	Assert(pics && szFind);

	HRESULT hr = pics->HrListAllUsersA(szFind, CSPROP_QUERY_CONTAINS);
	pics->Release();

	return (SUCCEEDED(hr));
}

// List all members in a channel
BOOL FListAllMembersInChannel(PICS pics, PICS_PROPERTY picsProp, DWORD dwIndex)
{
	Assert(pics && picsProp);

	HRESULT		hr;
	CS_PROPDATA cspd;
	DWORD		dwID;
	BOOL	fIsMic = (NOERROR == pics->HrIsMicSocket());
	if (!fIsMic)
	{
		dwIndex = CSINDEX_PROP_CHANNEL_NAME;
	}
	// Get the channel's id/name
	if (FAILED(picsProp->HrGetProperty(&cspd, dwIndex)))
	{
		AssertSz(0, "HrGetProperty");
		return NULL;
	}
	
	if (fIsMic)
	{
		// Make sure what we got was an ID
		Assert(cspd.dwcb == sizeof(DWORD));
		dwID = *((DWORD*)cspd.pbData);

		hr = pics->HrListAllMembersA(dwID);
	}
	else
	{
		hr = pics->HrListAllMembersFromNameA((CHAR *)cspd.pbData);
	}

	pics->Release();

	return (SUCCEEDED(hr));
}

// Get the latest properties of a channel
BOOL FGetLatestPropsChannel(PICS pics, PICS_PROPERTY picsProp, DWORD dwIndex)
{
	Assert(pics && picsProp);

	HRESULT		hr;
	CS_PROPDATA cspd;
	DWORD		dwID;
	BOOL		fIsMic = (NOERROR == pics->HrIsMicSocket());
	if (!fIsMic)
	{
		dwIndex = CSINDEX_PROP_CHANNEL_NAME;
	}
	// Get the channel's id/name
	if (FAILED(picsProp->HrGetProperty(&cspd, dwIndex)))
	{
		AssertSz(0, "HrGetProperty");
		return NULL;
	}
	
	if (fIsMic)
	{
		// Make sure what we got was an ID
		Assert(cspd.dwcb == sizeof(DWORD));
		dwID = *((DWORD *)cspd.pbData);
		
		hr = pics->HrQueryChannelPropertiesA(dwID);
	}
	else
	{
		hr = pics->HrQueryChannelPropsFromNameA((CHAR*)cspd.pbData);
	}

	pics->Release();

	return (SUCCEEDED(hr));
}

// Get the properties of a channel member or a User in the Browser view
BOOL FGetMemberPropsFromBrowser(HWND hWndParent, PICS_PROPERTY picsProp, BOOL fUser)
{
	Assert(picsProp);

	BOOL	fRet;

	CMemberProps* pcmp = new CMemberProps(fUser ? IDD_USERPROPS : IDD_MEMBERPROPS);
	if (!pcmp)
	{
		AssertGLE(FALSE);
		DoOOM();
		return FALSE;
	}
	
	SetDisableAll(TRUE);
	fRet = pcmp->FMemberPropDlg(hWndParent, NULL, 0, picsProp);	
	SetDisableAll(FALSE);

	if (pcmp)
	{
		pcmp->Release();
	}
	
	return fRet;
}

// Get the real name of someone in the Browser view
BOOL FGetRealNameFromBrowser(PICS pics, PICS_PROPERTY picsProp)
{
	Assert(picsProp && pics);
	// Get the NickName
	CS_PROPDATA		csPropData;
	HRESULT			hr = S_FALSE;

	if (FAILED(picsProp->HrGetProperty(&csPropData, CSINDEX_PROP_MEMBER_NAME)))
	{
		AssertSz(0, "HrGetProperty");
		goto LReturn;
	}
	
	hr = (csPropData.fAnsi)
		?	pics->HrGetRealNameA((CHAR *)(csPropData.pbData))
		:	pics->HrGetRealNameW((WCHAR *)(csPropData.pbData));

LReturn:
	pics->Release();
	return SUCCEEDED(hr);
}

// AWAY DIALOG
#ifdef NOTNOW
BOOL FSetAway(HWND hWndParent, PICS pSock)
{	
	Assert(pSock);

	HRESULT	hr;
	BOOL	fRet;

	CSetAway* pcsw = new CSetAway;
	if (!pcsw)
	{
		AssertGLE(FALSE);
		DoOOM();
		goto LReturn;
	}

	SetDisableAll(TRUE);
	fRet = pcsw->FSetAwayDlg(hWndParent, FIsAway());
	SetDisableAll(FALSE);
	if (!fRet)
	{
		goto LReturn;
	}
	// Ok,  mark us as away or not away..
	hr = pSock->HrSetAwayA(pcsw->FAway(), pcsw->PszAway());
	SetIsAway(pcsw->FAway());
	// And update the registry if we are away
	if (pcsw->FAway())
	{
		SetRegistryRaw(HKEY_CURRENT_USER, REG_SZAWAYVAL, REG_SZ, 
					(PVOID)pcsw->PszAway(), lstrlen(pcsw->PszAway()) + 1);
	}

LReturn:
	if (pSock)
	{
		pSock->Release();
	}
	if (pcsw)
	{
		pcsw->Release();
	}
	return (SUCCEEDED(hr));
}

CSetAway::CSetAway(void)
	:CChatWizard()
{
	m_szAway[0]	= '\0';
	m_fAway = FALSE;
}

CSetAway::~CSetAway(void)
{
}

BOOL CSetAway::FSetAwayDlg(HWND hWndParent, BOOL fAway)
{
	Assert(hWndParent);

	m_fAway = fAway;
	// Init the Wizard. 1 page for now
	if (!FInit(hWndParent, 1))
	{
		return FALSE;
	}
	// Add Wizard pages
	if (!FAddPage(IDD_SETAWAY, SetAwayDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Display and do the Wizard. Note,  this will return ONLY when the Wizard is DONE
	return FShow();
}

BOOL CSetAway::FInitSetAwayDlg(HWND hDlg)
{
	// Its ok for centering to fail
	FCenter(hDlg);

	Assert(hDlg);
	// Limit text and so forth
	if (!FEditBoxLimitText(hDlg, IDC_EDITAWAYTEXT, CS_CCHMAX_MIC_AWAYMSG))
	{
		return FALSE;
	}
	// Load the away text from the registry and set the edit box with it
	if (FGetRegistrySz(HKEY_CURRENT_USER, REG_SZAWAYVAL, (TCHAR *)m_szAway, CS_CCHMAX_MIC_AWAYMSG))
	{
		if (!::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITAWAYTEXT), (TCHAR *)&m_szAway))
		{
			AssertGLE(FALSE);
			return FALSE;
		}
	}
	// Mark us away or not
	return CheckDlgButton(hDlg, IDC_CHKAWAY, m_fAway ? BST_CHECKED : BST_UNCHECKED);
}

BOOL CSetAway::FGetSetAwayParams(HWND hDlg)
{
	// Did they turn it on or off?
	m_fAway = (BST_CHECKED == IsDlgButtonChecked(hDlg, IDC_CHKAWAY));
	if (m_fAway)
	{
		// Get the away text. Empty away text is NOT ok.. as it implies that away is being
		// turned off.. a la IRC
		if (!FGetText(hDlg, IDC_EDITAWAYTEXT, IDS_ERR_NOAWAYTEXT, 
					(TCHAR*)&m_szAway, CS_CCHMAX_MIC_AWAYMSG + 1))
		{
			::SetWindowLong(hDlg, DWL_MSGRESULT, -1);
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CSetAway::FNotifySetAway(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_WIZFINISH:
		FGetSetAwayParams(hDlg);
		break;

	case PSN_SETACTIVE:
		SetFinishText(hDlg, IDS_OK);
		break;
	}
	return fRet;
}

BOOL CALLBACK SetAwayDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CSetAway*	psa;
	BOOL		fRet;

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE* ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		psa = (CSetAway*)ppsp->lParam; 
		::SetWindowLong(hDlg, DWL_USER, (LONG)psa);
	}
	else
	{
		psa = (CSetAway*)::GetWindowLong(hDlg, DWL_USER);
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !psa->FInitSetAwayDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = psa->FNotifySetAway(hDlg, lParam);
		break;

	case WM_COMMAND:
		if (ID_SETFOCUS == LOWORD(wParam))
		{
			psa->SetFocus(hDlg, (int) lParam);
		}
		break;
	}  
	return fRet;
} 

#endif

// MEMBER PROPERTIES
CMemberProps::CMemberProps(int idDlg)
	: CChatWizard()
{
	m_prgMem	= NULL;
	m_picsProp	= NULL;
	m_cMem		= 0;
	m_idDlg		= idDlg;
}

CMemberProps::~CMemberProps(void)
{
}

BOOL CMemberProps::FMemberPropDlg(HWND hWndParent, PICS_MEMBER* prgMem, int cMem, PICS_PROPERTY picsProp)
{
	Assert(hWndParent);
	// Init the Wizard. 1 page for now
	if (!FInit(hWndParent, 1))
	{
		return FALSE;
	}
	// Add Wizard pages
	if (!FAddPage(m_idDlg, MemPropsDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	// Load the Yes/No strings
	::lstrcpy(m_szYes, ::GetSz(HInstance(hWndParent), IDS_YES));
	::lstrcpy(m_szNo, ::GetSz(HInstance(hWndParent), IDS_NO));

	m_prgMem	= prgMem;
	m_picsProp	= picsProp;
	m_cMem		= cMem;
	// Display and do the Wizard. Note,  this will return ONLY when the Wizard is DONE
	return FShow();
}

BOOL CMemberProps::FInitMemProps(HWND hDlg)
{
	// Failure is OK!
	FCenter(hDlg);
	// Is it a single property thing?
	if (!m_prgMem)
	{
		return FInitSingleMemProps(hDlg);
	}
	// Populate the Combo box
	PICS_MEMBER picsMem;
	TCHAR		szNick[MAX_PATH], *psz;
	HWND		hWndCombo = ::HWndGetDlgItem(hDlg, IDC_COMBOMEMBERS);

	for (int i = 0; i < m_cMem; ++i)
	{
		picsMem = m_prgMem[i];
		Assert(picsMem);

		psz = ::PszGetName(picsMem, szNick);
		if (psz)
		{
			::SendMessage(hWndCombo, CB_ADDSTRING, 0, (WPARAM)psz);
		}
	}
	
	::SendMessage(hWndCombo, CB_SETCURSEL, 0, 0);		
	
	return FSetProps(hDlg);
}

BOOL CMemberProps::FInitSingleMemProps(HWND hDlg)
{
	if (!m_picsProp)
	{
		Assert(FALSE);
		return FALSE;
	}
	
	TCHAR	szNick[MAX_PATH];
	HWND	hWndCombo = ::HWndGetDlgItem(hDlg, IDC_COMBOMEMBERS);
	TCHAR* psz = ::PszGetDisplaySz(m_picsProp, CSINDEX_PROP_MEMBER_NAME, szNick);
	if (psz)
	{
		::SendMessage(hWndCombo, CB_ADDSTRING, 0, (WPARAM)psz);
	}
	::SendMessage(hWndCombo, CB_SETCURSEL, 0, 0);

	::EnableWindow(hWndCombo, FALSE);

	return FSetProps(hDlg);
}

BOOL CMemberProps::FSetProps(HWND hDlg)
{
	BOOL fSet;
	int	index;
	PICS_MEMBER pMem;
	DWORD	dwMode;	
	
	if (m_prgMem)
	{
		// Get current selection
		index = ::SendDlgItemMessage(hDlg, IDC_COMBOMEMBERS, CB_GETCURSEL, 0, 0);
		Assert(index < m_cMem);
		
		pMem = m_prgMem[index];
		Assert(pMem);
		// Get the mode
		if (FAILED(pMem->HrGetMemberMode(&dwMode)))
		{
			AssertSz(0, "HrGetMemberMode");
			return FALSE;
		}
	}
	else
	{
		Assert(m_picsProp);
		
		CS_PROPDATA		csPropData;

		if (FAILED(m_picsProp->HrGetProperty(&csPropData, CSINDEX_PROP_MEMBER_MODE)))
		{
			AssertSz(0, "HrGetProperty");
			return FALSE;
		}
		
		Assert(csPropData.pbData && !csPropData.fString);
		dwMode = *((DWORD*)csPropData.pbData);
	}
	
	BOOL fUser = (m_idDlg == IDD_USERPROPS);
	// Is Authenticated?
	fSet = (fUser)	? (0 != (dwMode & CS_USER_AUTHUSER))
					: (0 != (dwMode & CS_MEMBER_AUTHUSER));
	::SendDlgItemMessage(hDlg, IDC_LBLAUTH, WM_SETTEXT, 0, (LPARAM) (fSet ? m_szYes : m_szNo));
	// Takes whispers?
	fSet = (fUser)	?	(0 == (dwMode & CS_USER_NOWHISPER))
					:	(0 == (dwMode & CS_MEMBER_NOWHISPER));
	::SendDlgItemMessage(hDlg, IDC_LBLNOWHISPER, WM_SETTEXT, 0, (LPARAM) (fSet ? m_szYes : m_szNo));
	// IRC user?
	fSet = (fUser)	?	(0 == (dwMode & CS_USER_IRC))
					:	(0 == (dwMode & CS_MEMBER_IRC));
	::SendDlgItemMessage(hDlg, IDC_LBLIRCUSER, WM_SETTEXT, 0, (LPARAM) (fSet ? m_szYes : m_szNo));
	// And finally.. hosts and speakers
	int idStr;
	
	if (dwMode & CS_MEMBER_HOST)
	{
		idStr = IDS_HOST;
	}
	else if (dwMode & CS_MEMBER_SPEAKER)
	{
		idStr = IDS_SPEAKER;
	}
	else
	{
		idStr = IDS_SPECTATOR;
	}

	::SendDlgItemMessage(hDlg, IDC_LBLSTATUS, WM_SETTEXT, 0, (LPARAM)GetSz(HInstance(hDlg), idStr));

	return TRUE;
}

BOOL CMemberProps::FNotify(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_SETACTIVE:
		SetFinishText(hDlg, IDS_OK);
		break;
	}

	return fRet;
}

BOOL CALLBACK MemPropsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CMemberProps*	pmp;
	BOOL			fRet;

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE*	ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		pmp = (CMemberProps*)ppsp->lParam; 
		SetWindowLong(hDlg, DWL_USER, (LONG)pmp);
	}
	else
	{
		pmp = (CMemberProps*)GetWindowLong(hDlg, DWL_USER);
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pmp->FInitMemProps(hDlg);
		break;
	
	case WM_NOTIFY:
		fRet = pmp->FNotify(hDlg, lParam);
		break;

	case WM_COMMAND:
		switch (HIWORD(wParam))
		{
		default:
			break;

		case CBN_SELENDOK:
			return pmp->FSetProps(hDlg);
		}

		switch (LOWORD(wParam))
		{
		default:
			break;

		case ID_SETFOCUS:
			pmp->SetFocus(hDlg, (int)lParam);
			break;
		}
		break;
	}  

	return fRet;
}

// OPTIONS DIALOG
BOOL FDoOptionsDlg(HWND hWndParent, PUSEROPTIONS puo)
{
	COptionsDlg* pOptions = new COptionsDlg;
	if (!pOptions)
	{
		AssertGLE(FALSE);
		return FALSE;
	}

	SetDisableAll(TRUE);
	BOOL fRet = pOptions->FOptionsDlg(hWndParent, puo);
	SetDisableAll(FALSE);

	pOptions->Release();

	return fRet;
}


BOOL FLoadUserOptions(PUSEROPTIONS puserOptions)
{
	Assert(puserOptions);

	::FGetRegistryBool(HKEY_CURRENT_USER, REG_SZNOTIFYJOIN,		&puserOptions->fNotifyJoin);
	::FGetRegistryBool(HKEY_CURRENT_USER, REG_SZNOTIFYLEAVE,	&puserOptions->fNotifyLeave);
	::FGetRegistryBool(HKEY_CURRENT_USER, REG_SZBLANKLINE,		&puserOptions->fBlankLine);
	::FGetRegistryBool(HKEY_CURRENT_USER, REG_SZSAVE,			&puserOptions->fAutoSave);
	::FGetRegistryBool(HKEY_CURRENT_USER, REG_SZINVITEIGNORE,	&puserOptions->fIgnoreInvite);
	::FGetRegistryDword(HKEY_CURRENT_USER, REG_SZURLCOLOR,		(DWORD*)&puserOptions->cRefURL);

	return TRUE;
}

BOOL FIgnoreInvites(void)
{
	BOOL fRet = FALSE;

	::FGetRegistryBool(HKEY_CURRENT_USER, REG_SZINVITEIGNORE, &fRet);

	return fRet;
}

COptionsDlg::COptionsDlg(void)
	:CChatPropertyPage()
{
}

COptionsDlg::~COptionsDlg(void)
{
}

BOOL COptionsDlg::FOptionsDlg(HWND hWndParent, PUSEROPTIONS pOptions)
{
	Assert(hWndParent);
	
	// 1 Page
	if (!FInit(hWndParent, 1, PSH_NOAPPLYNOW, IDS_OPTIONSDLGTITLE))
	{
		return FALSE;
	}
	// Add pages
	if (!FAddPage(IDD_OPTIONS, UserOptionsDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	::CopyMemory(&m_userOptions, (PVOID)pOptions, sizeof(USEROPTIONS));
	return FShow();
}

BOOL COptionsDlg::FInitOptionsDlg(HWND hDlg)
{
	::CheckDlgButton(hDlg, IDC_CHKJOIN,			m_userOptions.fNotifyJoin);
	::CheckDlgButton(hDlg, IDC_CHKLEAVE,		m_userOptions.fNotifyLeave);
	::CheckDlgButton(hDlg, IDC_CHKBLANKLINE,	m_userOptions.fBlankLine);
	::CheckDlgButton(hDlg, IDC_CHKSAVE,			m_userOptions.fAutoSave);
	::CheckDlgButton(hDlg, IDC_CHKINVITE,		m_userOptions.fIgnoreInvite);
	// Init the color buttns
	if (m_ccbURL.FInit(hDlg, IDC_BTNURL))
	{
		m_ccbURL.SetColor(m_userOptions.cRefURL);
	}
	return TRUE;
}


BOOL COptionsDlg::FNotifyOptions(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg,  DWL_MSGRESULT, !FGetOptionsParams(hDlg));
		break;

	case PSN_APPLY:
		break;
	}

	return fRet;
}

BOOL COptionsDlg::FGetOptionsParams(HWND hDlg)
{
	::FRegistryBoolSet(HKEY_CURRENT_USER, REG_SZNOTIFYJOIN,		::IsDlgButtonChecked(hDlg, IDC_CHKJOIN));
	::FRegistryBoolSet(HKEY_CURRENT_USER, REG_SZNOTIFYLEAVE,	::IsDlgButtonChecked(hDlg, IDC_CHKLEAVE));
	::FRegistryBoolSet(HKEY_CURRENT_USER, REG_SZBLANKLINE,		::IsDlgButtonChecked(hDlg, IDC_CHKBLANKLINE));
	::FRegistryBoolSet(HKEY_CURRENT_USER, REG_SZSAVE,			::IsDlgButtonChecked(hDlg, IDC_CHKSAVE));
	::FRegistryBoolSet(HKEY_CURRENT_USER, REG_SZINVITEIGNORE,	::IsDlgButtonChecked(hDlg, IDC_CHKINVITE));

	COLORREF cRef = m_ccbURL.ColorRef();
	::SetRegistryRaw(HKEY_CURRENT_USER, REG_SZURLCOLOR, REG_DWORD, (PVOID)&cRef, sizeof(DWORD));

	return TRUE;
}

static BOOL FGetPod(HWND hDlg, UINT uMsg, LPARAM lParam, COptionsDlg **ppcs)
{
	Assert(ppcs);

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE* ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		*ppcs = (COptionsDlg*)ppsp->lParam; 
		SetWindowLong(hDlg, DWL_USER, (LONG)*ppcs);
	}
	else
	{
		*ppcs = (COptionsDlg *) GetWindowLong(hDlg, DWL_USER);
	}
	return (NULL != *ppcs);
}

BOOL CALLBACK UserOptionsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	COptionsDlg*	pcs;
	BOOL			fRet;

	if (!FGetPod(hDlg, uMsg, lParam, &pcs))
	{
		return FALSE;
	}

	switch (uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcs->FInitOptionsDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcs->FNotifyOptions(hDlg, lParam);
		break;
	
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case ID_SETFOCUS:
			pcs->SetFocus(hDlg, (int) lParam);
			break;
		
		case IDC_BTNURL:
			(pcs->m_ccbURL).FDrawButton(0, FALSE);
			(pcs->m_ccbURL).FDoPopUp();
			break;
		}
		break;
	}  
	
	return fRet;
} 
