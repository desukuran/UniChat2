//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICCHAN__
#define __ICCHAN__

#include "icinc.h"
#include "icwizard.h"

class	CCreateChannel;

typedef	CCreateChannel	IC_CREATECHAN, *PIC_CREATECHAN;

BOOL	FCreateChannel(HWND hWndParent);
BOOL	FSetTopic(HWND hWndParent, PICS_CHANNEL pChannel);
HRESULT	HrHandleInvite(HWND hWndParent, PCS_MSGBASE pMsg);

/////////////////////////////////////////////////////////////////////////////////////////////
class CCreateChannel : public CChatPropertyPage
{
	friend BOOL CALLBACK ChannelNameDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
	friend BOOL CALLBACK ChannelTypeDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
	friend BOOL CALLBACK JoinChannelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
	friend BOOL CALLBACK ChannelAdvancedDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CCreateChannel(void);
	~CCreateChannel(void);

	BOOL	FCreateChannelDlg(HWND hWndParent);
	BOOL	FJoinChannelDlg(HWND hWndParent);
	BOOL	FChannelPropertyDlg(HWND hWndParent, PICS_CHANNEL pChannel);
	TCHAR*	PszName(void)		{ return m_szName; }
	TCHAR*	PszTopic(void)		{ return m_szTopic; }
	TCHAR*	PszPass(void)		{ return m_szPass; }
	BYTE	BCreateFlags(void)	{ return m_bCreateFlags; }
	DWORD	DwType(void)		{ return m_dwType; }
	DWORD	DwFlags(void)		{ return m_dwFlags; }
	DWORD	DwCUser(void)		{ return m_dwcUser; }
	virtual	void	Free(void)	{ delete this; }

protected:
	BOOL	FInitChannelNameDlg(HWND hDlg);
	BOOL	FNotifyChannelName(HWND hDlg, LPARAM lParam);
	BOOL	FGetChannelNameParams(HWND hDlg);
	BOOL	FSetMicOnly(HWND hDlg);
						
	BOOL	FInitChannelTypeDlg(HWND hDlg);
	BOOL	FGetChannelTypeParams(HWND hDlg);
	BOOL	FNotifyChannelType(HWND hDlg, LPARAM lParam);

	BOOL	FInitJoinChannelDlg(HWND hDlg);
	BOOL	FNotifyJoinChannel(HWND hDlg, LPARAM lParam);
	BOOL	FGetJoinChannelParams(HWND hDlg);

	BOOL	FInitChannelAdvancedDlg(HWND hDlg);
	BOOL	FNotifyChannelAdvanced(HWND hDlg, LPARAM lParam);
	BOOL	FGetChannelAdvancedParams(HWND hDlg);
// Data
protected:
	TCHAR	m_szName[CS_CCHMAX_IRC_CHANNEL + 1];
	TCHAR	m_szTopic[CS_CCHMAX_MIC_TOPIC + 1];
	TCHAR	m_szPass[CS_CCHMAX_CHANNEL_PASS + 1];
	BYTE	m_bCreateFlags;
	DWORD	m_dwType;
	DWORD	m_dwFlags;
	BOOL	m_fFinish;
	BOOL	m_fProp;
	BOOL	m_fIsMicSocket;
	DWORD	m_dwcUser;
	BOOL	m_fIsHost;
};

/////////////////////////////////////////////////////////////////////////////////////////////
class CChangeTopic : public CChatWizard
{
	friend BOOL CALLBACK ChangeTopicDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CChangeTopic(void);
	~CChangeTopic(void);

	BOOL	FChangeTopicDlg(HWND hWndParent, TCHAR* psz);

	TCHAR*	PszTopic(void)	{ return m_szTopic; }
	virtual	void Free(void)	{ delete this; }

protected:
	BOOL	FInitChangeTopicDlg(HWND hDlg);
	BOOL	FNotifyChangeTopic(HWND hDlg, LPARAM lParam);
	BOOL	FGetTopicParams(HWND hDlg);
protected:
	TCHAR	m_szTopic[CS_CCHMAX_MIC_TOPIC + 1];	
};

/////////////////////////////////////////////////////////////////////////////////////////////
class CInvite : public CChatWizard
{
	friend BOOL CALLBACK InviteDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CInvite(void);
	~CInvite(void);

	BOOL FInviteDlg(HWND hWndParent, PICS_INVITATION pInvite);
	virtual	void Free(void)	{ delete this; }

protected:
	BOOL	FInitInviteDlg(HWND hDlg);
	BOOL	FNotifyInvite(HWND hDlg, LPARAM lParam);
	void	Destroy(void);
protected:
	PICS_INVITATION		m_pInvite;
};

#endif

