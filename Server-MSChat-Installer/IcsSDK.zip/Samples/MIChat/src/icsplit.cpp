//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icsplit.h"

const TCHAR gSplitterClass[] = TEXT("MICCHATSPLITBAR");

//--------------------------------------------------------------------------------------------
CChatSplitterWnd::CChatSplitterWnd(void)
			:CChatChildWnd()
{
	m_bType			= 0;
	m_hCursor		= NULL;
	m_fDrag			= FALSE;
	m_idCtl			= 0;
	::ZeroMemory(&m_rcSav, sizeof(RECT));
	::ZeroMemory(&m_rcBounds, sizeof(RECT));
}

CChatSplitterWnd::~CChatSplitterWnd(void)
{
}

// protected
BOOL CChatSplitterWnd::FCreate(HWND hWndParent, int idCtl, RECT* prc, RECT* prcBounds, BOOL fVisible)
{
	// Create the window
	if (!CChatChildWnd::FCreate(hWndParent, idCtl, prc, (TCHAR *) gSplitterClass, SplitWndProc))
	//if (!CChatChildWnd::FCreate(hWndParent, idCtl, prc, (TCHAR *) gSplitterClass, WS_CHILD | WS_BORDER | WS_VISIBLE, 
	//			0, SplitWndProc))
	{
		return FALSE;
	}
	// Load cursors
	if (!FLoadCursor())
	{
		goto LError;
	}
	// Copy the bounding rect
	if (!FSetBoundingRect(prcBounds))
	{
		goto LError;
	}

	m_idCtl = idCtl;
	// plug a pointer of this object into this window
	::SetWindowLong(m_hWnd, GWL_USERDATA, (LONG)this);
	// NOW show the window
	if (fVisible)
	{
		ShowWindow();
	}
	return TRUE;

LError:
	FDestroyWindow();
	UnregisterClass();
	
	return FALSE;
}

// public
BOOL CChatSplitterWnd::FMoveSplitter(RECT* prc)
{
	// FIX ME: Make sure we don't exceed the parent window's bounds
	return FMoveWindow(prc);
}

// public
BOOL CChatSplitterWnd::FSetBoundingRect(RECT* prcBounds)
{
	// if prcBounds is NULL, set bounds to the entire parent window
	if (prcBounds)
	{
		::CopyMemory(&m_rcBounds, (PVOID)prcBounds, sizeof(RECT));
	}
	else
	{
		RECT rc;
		
		if (!::GetClientRect(m_hWndParent, &rc))
		{
			AssertGLE(FALSE);
			return FALSE;
		}
		::CopyMemory(&m_rcBounds, &rc, sizeof(RECT));
	}
	return TRUE;
}

// public
BOOL CChatSplitterWnd::FHandleWMKeyDown(WPARAM wParam)
{
	POINT	pt;
	RECT	rc;
	// where be the mouse?
	if (!::GetCursorPos((LPPOINT)&pt))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	if (!::ScreenToClient(m_hWndParent, (LPPOINT)&pt))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Interpret the keyboard
	switch (wParam)
	{
	default:
		return FALSE;

	case VK_UP:
		pt.y -= DYSPLITSTEP;
		break;

	case VK_DOWN:
		pt.y += DYSPLITSTEP;
		break;

	case VK_LEFT:
		pt.x -= DXSPLITSTEP;
		break;

	case VK_RIGHT:
		pt.x += DXSPLITSTEP;
		break;

	case VK_HOME:
		pt.x = pt.y = 0;
		break;

	case VK_END:
		if (!::GetClientRect(m_hWndParent, (LPRECT)&rc))
		{
			AssertGLE(FALSE);
			return FALSE;
		}
		pt.x = rc.right - LGetWidth() - 1;
		pt.y = rc.bottom - LGetHeight() - 1;
		break;

	case VK_ESCAPE:
		if (!FGetPointOnParent(&pt))
		{
			return FALSE;
		}
		// fall through
	case VK_RETURN:
		Assert(FALSE);
		// Insert code to finish it..
		break;
	}

	if (!::ClientToScreen(m_hWndParent, (LPPOINT)&pt))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Update the mouse position
	if (!::SetCursorPos(pt.x, pt.y))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Convert to the coordinates of the splitter and redraw
	::ScreenToClient(m_hWnd, (LPPOINT)&pt);
	
	return FDrawSplitter(&pt, TRUE);
}

// public
BOOL CChatSplitterWnd::FHandleWMMouseDown(LPARAM lParam)
{
	::ZeroMemory(&m_rcSav, sizeof(RECT));
	// Capture the mouse to permit dragging
	::SetFocus(m_hWnd);
	::SetCapture(m_hWnd);
	m_fDrag = TRUE;
	// Initialize the slider drag
	return FHandleWMMouseMove(lParam);
}

// public
BOOL CChatSplitterWnd::FHandleWMMouseMove(LPARAM lParam)
{
	if (m_fDrag)
	{
		POINT pt;
			
		GetPointFromLParam(lParam, &pt);
		// Move the splitter
		return FDrawSplitter(&pt, TRUE);
	}
	return TRUE;
}

// public
BOOL CChatSplitterWnd::FHandleWMMouseUp(LPARAM lParam)
{
	POINT pt;
	// Erase splitter
	GetPointFromLParam(lParam, &pt);
	FDrawSplitter(&pt, TRUE, TRUE);
	// Move splitter to the new location
	RECT rc;
	if (!FGetSplitterRect(&rc, &pt))
	{
		goto LRelease;
	}
	if (!FMoveSplitter(&rc))
	{
		AssertSz(0, "FMoveSplitter");
	}

LRelease:
	// And give up capture
	GetCapture();
	m_fDrag = FALSE;
	return ::ReleaseCapture();
}

// public
BOOL CChatSplitterWnd::FHandleWMSetCursor(void)
{
	Assert(m_hCursor);
	// Set cursor
	::SetCursor(m_hCursor);
	return TRUE;
}

// protectd
BOOL CChatSplitterWnd::FLoadCursor(void)
{
	// Set cursor
	switch(m_bType)
	{
	default:
		Assert(FALSE);
		return FALSE;

	case HSPLITTER:
		m_hCursor = ::LoadCursor(NULL, MAKEINTRESOURCE(IDC_SIZENS));
		break;
	
	case VSPLITTER:
		m_hCursor = ::LoadCursor(NULL, MAKEINTRESOURCE(IDC_SIZEWE));
		break;
	}
		
	if (NULL == m_hCursor)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

// protected
BOOL CChatSplitterWnd::FGetPointOnParent(POINT *ppt)
{
	// Take the saved rect, convert it to the parent's coordinates and return left, top
	Assert(ppt);

	RECT	rc;
	::CopyMemory(&rc, &m_rcSav, sizeof(RECT));
	MapWindowPointsToParent(&rc);
	ppt->x = rc.left;
	ppt->y = rc.top;
	return TRUE; 
}

// protected
BOOL CChatSplitterWnd::FGetSplitterRect(RECT *prc, POINT *ppt)
{
	// Splitter is being moved. Figure out where to put it.
	// Also save the previous location of the splitter
	// Note: splitter is drawn in the parent window's DC, so we must convert the splitter's
	// coordinates to it..
	Assert(prc && ppt);

	LONG	dxy;
	// Get the client rectangle of the splitter 
	//if (!FGetClientRect((LPRECT)prc))
	if (!FGetWindowRect((LPRECT)prc))
	{
		return FALSE;
	}
	// Covert to this window's coordinates
	::MapWindowPoints(NULL, m_hWnd, (LPPOINT)prc, 2);
	// Now based on what type of splitter this is, construct the new rect
	switch(m_bType)
	{
	default:
		Assert(FALSE);
		return FALSE;

	case HSPLITTER:
		// Update vertically only
		dxy			= prc->bottom - prc->top;
		prc->top	= ppt->y;
		prc->bottom	= prc->top + dxy;
		break;

	case VSPLITTER:
		// Update horizontally only
		dxy			= prc->right- prc->left;
		prc->left	= ppt->x;
		prc->right	= prc->left + dxy;
		break;
	}
	// turn it into parent coods
	MapWindowPointsToParent(prc);
	// Save it
	::CopyMemory(&m_rcSav, prc, sizeof(RECT));

	return TRUE;
}

// protected
void CChatSplitterWnd::AdjustPoint(POINT *ppt)
{
	Assert(ppt);

	// Adjust the given point so it is always WITHIN the bounding rects given to us
	// NOTE: this assumes that ppt is in m_hWnd coords
	POINT pt = *ppt;
	// splitter to parent
	::MapWindowPoints(m_hWnd, m_hWndParent, &pt, 1);

	if (pt.x < m_rcBounds.left)
	{
		pt.x = m_rcBounds.left;
	}
	else if (pt.x > m_rcBounds.right)
	{
		pt.x = m_rcBounds.right;
	}

	if (pt.y < m_rcBounds.top)
	{
		pt.y = m_rcBounds.top;
	}
	else if (pt.y > m_rcBounds.bottom)
	{
		pt.y = m_rcBounds.bottom;
	}
	// parent to splitter
	::MapWindowPoints(m_hWndParent, m_hWnd, &pt, 1);

	ppt->x	= (short) pt.x;
	ppt->y	= (short) pt.y;
}

// protected
void CChatSplitterWnd::GetPointFromLParam(LPARAM lParam, POINT *ppt)
{
	Assert(ppt);

	ppt->x	= (short)LOWORD(lParam);
	ppt->y	= (short)HIWORD(lParam);

	AdjustPoint(ppt);
}

// protected
BOOL CChatSplitterWnd::FDrawSplitter(POINT *ppt, BOOL fErase, BOOL fOnlyErase)
{
	// Erase previous splitter, then draw splitter in new location
	RECT	rc;
	BOOL	fRet = FALSE;

	Assert(m_hWndParent && ppt);

	HDC hDC = ::GetDC(m_hWndParent);
	if (NULL == hDC)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Erase saved rect
	if (fErase)
	{
		if (!FPatBlt(hDC, &m_rcSav))
		{
			return FALSE;
		}
	}
	if (!fOnlyErase)
	{
		// Get a new rect
		if (!FGetSplitterRect(&rc, ppt))
		{
			goto LReturn;
		}
		// Draw it
		if (!FPatBlt(hDC, &rc))
		{
			goto LReturn;
		}
	}
	fRet = TRUE;
LReturn:

	::ReleaseDC(m_hWndParent, hDC);
	return fRet;
}

// protected
BOOL CChatSplitterWnd::FPatBlt(HDC hDC, RECT* prc)
{
	BOOL fRet = ::PatBlt(hDC, prc->left, prc->top,
						prc->right - prc->left, prc->bottom - prc->top, PATINVERT);
	AssertGLE(fRet);
	return fRet;
}

// protected
void CChatSplitterWnd::MapWindowPointsToParent(RECT* prc)
{
	Assert(prc && m_hWnd);

	::MapWindowPoints(m_hWnd, m_hWndParent, (LPPOINT)prc, 2);
}

// protected
void CChatSplitterWnd::SendDoneToParent(void)
{
	// Let the parent know that the splitter is no longer active
	int	idDone;

	switch (m_bType)
	{
	default:
		Assert(FALSE);
		return;

	case HSPLITTER:
		idDone = USER_HSPLITDONE;
		break;

	case VSPLITTER:
		idDone = USER_VSPLITDONE;
		break;
	}
	::SendMessage(m_hWndParent, WM_COMMAND, MAKEWPARAM(idDone, 0), (LPARAM)m_idCtl);
}

LRESULT CALLBACK SplitWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CChatSplitterWnd* pcsw = (CChatSplitterWnd*)::GetWindowLong(hWnd, GWL_USERDATA);

	switch (uMsg)
	{
	default:
		break;
	// Control splitters with keyboard
	case WM_KEYDOWN:
		return pcsw->FHandleWMKeyDown(wParam);

	// Splitters become active now
	case WM_LBUTTONDOWN:
		return pcsw->FHandleWMMouseDown(lParam);

	// Move splitter
	case WM_MOUSEMOVE:
		return pcsw->FHandleWMMouseMove(lParam);

	// end of splitter
	case WM_LBUTTONUP:
		if (!pcsw->FHandleWMMouseUp(lParam))
		{
			break;
		}
		// Let the owner know that we are done
		pcsw->SendDoneToParent();
		return TRUE;

	case WM_SETCURSOR:
		if (pcsw->FHandleWMSetCursor())
		{
			return TRUE;
		}
		break;
	}
	return (DefWindowProc(hWnd, uMsg, wParam, lParam));
}

