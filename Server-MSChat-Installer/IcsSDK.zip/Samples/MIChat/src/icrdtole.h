//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __RICHOLE__
#define __RICHOLE__

#pragma warning( disable : 4005 )	// macro redefinition
#pragma warning( disable : 4103 )	// used pragma pack

#undef SHORT
#undef USHORT
#undef ULONG

//--------------------------------------------------------------------------------------------
//
// INCLUDES
//
//--------------------------------------------------------------------------------------------
#include <ole2.h>
#include <richedit.h>
#include <richole.h>

#pragma warning( default : 4103 )
#pragma warning( default : 4005 )

//--------------------------------------------------------------------------------------------
//
// TYPES
//
//--------------------------------------------------------------------------------------------
//
// Type for an object-destroyed callback
//
typedef void (PASCAL *PFNDESTROYED)(void);
typedef LPVOID FAR *LPLPVOID;

//--------------------------------------------------------------------------------------------
//
// CLASSES
//
//--------------------------------------------------------------------------------------------

//
// Generic Call Back for RichEdit
//
class CTCRichEditCallback : public IRichEditOleCallback
	{
	//
	// Interfaces
	//
	public:

										CTCRichEditCallback(LPUNKNOWN punkOuter,
															PFNDESTROYED pfndestroy);
										~CTCRichEditCallback(void);
				//
				// IUnknown methods
				//
				STDMETHODIMP			QueryInterface(REFIID, LPLPVOID);
				STDMETHODIMP_(ULONG)	AddRef(void);
				STDMETHODIMP_(ULONG)	Release(void);
				//
				// IRichEditOleCallback methods
				//
				STDMETHODIMP			GetNewStorage(LPSTORAGE FAR * lplpstg);
				STDMETHODIMP			GetInPlaceContext(LPOLEINPLACEFRAME FAR * lplpFrame,
														LPOLEINPLACEUIWINDOW FAR * lplpDoc,
															LPOLEINPLACEFRAMEINFO lpFrameInfo);
				STDMETHODIMP			ShowContainerUI(BOOL fShow) ;
				STDMETHODIMP			QueryInsertObject(LPCLSID lpclsid, LPSTORAGE lpstg,
															LONG cp);
				STDMETHODIMP			DeleteObject(LPOLEOBJECT lpoleobj);
				STDMETHODIMP			QueryAcceptData(LPDATAOBJECT lpdataobj,
															CLIPFORMAT FAR * lpcfFormat,
															DWORD reco,	BOOL fReally,HGLOBAL hMetaPict);
				STDMETHODIMP			ContextSensitiveHelp(BOOL fEnterMode);
				STDMETHODIMP			GetDragDropEffect(BOOL fDrag, DWORD grfKeyState,
															LPDWORD pdwEffect);
				STDMETHODIMP			GetContextMenu(WORD seltype, LPOLEOBJECT lpoleobj,
															CHARRANGE FAR * lpchrg,
															HMENU FAR * lphmenu);	
	//
	// Data
	//
	protected:					
				ULONG           		m_cRef;			// Object reference count
				LPUNKNOWN				m_punkOuter;	// Controlling unknown
				PFNDESTROYED			m_pfndestroy;	// To call on closure
	};

#endif 
