//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICSEND__
#define __ICSEND__

#include "icinc.h"
#include "icpane.h"
#include "icwprop.h"
#include "icbtn.h"

// Pane that contains Send Window Features
class CChatSendPane : public CChatPane
{
	friend	LRESULT CALLBACK SendWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// interfaces
public:
	CChatSendPane(void);
	~CChatSendPane(void);

	TCHAR*			PszSendText(void);
	int				GetSendTextLength(void)	{ return m_uiSend.GetTextLength(); }
	CUIRichEdit*	Pui()					{ return &m_uiSend; }

	BOOL		FMemberModeChange(PICS_CHANNEL pChannel, PICS_MEMBER pMember);
	BOOL		FChannelModeChange(PICS_CHANNEL pChannel);

	virtual HWND	HWndSetFocus(void);

protected:
	virtual BOOL	FInitElements(void);
	virtual BOOL	FHandleWMSize(WPARAM wParam, LPARAM lParam);
// Data
protected:
	CUIRichEdit		m_uiSend;		// send message buffer window
	CChatBtnPane	m_cbp;			// sub pane..
	
	TCHAR*			m_pszBuf;		// buffer for getting "send" data
};

#endif
