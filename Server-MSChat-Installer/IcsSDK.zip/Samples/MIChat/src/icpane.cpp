//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icpane.h"

TCHAR	gPaneClass[] = TEXT("MICCHATPANE");

//--------------------------------------------------------------------------------------------
CChatPane::CChatPane(void)
		: CChatChildWnd()
{
	m_wndProc = NULL;
	SetParentPane(NULL);
}

CChatPane::~CChatPane(void)
{
}

BOOL CChatPane::FCreateOverlap(HWND hWndParent, RECT* prc)
{
	if (!CChatChildWnd::FCreate(hWndParent, NULL, prc, gPaneClass, 
								WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME, 
								WS_EX_CLIENTEDGE, PaneWndProc))
	{
		return FALSE;
	}
	// Store a pointer to this object in the window
	SetWindowLong(m_hWnd, GWL_USERDATA, (LONG)this);
	// In reality,  we don't want a parent for this window. FCreate will have registered
	// hWndParent is a parent window,  and once that is done...
	::SetParent(m_hWnd, NULL);
	// let panes initialize their sub-components
	if (!FInitElements())
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CChatPane::FCreate(HWND hWndParent, int idCtl, RECT* prc, BOOL fBorder, BOOL fPopUp)
{
	if (!CChatChildWnd::FCreate(hWndParent, idCtl, prc, gPaneClass, 
								(fPopUp ? WS_POPUP : WS_CHILD)  
								| (fPopUp ? 0 : WS_VISIBLE) // popups are NOT visible by default
								| (fBorder ? WS_BORDER : 0), 
								fBorder ? WS_EX_CLIENTEDGE : 0, PaneWndProc))
	{
		return FALSE;
	}
	// Store a pointer to this object in the window
	SetWindowLong(m_hWnd, GWL_USERDATA, (LONG)this);
	// let panes initialize their sub-components
	if (!FInitElements())
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CChatPane::FGiveMsgToParent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (m_pcpParent)
	{
		return m_pcpParent->FHandleMsgFromChild(uMsg, wParam, lParam);
	}
	return ::PostMessage(m_hWndParent, uMsg, wParam, lParam);
}

////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK PaneWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CChatPane* pcp = (CChatPane*)GetWindowLong(hWnd, GWL_USERDATA);

	switch(uMsg)
	{
	default:
		break;
	
	case WM_SIZE:
		if (pcp)
		{
			if (wParam != SIZE_MINIMIZED && wParam != SIZE_MAXHIDE)
			{
				if (pcp->FHandleWMSize(wParam, lParam))
				{
					return TRUE;
				}
			}
		}
		break;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

