//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICMEMBER__
#define __ICMEMBER__

#include "icinc.h"

//
// A Chat member

// Chat member properties stored as flags:
//
#define CLIENTPROPSELECTED	0x0001	// bit 1 - if set, the user is selected -(checkmarked in a list)

class CMember
{
// Interfaces
public:
	CMember(void);
	~CMember(void);
	CHARFORMAT*	PcFormat(void)	{ return m_pcFormat; }
	BOOL		FSetCharFormat(CHARFORMAT* pcf);
	void		FResetCharFormat(void)	{ DeleteCharFormat(); }
	BOOL		FIsSelected(void)		{ return ( 0 != (m_bFlags & CLIENTPROPSELECTED)); }
	void		SetSelected(BOOL fSelected);

protected:
	void		DeleteCharFormat(void);
// Data
protected:
// A Chat Member's local properties
	CHARFORMAT*	m_pcFormat;		// color and font info
	BYTE		m_bFlags;		// common flags, such as AWAY and Ignore
};

#endif
