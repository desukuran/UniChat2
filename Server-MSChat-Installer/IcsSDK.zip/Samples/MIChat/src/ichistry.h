//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICHISTORY__
#define __ICHISTORY__

#include "icinc.h"
#include "icpane.h"
#include "icwprop.h"

//
// Pane that contains History Window Features
class CChatHistoryPane : public CChatPane
{
friend	LRESULT CALLBACK HistoryWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// interfaces
public:
	CChatHistoryPane(void);
	~CChatHistoryPane(void);
	BOOL		FSetBufferSize(DWORD dwcb);
	BOOL		FHandleMsg(PCS_MSGBASE pcsMsg, PICS_CHANNEL picsChannel);
	BOOL		FHandleWhisper(PCS_MSGBASE pcsMsg, PICS_CHANNEL picsChannel);
	TCHAR		*PszGetName(PICS_MEMBER pcm);
	BOOL		FHandleAddMember(PICS_MEMBER pcm);
	BOOL		FHandleDelMember(PICS_MEMBER pcm);
	BOOL		FHandleModeChannel(PCS_MSGBASE pcsMsg);
	BOOL		FHandleModeChannel(PICS_MEMBER pcm);

	BOOL		FHandleNickChange(PCS_MSGBASE pcsMsg);

	BOOL		FInsertMsg(PICS_MEMBER pcsMem, TCHAR* psz, PICS_CHANNEL picsChannel, 
						BOOL fScroll=FALSE, BOOL fWhisper=FALSE, BOOL fEcho=FALSE);

	BOOL		FInsertWhisper(PICS_MEMBER picsFrom, DWORD dwcMem, 
								PICS_MEMBER* prgMember, TCHAR* psz, BOOL fScroll=FALSE);
	
	BOOL		FSave(BOOL fSaveAs=FALSE);

	CUIRichEdit*	Pui()	{ return &m_ui; }
	void		SetBlank(BOOL fSet)
					{
					m_fBlank = fSet;
					}
	BOOL		FBlankLine(void)
					{
					return m_fBlank;
					}
	void		SetURLColor(COLORREF cRef)
					{
					m_ui.SetLinkColor(cRef);
					}			
protected:
virtual	BOOL		FInitElements(void);
virtual	BOOL		FHandleWMSize(WPARAM wParam, LPARAM lParam);

	BOOL		FInsertUserName(PICS_MEMBER pcm, BOOL fEnd = TRUE);
	BOOL		FInsertSystemMsg(DWORD dwMsgId, TCHAR *psz, TCHAR *szPrefix = NULL);				
//
// Data
// 
protected:
	CUIRichEdit	m_ui;		// history window
	TCHAR		*m_pszText;	// we preallocate this buffer..

	TCHAR		m_szConvert[CS_CCHMAX_MIC_USERNAME + 1];
	BOOL		m_fBlank;	// blank line after every msg?
};

#endif
