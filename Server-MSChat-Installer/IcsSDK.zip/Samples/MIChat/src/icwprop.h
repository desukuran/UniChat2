//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICWPROP__
#define __ICWPROP__

#include "icinc.h"
#include "icutil.h"
#include "icrdtole.h"
#include "fontclr.h"

// File Types
#define TC_RTF		1
#define TC_TXT		2

extern TCHAR gszTerm[];

//--------------------------------------------------------------------------------------------
BOOL	FHandleIfMicURL(HWND hWndParent, TCHAR* szURL);
BOOL	FIsURL(TCHAR* szURL, int* pISep, int* pcchURL);
BOOL	FCopyURL(TCHAR* szURL, TCHAR** ppszCopy);
BOOL	FMakeMicURL(CHAR* szServer, CHAR* szChannel, CHAR* szURL);
//--------------------------------------------------------------------------------------------
// RichEdit Window UI element
class CUIRichEdit : public CChatChildWnd
{
friend	DWORD CALLBACK RichSaveHistory(DWORD dwCookie, LPBYTE pbBuff, LONG lcb, LONG far* plcb);
friend	LRESULT CALLBACK RichEditUIWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CUIRichEdit(int idName=-1);
	~CUIRichEdit(void);

 	BOOL		FCreate(HWND hWndParent, int idCtl, RECT* prc, BOOL fAutoURL=TRUE, BOOL fAutoScroll=FALSE);
	BOOL		FSetColorCharFormat(COLORCHARFORMAT* pccf, BOOL fRedraw=FALSE);
	COLORCHARFORMAT* Pccf(void)	{ return &m_ccf; }
	BOOL		FRedraw(void);
	void		SetDirty(void)	{ if (m_hWnd)	SendMessage(EM_SETMODIFY, (WPARAM)TRUE); }
	void		SetClean(void)	{ if (m_hWnd)	SendMessage(EM_SETMODIFY, (WPARAM)FALSE); }
	BOOL		FDirty(void)	{ return (m_hWnd) ? SendMessage(EM_GETMODIFY) : FALSE; }
	BOOL		FIsSaved(void)	{ return (INVALID_HANDLE_VALUE != m_hFile); }	// was this saved before?
	void		SetReadOnly(BOOL fReadOnly)
				{
					m_fReadOnly = fReadOnly;
					SendMessage(EM_SETREADONLY, (WPARAM)(BOOL)fReadOnly);
				}
	BOOL		FReadOnly(void)	{ return m_fReadOnly; }
	BOOL		IsVisible(void)	{ return m_hWnd ? IsWindowVisible(m_hWnd) : FALSE; }
	TCHAR*		PSzName(void)	{ return m_szName; }
	int			GetTextLength(void)		{ return SendMessage(WM_GETTEXTLENGTH); }
	void		SetTextLimit(int cbMax)	{ SendMessage(EM_SETLIMITTEXT, (WPARAM)cbMax); }
	// Action Commands
	void 		Copy(void);
	void		Cut(void);
	void		Paste(void);
	void		SelectAll(void);
	void		Clear(void);
	BOOL		FSaveAs(TCHAR* pszFileName, int wFileType);
	BOOL		FSave(TCHAR* pszFileName);
	void		Deselect(void);
	TCHAR*		PSzGetSelection(void);
	TCHAR*		PSzGetAllText(void);
	BOOL		FGetAllText(TCHAR* pszText, int cch);

	void		InsertText(TCHAR* psz);
	void		InsertAllText(TCHAR* psz);
	void		IndentText(DWORD dwIndent);
	BOOL		FInsertMsg(DWORD dwMsgID, TCHAR* psz=NULL);
	void 		CarriageReturn(void)	{ InsertText(gszTerm); }

	void 		SetCharFormat(BOOL fSet, BOOL fColor, BOOL fBold=FALSE, CHARFORMAT* pcf=NULL);
	void		TurnOnColor(CHARFORMAT* pcf)	{ SetCharFormat(TRUE, TRUE, FALSE, pcf); }
	void		TurnOffColor(CHARFORMAT* pcf)	{ SetCharFormat(FALSE, TRUE, FALSE, pcf); }
	void		TurnOnBold(void)				{ SetCharFormat(TRUE, FALSE, TRUE); }
	void		TurnOffBold(void)				{ SetCharFormat(FALSE, FALSE, TRUE); }
	void		TurnOnColorAndBold(CHARFORMAT* pcf)		{ SetCharFormat(TRUE, TRUE, TRUE, pcf); }
	void		TurnOffColorAndBold(CHARFORMAT* pcf)	{ SetCharFormat(FALSE, TRUE, TRUE, pcf); }

	void		SetDefaultCharFormat(void)	{ SendMessage(EM_SETCHARFORMAT, (WPARAM)SCF_SELECTION, (LPARAM)&m_ccf.cformat); }
	void		SaveAndMoveSel(void);
	void		RestoreSel(void);
	void		AutoScrollHistory(void);
	BOOL		FEndInView(void);

	HRESULT			HrStorageGet(LPSTORAGE* lplpstg);
	LPRICHEDITOLE	PREOle(void)	{ return m_pREOle; }
	BOOL		FDragDrop(ENDROPFILES* pedf);
	void		DragAcceptFiles(BOOL fOn)	{ ::DragAcceptFiles(m_hWnd, fOn); }

	// Action command status
virtual	BOOL		FCopyAvailable(void);
virtual	BOOL		FCutAvailable(void)	{ return (FCopyAvailable() && !FReadOnly()); }
virtual BOOL		FPasteAvailable(void);

	void		SetWindowProc(WNDPROC wndProc);
	BOOL		FGiveMsgToParent(UINT uMsg, WPARAM wParam, LPARAM lParam);
	
	// URLS
	void		RecognizeURLs(LONG cpRangeStart, LONG cpRangeEnd);
	BOOL		FHandleLink(ENLINK* penlink);
	BOOL		FFindBrowser(BOOL fReload = FALSE);
	BOOL		FLaunchBrowser(TCHAR* szURL);
	BOOL		FWinExecBrowser(TCHAR* szURL);
	COLORREF	CRefLink(void)				{ return m_cRefURL; }
	void		SetLinkColor(COLORREF cRef)	{ m_cRefURL = cRef; }

protected:
	BOOL		FInitElement(void);
	BOOL		FInitOLE(void);
	DWORD		DwSaveHistory(LPBYTE pbBuff, LONG lcb, LONG* plcb);
	BYTE		FIsShortCut(LPSTR pszFile);
	BOOL		FAcceptDrag(TCHAR* szFile);
				
	BOOL		FInitFontColors(void);

	LRESULT		LrCallWindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam);

// Data
protected:
	// DLL
	HINSTANCE		m_hInstRichEdit;	// richedit dll.
	int				m_idName;			// id of the string that represents this object's name.
	// window properties..
	TCHAR			m_szName[64];		// internal name of this element. Used for customize dialogs
	COLORCHARFORMAT	m_ccf;	
	int				m_cBold;			// is bolding on? A ref count
	CHARRANGE 		m_charSav;			// save previous selection		
	BOOL			m_fRestore;			// scolling restoration needed?
	// ole objects
	LPRICHEDITOLE	m_pREOle;			// pointer to the richedit's ole interface
	LPSTORAGE		m_pStorage;			// pointer to storage for this message.	
	DWORD			m_cdwItem;			// count of ole shortcuts inserted
	//CUIDragAndDrop	*m_puiDragDrop;		// drag and drop
	// History File
	HANDLE 			m_hFile;
	int				m_iFileType;
	BOOL			m_fReadOnly;
	BOOL			m_fAutoScroll;
	// URLS
	BOOL			m_fFindURLS;	// auto find URLS?
	LPTSTR			m_pszURLPrefixs;
	TCHAR			m_szBrowserPath[MAX_PATH];
	HCURSOR			m_hCursor;
	COLORREF		m_cRefURL;
	// Subclass
	WNDPROC			m_wndProc;		// we subclass the rich edit control
};

// Interface with RichEdit. 
// One of the contents of this pane is a Richedit control
// RICH EDIT Callback
class CChatRichEditCallBack : public CTCRichEditCallback
{
// Interfaces
public:
	CChatRichEditCallBack(LPUNKNOWN punkOuter, PFNDESTROYED pfndestroy);
	STDMETHODIMP	GetClipboardData(CHARRANGE FAR* lpchrg, DWORD reco, LPDATAOBJECT FAR* lplpdataobj);
	STDMETHODIMP	GetNewStorage(LPSTORAGE FAR* lplpstg);
	void			SetPUI(CUIRichEdit* pui);
// Data
protected:
	CUIRichEdit*	m_pui;
};


#endif
