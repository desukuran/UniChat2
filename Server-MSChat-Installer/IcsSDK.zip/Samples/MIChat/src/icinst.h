//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICINST__
#define __ICINST__

#include "icinc.h"
#include "icsplit.h"
#include "icpane.h"
#include "ictools.h"
#include "ichistry.h"
#include "icsend.h"
#include "icmember.h"
#include "icmemlst.h"
#include "icchan.h"
#include "icfind.h"

// default perkilo (out of 1000) split
#define PERCENTSIZE			1000	// this percentage is out of 1000 - perkilo!
#define PCTHSPLITDEFAULT 	750
#define PCTVSPLITDEFAULT 	800
#define PCTLHSPLITDEFAULT 	200

// Ids for the portions that splitters divide the main chat window into
#define LEFTWIDTH			1	// these 2 are for the Horizontal splitter
#define RIGHTWIDTH			2
#define TOPHEIGHT			3	// vertical splitter
#define BOTTOMHEIGHT		4
#define TOTALWIDTH			5	// and the sum of all evils
#define TOTALHEIGHT			6
#define TOOLBARHEIGHT		7
#define MIDDLEWIDTH			8
#define STATUSBARHEIGHT		9

// Ids for context menus
#define imenuMember			0
#define imenuChannelFolder	1
#define imenuUsersFolder	2
#define imenuChannel		3
#define imenuUser			4
#define imenuMemBrowser		5

#define cmenus				6

//--------------------------------------------------------------------------------------------
class	CIChat;

typedef CIChat	CI_CHAT, *PCI_CHAT;

//////////////////////////////////////////////////////////////////////////////////////////////
// The main application class.
// Everything is global here.
class CIChat
{
	friend LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CIChat(DWORD dwID);
	~CIChat(void);

	BOOL		FInit(HINSTANCE hInst, PICS_CHANNEL picsChan);
	void		Quit(void);
	BOOL		FHandleCommand(WPARAM wParam, LPARAM lParam);
	BOOL		FHandleNotify(NMHDR *pnmhdr);
	BOOL		FSizeAll(void);
	DWORD		DwMainThread(void);
	DWORD		DwMessageThread(void);
	HWND		HWndMain(void)			{ return m_hWnd; }
	void		SetDefaultFocus(void)	{ m_ccsp.HWndSetFocus(); }
protected:
	// UI
	BOOL		FRegisterClass(void);
	void		UnregisterClass(void);
	BOOL		FCreateWindow(void);
	void		DestroyWindow(void);
	BOOL		FInitSplitters(void);
	BOOL		FInitPanes(void);
	BOOL		FInitToolBar(void);
	BOOL		FInitStatusBar(void);
	BOOL		FLoadUserSettings(void);

	int			IGetHeightWidth(int idType);
	void		GetHSplitterRect(RECT* prc);
	void		GetVSplitterRect(RECT* prc);
	void		GetLVSplitterRect(RECT* prc);
	void		GetHistoryRect(RECT* prc);
	void		GetSendRect(RECT* prc);
	void		GetListBoxRect(RECT* prc);
	void		GetToolBarRect(RECT* prc);
	void		GetFindRect(RECT* prc);
	void		GetStatusBarRect(RECT* prc);

	BOOL		FSizePanes(void);
	BOOL		FSizeSplitters(void);
	BOOL		FSizeBars(void);
	BOOL		FSetPercent(BOOL fSetH, int idCtl);
	BOOL		FSetHPercent(int idCtl)		{ return FSetPercent(TRUE, idCtl); }
	BOOL		FSetVPercent(int idCtl)		{ return FSetPercent(FALSE, idCtl); }

	// Commands
	int			FCheckCommandStatus(UINT idCmd, int* pidStr, int* pidHelp);
	BOOL		FInitMenu(HMENU hMenu, UINT uPos);
	BOOL		FIsCommandActive(UINT idCmd, BOOL* pfChecked=NULL);
	BOOL		FCheckEditCommandStatus(UINT idCmd, int* pidStr, int* pidHelp);
	BOOL		FCheckViewCommandStatus(UINT idCmd, int* pidStr, int* pidHelp);
	CUIRichEdit*	PuiGetFocus(void);
	BOOL		FHandleEditCommand(WPARAM wParam, LPARAM lParam);
	BOOL		FHandleViewCommand(WPARAM wParam, LPARAM lParam);
	BOOL		FShowFindPane(void);

	// Chat
	BOOL		FHandleChannelMsg(PCS_MSGBASE pcsMsg);

	BOOL		FCreateChannel(void);
	BOOL		FJoinChannel(void);
	BOOL		FChannelProperties(void);

	BOOL		FSendText(void);
	BOOL		FCopyMeOnMsg(TCHAR* psz);
	BOOL		FSendWhisper(void);

	PICS_CHANNEL	PicsChannel(void);
	BOOL		FCloseChannel(void);
	BOOL		FAmIHost(void);
	BOOL		FAmISpeaker(void);
	BOOL		FIsMemberMe(PICS_MEMBER pMember);
	BOOL		FDoITakeWhispers(void);
	BOOL		FToggleTakeWhispers(void);

	BOOL		FHandleServerErrors(HRESULT hr);
	BOOL		FSetWindowTitle(void);
	BOOL		FSetStatusBar(void);
	BOOL		FIsRoomChat(void);
	BOOL		FIsEchoSourceChat(void);
	BOOL		FIsModeratedChat(void);
	BOOL		FIsWhisperActive(void);

	BOOL		FAddMember(PCS_MSGBASE pcsMsg);
	BOOL		FDelMember(PCS_MSGBASE pcsMsg);
	BOOL		FUpdateMember(PCS_MSGBASE pcsMsg, BOOL fMode = TRUE);
	BOOL		FUpdateNick(PCS_MSGBASE pcsMsg);
	BOOL		FHandleModeChannel(PCS_MSGBASE pcsMsg);
				
	void		SetGotList(BYTE bGot);
	BYTE		BGotList(void);

	BOOL		FListAllChannels(void);
	BOOL		FListAllUsers(void);

	BOOL		FShowMemberProperties(void);
	BOOL		FShowUserProperties(void);
	BOOL		FIsMemberPropertiesActive(void);
	BOOL		FIsUserPropertiesActive(void);
	BOOL		FIsMemberSelectedInBrowser(PICS_PROPERTY* ppProp, BOOL fUsersAlso=FALSE);
	BOOL		FIsUserSelectedInBrowser(PICS_PROPERTY* ppProp);

	BOOL		FIsRealNameActive(void);
	BOOL		FGetRealName(void);
	BOOL		FGetUserRealName(void);
	
	BOOL		FDoHelp(void);
	
	BOOL		FInviteMember(void);
	BOOL		FInviteUser(void);
	BOOL		FInvite(PICS_PROPERTY pp);
	BOOL		FCanIChangeTopic(void);

	BOOL		FInsertURL(void);
	BOOL		FCreateShortcut(BOOL fDesktop);

	BOOL		FConnectionSettings(void);

	BOOL		FKickAlert(void);

	BOOL		FTabKeyNav(int idCmd, BOOL fShift=FALSE);
	BOOL		FNotifyJoin(void)	{ return m_userOptions.fNotifyJoin; }
	BOOL		FNotifyLeave(void)	{ return m_userOptions.fNotifyLeave; }
	BOOL		FAutoSave(void)		{ return m_userOptions.fAutoSave; }
	BOOL		FBlankLine(void)	{ return m_userOptions.fBlankLine; }
	BOOL		FIgnoreInvite(void) { return m_userOptions.fIgnoreInvite; }
	COLORREF	CRefURL(void)		{ return m_userOptions.cRefURL; }

// Data
public:
	HINSTANCE		m_hInst;
	BOOL			m_fRegistered;
	HWND			m_hWnd;		// the main window
	CS_LOCK			m_csData;	// data protector
	DWORD			m_dwID;		// this chat instance's id.

	// Channel
	PICS_CHANNEL	m_pChannel;
	PICS_MEMBER		m_pMemMe;			// pointer to ourselves..
	PICS_MEMBER		m_pMemKick;			// pointer to member who kicked us..
	CHAR*			m_szReason;			// reason for the kick
	CS_THREAD		m_msgThread;
	// CS_THREAD		m_mainThread;	// the main thread for this instance

	// UI ELEMENTS
	// Splitters
	CChatSplitterWnd	m_cswH;		// horizontal splitter
	CChatSplitterWnd	m_cswV;		// vertical splitter
	CChatSplitterWnd	m_cswLV;	// the left vertical splitter
	// The splitters split the screen according to the following percentages
	int				m_pctH;	// % of real estate is split horizontally by these..
	int				m_pctLH;
	int				m_pctV;	// % of real estate is split vertically by these
	int				m_pctLHSav;
	//
	// And the panes they split
	CChatHistoryPane	m_cchp;
	CChatSendPane		m_ccsp;
	CChatListPane		m_cclp;
	CChatFindPane*		m_pccfp;
	//
	// Find
	CFindDlg*		m_pcfd;			// channels
	CFindDlg*		m_pcfdUsers;	// users
	//
	// Toolbars and status bars
	CChatToolBar	m_ctb;
	CChatStatusBar	m_csb;
	//
	// Flags
	BOOL			m_fInStartUp;	// are we still starting? 
	BYTE			m_bGotList;
	BYTE			m_bModeSkip;	// mode change notifications to ignore
	// User options
	USEROPTIONS		m_userOptions;
};

#endif
