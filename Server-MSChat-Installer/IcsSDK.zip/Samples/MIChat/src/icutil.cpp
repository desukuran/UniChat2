//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icutil.h"

#define		IRGMAXSZS		20

TCHAR		gszStrTable[IRGMAXSZS][256];
int			giSzTable = 0;


const TCHAR SZMICCHATKEY[] = "Software\\Microsoft\\MicChat";

// Format of .URLs that we read and save to the Desktop etc
//
const TCHAR SZSHORTCUT[]	= "InternetShortcut";
const TCHAR SZURLKEY[]		= "URL";

//--------------------------------------------------------------------------------------------
// Common APIS
//--------------------------------------------------------------------------------------------

HWND HWndCreateDummy(HINSTANCE 	hInst,  	// instance of the app/dll
					WNDPROC		pwndProc, 	// window procedure for this window..
					LPCTSTR		pszName)	// class name..
{
	Assert (NULL != hInst && NULL != pwndProc && NULL != pszName);

	WNDCLASS	WndCls;
	HWND		hWnd;
	
	hWnd = NULL;
	::ZeroMemory(&WndCls, sizeof(WNDCLASS));

	WndCls.style 			= CS_GLOBALCLASS;
	WndCls.lpfnWndProc 		= pwndProc;
	
	WndCls.hInstance 		= hInst;
	WndCls.lpszClassName	= pszName;

	if (!::RegisterClass(&WndCls))
	{
		AssertGLE(FALSE);
		return NULL;
	}

	hWnd = ::CreateWindow(pszName, 
						pszName, 
						WS_OVERLAPPEDWINDOW |	//put up a window that is overlapped, centered and hidden
						DS_CENTER, 
						CW_USEDEFAULT, 			//use default sizes...
						CW_USEDEFAULT, 
						CW_USEDEFAULT, 
						CW_USEDEFAULT, 
						NULL, 
						NULL, 
						hInst, 
						NULL);
	if (!hWnd)
	{
		AssertGLE(FALSE);
		::UnregisterClass(pszName, hInst);
		return NULL;
	}
	return hWnd;
} // HWndCreateDummy

BOOL FGetTextExtentPoint(HWND hWnd, TCHAR* psz, SIZE* psize)
{
	BOOL	fRet = FALSE;

	Assert(hWnd && psize);

	HDC hdc = ::GetDC(hWnd);
	if (NULL == hdc || !::GetTextExtentPoint32(hdc, psz, lstrlen(psz), psize))
	{
		AssertGLE(FALSE);
		goto LReturn;
	}
	fRet = TRUE;

LReturn:
	if (hdc)
	{
		::ReleaseDC(hWnd, hdc);
	}
	return fRet;
}

// BEWARE uses static variable.
TCHAR* GetSz(HINSTANCE hInst, WORD wszID)
{
	TCHAR* psz = gszStrTable[giSzTable];
	
	giSzTable++;
	if (giSzTable >= IRGMAXSZS)
	{
		giSzTable = 0;
	}
	if (!::LoadString(hInst, wszID, psz, 256))
	{
		AssertGLE(FALSE);
		*psz = 0;
	}
	return (psz);
} 

// Some generic routines to manipulate Dialog controls
HWND HWndGetDlgItem(HWND hDlg, int idControl)
{
	Assert(hDlg);
	return ::GetDlgItem(hDlg, idControl);
} 

BOOL FEnableControl(HWND hDlg, int idControl, BOOL fEnable)
{
	Assert(hDlg);

	::EnableWindow(HWndGetDlgItem(hDlg, idControl), fEnable);

	return TRUE;
}

BOOL FShowControl(HWND hDlg, int idControl, BOOL fShow)
{
	HWND hWnd = HWndGetDlgItem(hDlg, idControl);
	if (hWnd)
	{
		::ShowWindow(hWnd, fShow ? SW_SHOW : SW_HIDE);
		return TRUE;
	}
	return FALSE;
}

BOOL FEditBoxLimitText(HWND hDlg, int idControl, DWORD cb)
{
	Assert(hDlg);

	::SendDlgItemMessage(hDlg, idControl, EM_LIMITTEXT, (WPARAM)cb, 0);

	return TRUE;
}

BOOL FCheckDlgItem(HWND hDlg, int idControl, BOOL fCheck)
{
	Assert(hDlg);

	::SendDlgItemMessage(hDlg, idControl, BM_SETCHECK, (WPARAM)fCheck, 0);
	return TRUE;
}

HINSTANCE HInstance(HWND hWnd)
{
	return (HINSTANCE)::GetWindowLong(hWnd, GWL_HINSTANCE);
}

BOOL FSetDlgItemText(HWND hDlg, int idCtl, int idStr)
{
	Assert(idStr > -1);
	Assert(hDlg);

	TCHAR* psz = GetSz(HInstance(GetParent(hDlg)), idStr);
	if (!psz)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return ::SetWindowText(HWndGetDlgItem(hDlg, idCtl), psz);
}

BOOL FCenterWindow(HWND hWnd)
{
	Assert(hWnd);

	RECT rc;

    if (!::GetWindowRect(hWnd, &rc))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
    return ::SetWindowPos(hWnd, NULL, 
						((::GetSystemMetrics(SM_CXSCREEN) - (rc.right - rc.left)) / 2), 
						((::GetSystemMetrics(SM_CYSCREEN) - (rc.bottom - rc.top)) / 2), 
						0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
}

// Create a file
HANDLE CreateNormalFile(char* psz, BOOL fCreate, BOOL fNoAccess)
{
	HANDLE hFile = ::CreateFile(psz, 
						GENERIC_READ | GENERIC_WRITE, 
						fNoAccess ? 0 : FILE_SHARE_READ, NULL, 
						fCreate? OPEN_ALWAYS : OPEN_EXISTING, 
						FILE_ATTRIBUTE_NORMAL, 
						NULL);
	if (INVALID_HANDLE_VALUE == hFile)
	{
		AssertGLE(!fCreate);
	}
	return hFile;
}

HFONT HfontChangeFontWeight(HFONT hfont, long lfWeight, BOOL fStrike)
{
	HDC hdc = ::GetDC(NULL);
	if (NULL == hdc)
	{
		AssertGLE(FALSE);
		return NULL;
	}
	HFONT hfontSav = (HFONT)::SelectObject(hdc, (HGDIOBJ)hfont);
	
	TEXTMETRIC	tm;
	if (!::GetTextMetrics(hdc, &tm))
	{
		AssertGLE(FALSE);
		return NULL;
	}
	
	LOGFONT		lf;
	::ZeroMemory(&lf, sizeof(lf));
	if (!::GetTextFace(hdc, LF_FACESIZE, lf.lfFaceName))
	{
		AssertGLE(FALSE);
		return NULL;
	}
	
	::SelectObject(hdc, (HGDIOBJ)hfontSav);
	::ReleaseDC(NULL, hdc);
	
	lf.lfHeight 		= tm.tmHeight;
	lf.lfWidth 			= tm.tmAveCharWidth;
	lf.lfWeight			= lfWeight;
	lf.lfItalic			= tm.tmItalic;
	lf.lfUnderline		= tm.tmUnderlined;
	lf.lfStrikeOut		= fStrike ? TRUE : tm.tmStruckOut;
	lf.lfCharSet		= tm.tmCharSet;
	lf.lfPitchAndFamily	= tm.tmPitchAndFamily;
	
	return ::CreateFontIndirect(&lf);
}

// Do a generic Alert, using the given string
int FDoAlert(HWND hWndParent, int idStr, UINT uType)
{
	//Assert(hWndParent);
	HINSTANCE hInst = HInstance(hWndParent);
	// put up the message box
	return ::MessageBox(hWndParent, GetSz(hInst, idStr), GetSz(hInst, IDS_APPTITLE), uType);
}

// Do a generic Notification.
int FDoNotify(HWND hWndParent, int idStr, TCHAR *sz, UINT uType)
{
	//Assert(hWndParent);
	HINSTANCE hInst = HInstance(hWndParent);
	// put up the message box
	TCHAR szOut[512];
	wsprintf(szOut, "%s\r\t%s", GetSz(hInst, idStr), sz);

	return MessageBox(hWndParent, szOut, GetSz(hInst, IDS_APPTITLE), uType);
}

int FDoPrintFAlert(HWND hWndParent, int idStr, TCHAR *sz, UINT uType)
{
	//Assert(hWndParent);
	HINSTANCE hInst = HInstance(hWndParent);
	// put up the message box
	TCHAR szOut[512];
	wsprintf(szOut, GetSz(hInst, idStr), sz);

	return MessageBox(hWndParent, szOut, GetSz(hInst, IDS_APPTITLE), uType);
}

BOOL FSetFocus(HWND hDlg, int idControl)
{
	Assert(hDlg);

	HWND hWnd = ::GetDlgItem(hDlg, idControl);
	if (hWnd)
	{
		//use postMessage as this could come from a thread that did not create the window!
		::PostMessage(hDlg, WM_COMMAND, (WPARAM)105, (LPARAM)idControl);
	}
	return TRUE;
}

// FIX ME
static CHAR g_szANSI[256];

CHAR* PszWideToAnsi(WCHAR* psz)
{
	Assert(psz);

	if (FALSE == ::WideCharToMultiByte(CP_ACP, 0, psz, -1, g_szANSI, 256, NULL, NULL))
	{
		AssertGLE(FALSE);
		return NULL;
	}
	return g_szANSI;
}

BOOL FWideCharToAnsi(WCHAR* psz, CHAR* pszAnsi, int cbAnsi)
{
	Assert(psz && pszAnsi);

	if (FALSE == ::WideCharToMultiByte(CP_ACP, 0, psz, -1, pszAnsi, cbAnsi, NULL, NULL))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

BOOL FAnsiToWideChar(CHAR* psz, WCHAR* pszWide, int cbWide)
{
	Assert(psz && pszWide);

	if (FALSE == ::MultiByteToWideChar(CP_ACP, 0, psz, -1, pszWide, cbWide))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

// Set the char format for a Rich Text Window..
void SetCharFormat(HWND	hWnd, BOOL fSet, BOOL fColor, COLORREF cref, COLORREF* pcref, BOOL fBold, 
					BOOL fAll)
{
	CHARFORMAT cf;
	CHARRANGE crSav;

	Assert(NULL != hWnd);
	// Select all text and set its format
	if (fAll)
	{
		if (!FSelectAllRichText(hWnd, &crSav))
		{
			return;
		}
	}
	// Obtain the current font from the current window and bold/unbold it.
	cf.cbSize = sizeof(CHARFORMAT);
	SendMessage(hWnd, EM_GETCHARFORMAT, TRUE, (LPARAM)&cf);

	if (fBold)
	{
		cf.dwMask |= CFM_BOLD;
		if (fSet)
		{
			cf.dwEffects |= CFM_BOLD;
		}
		else
		{
			cf.dwEffects &= ~CFM_BOLD;
		}
	}
	if (fColor)
	{
		cf.dwMask 		|= CFM_COLOR;
		cf.dwEffects	&= ~CFE_AUTOCOLOR;
		if (fSet)
		{
			if (pcref)
			{
				*pcref = cf.crTextColor;
			}
			cf.crTextColor = cref;
		}
		else
		{
			if (pcref)
			{
				cf.crTextColor = *pcref;
			}
			else
			{
				Assert(FALSE);
				return;
			}
		}
	}
	::SendMessage(hWnd, EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM)&cf);

	// Restore things
	if (fAll)
	{
		::SendMessage(hWnd, EM_EXSETSEL, 0, (LPARAM)&crSav);
		::SendMessage(hWnd, EM_HIDESELECTION, FALSE, 0);
	}
}

// Select all in a RichEdit window WITHOUT the selection showing. Returns previous selection in pcrSav
BOOL FSelectAllRichText(HWND hWnd, CHARRANGE *pcrSav)
{
	CHARRANGE cr;
	CHARRANGE crSav;
	
	Assert(NULL != hWnd);

	::SendMessage(hWnd, EM_HIDESELECTION, TRUE, 0);
	::SendMessage(hWnd, EM_EXGETSEL, 0, (LPARAM)&crSav);
	// Extend current selection all the way
	cr.cpMin = 0;
	cr.cpMax = -1;
	::SendMessage(hWnd, EM_EXSETSEL, 0, (LPARAM)&cr);
	if (pcrSav)
	{
		::CopyMemory(pcrSav, &crSav, sizeof(CHARRANGE));
	}
	return TRUE;
}

// Change a richedit window's font
BOOL FSetRichTextFont(HWND 	hWnd, CHARFORMAT	*pcf, BOOL fAll)
{
	CHARRANGE crSav;

	Assert(NULL != hWnd);
	// If applying to whole window, select everything, but do it silently
	// i.e. User should not see selection
	if (fAll)
	{
		if (!FSelectAllRichText(hWnd, &crSav))
		{
			return FALSE;
		}
	}
	else
	{
		// Save current selection, and apply
		::SendMessage(hWnd, EM_HIDESELECTION, TRUE, 0);
		::SendMessage(hWnd, EM_EXGETSEL, 0, (LPARAM)&crSav);
	}
	::SendMessage(hWnd, EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM)pcf);
	// Restore original...
	::SendMessage(hWnd, EM_EXSETSEL, 0, (LPARAM)&crSav);
	::SendMessage(hWnd, EM_HIDESELECTION, FALSE, 0);
	return TRUE;
}

COLORREF ColorRefGet(int index, BOOL fTextColor)
{
	return GetSysColor(fTextColor ? COLOR_WINDOWTEXT : COLOR_WINDOW);
}

// Standard Windows Choose Color dialog
BOOL FChooseColor(HWND hWnd, COLORREF rgb, COLORREF *prgbResult)
{
	Assert(prgbResult);

	CHOOSECOLOR	cc;
	COLORREF	rgrgb[16];
	
	::ZeroMemory(&cc, sizeof(CHOOSECOLOR));
	::ZeroMemory(&rgrgb[0], sizeof(COLORREF) * 16);
	cc.lStructSize = sizeof(CHOOSECOLOR);
	cc.hwndOwner = hWnd;
	cc.rgbResult = rgb;
	cc.lpCustColors = &rgrgb[0];
	cc.Flags = CC_RGBINIT | CC_PREVENTFULLOPEN;
	
	BOOL fRet = ChooseColor(&cc);
	*prgbResult = (fRet) ? cc.rgbResult : rgb;
	return fRet;
}

void MarkDefaultMenuitem(HMENU hmenu, int iitemDefault)
{
	MENUITEMINFO mii;
	
	::ZeroMemory(&mii, sizeof(mii));
	mii.cbSize = sizeof(mii);
	mii.fMask = MIIM_STATE;
	if (::GetMenuItemInfo(hmenu, iitemDefault, TRUE, &mii))
	{
		mii.fState |= MFS_DEFAULT;
		::SetMenuItemInfo(hmenu, iitemDefault, TRUE, &mii);
	}
}

// REGISTRY FUNCTIONS
BOOL FGetDesktopPath(TCHAR* szPath, DWORD cch)
{
	Assert(szPath);

	HKEY	hkey;
	DWORD	dwType;
	BOOL	fRet = FALSE;
	// Get the root key
	LONG lRet = ::RegOpenKeyEx(HKEY_CURRENT_USER, 
						"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", 
						0, KEY_READ, &hkey);
	if (lRet != ERROR_SUCCESS)
	{
		return FALSE;
	}
	// Get the path
	if (ERROR_SUCCESS == ::RegQueryValueEx(hkey, "Desktop", 0, &dwType, (BYTE*)szPath, &cch))
	{
		Assert(dwType == REG_SZ || dwType == REG_MULTI_SZ || dwType == REG_EXPAND_SZ);
		fRet = (dwType == REG_SZ || dwType == REG_MULTI_SZ || dwType == REG_EXPAND_SZ);
	}
	::RegCloseKey(hkey);
	return fRet;
}

BOOL FOpenMicRegKey(HKEY hkeyRoot, char* szSubkey, REGSAM samDesired, HKEY* phkey)
{
	HKEY hkey;
	
	LONG lRet = ::RegOpenKeyEx(hkeyRoot, SZMICCHATKEY, 0, samDesired, &hkey);
	if (lRet != ERROR_SUCCESS)
		return FALSE;
	if (!szSubkey)
	{
		*phkey = hkey;
		return TRUE;
	}
	lRet = ::RegOpenKeyEx(hkey, szSubkey, 0, samDesired, phkey);
	::RegCloseKey(hkey);
	return (lRet == ERROR_SUCCESS);
}

BOOL FGetRegistrySz(HKEY hkeyRoot, LPCSTR pszVal, LPSTR pszBuf, DWORD cbBuf)
{
	Assert(pszVal);

	HKEY 	hkey;
	DWORD	dwType;
	BOOL	fRet = FALSE;
	
	pszBuf[0] = 0;
	
	if (FOpenMicRegKey(hkeyRoot, NULL, KEY_READ, &hkey))
	{
		if (ERROR_SUCCESS == ::RegQueryValueEx(hkey, (LPTSTR)pszVal, 0, &dwType, (BYTE*)pszBuf, &cbBuf))
		{
			Assert(dwType == REG_SZ || dwType == REG_MULTI_SZ || dwType == REG_EXPAND_SZ);
			fRet = (dwType == REG_SZ || dwType == REG_MULTI_SZ || dwType == REG_EXPAND_SZ);
		}
		::RegCloseKey(hkey);
	}
	return fRet;
}

BOOL FGetRegistryDword(HKEY hkeyRoot, LPCSTR szVal, DWORD* pdw)
{
	Assert(szVal);

	HKEY 	hkey;
	DWORD	dwType;
	BOOL	fRet = FALSE;
	DWORD	cbBuf = sizeof(DWORD);
	if (FOpenMicRegKey(hkeyRoot, NULL, KEY_READ, &hkey))
	{
		if (ERROR_SUCCESS == ::RegQueryValueEx(hkey, (LPTSTR)szVal, 0, &dwType, (BYTE*)pdw, &cbBuf))
		{
			Assert(dwType == REG_DWORD);
			fRet = (dwType == REG_DWORD);
		}
		::RegCloseKey(hkey);
	}
	return fRet;
}

void SetRegistryRaw(HKEY hkeyRoot, LPCSTR pszVal, DWORD dwType, LPVOID pv, DWORD cb)
{
	HKEY 	hkey;
	DWORD	dwDis;
		
	if (RegCreateKeyEx(hkeyRoot, SZMICCHATKEY, 0, "", 
					   REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, 
					   &hkey, &dwDis) == ERROR_SUCCESS)
	{
		::RegSetValueEx(hkey, pszVal, 0, dwType, (LPBYTE)pv, cb);
		::RegCloseKey(hkey);
	}
}

BOOL FRegistryKeyExists(HKEY hkeyRoot, char *szSubkey, BOOL fAddIfNo)
{
	HKEY hkeyMic;
	HKEY hkeyT;
	
	if (szSubkey)
	{
		// first we have to make sure the main MICHAT key exists:
		if (!FRegistryKeyExists(hkeyRoot, NULL, fAddIfNo))
			return FALSE;
		
		// okay, it's there.  now we try to do the subkey.
		if (!FOpenMicRegKey(hkeyRoot, NULL, KEY_ALL_ACCESS, &hkeyMic))
		{
			Assert(FALSE);
			return FALSE;
		}
		// does the subkey already exist?
		if (ERROR_SUCCESS == ::RegOpenKey(hkeyMic, szSubkey, &hkeyT))
		{
			::RegCloseKey(hkeyT);
			::RegCloseKey(hkeyMic);
			return TRUE;
		}
		// no.  should we create it?
		if (!fAddIfNo)
			return FALSE;
		// create it.
		if (ERROR_SUCCESS == ::RegCreateKey(hkeyMic, szSubkey, &hkeyT))
		{
			::RegCloseKey(hkeyT);
			::RegCloseKey(hkeyMic);
			return TRUE;
		}
	}
	else
	{
		// no szSubkey was passed in, so let's check for the main MICHAT key.
		// already there?
		if (ERROR_SUCCESS == ::RegOpenKey(hkeyRoot, SZMICCHATKEY, &hkeyT))
		{
			::RegCloseKey(hkeyT);
			return TRUE;
		}
		// If no, should we add it?
		if (!fAddIfNo)
		{
			return FALSE;
		}
		// try to add it
		if (ERROR_SUCCESS == ::RegCreateKey(hkeyRoot, SZMICCHATKEY, &hkeyT))
		{
			::RegCloseKey(hkeyT);
			return TRUE;
		}
	}
	return FALSE;
}

BOOL FCreateAndSetRegistry(HKEY hkeyRoot, char* pszVal, DWORD dwType, LPVOID pv, DWORD cb)
{
	HKEY hkey;

	if (!FRegistryKeyExists(hkeyRoot, pszVal, TRUE))
	{
		return FALSE;
	}
		
	if (!FOpenMicRegKey(hkeyRoot, pszVal, KEY_ALL_ACCESS, &hkey))
	{
		return FALSE;
	}

	::RegSetValueEx(hkey, (char*)pv, 0, REG_SZ, (CONST BYTE*)"", 1); // put value as null string. 
	return TRUE;
}

// Set Registry boolean variables
BOOL FRegistryBoolSet(HKEY hkeyRoot, LPCSTR szVal, BOOL fOn)
{
	TCHAR* szOn = (fOn) ? "yes" : "no";
	::SetRegistryRaw(HKEY_CURRENT_USER, szVal, REG_SZ, (LPVOID)szOn, lstrlen(szOn));
	return TRUE;
}

// Is the registry boolean variable set?
BOOL FGetRegistryBool(HKEY hkeyRoot, LPCSTR szVal, BOOL *pf)
{
	TCHAR szBuf[MAX_PATH];
	
	*pf = FALSE;
	if (FGetRegistrySz(hkeyRoot, szVal, szBuf, MAX_PATH))
	{
		if (!lstrcmpi(szBuf, "yes"))
		{
			*pf = TRUE;
		}
		return TRUE;
	}
	return FALSE;
}

// FILE STUFF

BOOL FSaveAsDialog(HINSTANCE hInst, HWND hWndParent, TCHAR *pszFileName, DWORD cchSz, DWORD *pdwIndex)
{
	Assert(hInst && pszFileName && pdwIndex);

	int 			cbString;
	TCHAR 			chReplace;
//	TCHAR 			szFile[MAX_PATH];
	TCHAR 			szFilter[MAX_PATH];
	TCHAR 			szDefExt[]="RTF";
	TCHAR			szFileTitle[MAX_PATH];
	OPENFILENAME 	ofn;
	BOOL			fRet;

	cbString = LoadString(hInst, IDS_SAVEFILTER, szFilter, sizeof(szFilter));
	if (0 == cbString || !::LoadString(hInst, IDS_UNTITLED, pszFileName, cchSz))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Build the filter to display in teh dialog
	chReplace = szFilter[cbString-1];
	for (int i=0; szFilter[i] != '\0'; i++)
	{
		if (szFilter[i] == chReplace)
		{
			szFilter[i] = '\0';
		}
	}
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	szFileTitle[0] = '\0';
	// And construct the dialog title
	ofn.lStructSize			= sizeof(ofn);
	ofn.hwndOwner			= hWndParent;
	ofn.hInstance			= NULL;
	ofn.lpstrFilter			= (LPSTR)szFilter;
	ofn.lpstrCustomFilter	= NULL;
	ofn.nMaxCustFilter		= 0;
	ofn.nFilterIndex		= 1;
	ofn.lpstrFile			= (LPSTR)pszFileName;
	ofn.nMaxFile			= cchSz;
	ofn.lpstrFileTitle		= szFileTitle;
	ofn.nMaxFileTitle		= sizeof(szFileTitle);
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrTitle			= NULL;
	ofn.Flags				= OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	ofn.nFileOffset			= 0;
	ofn.nFileExtension		= 0;
 	ofn.lpstrDefExt			= (LPSTR)szDefExt;
	ofn.lCustData			= 0L;
	ofn.lpfnHook			= NULL;
	ofn.lpTemplateName		= NULL;
	// Query user for filename for input
    fRet = GetSaveFileName(&ofn);

	*pdwIndex = ofn.nFilterIndex;

	return fRet;
}

BOOL FGetBrowserPath(HINSTANCE hInst, HWND hWndParent, TCHAR *pszFileName, DWORD cchSz)
{
	Assert(hInst && pszFileName);

	int 			cbString;
//	TCHAR 			chReplace;
	TCHAR 			szTitle[MAX_PATH];
	TCHAR 			szFilter[]="\0*.EXE\0";
	OPENFILENAME 	ofn;
	BOOL			fRet;
	
	cbString = ::LoadString(hInst, IDS_BROWSER, szTitle, sizeof(szTitle));
	if (0 == cbString)
	{
		AssertGLE(FALSE);
		return FALSE;
	}

	::ZeroMemory(&ofn, sizeof(OPENFILENAME));
	// And construct the dialog title
	ofn.lStructSize			= sizeof(ofn);
	ofn.hwndOwner			= hWndParent;
	ofn.lpstrFilter			= (LPSTR)szFilter;
	ofn.nFilterIndex		= 1;
	ofn.lpstrFile			= (LPSTR)pszFileName;
	ofn.nMaxFile			= cchSz;
	ofn.lpstrTitle			= szTitle;
	ofn.Flags				= OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
	// Query user for the browser
    fRet = GetOpenFileName(&ofn);

	return fRet;
}

BOOL FCreateShortCutOnDesktop(CHAR* szFileName, CHAR* szURL)
{
	Assert(szFileName && szURL);

	TCHAR	szDesktop[MAX_PATH +1];
	TCHAR	szCurDir[MAX_PATH + 1];
	BOOL	fRet = FALSE;
	// Get path to the current desktop
	if (!FGetDesktopPath(szDesktop, MAX_PATH))
	{
		return FALSE;
	}
	// Have to do this to get around MAX_PATH restrictions on Paths
	// Get current directory
	if (!::GetCurrentDirectory(MAX_PATH, szCurDir))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Set dir to Desktop
	if (!::SetCurrentDirectory(szDesktop))
	{
		AssertGLE(FALSE);
		goto LReturn;
	}
	// Create file
	HANDLE hFile;
	hFile = CreateNormalFile(szFileName);
	if (INVALID_HANDLE_VALUE == hFile)
	{
		goto LReturn;
	}
	::wsprintf(szDesktop, "[%s]\r\n%s=%s", SZSHORTCUT, SZURLKEY, szURL);
	DWORD cb;
	::WriteFile(hFile, szDesktop, ::lstrlen(szDesktop), &cb, NULL);
	::CloseHandle(hFile);
	fRet = TRUE;

LReturn:

	::SetCurrentDirectory(szCurDir);
	return fRet;
}

// MEMBER stuff
TCHAR* PszGetName(PICS_MEMBER pcm, TCHAR* psz)
{
	Assert(pcm && psz);

	BOOL	fAnsi;
	BYTE*	pb;

	if (FAILED(pcm->HrGetName(&pb, &fAnsi)))
	{
		AssertSz(0, "HrGetName");
		return NULL;
	}
	// If this is an ANSI client, convert all Unicode strings into ANSI
	// Else, do the reverse
#ifdef UNICODE
	AssertSz(0, "Not implemented");
#else
	if (!fAnsi)	// unicode name. convert it to ansi
	{
		if (!FWideCharToAnsi((WCHAR*)pb, psz, CS_CCHMAX_MIC_USERNAME + 1))
		{
			return NULL;
		}
		return psz;
	}
#endif
	
	return (TCHAR*)pb;
}

TCHAR* PszGetChannelName(PICS_CHANNEL pcm, TCHAR* psz)
{
	Assert(pcm && psz);

	BOOL	fAnsi;
	BYTE*	pb;

	if (FAILED(pcm->HrGetName(&pb, &fAnsi)))
	{
		AssertSz(0, "HrGetName");
		return NULL;
	}
	// If this is an ANSI client, convert all Unicode strings into ANSI
	// Else, do the reverse
#ifdef UNICODE
	AssertSz(0, "Not implemented");
#else
	if (!fAnsi)	// unicode name. convert it to ansi
	{
		// IRC channel names are longer.. so this will serve both mic and irc
		if (!FWideCharToAnsi((WCHAR*)pb, psz, CS_CCHMAX_IRC_CHANNEL + 1))
		{
			return NULL;
		}
		return psz;
		}
#endif
	return (TCHAR*)pb;
}

TCHAR* PszGetDisplaySz(PICS_PROPERTY picsProperty, DWORD dwIndex, TCHAR* szConvert)
{
	Assert(picsProperty && szConvert);

	CS_PROPDATA csPropData;
	// Get the data
	if (FAILED(picsProperty->HrGetProperty(&csPropData, dwIndex)))
	{
		AssertSz(0, "HrGetProperty");
		return NULL;
	}
	Assert(csPropData.pbData && csPropData.fString);
	// If this is an ANSI client, convert all Unicode strings into ANSI
	// Else, do the reverse
#ifdef UNICODE
	AssertSz(0, "Not implemented");
#else
	if (!csPropData.fAnsi)	// unicode string. convert it to ansi
	{
		if (!FWideCharToAnsi((WCHAR*)csPropData.pbData, szConvert, MAX_PATH))
		{
			return NULL;
		}
		return szConvert;
	}
#endif
	return (TCHAR*)csPropData.pbData;
}
