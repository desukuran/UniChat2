//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icmain.h"
#include "icinst.h"
#include "icprop.h"
#include "icwprop.h"
#include "icfind.h"
#include "icwizard.h"
#include "icque.h"
#include "icutil.h"

//--------------------------------------------------------------------------------------------
// GLOBALS
//--------------------------------------------------------------------------------------------
CIChatMain	gciChat;		// chat globals

const TCHAR	gszDummyName[] = "Microsoft MyChat";
// Command line TAGS
const TCHAR SZCMDURL[] = "URL";	// URLs

//--------------------------------------------------------------------------------------------
// PROTOTYPES
//--------------------------------------------------------------------------------------------
LRESULT CALLBACK MicChatWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
DWORD __stdcall DwMainMsgThreadProc(PVOID pvData);
int FIsChannelCreateError(HRESULT hr);

//--------------------------------------------------------------------------------------------
// Functions
//--------------------------------------------------------------------------------------------
void* __cdecl operator new(size_t cb)
{
	return MemoryAlloc(cb);
}
void __cdecl operator delete(void* pv)
{
	MemoryDeAlloc(pv);
}

int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpszCmd, int nCmdShow)
{
	MSG 		msg;
	HACCEL 		hAccelTable;
	HCURSOR		hCursor, hCursorSav;
	BOOL 		fRet = FALSE;
	
	// Get starting params. NOTE: We don't use the WinMain stuff that comes with the
	// C++ Runtime. This keeps exe size down.
	hInst		= ::GetModuleHandle(NULL);
	lpszCmd		= ::GetCommandLine();

#ifdef DEBUG
	InitLeakCheck();
#endif

	if (NULL == lpszCmd || NULL == hInst)
	{
		AssertGLE(FALSE);
		goto LReturn;
	}

	hCursor = ::LoadCursor(NULL, MAKEINTRESOURCE(IDC_APPSTARTING));
	if (!hCursor)
	{
		AssertGLE(FALSE);
		goto LReturn;
	}

	hCursorSav = ::SetCursor(hCursor);

	if (!gciChat.FInit(hInst)) 
	{
		goto LReturn;
	}

	hAccelTable = ::LoadAccelerators(hInst, MAKEINTRESOURCE(IDR_ACCELERATORMIC));

	BOOL fMsg;

	while (1)
	{
		// GetMessage can return -1 in win32!
		fMsg = ::GetMessage(&msg, NULL, 0, 0);
		if (FALSE == fMsg)
		{
			break;
		}
		if (TRUE == fMsg)
		{
			if (!::TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
			{
				::TranslateMessage(&msg);// Translates virtual key codes
				::DispatchMessage(&msg); // Dispatches message to window
			}
		}
	}

	fRet = msg.wParam;
	
LReturn:
#ifdef DEBUG
	CheckForLeaks("MyChat");
	ReleaseLeakCheck();
#endif
	
	return fRet; 
}

//--------------------------------------------------------------------------------------------
// CLASSES
//--------------------------------------------------------------------------------------------
CIChatMain::CIChatMain(void)
{
	m_hWnd			= NULL;
	m_hInst			= NULL;
	m_hWndFore		= NULL;
	m_cChats		= 0;
	m_pics			= NULL;
	m_bTypeLogin	= CS_CHANNEL_ALLOWANON;
	m_picWizard		= NULL;
	m_fAway			= FALSE;
	m_pcfp			= NULL;
	m_pfData		= NULL;
	m_pszCmdLine	= NULL;
	m_szDefServer	= NULL;
	m_szDefChan		= NULL;
	m_szURLCopy		= NULL;
	m_fMicSocket	= TRUE;
	m_fDisable		= FALSE;
}

CIChatMain::~CIChatMain(void)
{
}

BOOL CIChatMain::FInit(HINSTANCE hInst)
{
	Assert(hInst);

	m_hInst			= hInst;
	m_pszCmdLine	= GetCommandLine();

	m_hWnd		= HWndCreateDummy(hInst, MicChatWndProc, gszDummyName);
	::SetWindowText(m_hWnd, GetSz(m_hInst, IDS_APPTITLE));
	
	if (NULL == m_hWnd || !FLoadMenus())
	{
		Assert(FALSE);
		Quit();
		return FALSE;
	}
	// grab the command line
	FParseCommandLine();
	// Log Us In
	::SetCursor(LoadCursor(NULL, IDC_ARROW));
	
	CLogin	cl;
	CHAR*	szServer;
				
	szServer = m_szDefServer;
	if (!cl.FConnect(m_hWnd, szServer))
	{
		Quit();
		return FALSE;
	}

	PICS pics = cl.Pics();
	pics->AddRef();
	FSetChatSocket(pics);
	// Create a channel by default
	FPostCommand(MAKEWPARAM(IDC_CREATECHANNEL, 0), 0);
	
	return TRUE;
}

int g_rgiitemDefault[cmenus] = {0, -1, -1, -1, 0};
BOOL CIChatMain::FLoadMenus(void)
{
	m_hmenuPopups = ::LoadMenu(m_hInst, MAKEINTRESOURCE(IDM_POPUPS));
	
	for (int i = 0; i < cmenus; i++)
	{
		m_rghmenu[i] = GetSubMenu(m_hmenuPopups, i);
		if (!m_rghmenu[i])
			return FALSE;
		if (g_rgiitemDefault[i] != -1)
			MarkDefaultMenuitem(m_rghmenu[i], g_rgiitemDefault[i]);
	}
	return TRUE;
}

BOOL CIChatMain::FParseCommandLine(void)
{
	TCHAR* sz = m_pszCmdLine;
	// Look for the standard command line modifier tag
	TCHAR* szTag = ::strstr(sz, "-");
	if (!szTag)
	{
		return FALSE;
	}
	// Check for Commands
	TCHAR* szParam = ::strstr(szTag, SZCMDURL);
	if (!szParam)
	{
		return FALSE;
	}
	// Skip past Command
	szTag = ::strstr(szParam, " ");
	if (!szTag)
	{
		return FALSE;
	}
	// Skip pass spaces
	while (*szTag && ' ' == *szTag)
	{
		++szTag;
	}

	if (!FCopyURL(szTag, &m_szURLCopy))
	{
		return FALSE;
	}

	if (*szTag)
	{
		int cch;
		if (FGetServerNameFromCommand(m_szURLCopy, &m_szDefServer, &cch))
		{
			int cchChan;
			if (FGetChannelNameFromCommand(m_szDefServer, &m_szDefChan, &cchChan))
			{
				m_szDefChan[cchChan] = '\0';
			}
			m_szDefServer[cch] = '\0';
		}
	}
	return FALSE;
}

BOOL CIChatMain::FGetServerNameFromCommand(TCHAR *szCmd, TCHAR **pszServer, int *pcch)
{
	Assert(pszServer && pcch);

	TCHAR *sz, *szColon;
	TCHAR *sz1, *sz2;
	BOOL fRet = FALSE;

	*pszServer = NULL;
	sz = szCmd;
	sz1 = sz2 = szColon = NULL;
	
	szColon = ::strstr(sz, ":");
	Assert(szColon);
	// Does it start with 2 // ?
	sz1 = ::strstr(sz, "/");
	if (sz1 && 1 == (sz1 - szColon))
	{
		sz2 = ::strstr(sz1+1, "/");
	}
	// Do we have a Server name?
	if (sz1 && sz2 && (1 == (sz2 - sz1)))
	{
		*pszServer = (sz2 + 1);
		// Get the length of the name
		sz1 = ::strstr(*pszServer, "/");
		*pcch = (!sz1) ? ::lstrlen(*pszServer) : (sz1 - (*pszServer));
		fRet = (*pcch >= 1);
	}
	return fRet;	
}

// This assumes we have already found a server.
BOOL CIChatMain::FGetChannelNameFromCommand(TCHAR *szCmd, TCHAR **pszName, int *pcch)
{
	Assert(szCmd && pszName && pcch);

	TCHAR *sz, *szEnd;
	// Channel names must start and end with /
	sz = ::strstr(szCmd, "/");
	if (sz)
	{
		sz++;
	}
	else
	{
		// OR someone could have put the name right after the :
		sz = ::strstr(szCmd, ":");
		if (sz)
		{
			++sz;
		}
	}
	// Now find the terminating /
	szEnd = ::strstr(sz, "/");
	*pcch = (szEnd) ? szEnd - sz : ::lstrlen(sz);
	// Make sure we have something!
	if (*pcch < 1)
	{
		sz = NULL;
	}
	*pszName = sz;

	return (NULL != sz);
}

void CIChatMain::Quit(void)
{
	// Cleanup everything
	if (m_cChats <= 0)
	{
		FCloseChatSocket();
		if (m_pics)
		{
			m_pics->Release();
		}
		if (m_szURLCopy)
		{
			delete [] m_szURLCopy;
		}
		m_fifo.FRemoveAll();	// clean up this que
		// Wait for threads
		m_msgThread.DwWaitForThread(15000);

		DestroyWindow();

		DestroyMenu(m_hmenuPopups);
	}
}

void CIChatMain::SetForeInstance(HWND hWnd)
{
	m_csData.Lock();
	m_hWndFore = hWnd;
	m_csData.Unlock();
}

void CIChatMain::SetForeDialog(HWND hDlg)
{
	m_csData.Lock();
	m_hDlgFore = hDlg;
	m_csData.Unlock();
}

HWND CIChatMain::HWndForeDlg(void)
{
	m_csData.Lock();
	HWND hDlg = m_hDlgFore;
	m_csData.Unlock();
	return hDlg;
}

HWND CIChatMain::HWndFore(void)
{
	m_csData.Lock();
	HWND hWnd = (m_hWndFore) ? m_hWndFore : m_hWnd;
	m_csData.Unlock();
	return hWnd;
}

BOOL CIChatMain::FCreateNewChat(PICS_CHANNEL picsChannel)
{
	BOOL	fRet = FALSE;
	CIChat* pic = NULL;
	DWORD index = 0;

	if (NULL == picsChannel)
	{
		Assert(FALSE);
		goto LReturn;
	}
	// Create a new Chat instance and save it in the chat table.
	// Currently, the index field is unused. We'll leave it be for now, because there might
	// be future uses.
	pic = new CIChat(index);
	if (NULL == pic)
	{
		AssertGLE(FALSE);
		goto LReturn;
	}

	m_csData.Lock();
	++m_cChats;
	m_csData.Unlock();

	// Bring it to life
	if (!pic->FInit(m_hInst, picsChannel))
	{
		goto LReturn;
	}
	fRet = TRUE;

LReturn:

	if (!fRet && pic)
	{
		FCloseChat(index);
		delete pic;
	}

	return fRet;
}

BOOL CIChatMain::FCreateNewChannel(HWND hWndParent)
{
	Assert(hWndParent);

	IC_CREATECHAN*	picChan = NULL;
	BOOL			fRet = FALSE;
	// Channel creation dialog
	picChan = new IC_CREATECHAN;
	if (!picChan)
	{
		AssertGLE(FALSE);
		DoOOM();
		goto LReturn;
	} 
	SetDisableAll(TRUE);
	fRet = FCreateChannel(hWndParent, picChan);
	SetDisableAll(FALSE);

LReturn:
	if (picChan)
	{
		picChan->Release();
	}
	return fRet;
}

BOOL CIChatMain::FJoinNewChannel(HWND hWndParent, CChatFindPane *pccfp)
{
	BOOL fRet = FALSE;

	IC_CREATECHAN* picChan = new IC_CREATECHAN;
	if (!picChan)
	{
		AssertGLE(FALSE);
		DoOOM();
		goto LReturn;
	}
	SetDisableAll(TRUE);
	fRet = FJoinChannel(hWndParent, picChan, pccfp);
	SetDisableAll(FALSE);

LReturn:
	if (picChan)
	{
		picChan->Release();
	}
	return fRet;
}

BOOL CIChatMain::FCreateChannel(HWND hWndParent, IC_CREATECHAN *picChan)
{
	Assert(hWndParent && picChan);

	CS_CINFO cInfo;
	// Channel creation dialog
	if (!picChan->FCreateChannelDlg(hWndParent) || !FBuildCSInfo(&cInfo, picChan))
	{
		return FALSE;
	}
	
	return FCreateChannelFromCInfo(hWndParent, &cInfo);
}

BOOL CIChatMain::FBuildCSInfo(PCS_CINFO pcs, PIC_CREATECHAN pChan)
{
	Assert(pcs && pChan);

	::ZeroMemory((PVOID)pcs, sizeof(CS_CINFO));
	pcs->dwcb			= sizeof(CS_CINFO);
	pcs->dwType			= pChan->DwType();
	pcs->dwFlags		= pChan->DwFlags();
	pcs->bCreateFlags	= pChan->BCreateFlags();
	pcs->pvChannelName	= pChan->PszName();
	pcs->pvTopic		= pChan->PszTopic();
	pcs->pvPassword		= pChan->PszPass();
	pcs->dwcUserMax		= pChan->DwCUser();

	return TRUE;
}

// Creates a channel, given the name. 
// If channel already exists, it joins it
// Else it always creates a channel with the basest of default params.
BOOL CIChatMain::FCreateChannelFromName(HWND hWndParent, TCHAR* szName)
{
	Assert(szName);

	TCHAR szTemp[1];

	szTemp[0] = '\0';
	CS_CINFO cs;
	::ZeroMemory(&cs, sizeof(CS_CINFO));
	cs.dwcb				= sizeof(CS_CINFO);
	cs.dwType			= CS_CHANNEL_PUBLIC | CS_CHANNEL_ALLOWANON;
	cs.dwFlags			= CS_CHANNEL_FLAG_MICONLY;
	cs.bCreateFlags		= CS_CHANNEL_CREATE_JOIN;
	cs.pvChannelName	= szName;
	cs.pvTopic			= szTemp;
	cs.pvPassword		= szTemp;
	return FCreateChannelFromCInfo(hWndParent, &cs);
}

// Given the channel creation params (CS_CINFO), create it
BOOL CIChatMain::FCreateChannelFromCInfo(HWND hWndParent, PCS_CINFO pcs)
{
	BOOL fRet = FALSE;

	PICS pics = PChatSocket();
	HRESULT hr = pics->HrCreateChannelA(pcs);
	if (FAILED(hr))
	{
		// FIX ME - handle this for MIC ONLY chats
		::FHandleChatSockErrors(hWndParent, hr);
		goto LReturn;
	}
	
	fRet = TRUE;

LReturn:
	if (pics)
	{
		pics->Release();
	}

	return fRet;
}

BOOL CIChatMain::FJoinChannel(HWND hWndParent, IC_CREATECHAN* picChan, CChatFindPane* pccfp)
{
	Assert(hWndParent && picChan);

	HRESULT			hr;
	CS_JOININFO		cInfo;
	BOOL			fRet = FALSE;
	PICS			pics = NULL;
	TCHAR			szName[MAX_PATH];

	szName[0] = '\0';
	// If we cannot AutoJoin, then we should ask the user for the name of a channel to join
	if (!(pccfp && pccfp->FAutoJoinChannel((TCHAR *)szName)) || '\0' == szName[0])
	{
		if (!picChan->FJoinChannelDlg(hWndParent) || !FBuildCJInfo(&cInfo, picChan))
		{
			goto LReturn;
		}
	}
	else
	{
		TCHAR szPassword[1];
		// Auto join
		::ZeroMemory((PVOID)&cInfo, sizeof(CS_JOININFO));
		cInfo.dwcb			= sizeof(CS_JOININFO);
		cInfo.pvChannelName	= szName;
		szPassword[0] = '\0';
		cInfo.pvPassword	= &szPassword;
	}
	pics = PChatSocket();
	hr = pics->HrJoinChannelA(&cInfo);
	if (FAILED(hr))
	{
		// FIX ME - fix this for MIC ONLY chats
		FHandleChatSockErrors(hWndParent, hr);
		goto LReturn;
	}
	 fRet = TRUE;

LReturn:
	if (pics)
	{
		pics->Release();
	}
	return fRet;
}

BOOL CIChatMain::FBuildCJInfo(PCS_JOININFO pcs, PIC_CREATECHAN pChan)
{
	Assert(pcs && pChan);

	::ZeroMemory((PVOID)pcs, sizeof(CS_JOININFO));
	pcs->dwcb			= sizeof(CS_JOININFO);
	pcs->pvChannelName	= pChan->PszName();
	pcs->pvPassword		= pChan->PszPass();

	return TRUE;
}

BOOL CIChatMain::FJoinChannelFromURL(HWND hWndParent, TCHAR *szURL)
{
	Assert(hWndParent && szURL);

	TCHAR			*szCopy, *szName, *szServer, *szChan;
	int				cchServer;
//	CS_JOININFO		cInfo;
	BOOL			fRet = FALSE;
	PICS			pics = NULL;

	if (!FCopyURL(szURL, &szCopy))
	{
		return FALSE;
	}
	// Is there a server name in the story?
	szChan = szCopy;
	if (FGetServerNameFromCommand(szCopy, &szServer, &cchServer))
	{
		if (!FLaunchNewChatProcess(szServer, cchServer, szCopy))
		{
			// Chat is on the SAME server as we are on currently
			szChan = szServer + cchServer;
		}
		else
		{
			fRet = TRUE;
			goto LReturn;
		}
	}
	// Find the channel name
	int cchChan;

	if (FGetChannelNameFromCommand(szChan, &szName, &cchChan))
	{
		szName[cchChan] = '\0';
		fRet = FCreateChannelFromName(hWndParent, szName);
	}

LReturn:
	delete [] szCopy;	
	
	return fRet;
}

BOOL CIChatMain::FLaunchNewChatProcess(TCHAR* szServer, int cchServer, TCHAR* szURL)
{
	Assert(szServer);

	TCHAR* szCurServer;
	
	TCHAR ch = szServer[cchServer];
	szServer[cchServer] = '\0';
	// Get server name
	PICS pics = PChatSocket();
	Assert(pics);
	pics->HrGetServerName(&szCurServer);
	pics->Release();
	// Is it the server we are already connected to
	if (0 == ::lstrcmpi(szServer, szCurServer))
	{
		szServer[cchServer] = ch;
		return FALSE;
	}

	TCHAR	szPath[MAX_PATH + 1];
	TCHAR	szLaunch[MAX_PATH * 2 + 4];

	if (!::GetModuleFileName(m_hInst, szPath, MAX_PATH))
	{
		AssertGLE(FALSE);
		return TRUE;
	}
	
	int cch, cchURL;
	
	szServer[cchServer] = ch;
	cch		= ::lstrlen(szPath);
	cchURL	= ::lstrlen(szURL);
	if ((cch + cchURL + sizeof(SZCMDURL)) > 2*MAX_PATH)
	{
		AssertSz(0, "URL TOO LONG");
		MessageBeep(MB_OK);
		return TRUE;
	}

	::wsprintf(szLaunch, "%s -%s %s", szPath, SZCMDURL, szURL);
	if (::WinExec(szLaunch, SW_SHOW) < 32)
	{
		MessageBeep(MB_OK);
	}
	
	return TRUE;
}

BOOL CIChatMain::FJoinChannelFromName(HWND hWndParent, TCHAR* szName)
{
	Assert(hWndParent && szName);

	CS_JOININFO		cInfo;
	BOOL			fRet = FALSE;
	PICS			pics = NULL;
	HRESULT			hr;

	TCHAR szPassword[1];
	// Auto join
	::ZeroMemory((PVOID)&cInfo, sizeof(CS_JOININFO));
	cInfo.dwcb			= sizeof(CS_JOININFO);
	cInfo.pvChannelName	= szName;
	szPassword[0] = '\0';
	cInfo.pvPassword	= &szPassword;

	pics = PChatSocket();
	hr = pics->HrJoinChannelA(&cInfo);
	if (FAILED(hr))
	{
		// FIX ME - fix this for MIC ONLY chats
		FHandleChatSockErrors(hWndParent, hr);
		goto LReturn;
	}

	 fRet = TRUE;

LReturn:
	if (pics)
	{
		pics->Release();
	}

	return fRet;
}

BOOL CIChatMain::FCloseChat(DWORD index)
{
	BOOL	fRet = FALSE;

	m_csData.Lock();

	--m_cChats;
	
	if (m_cChats <= 0)
	{
		// Ask them if its ok to log off, but only if we are still connected
		m_hWndFore = NULL;
		if (NOERROR != m_pics->HrIsConnected() ||
			IDYES == FDoAlert(m_hWnd, IDS_ERR_LOGOFFOK, ALERT_YESNO))
		{
			::PostMessage(m_hWnd, WM_CLOSE, 0, 0);
		}
		else
		{
			// Create a new chat
			m_cChats = 0;
			::PostMessage(m_hWnd, WM_COMMAND, MAKEWPARAM(IDC_CREATECHANNEL, 0), 0);
		}
	}
	m_csData.Unlock();
	return fRet;
}

void CIChatMain::DestroyWindow(void)
{
	if (m_hWnd)
	{
		::DestroyWindow(m_hWnd);
		m_hWnd = NULL;
		UnregisterClass(gszDummyName, m_hInst);
	}
}

// CHATSOCKETS
BOOL CIChatMain::FSetChatSocket(PICS pics)
{
	Assert(pics);

	BOOL	fRet = TRUE;
	m_csData.Lock();
	
	if (m_pics)
	{
		AssertSz(0, "Already have a socket");
	}
	else
	{
		m_pics = pics;
		fRet = FCreateMsgThread();
	}
	m_fMicSocket = (NOERROR == pics->HrIsMicSocket());
	m_csData.Unlock();

	return fRet;
}


PICS CIChatMain::PChatSocket(void)
{
	m_csData.Lock();
	if (m_pics)
	{
		m_pics->AddRef();
	}
	PICS pics = m_pics;
	m_csData.Unlock();
	return pics;
}

BOOL CIChatMain::FCloseChatSocket(void)
{
	m_csData.Lock();
	if (m_pics)
	{
		m_pics->HrLogOff();
		m_pics->HrCloseSocket();
	}
	m_csData.Unlock();
	return TRUE;
}

DWORD CIChatMain::CChats(void)
{
	m_csData.Lock();
	DWORD cChats = m_cChats;
	m_csData.Unlock();
	return cChats;
}

// NOTE: this will UP the ref count on the wizard!
IC_WIZARD *CIChatMain::PicWizard(void)
{
	m_csData.Lock();
	IC_WIZARD* picw = m_picWizard;
	if (picw)
	{
		picw->AddRef();
	}
	m_csData.Unlock();

	return picw;
}

void CIChatMain::SetWizard(IC_WIZARD *picw)
{
	m_csData.Lock();
	m_picWizard = picw;
	m_csData.Unlock();
}

void CIChatMain::SetIsAway(BOOL fSet)
{
	m_csData.Lock();
	m_fAway = fSet;
	m_csData.Unlock();
}

BOOL CIChatMain::FIsAway(void)
{
	m_csData.Lock();
	BOOL fRet = m_fAway;
	m_csData.Unlock();
	return fRet;
}

void CIChatMain::FreeFifo(void)
{
	if (m_pfData)
	{
		m_fifo.FFreeData(m_pfData);
		m_pfData = NULL;
	}
}

PFIFODATA CIChatMain::PFifoData(void)
{
	m_csData.Lock();
	PFIFODATA pfifo = m_pfData;
	m_csData.Unlock();
	return pfifo;
}

BOOL CIChatMain::FPopFifo(void)
{
	m_csData.Lock();
	Assert(NULL == m_pfData);
	BOOL fRet = m_fifo.FGet(&m_pfData);
	m_csData.Unlock();
	return fRet;
}

// If fClear == TRUE, it tells us that we are done with the FIND for the current find pane
// m_pcfp. So clear stuff
void CIChatMain::SetFinder(BOOL fClear, BOOL fReset)
{
	m_csData.Lock();
	
	if (fClear)
	{
		FreeFifo();
		m_pcfp = NULL;
	}
	else if (!m_pcfp)
	{
		PFIFODATA	pfData;

		if (FPopFifo())
		{
			pfData = PFifoData();
			
			Assert(pfData);
		
			if (pfData->pv)
			{
				m_pcfp = (CChatFindPane *)pfData->pv;
				
				switch (pfData->bType)
				{
				default:
					break;

				case FIFOTYPE_FINDCHANNEL:
					if (fReset)
					{
						m_pcfp->FGotFirstChannel();
					}
					break;

				case FIFOTYPE_FINDMEMBER:
					if (fReset)
					{
						m_pcfp->FGotFirstMember();
					}
					break;

				case FIFOTYPE_FINDUSER:
					if (fReset)
					{
						m_pcfp->FGotFirstUser();
					}
					break;
				}
			}
		}
	}
	m_csData.Unlock();
}

CChatFindPane* CIChatMain::PFinder(void)
{
	m_csData.Lock();
	CChatFindPane* pFind = m_pcfp;
	m_csData.Unlock();
	return pFind;
}

BOOL CIChatMain::FCreateMsgThread(void)
{
	// Launch a msg que reader
	if (!m_msgThread.FCreateThread(DwMainMsgThreadProc, this))
	{
		AssertSz(0, "Can't create thread");
		return FALSE;
	}
	return TRUE;
}

BOOL CIChatMain::FListAllChannels(CChatFindPane *pcfp, CFindDlg	*pcfd)
{
	Assert(pcfp && pcfd);

	// Add this request to our query que
	POSITION pos;
	if (!m_fifo.FAdd(FIFOTYPE_FINDCHANNEL, (PVOID)pcfp, &pos))
	{
		return FALSE;
	}
	// This will release pics.. because PChatSocket() ups the ref count
	BOOL fRet = ::FListAllChannels(PChatSocket(), pcfd->DwMin(), pcfd->DwMax(), pcfd->SzFind(), pcfd->FContains());

	if (!fRet)
	{
		// Since this is an invalid request, we don't want it on the que anymore
		m_fifo.DeleteAt(pos);
	}
	return fRet;
}

BOOL CIChatMain::FListAllUsers(CChatFindPane *pcfp, CFindDlg	*pcfd)
{
	Assert(pcfp && pcfd);

	// Add this request to our query que
	POSITION pos;
	if (!m_fifo.FAdd(FIFOTYPE_FINDUSER, (PVOID)pcfp, &pos))
	{
		return FALSE;
	}
	BOOL fRet = ::FListAllUsers(PChatSocket(), pcfd->SzFind());

	if (!fRet)
	{
		// Since this is an invalid request, we don't want it on the que anymore
		m_fifo.DeleteAt(pos);
	}
	return fRet;

}

BOOL CIChatMain::FListAllMembers(CChatFindPane* pcfp, PICS_PROPERTY picsProp, DWORD dwIndex)
{
	Assert(picsProp);
	Assert(pcfp);

	BOOL fRet;
	POSITION pos;
	// Add it to our query que
	if (!m_fifo.FAdd(FIFOTYPE_FINDMEMBER, (PVOID) pcfp, &pos))
	{
		return FALSE;
	}
	// This will release pics.. because PChatSocket() ups the ref count
	fRet = ::FListAllMembersInChannel(PChatSocket(), picsProp, dwIndex);
	if (!fRet)
	{
		// Since this is an invalid request, we don't want it on the que anymore
		m_fifo.DeleteAt(pos);
	}
	return fRet;
}

BOOL CIChatMain::FGetLatestChannelProps(CChatFindPane *pcfp, PICS_PROPERTY picsProp, DWORD dwIndex)
{
	Assert(picsProp);
	Assert(pcfp);

	BOOL fRet;
	POSITION pos;
	// Add it to our query que
	if (!m_fifo.FAdd(FIFOTYPE_PROPCHANNEL, (PVOID) pcfp, &pos))
	{
		return FALSE;
	}
	// This will release pics.. because PChatSocket() ups the ref count
	fRet = ::FGetLatestPropsChannel(PChatSocket(), picsProp, dwIndex);

	if (!fRet)
	{
		// Since this is an invalid request, we don't want it on the que anymore
		m_fifo.DeleteAt(pos);
	}
	return fRet;

}

BOOL CIChatMain::FGetRealName(HWND hWndParent, PICS_PROPERTY picsProp)
{
	Assert(picsProp);
	BOOL fRet;
	POSITION pos;

	// Add it to our query que
	if (!m_fifo.FAdd(FIFOTYPE_REALNAME, (PVOID)NULL, &pos))
	{
		return FALSE;
	}
	// This will release pics.. because PChatSocket() ups the ref count
	fRet = ::FGetRealNameFromBrowser(PChatSocket(), picsProp);
	if (!fRet)
	{
		// Since this is an invalid request, we don't want it on the que anymore
		m_fifo.DeleteAt(pos);
	}
	return fRet;
}

BOOL CIChatMain::FHandlePropertyData(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	PCS_PROPERTY	pcsProp;
	BOOL	fRet = FALSE;

	SetFinder();	// make sure the finder is set right

	pcsProp = (PCS_PROPERTY) (pcsMsg + 1);
	if (pcsProp->picsProperty)
	{
		switch (m_pfData->bType)
		{
		default:
			AssertSz(0, "Unknown FIFO Type");
			return FALSE;
		
		case FIFOTYPE_PROPCHANNEL:
			fRet = m_pcfp->FUpdateProperty(pcsProp->picsProperty);
			break;
		}		
		SetFinder(TRUE);	// clear it..we're done
	}
	return fRet;
}

BOOL CIChatMain::FHandleQueryData(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	PCS_PROPERTY	pcsProp;
	BOOL	fRet = FALSE;

	SetFinder();	// make sure the finder is set right

	if (m_pcfp)
	{
		m_pcfp->ShowWindow();
		m_pcfp->HWndSetFocus();
	}

	pcsProp = (PCS_PROPERTY) (pcsMsg + 1);
	Assert(m_pfData);
	switch (m_pfData->bType)
	{
	default:
		break;

	case FIFOTYPE_FINDCHANNEL:
		if (pcsProp->picsProperty)
		{
			fRet = m_pcfp->FInsertChannel(pcsProp->picsProperty);
		}
		if (pcsProp->fLastRecord)
		{
			fRet = m_pcfp->FGotAllChannels();
		}
		break;

	case FIFOTYPE_FINDMEMBER:
		if (pcsProp->picsProperty)
		{
			fRet = m_pcfp->FInsertMember(pcsProp->picsProperty);
		}
		if (pcsProp->fLastRecord)
		{
			fRet = m_pcfp->FGotAllMembers();
		}
		break;

	case FIFOTYPE_FINDUSER:
		if (pcsProp->picsProperty)
		{
			fRet = m_pcfp->FInsertUser(pcsProp->picsProperty);
		}
		if (pcsProp->fLastRecord)
		{
			fRet = m_pcfp->FGotAllUsers();
		}
		break;

	case FIFOTYPE_REALNAME:
		fRet = TRUE;
		ParsePropertyData(pcsMsg, NULL, HWndFore());
		break;

	case FIFOTYPE_PROPCHANNEL:
		if (pcsProp->picsProperty)
		{
			fRet = m_pcfp->FUpdateProperty(pcsProp->picsProperty);
		}
		break;
	}

	if (pcsProp->fLastRecord)
	{
		SetFinder(TRUE);	// clear it..we're done
	}

	return fRet;
}

BOOL CIChatMain::FHandlePropertyError(HRESULT hr)
{
	SetFinder(FALSE, FALSE);	// make sure the finder is set right
	
	int		idStr;
	BOOL	fCleanUp = TRUE;

	if (m_pcfp)	// did we send a query 
	{
		switch (m_pfData->bType)
		{
		default:
			idStr = IDS_ERR_GENERIC;
			break;
		
		case FIFOTYPE_PROPCHANNEL:
			idStr = -1;		 // no alerts on this failure
			fCleanUp = FALSE;
			break;

		case FIFOTYPE_FINDCHANNEL:
			idStr = (CS_E_NOMATCHES == hr) ? IDS_ERR_NOCHATSFOUND : IDS_ERR_GENERIC;
			break;

		case FIFOTYPE_FINDMEMBER:
			idStr = (CS_E_NOMATCHES == hr) ? IDS_ERR_CHATPROTECTED : IDS_ERR_CHATGONE;
			break;
		
		case FIFOTYPE_FINDUSER:
			idStr = (CS_E_NOMATCHES == hr) ? IDS_ERR_NOUSERSFOUND : IDS_ERR_GENERIC;
			break;
		}

		if (-1 != idStr)
		{
			FDoAlert(HWndFore(), idStr, ALERT_WARNING);
			if (fCleanUp)
			{
				if (CS_E_NOMATCHES == hr)
				{
					m_pcfp->FNoDataOnLookUp();
				}
				else
				{
					m_pcfp->FLookUpError();
				}
			}
		}
		SetFinder(TRUE);
		return TRUE;
	}
	return FALSE;
}

BOOL CIChatMain::FPostCommand(WPARAM wParam, LPARAM lParam)
{
	Assert(m_hWnd);

	return ::PostMessage(m_hWnd, WM_COMMAND, wParam, lParam);
}

// Stop any currently running wizards
BOOL CIChatMain::FStopWizard(BOOL fCancel, HRESULT hr)
{
	IC_WIZARD* picWizard = PicWizard();
	if (picWizard)
	{
		picWizard->StopDialog(fCancel, hr); 
		picWizard->Release();
		SetWizard(NULL);
		return TRUE;
	}
	
	return FALSE;
}

BOOL CIChatMain::FWaitForMsg(void)
{
	Assert(m_pics);
	PICS pics = PChatSocket();
	if (!pics)
	{
		AssertSz(0, "Socket disappeared");
		return TRUE;
	}
	PCS_MSGBASE	pcsMsg;
	BOOL		fNotDone = TRUE;
	while (fNotDone && SUCCEEDED(pics->HrWaitForMsg(&pcsMsg, INFINITE)))
	{
		Assert(pcsMsg);
		DebugMessageType("CIChatMain::FWaitForMsg", pcsMsg->csMsgType);
		switch (pcsMsg->csMsgType)
		{
		default:
			break;

		case CSMSG_TYPE_ERROR:
			PCS_ERROR	pErr;

			pErr = (PCS_ERROR) (pcsMsg + 1);
			// Is it a query error?
			if (CS_E_PROPLOOKUP == pErr->hr || CS_E_NOMATCHES == pErr->hr)
			{
				if (FHandlePropertyError(pErr->hr))
				{
					break;
				}
			}
			// is it a wizard related error?
			if (FStopWizard(TRUE, pErr->hr))
			{
				break;
			}
			// Generic Error
			if (!FHandleChatSockErrors(HWndFore(), pErr->hr))
			{
				fNotDone = FALSE;	// fatal error. This will stop this function
			}
			// Could not create channel.. if there are no more..try to create another one.
			// If this was a password failure, pop up the Join dialog
			if (FIsChannelCreateError(pErr->hr))
			{
				if (CS_E_CHANNELBADPASS == pErr->hr)
				{
					::PostMessage(m_hWnd, WM_COMMAND, MAKEWPARAM(IDC_JOINCHANNEL, 0), 0);
				}
				else if (0 == CChats())
				{
					::PostMessage(m_hWnd, WM_COMMAND, MAKEWPARAM(IDC_CREATECHANNEL, 0), 0);
				}
				else if (NOERROR != pics->HrIsConnected())
				{
					PostMessage(m_hWnd, WM_CLOSE, 0, 0);
				}
			}
			else if (0 == CChats())
			{
				::PostMessage(m_hWnd, WM_CLOSE, 0, 0);
			}
			break;

		case CSMSG_TYPE_LOGIN:
			// Successful login
			FStopWizard(FALSE, NOERROR);
			break;

		case CSMSG_TYPE_ADDCHANNEL:
			PCS_MSGCHANNEL	pMsg;
			// Got a channel. Create a chat
			pMsg = (PCS_MSGCHANNEL)(pcsMsg + 1);
			
			if (pMsg->picsChannel)
			{
				// Up the Ref count, since we are going to hold on to this pointer
				(pMsg->picsChannel)->AddRef();
				FPostCommand(MAKEWPARAM(IDC_CREATECHAT, 0), (LPARAM)pMsg->picsChannel);
			}
			break;

		case CSMSG_TYPE_PROPERTYDATA:
			FHandlePropertyData(pcsMsg);
			break;

		case CSMSG_TYPE_QUERYDATA:
			FHandleQueryData(pcsMsg);
			break;

		case CSMSG_TYPE_INVITE:
			::HrHandleInvite(HWndFore(), pcsMsg);
			break;
		}
		// Free the msg
		HrFreeMsg(pcsMsg);
	}
	// Release our copy
	pics->Release();

	return TRUE;
}

// Returns TRUE if error is NOT fatal, false otherwise.
int FHandleChatSockErrors(HWND hWndParent, HRESULT hr, BOOL fMicOnly)
{
	int		idStr;
	BOOL	fRet = TRUE;
	
	switch(hr)
	{
	default:
		idStr = IDS_ERR_GENERIC;
		break;
	
	case NOERROR:
		return TRUE;

	case CS_E_WINSOCKDLL:
		idStr = IDS_ERR_REDOSETUP;
		fRet = FALSE;	// fatal error
		break;

	case CS_E_HOSTNOTFOUND:
		idStr = IDS_ERR_SERVERNOTFOUND;
		break;
	
	case CS_E_SOCKETCREATE:
	case CS_E_CANTCONNECT:
		idStr = IDS_ERR_CONNECT;
		break;

	case CS_E_NOTCONNECTED:
	case CS_E_SOCKETCLOSED:
		idStr = IDS_ERR_NOTCONNECTED;
		fRet = FALSE;	// fatal error
		break;

	case CS_E_LOSTCONNECTION:
	case CS_E_NOTLOGGEDIN:
		idStr = IDS_ERR_LINEDROPPED;
		fRet = FALSE;	// fatal error
		break;

	case CS_E_HOSTDROPPEDCONNECTION:
		idStr = IDS_ERR_HOSTHUNGUP;
		fRet = FALSE;	// fatal error
		break;

	case CS_E_SOCKETERROR:
	case CS_E_NETWORKDOWN:
		idStr = IDS_ERR_GENERIC;
		fRet = FALSE;	// fatal error
		break;

	case CS_E_ILLEGAL_CHARS:
		// FIX ME - we need to extend this for MIC ONLY chats
		idStr = IDS_ERR_CHANNELCHARS_IRC;
		break;

	case CS_E_FIRSTCHAR:
		// FIX ME - we need to extend this for MIC ONLY chats
		idStr = IDS_ERR_CHANNELFIRSTCHAR;
		break;

	case CS_E_CREATEFAIL:
	case CS_E_JOINFAIL:
		idStr = IDS_ERR_GENERIC;
		break;

	case CS_E_CHANNELEXISTS:
		idStr = IDS_ERR_ALREADYEXISTS;
		break;
	
	case CS_E_CHANNELNOTFOUND:
		idStr = IDS_ERR_CHANNELNOTFOUND;
		break;

	case CS_E_CHANNELFULL:
		idStr = IDS_ERR_CHANNELFULL;
		break;

	case CS_E_ALREADYONCHANNEL:
		idStr = IDS_ERR_ALREADYONCHANNEL;
		break;
	
	case CS_E_INVITEONLYCHANNEL:
		idStr = IDS_ERR_CHANNELINVITEONLY;
		break;
	
	case CS_E_CHANNELBADPASS:
		idStr = IDS_ERR_CHANNELPASSWORD;
		break;
	
	case CS_E_TOOMANYCHANNELS:
		idStr = IDS_ERR_TOOMANYCHANNELS;
		break;
				
	case CS_E_BANNED:
		idStr = IDS_ERR_BANNED;
		break;

	case CS_E_SERVER:
		idStr = IDS_ERR_GENERIC;
		break;

	case CS_E_UNKNOWNUSER:
	case CS_E_ILLEGALUSER:
		idStr = IDS_ERR_ILLEGALUSER;
		break;

	case CS_E_ALIASINUSE:
		idStr = IDS_ERR_NAMEINUSE;
		break;

	case CS_E_PROPLOOKUP:
		idStr = IDS_ERR_CHATGONE;
		break;
	
	case CS_E_NOWHISPER:
		idStr = IDS_ERR_NOWHISPER;
		break;
	
	case CS_E_BADCHANNELNAME:
		idStr = IDS_ERR_BADCHATNAME;
		break;
	
	case CS_E_AUTHNOTAVAIL:
		idStr = IDS_ERR_NOAUTHENTICATE;
		break;
	
	case CS_E_SERVERISFULL:
		idStr = IDS_ERR_SERVERFULL;
		break;
	
	case CS_E_AUTHENTICATEDONLY:
		idStr = IDS_ERR_AUTHONLY;
		break;
	
	case CS_E_UNKNOWNSECURITYPACKAGE:
		idStr = IDS_ERR_AUTHNOTAVAIL;
		break;
	
	case CS_E_NOTINCHANNEL:
		return FALSE;
	}

	FDoAlert(hWndParent, idStr, ALERT_ERROR);

	return fRet;
}

// Returns TRUE if error was a channel create error
int FIsChannelCreateError(HRESULT hr)
{
	switch(hr)
	{
	default:
		return FALSE;
	case CS_E_ILLEGAL_CHARS:
	case CS_E_FIRSTCHAR:
	case CS_E_CREATEFAIL:
	case CS_E_JOINFAIL:
	case CS_E_CHANNELEXISTS:
	case CS_E_CHANNELNOTFOUND:
	case CS_E_CHANNELFULL:
	case CS_E_ALREADYONCHANNEL:
	case CS_E_INVITEONLYCHANNEL:
	case CS_E_CHANNELBADPASS:
	case CS_E_TOOMANYCHANNELS:
	case CS_E_BANNED:
	case CS_E_SERVER:
	case CS_E_UNKNOWNUSER:
	case CS_E_ILLEGALUSER:
	case CS_E_BADCHANNELNAME:
	case CS_E_AUTHENTICATEDONLY:
		break;
	}
	return TRUE;
}

// WndProc
LRESULT CALLBACK MicChatWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	default:
		break;

	case WM_CLOSE:
		gciChat.Quit();
		break;	
	
	case WM_DESTROY:  // window being destroyed
		::PostQuitMessage(0);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case IDC_CREATECHANNEL:
			if (gciChat.m_szDefChan) // do we have something we can join by default?
			{
				if (FCreateChannelFromName(HWndFore(), gciChat.m_szDefChan) || 0 != gciChat.CChats()) 
				{
					gciChat.m_szDefChan = NULL;
					break;
				}
				gciChat.m_szDefChan = NULL;
			}
			if (!FCreateNewChannel(HWndFore()) && 0 == gciChat.CChats())
			{
				gciChat.Quit();
			}
			break;
		
		case IDC_JOINCHANNEL:
			if (!FJoinNewChannel(HWndFore(), NULL) && 0 == gciChat.CChats())
			{
				gciChat.Quit();
			}
			break;

		case IDC_CREATECHAT:
			return FCreateNewChat((PICS_CHANNEL)lParam);
		}
		break;
	}
	return (::DefWindowProc(hWnd, uMsg, wParam, lParam));
}

// MSG Thread
DWORD __stdcall DwMainMsgThreadProc(PVOID pvData)
{
	Assert(pvData);

	CIChatMain* pMain = (CIChatMain*)pvData;

	return pMain->FWaitForMsg();
}

// CIFIFO
BOOL CIFifo::FAdd(BYTE bType, PVOID pv, POSITION* ppos)
{
	// Allocate a new item
	PFIFODATA pfData = new FIFODATA;
	if (!pfData)
	{
		AssertGLE(FALSE);
		DoOOM();
		return FALSE;
	}

	pfData->bType = bType;
	pfData->pv = pv;
	if (!FEnQue((PVOID)pfData, ppos))
	{
		delete pfData;
		return FALSE;
	}

	return TRUE;
}

BOOL CIFifo::FGet(PFIFODATA* ppfData)
{
	Assert(ppfData);

	return FDeQue((PVOID*)ppfData);
}

void CIFifo::DeleteAt(POSITION pos)
{
	if (pos)
	{
		RemoveAt(pos);
	}
}

BOOL CIFifo::FFreeData(PVOID pv)
{
	if (pv)
	{
		PFIFODATA	pfifo = (PFIFODATA)pv;
		switch (pfifo->bType)
		{
		default:
			break;

		case FIFOTYPE_FINDCHANNEL:
		case FIFOTYPE_FINDMEMBER:
		case FIFOTYPE_PROPCHANNEL:
		case FIFOTYPE_PROPMEMBER:
		case FIFOTYPE_FINDUSER:
			((CChatFindPane*)pfifo->pv)->Release();
			break;
		}

		delete (pfifo);
	}
	
	return TRUE;
}
