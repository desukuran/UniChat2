//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICUTIL__
#define __ICUTIL__

#include "icinc.h"

//--------------------------------------------------------------------------------------------
// MACROS
//--------------------------------------------------------------------------------------------
#define DoOOM()
#define DoAlert(a, b, c)

//--------------------------------------------------------------------------------------------
// Common APIS
//--------------------------------------------------------------------------------------------
BOOL		FGetTextExtentPoint(HWND hWnd, TCHAR* psz, SIZE* psize);
TCHAR*		GetSz(HINSTANCE hInst, WORD wszID);

HWND		HWndCreateDummy(HINSTANCE hInst, WNDPROC pwndProc, LPCTSTR pszName);

HINSTANCE	HInstance(HWND hWnd);
HWND 		HWndGetDlgItem(HWND hDlg, int idControl);
BOOL 		FEnableControl(HWND hDlg, int idControl, BOOL fEnable);
BOOL 		FShowControl(HWND hDlg, int idControl, BOOL fShow);
BOOL 		FEditBoxLimitText(HWND hDlg, int idControl, DWORD cb);
BOOL 		FCheckDlgItem(HWND hDlg, int idControl, BOOL fCheck);
BOOL		FSetDlgItemText(HWND hDlg, int idCtl, int idStr);
BOOL		FCenterWindow(HWND hWnd);

HANDLE		CreateNormalFile(char* psz, BOOL fCreate=TRUE, BOOL fNoAccess=FALSE);
BOOL		FSaveAsDialog(HINSTANCE hInst, HWND hWndParent, TCHAR* pszFileName, DWORD cchSz, DWORD* pdwIndex);
BOOL		FGetBrowserPath(HINSTANCE hInst, HWND hWndParent, TCHAR* pszFileName, DWORD cchSz);
BOOL		FCreateShortCutOnDesktop(CHAR* szFileName, CHAR* szURL);

HFONT		HfontChangeFontWeight(HFONT hfont, long lfWeight, BOOL fStrike=FALSE);

void		SetCharFormat(HWND	hWnd, BOOL fSet, BOOL fColor, COLORREF	cref, COLORREF* pcref, 
						BOOL fBold, BOOL fAll=FALSE);

BOOL		FSelectAllRichText(HWND hWnd, CHARRANGE* pcrSav);

CHAR*		PszWideToAnsi(WCHAR* psz);
BOOL		FWideCharToAnsi(WCHAR* psz, CHAR* pszAnsi, int cbAnsi);
BOOL		FAnsiToWideChar(CHAR* psz, WCHAR* pszWide, int cbWide);
BOOL		FSetRichTextFont(HWND hWnd, CHARFORMAT* pcf, BOOL fAll=TRUE);
COLORREF	ColorRefGet(int index, BOOL fTextColor=TRUE);
BOOL		FChooseColor(HWND hWnd, COLORREF rgb, COLORREF* prgbResult);

void		MarkDefaultMenuitem(HMENU hmenu, int iitemDefault);

// REGISTRY FUNCTIONS
BOOL		FGetDesktopPath(TCHAR* szPath, DWORD cch);
BOOL		FOpenMicRegKey(HKEY hkeyRoot, char* szSubkey, REGSAM samDesired, HKEY* phkey);
BOOL		FGetRegistrySz(HKEY hkeyRoot, LPCSTR pszVal, LPSTR pszBuf, DWORD cbBuf);
BOOL		FRegistryKeyExists(HKEY hkeyRoot, char* szSubkey, BOOL fAddIfNo);
void		SetRegistryRaw(HKEY hkeyRoot, LPCSTR pszVal, DWORD dwType, LPVOID pv, DWORD cb);
BOOL		FCreateAndSetRegistry(HKEY hkeyRoot, char* pszVal, DWORD dwType, LPVOID pv, DWORD cb);
BOOL		FRegistryBoolSet(HKEY hkeyRoot, LPCSTR szVal, BOOL fOn);
BOOL		FGetRegistryBool(HKEY hkeyRoot, LPCSTR szVal, BOOL* pf);
BOOL		FGetRegistryDword(HKEY hkeyRoot, LPCSTR szVal, DWORD* pdw);
// ERROR APIS and constants
const UINT	ALERT_ERROR		= MB_ICONERROR | MB_OK;
const UINT	ALERT_WARNING	= MB_ICONEXCLAMATION | MB_OK;
const UINT	ALERT_YESNO		= MB_ICONEXCLAMATION | MB_YESNO;

int			FDoAlert(HWND hWndParent, int idStr, UINT uType);
int			FDoPrintFAlert(HWND hWndParent, int idStr, TCHAR* sz, UINT uType);

const UINT	NOTIFY_OK = MB_OK | MB_ICONINFORMATION;
int			FDoNotify(HWND hWndParent, int idStr, TCHAR* sz, UINT uType);
// MEMBER STUFF
TCHAR*		PszGetName(PICS_MEMBER pcm, TCHAR* psz);
TCHAR*		PszGetChannelName(PICS_CHANNEL pcm, TCHAR* psz);
TCHAR*		PszGetDisplaySz(PICS_PROPERTY picsProperty, DWORD dwIndex, TCHAR* szConvert);

#endif
