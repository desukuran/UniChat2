//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icwizard.h"

int CALLBACK ChatPropSheetCallback(HWND, UINT message, LPARAM lParam);

////////////////////////////////////////////////////////////////////////////////////////////
CChatPropertyPage::CChatPropertyPage()
	: CRefCount()
{
	::ZeroMemory(&m_psh, sizeof(PROPSHEETHEADER));
	Reset();
}

CChatPropertyPage::~CChatPropertyPage(void)
{
	Reset();
}

void CChatPropertyPage::Reset(void)
{
	if (m_psh.phpage)
	{
		delete [] m_psh.phpage;
		m_psh.phpage = NULL;
	}
	m_cPages	= 0;
	m_hInst		= NULL;
	m_hDlg		= NULL;
}

BOOL CChatPropertyPage::FInit(HWND hWndParent, UINT cPages, DWORD dwFlags, int idStrTitle, UINT nStartPage)
{
	Assert(hWndParent && cPages && !m_hInst);

	m_hInst = HInstance(hWndParent);
	// cPages pages. Alloc memory for an array of pointers to HPROPSHEETPAGE 
	m_psh.phpage	= new HPROPSHEETPAGE[cPages];
	if (!m_psh.phpage)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	m_psh.dwSize 		= sizeof(PROPSHEETHEADER);
	m_psh.dwFlags		= dwFlags | PSH_USECALLBACK;
    m_psh.hwndParent 	= hWndParent;
    m_psh.hInstance 	= m_hInst;
    m_psh.pszCaption 	= (-1 == idStrTitle) ? NULL : MAKEINTRESOURCE(idStrTitle);
    m_psh.nPages 		= cPages;
    m_psh.nStartPage	= nStartPage;
	m_psh.pfnCallback	= ChatPropSheetCallback;

	return TRUE;
}

BOOL CChatPropertyPage::FAddPage(int idDlg, DLGPROC dlgProc, LPARAM lParam)
{
	Assert(m_psh.phpage && (m_cPages < m_psh.nPages));

   	PROPSHEETPAGE 	psp;
	// Allocate the page
	::ZeroMemory(&psp, sizeof(PROPSHEETPAGE));
    psp.dwSize 		= sizeof(PROPSHEETPAGE);
    psp.hInstance 	= m_hInst;
    psp.pszTemplate = MAKEINTRESOURCE(idDlg);
    psp.pfnDlgProc 	= dlgProc;
	psp.lParam		= lParam;

	HPROPSHEETPAGE	hph = ::CreatePropertySheetPage(&psp);
	if (!hph)
	{
		AssertGLE(FALSE);
		DeleteAllPages();
		return FALSE;
	}
	// Add the page
	m_psh.phpage[m_cPages] = hph;
	++m_cPages;

	return TRUE;
}

BOOL CChatPropertyPage::FShow(void)
{
	Assert(m_psh.phpage && m_cPages == m_psh.nPages);

	return ::PropertySheet(&m_psh);
}

BOOL CChatPropertyPage::FCenter(HWND hDlg)
{
	Assert(hDlg);

	HWND hwndParent = ::GetParent(hDlg);
	
	return FCenterWindow(hwndParent);
}

void CChatPropertyPage::StopDialog(BOOL fCancel, HRESULT hr)
{
	if (m_hDlg)
	{
		::PostMessage(m_hDlg, WM_COMMAND, (fCancel) ? ID_CANCELWIZ : ID_FINISHWIZ, (LPARAM)hr);
	}
}

void CChatPropertyPage::DeleteAllPages(void)
{
	if (!m_psh.phpage)
		return;

	UINT index = 0;

	while (index < m_cPages)
	{
		::DestroyPropertySheetPage(m_psh.phpage[index]);
		++index;
	}
	m_cPages = 0;
}

BOOL CChatPropertyPage::FGetText(HWND hDlg, int idCtl, int idErr, TCHAR* psz, DWORD cch)
{
	Assert(hDlg && psz);

	if (0 == SendDlgItemMessage(hDlg, idCtl, WM_GETTEXT, (WPARAM)cch, (LPARAM)psz))
	{
		if (-1 != idErr)
		{
			FDoErrorAndSetFocus(hDlg, idCtl, idErr);
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CChatPropertyPage::FSelectPage(HWND hDlg, int index)
{
	return PropSheet_SetCurSel(GetParent(hDlg), NULL, index);
}

void CChatPropertyPage::SendSetFocus(HWND hDlg, int idCtl)
{
	::PostMessage(hDlg, WM_COMMAND, (WPARAM)ID_SETFOCUS, (LPARAM)idCtl);
}

void CChatPropertyPage::SetFocus(HWND hDlg, int idCtl)
{
	::SetFocus(::GetDlgItem(hDlg, idCtl));
}

int CChatPropertyPage::FDoErrorAndSetFocus(HWND hDlg, int idCtl, int idErr)
{
	int iRet = ::FDoAlert(hDlg, idErr, ALERT_WARNING);
	SendSetFocus(hDlg, idCtl);

	return iRet;
}

void CChatPropertyPage::PressWizButton(HWND hDlg, int idBtn)
{
	Assert(hDlg);

	PropSheet_PressButton(GetParent(hDlg), idBtn);
}

// Wizards are simply special Property sheets
void CChatWizard::SetWizButtons(HWND hDlg, DWORD dwFlags)
{
	Assert(hDlg);

	::PropSheet_SetWizButtons(GetParent(hDlg), dwFlags);
}

void CChatWizard::SetFinishText(HWND hDlg, int idStr)
{
	Assert(hDlg);

	PropSheet_SetFinishText(GetParent(hDlg), GetSz(m_hInst, idStr));
}

////////////////////////////////////////////////////////////////////////////////////////////
// Use the callback to eliminate the Help button
int CALLBACK ChatPropSheetCallback(HWND, UINT message, LPARAM lParam)
{
	switch (message)
	{
	case PSCB_PRECREATE:
		{
		LPDLGTEMPLATE lpTemplate = (LPDLGTEMPLATE)lParam;

		// Ensure DS_CONTEXTHELP is turned OFF
		lpTemplate->style &= ~DS_CONTEXTHELP;
		return TRUE;
		}
	}

	return 0;
}
