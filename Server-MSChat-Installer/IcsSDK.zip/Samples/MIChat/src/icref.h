//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICREFCOUNT__
#define __ICREFCOUNT__

class CRefCount
{
// Interfaces
public:
	CRefCount(void);
	~CRefCount(void);
	void			AddRef(void);
	void			Release(void);
	virtual	void	Free(void)	{ delete this; }
// Data
public:
	LONG	m_lRef;
};

#endif
