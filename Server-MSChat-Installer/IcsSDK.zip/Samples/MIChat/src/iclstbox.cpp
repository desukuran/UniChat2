//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "iclstbox.h"
#include "icutil.h"

/////////////////////////////////////////////////////////////////////////////////////////
CChatListBox::CChatListBox(void)
		: CChatPane()
{
	m_hfontStrikeOut = NULL;
}

CChatListBox::~CChatListBox(void)
{
	if (m_hfontStrikeOut)
	{
		::DeleteObject((HGDIOBJ)m_hfontStrikeOut);
	}
}

LRESULT CALLBACK ChildListBoxWndProc(HWND, UINT, WPARAM, LPARAM);

BOOL CChatListBox::FInit(HWND hWnd)
{
	if (hWnd)
	{
		Assert(NULL == m_hWnd);
		m_hWnd = hWnd;
	}
	// Create font
	if (!FMakeStrikeFont())
	{
		return FALSE;
	}
	// Load bitmaps
	if (!m_ccbitmap.FLoad(HInstance(m_hWnd)))
	{
		return FALSE;
	}
	
	SetWindowProc(ChildListBoxWndProc);

	return FInitExtra();
}

BOOL CChatListBox::FMakeStrikeFont(void)
{
	Assert(NULL == m_hfontStrikeOut);

	// Create strike out font
	// Get current font
	HFONT hFont = (HFONT)SendMessage(WM_GETFONT);
	if (!hFont)
	{
		hFont = (HFONT)GetStockObject(SYSTEM_FONT);
	}
	
	if (!hFont)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	
	m_hfontStrikeOut = ::HfontChangeFontWeight(hFont, FW_THIN, TRUE);

	return (NULL != m_hfontStrikeOut);
}

BOOL CChatListBox::FCreate(HWND hWndParent, int idCmd, RECT *prc)
{
	if (!CChatChildWnd::FCreate(hWndParent, idCmd, prc, TEXT("LISTBOX"), 
						WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_OWNERDRAWFIXED |
						LBS_NOINTEGRALHEIGHT | LBS_NOTIFY | LBS_EXTENDEDSEL | LBS_SORT, 
						0, NULL))
	{
		return FALSE;
	}

	::SetWindowLong(m_hWnd, GWL_USERDATA, (LONG)this);
	return FInit(NULL);
}

// Responds to the WM_COMPAREITEM message
int CChatListBox::FCompareItem(LPCOMPAREITEMSTRUCT lpci)
{
	Assert(lpci);

	PICS_MEMBER pcm1 = (PICS_MEMBER)lpci->itemData1;
	PICS_MEMBER pcm2 = (PICS_MEMBER)lpci->itemData2;
	
	Assert(pcm1 && pcm2);
	if (!(pcm1 && pcm2))
	{
		return -1;
	}

	int f = ::CompareString(MAKELCID(MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT), SORT_DEFAULT), 
						NORM_IGNORECASE,
						(LPCTSTR)PszGetName(pcm1, m_szConvert1), -1, 
						(LPCTSTR)PszGetName(pcm2, m_szConvert2), -1);
	if (f)
	{
		// Successful
		return (f-2);	// see documentation on CompareString
	}
	AssertGLE(FALSE);

	return -1;
}

TCHAR* CChatListBox::PszGetName(PICS_MEMBER pcm, TCHAR* psz)
{
	return ::PszGetName(pcm, psz);
}

// Responds to WM_MEASUREITEM
int CChatListBox::FMeasureItem(HWND hWnd, LPMEASUREITEMSTRUCT lpmi)
{
	Assert(lpmi);

	SIZE size;

	if (!FGetTextExtent(IDS_SENDBTN, &size, hWnd))
	{
		return FALSE;
	}

	lpmi->itemWidth		= size.cx;
	lpmi->itemHeight	= size.cy;

	return TRUE;
}

// Responds to WM_DRAWITEM
int CChatListBox::FDrawItem(LPDRAWITEMSTRUCT lpdi)
{
	CMember*	pcm = NULL;
	
	Assert(lpdi);
	Assert(m_hWnd);
	
	if (0xffffffff == lpdi->itemData)
	{
		return FALSE;
	}
	// Get the user's properties
	PICS_MEMBER pcsMem = (PICS_MEMBER)lpdi->itemData;
	if (!pcsMem)
	{
		return FALSE;
	}

#ifdef NOTNOW
	HRESULT	hr = pcsMem->HrGetMemberData((PVOID*)&pcm);
	if (FAILED(hr))
	{
		AssertSz(0, "HrGetMemberData");
		return FALSE;
	}

	if (!pcm)
	{
		return FALSE;
	}
#endif
	
	char*		psz;
	DWORD 		rgbSelOld;
	DWORD 		rgbSelTextOld;
	DWORD 		rgbSel;
	DWORD 		rgbSelText;
	HDC			hDC;
	HBRUSH 		hbrush 		= NULL;
	HFONT 		hfontOld 	= NULL;
	BOOL		fIgnored	= FALSE;
	BOOL		fRet		= FALSE;
	
	
	fIgnored	= (NOERROR == pcsMem->HrIsMemberIgnored());
	hDC			= lpdi->hDC;

	if (lpdi->itemState & ODS_SELECTED)
	{
		// Draw item selected. Use standard windows colors.
		rgbSelText 	= ::GetSysColor(COLOR_HIGHLIGHTTEXT);
		rgbSel 		= ::GetSysColor(COLOR_HIGHLIGHT);
	}
	else
	{
		// If the user has a custom color, use that color
		CHARFORMAT*	pcformat = NULL;
		
#ifdef NOTNOW
		pcformat	= pcm->PcFormat();
#endif
		rgbSelText	= pcformat ? pcformat->crTextColor : ::GetSysColor(COLOR_WINDOWTEXT);
		rgbSel 		= ::GetSysColor(COLOR_WINDOW);
	}
	// Save original brush colors
	rgbSelTextOld 	= ::SetTextColor(hDC, rgbSelText);
	rgbSelOld 		= ::SetBkColor(hDC, rgbSel);
	// Allocate brushes we will use
	hbrush = ::CreateSolidBrush(rgbSel);
	// Make sure we got it
	if (NULL == hbrush)
	{
		AssertGLE(FALSE);
		goto LCleanUp;
	}
	// Erase whatever is there. Paint rectangle in background color
	if (!::FillRect(hDC, &(lpdi->rcItem), hbrush))
	{
		AssertGLE(FALSE);
		goto LCleanUp;
	}
	RECT	rc;
	// Let specialized people do specialized drawing and tell use where to
	// draw the rest
	::CopyMemory(&rc, &(lpdi->rcItem), sizeof(RECT));
	if (!FDrawExtra(lpdi, &rc, pcm))
	{
		goto LCleanUp;
	}
	// Now draw an appropriate bitmap - FIX ME
	if (!m_ccbitmap.FDrawModeBitmap(hDC, &rc, pcsMem))
	{
		goto LCleanUp;
	}
	// Now draw the name
	psz = PszGetName(pcsMem, m_szConvert1);
	Assert(psz);

	if (fIgnored)
	{
		hfontOld = (HFONT)::SelectObject(hDC, m_hfontStrikeOut);
	}

	if (!::TextOut(hDC, rc.left + 19, rc.top, psz, lstrlen(psz)))
	{
		AssertGLE(FALSE);
		goto LCleanUp;
	}

	if (lpdi->itemState & ODS_FOCUS)
	{
		::DrawFocusRect(hDC, &(lpdi->rcItem));
	}

	fRet = TRUE;
	// Restore saved values
LCleanUp:

	::SetTextColor(hDC, rgbSelTextOld);
	if (hbrush)
	{
		::DeleteObject(hbrush);
	}
	if (fIgnored)
	{
		::SelectObject(hDC, hfontOld);
	}

	::SetBkColor(hDC, rgbSelOld);
	
	return fRet;
}

// public
BOOL CChatListBox::FAddItem(PICS_MEMBER pcm, CMember *pMember)
{
	Assert(pcm);
	Assert(m_hWnd);

	BOOL	fRet = FALSE;

#ifdef NOTNOW
	// NOTE: This ASSUMES that we do NOT have a HASSTRINGS box.
	// The list box will stick pcm in the itemData field instead!
	if (FAILED(pcm->HrSetMemberData((PVOID)pMember)))
	{
		return FALSE;
	}
#endif
	// Save the current member mode.. so we can do comparisons when it changes
	DWORD dwMode = 0;

	if (SUCCEEDED(pcm->HrGetMemberMode(&dwMode)))
	{
		pcm->HrSetMemberData((PVOID)dwMode);
	}
	return (LB_ERRSPACE != SendMessage(LB_ADDSTRING, (LPARAM)pcm));
}

// public
BOOL CChatListBox::FDeleteItem(PICS_MEMBER pcm)
{
	LRESULT index = IFindMember(pcm);
	if (LB_ERR == index)
	{
		return FALSE;
	}
	// remove it from the list
	return (LB_ERR != SendMessage(LB_DELETESTRING, (WPARAM)index));
}

// Public
BOOL CChatListBox::FFreeItem(PICS_MEMBER pcm)
{
#ifdef NOTNOW
	Assert(pcm);

	CMember* pMember = PCMemberGet(pcm);
	if (pMember)
	{
		delete pMember;
		pcm->HrSetMemberData(NULL);
	}
#endif
	pcm->Release();

	return TRUE;
}

CMember* CChatListBox::PCMemberGet(PICS_MEMBER pcm)
{
#ifdef NOTNOW
	Assert(pcm);

	CMember* pMember;

	HRESULT hr = pcm->HrGetMemberData((PVOID*)&pMember);
	if (FAILED(hr))
	{
		AssertSz(0, "HrGetMemberData");
		pMember = NULL;
	}
	
	return pMember;
#else
	return NULL;
#endif
}

// public
PICS_MEMBER CChatListBox::PicsMemberGet(int index)
{
//	PICS_MEMBER pMem;
	DWORD dwData = (DWORD)SendMessage(LB_GETITEMDATA, (WPARAM)index);
	if (0xffffffff == dwData)
	{
		return NULL;
	}
	return ((PICS_MEMBER)dwData);
}

// public
BOOL CChatListBox::FUpdateItem(PICS_MEMBER pcm)
{
	Assert(pcm);

	LRESULT index = IFindMember(pcm);
	if (LB_ERR == index)
	{
		Assert(FALSE);
		return TRUE;
	}
	// Ensure that this item gets redraw in the member list
	RECT	rc;
	
	if (LB_ERR == SendMessage(LB_GETITEMRECT, (WPARAM)index, (LPARAM)&rc))
	{
		Assert(FALSE);
		return FALSE;
	}
	// This will redraw it
	return ::InvalidateRect(m_hWnd, &rc, FALSE);
}

// public
int CChatListBox::IGetCount(void)
{
	Assert(m_hWnd);

	int cCount = SendMessage(LB_GETCOUNT, (WPARAM)0);
	if (LB_ERR == cCount)
	{
		AssertGLE(FALSE);
		return 0;
	}
	return cCount;
}

// public
int CChatListBox::IGetSelCount(void)
{
	Assert(m_hWnd);
	
	int cCount = SendMessage(LB_GETSELCOUNT);
	if (LB_ERR == cCount)
	{
		AssertGLE(FALSE);
		return 0;
	}
	return cCount;
}

// public
BOOL CChatListBox::FGetSelection(int **pprgSel, int *pcMem)
{
	Assert(pprgSel && pcMem);

	BOOL	fRet = FALSE;
	int*	prgsel;		// buffer for LB_GETSELITEMS
	int		cSel;
	// Get # of items selected in the list..
	int icUser = IGetSelCount();	// selected user count
	if (0 == icUser)
	{
		goto LReturn;
	}
	// Allocate buffer for selection
	prgsel = new int[icUser];
	if (!prgsel)
	{
		DoOOM();
		AssertGLE(FALSE);
		goto LReturn;
	}
	// Get selection
	cSel = ::SendMessage(m_hWnd, LB_GETSELITEMS, (WPARAM)icUser, (LPARAM)prgsel);
	if (LB_ERR == cSel || cSel != icUser)
	{
		delete prgsel;
		AssertGLE(FALSE);
		goto LReturn;
	}
	
	*pprgSel = prgsel;
	*pcMem	= cSel;

	fRet = TRUE;

LReturn:
	return fRet;
}

BOOL CChatListBox::SelectItem(int index)
{
	return (LB_ERR != SendMessage(LB_SETSEL, (WPARAM)TRUE, (LPARAM)index));
}

// protected
BOOL CChatListBox::FDrawExtra(LPDRAWITEMSTRUCT lpdi, RECT *prc, CMember *pcm)
{
	Assert(lpdi);
	Assert(prc);
	// Setup for the remainder of drawing.
	// prc->top stays what it was
	prc->left		= 2;
	prc->right		= prc->left + 16;
	prc->bottom		= prc->top + 16;

	return TRUE;
}

// protected
LRESULT	CChatListBox::IFindMember(PICS_MEMBER pcm)
{
	Assert(pcm);
	Assert(m_hWnd);

	// Since the box does NOT have the LBS_HASSTRINGS flag, LB_FINDSTRING will compare
	// pcm against values stored in itemData..
	LRESULT lr = SendMessage(LB_FINDSTRINGEXACT, (WPARAM) -1, (LPARAM)pcm);

	return lr;
}

LRESULT CALLBACK ChildListBoxWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int		yPos;
	int		iItem;

	LONG lData = ::GetWindowLong(hWnd, GWL_USERDATA);
	Assert(0xffffffff != lData);
	if (0 != lData)
	{
		CChatListBox* pclb = (CChatListBox*)lData;
		switch (uMsg)
		{
		case WM_RBUTTONUP:
			pclb->LrCallWindowProc(WM_LBUTTONUP, wParam, lParam);
			break;
			
		case WM_RBUTTONDOWN:
			if (::GetAsyncKeyState(VK_CONTROL) >= 0 && ::GetAsyncKeyState(VK_SHIFT) >= 0)
			{
				// check where the click is.  if it's in a currently selected item,
				// just eat the click.
				yPos = HIWORD(lParam);
				iItem = yPos / SendMessage(hWnd, LB_GETITEMHEIGHT, 0, 0);
				iItem += SendMessage(hWnd, LB_GETTOPINDEX, 0, 0);
				if (SendMessage(hWnd, LB_GETSEL, iItem, 0))
				{
					break;
				}
			}
			pclb->LrCallWindowProc(WM_LBUTTONDOWN, wParam, lParam);
			break;
		
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			default:
				break;
			
			case IDC_SEND:
			case IDC_WHISPER:
				return pclb->FGiveMsgToParent(WM_COMMAND, wParam, 0);
			}
			break;

		case WM_KEYDOWN:
			switch(wParam)
			{
			default:
				break;

			case VK_F6:
			case VK_TAB:
				{
				int idCmd = (::GetAsyncKeyState(VK_SHIFT) & 0x8000) ? IDC_TABKEYSHIFT : IDC_TABKEY;
				return pclb->FGiveMsgToParent(WM_COMMAND, MAKEWPARAM(idCmd, 0), 0);
				}
			}
			break;

		}
		return pclb->LrCallWindowProc(uMsg, wParam, lParam);
	}
	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}
