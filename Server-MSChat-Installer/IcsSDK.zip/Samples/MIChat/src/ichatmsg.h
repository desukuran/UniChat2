/*--------------------------------------------------------------------------
	ichat.mc
        
       Common error/about strings

  --------------------------------------------------------------------------*/
//
//  Values are 32 bit values layed out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//
#define STATUS_SEVERITY_WARNING          0x2
#define STATUS_SEVERITY_SUCCESS          0x0
#define STATUS_SEVERITY_INFORMATIONAL    0x1
#define STATUS_SEVERITY_ERROR            0x3


//
// MessageId: IDS_MESSAGE
//
// MessageText:
//
//  %1%0
//
#define IDS_MESSAGE                      0x40001001L

//
// MessageId: IDS_USERNAMEEND
//
// MessageText:
//
//  :
//
#define IDS_USERNAMEEND                  0x40001002L

//
// MessageId: IDS_ADDMEMBER
//
// MessageText:
//
//  %1 has joined the conversation.%0
//
#define IDS_ADDMEMBER                    0x40001003L

//
// MessageId: IDS_DELMEMBER
//
// MessageText:
//
//  %1 has left the conversation.%0
//
#define IDS_DELMEMBER                    0x40001004L

//
// MessageId: IDS_HOSTNAME
//
// MessageText:
//
//  Host %1%0
//
#define IDS_HOSTNAME                     0x40001005L

//
// MessageId: IDS_WHISPER
//
// MessageText:
//
//   whispers %0
//
#define IDS_WHISPER                      0x40001006L

//
// MessageId: IDS_WHISPERLIST
//
// MessageText:
//
//   whispers to%0
//
#define IDS_WHISPERLIST                  0x40001007L

//
// MessageId: IDS_SPACE
//
// MessageText:
//
//   %0
//
#define IDS_SPACE                        0x40001008L

//
// MessageId: IDS_COMMA
//
// MessageText:
//
//  ,%0
//
#define IDS_COMMA                        0x40001009L

//
// MessageId: IDS_CHATROOM
//
// MessageText:
//
//  %1%0
//
#define IDS_CHATROOM                     0x4000100AL

//
// MessageId: IDS_PROMPT
//
// MessageText:
//
//  >%0
//
#define IDS_PROMPT                       0x4000100BL

//
// MessageId: IDS_USERCOUNT
//
// MessageText:
//
//  %1 Members%0
//
#define IDS_USERCOUNT                    0x4000100CL

//
// MessageId: IDS_USERCOUNTSINGLE
//
// MessageText:
//
//  %1 Member%0
//
#define IDS_USERCOUNTSINGLE              0x4000100DL

//
// MessageId: IDS_USERISSPECTATOR
//
// MessageText:
//
//  %1 is now a spectator.%0
//
#define IDS_USERISSPECTATOR              0x4000100EL

//
// MessageId: IDS_USERISHOST
//
// MessageText:
//
//  %1 is now a host.%0
//
#define IDS_USERISHOST                   0x4000100FL

//
// MessageId: IDS_USERISSPEAKER
//
// MessageText:
//
//  %1 is now a speaker.%0
//
#define IDS_USERISSPEAKER                0x40001010L

//
// MessageId: IDS_USERNEWNICK
//
// MessageText:
//
//   is now known as %1.%0
//
#define IDS_USERNEWNICK                  0x40001011L

