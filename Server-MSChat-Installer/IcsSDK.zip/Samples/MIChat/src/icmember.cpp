//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icmember.h"

// public
CMember::CMember(void)
{
	AssertSz(0, "Remove CMember!");
#ifdef NOTNOW
	m_pcFormat	= NULL;
	m_bFlags	= 0;
#endif
}

// public
CMember::~CMember(void)
{
	AssertSz(0, "Remove ~CMember!");
#ifdef NOTNOW
	DeleteCharFormat();
#endif
}

// public
BOOL CMember::FSetCharFormat(CHARFORMAT* pcf)
{
#ifdef NOTNOW
	Assert(pcf);

	if (NULL == m_pcFormat)
	{
		m_pcFormat = (CHARFORMAT*) new BYTE[sizeof(CHARFORMAT)];
	}
	if (NULL == m_pcFormat)
	{
		AssertGLE(FALSE);
		DoOOM();
		goto LError;
	}
	::CopyMemory((PVOID)m_pcFormat, (PVOID)pcf, sizeof(CHARFORMAT));

	return TRUE;

LError:
	DeleteCharFormat();

#endif
	return FALSE;		
}

// public
void CMember::SetSelected(BOOL fSelected)
{
#ifdef NOTNOW
	if (fSelected)
	{
		m_bFlags |= CLIENTPROPSELECTED;
	}
	else
	{
		m_bFlags &= ~CLIENTPROPSELECTED;
	}
#endif
}

// protected
void CMember::DeleteCharFormat(void)
{
#ifdef NOTNOW
	if (m_pcFormat)
	{
		delete [] (BYTE*)m_pcFormat;
		m_pcFormat = NULL;
	}
#endif
}

