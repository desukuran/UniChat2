//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICTOOLS__
#define __ICTOOLS__

#include "icinc.h"

class CChatToolBar:public CChatChildWnd 
{
// Interfaces
public:
	CChatToolBar(void);
	~CChatToolBar(void);

	BOOL		FCreate(HWND hWndParent, int idCtl, RECT* prc, 
						UINT cButtons, TBBUTTON* ptb, int cBitmaps, UINT idBitmap);

	BOOL		FAddButtons(TBBUTTON* ptb, int cButtons);
	BOOL		FAddStrings(int* prgId, int cId);
	BOOL		FAutoSize(void);
	BOOL		FGetItemRect(int idItem, RECT* prc);
};

class CChatStatusBar:public CChatChildWnd 
{
// Interfaces
public:
	CChatStatusBar(void);
	~CChatStatusBar(void);
	BOOL		FCreate(HWND hWndParent, int idCtl);
	BOOL		FSetStatusString(int idStr, DWORD dwPart=0);
	BOOL		FSetStatusString(TCHAR* sz, DWORD dwPart=0);
	BOOL		FSetStatusStringDef(void)	{ return FSetStatusString(IDS_F1HELP); }

	BOOL		FRestoreStatusString(void);
	BOOL		FUpdateUserCount(PICS_CHANNEL pChan);
// Data
protected:
	int			m_idStrCur;
	int			m_idStrPrev;
};

#endif
