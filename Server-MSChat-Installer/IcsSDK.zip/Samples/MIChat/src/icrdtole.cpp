//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icrdtole.h"

//--------------------------------------------------------------------------------------------
// GLOBALS and DEFINES
//--------------------------------------------------------------------------------------------
#define		verTlbMajor		1
#define		verTlbMinor		0
#define		WND_MSG			1
#define		WND_HISTORY		2

const OLECHAR	szTcTlb[] =	OLESTR("tctlb.tlb");

FORMATETC _feCfDrop = {CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};


CTCRichEditCallback::CTCRichEditCallback(LPUNKNOWN punkOuter, PFNDESTROYED pfndestroy)
{
	m_cRef			= 0;
	m_punkOuter		= punkOuter;
	m_pfndestroy	= pfndestroy;
} 

CTCRichEditCallback::~CTCRichEditCallback(void)
{
}

STDMETHODIMP CTCRichEditCallback::QueryInterface(REFIID riid, LPLPVOID ppv)
{
	*ppv = NULL;
	// The only calls for IUnknown are either in a nonaggregated
	// case or when created in an aggregation, so in either case
	// always return our IUnknown for IID_IUnknown.
	if (IsEqualIID(riid, IID_IUnknown))
	{
		*ppv = (LPVOID)this;
	}

	if (*ppv == NULL)
	{
	    return ResultFromScode(E_NOINTERFACE);
	}
	// AddRef any interface we'll return.
	((LPUNKNOWN)*ppv)->AddRef();

	return NOERROR;
}


STDMETHODIMP_(ULONG) CTCRichEditCallback::AddRef(void)
{
	return ++m_cRef;
}


STDMETHODIMP_(ULONG) CTCRichEditCallback::Release(void)
{
	if (0L != --m_cRef)
	{
		return m_cRef;
	}
	// Tell the housing that an object is going away so it can
	// shut down if appropriate.
	if (NULL != m_pfndestroy)
	{
		(*m_pfndestroy)();
	}
	delete this;
	return 0L;
}

STDMETHODIMP CTCRichEditCallback::GetNewStorage(LPSTORAGE* lplpstg)
{
	return (E_NOTIMPL);
}

STDMETHODIMP CTCRichEditCallback::GetInPlaceContext(LPOLEINPLACEFRAME* lplpFrame, 
													LPOLEINPLACEUIWINDOW* lplpDoc, 
													LPOLEINPLACEFRAMEINFO lpFrameInfo)
{
	return (E_NOTIMPL);
}

STDMETHODIMP CTCRichEditCallback::ShowContainerUI(BOOL fShow)
{
	return (E_NOTIMPL);
}

STDMETHODIMP CTCRichEditCallback::QueryInsertObject(LPCLSID lpclsid, LPSTORAGE lpstg, LONG cp)
{
	return (S_OK);
}

STDMETHODIMP CTCRichEditCallback::DeleteObject(LPOLEOBJECT lpoleobj)
{
	return (NOERROR);
}

STDMETHODIMP CTCRichEditCallback::QueryAcceptData(LPDATAOBJECT lpdataobj, 
												CLIPFORMAT*	lpcfFormat,
												DWORD		reco, 
												BOOL		fReally, 
												HGLOBAL		hMetaPict)
{
	*lpcfFormat = CF_TEXT;

	return (NOERROR);
}

STDMETHODIMP CTCRichEditCallback::ContextSensitiveHelp(BOOL fEnterMode)
{
	return (E_NOTIMPL);
}


STDMETHODIMP CTCRichEditCallback::GetDragDropEffect(BOOL fDrag, DWORD grfKeyState,
													LPDWORD pdwEffect)
{
	return (E_NOTIMPL);
}

STDMETHODIMP CTCRichEditCallback::GetContextMenu(WORD seltype, LPOLEOBJECT lpoleobj,
												CHARRANGE* lpchrg, HMENU* lphmenu)
{
#ifdef CONTEXTMENUS
	*lphmenu = ::LoadMenu(v.hInst, "MSGBUFPOPUP");
#endif
	return (E_NOTIMPL);
}
