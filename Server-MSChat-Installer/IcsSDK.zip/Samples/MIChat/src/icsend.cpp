//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icsend.h"
#include "icmain.h"

// Send Window Pane
CChatSendPane::CChatSendPane(void)
	: CChatPane()
{
	m_pszBuf = NULL;
}

CChatSendPane::~CChatSendPane(void)
{
	if (m_pszBuf)
	{
		delete [] (BYTE*)m_pszBuf;
	}
}

HWND CChatSendPane::HWndSetFocus(void)
{
	return ::SetFocus(m_uiSend.HWnd());
}

BOOL CChatSendPane::FInitElements(void)
{
	// Override with out member proc
	SetWindowProc(SendWndProc);
	// allocate send buffer
	m_pszBuf = (TCHAR*)new BYTE[CS_CCBMAX_MIC_MSG];
	if (!m_pszBuf)
	{
		DoOOM();
		AssertGLE(FALSE);
		return FALSE;
	}
	// First create the button pane. This will effect the positioning of everything else.
	if (!m_cbp.FCreate(m_hWnd, ID_SENDSUBPANE, NULL, FALSE))
	{
		return FALSE;
	}
	m_cbp.SetParentPane(this);

	RECT	rc;
	// Figure out how big the pane is and align all other controls accordingly.
	if (!m_cbp.FGetWindowRect(&rc))	 // get the btn pane's size
	{
		return FALSE;
	}
	int dx = rc.right - rc.left;
	if (!FGetClientRect(&rc))		// get our own rect
	{
		return FALSE;
	}
	// Reposition Btn Pane to be at the Right side of this pane.
	rc.left = rc.right - dx;
	if (!m_cbp.FMoveWindow(&rc))
	{
		return FALSE;
	}
	// Init rich edit,  positioning it to be to the left of the button pane
	rc.right	= rc.left;
	rc.left		= 0;
	if (!m_uiSend.FCreate(m_hWnd, ID_SENDBUFFER, &rc, FALSE, TRUE))
	{
		return FALSE;
	}
	// Make sure this is editable
	m_uiSend.SetReadOnly(FALSE);
	// And set the max # of chars that can be enterd at a time
	m_uiSend.SetTextLimit(CBMAXSEND);
	// And accept files
	m_uiSend.DragAcceptFiles(TRUE);
	// If this is NOT a MIC Socket,  disable Whisper button
	if (!FIsMicSocket())
	{
		m_cbp.FEnableWhisperButton(FALSE);
	}
	return TRUE;
}

TCHAR* CChatSendPane::PszSendText(void)
{
	Assert(m_pszBuf);

	if (m_uiSend.FGetAllText(m_pszBuf, CS_CCBMAX_MIC_MSG/sizeof(TCHAR)))
	{
		m_uiSend.Clear();
		return m_pszBuf;
	}
	return NULL;
}

BOOL CChatSendPane::FHandleWMSize(WPARAM wParam, LPARAM lParam)
{		
	// The mother pane got moved. Now we gotta move the babies
	RECT	rc;
	rc.top		= 0;
	rc.bottom	= HIWORD(lParam);
	// Reposition the button bar
	int dx		= m_cbp.LGetWidth();
	rc.left		= (LOWORD(lParam)) - dx;
	rc.right	= rc.left + dx;
	if (!m_cbp.FMoveWindow(&rc))
	{
		return FALSE;
	}
	// Have to reposition the send msg richedit control
	rc.right	= rc.left;
	rc.left		= 0;
	if (!m_uiSend.FMoveWindow(&rc))
	{
		return FALSE;
	}
	return FRedrawWindow();
}

BOOL CChatSendPane::FMemberModeChange(PICS_CHANNEL pChannel, PICS_MEMBER pMember)
{
	Assert(pChannel && pMember);
	// If the member being update is US..
	// and it turns out that we are no longer speakers.. we need to disable send/whisper buttons
	PICS_MEMBER pMemberUs;

	if (SUCCEEDED(pChannel->HrGetMe(&pMemberUs)))
	{
		if (pMember == pMemberUs)
		{
			BOOL fNotSpectator;
			// If the channel is now NOWHISPER,  disable whisper buttons
			DWORD dwMode;

			if (FAILED(pChannel->HrGetType(&dwMode)))
			{
				return FALSE;
			}	
			fNotSpectator = (NOERROR != pMemberUs->HrIsMemberSpectator());
			m_cbp.FEnableSendButton(fNotSpectator);
			// Enable whisper only if NOT a spectator AND this is NOT a no whisper channel
			m_cbp.FEnableWhisperButton(fNotSpectator && (0 == (dwMode & CS_CHANNEL_NOWHISPER)));
		}
		pMemberUs->Release();
	}
	return TRUE;
}

BOOL CChatSendPane::FChannelModeChange(PICS_CHANNEL pChannel)
{
	// If the channel is now NOWHISPER,  disable whisper buttons
	DWORD dwMode;

	if (FAILED(pChannel->HrGetType(&dwMode)))
	{
		return FALSE;
	}
	return m_cbp.FEnableWhisperButton(0 == (dwMode & CS_CHANNEL_NOWHISPER));
}

/////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK SendWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CChatSendPane* pcsp = (CChatSendPane*)::GetWindowLong(hWnd, GWL_USERDATA);
	
	if (pcsp)
	{
		switch(uMsg)
		{
		default:
			break;

		case WM_NOTIFY:
			{
			NMHDR* pnhmdr = (NMHDR*)lParam;
			switch (pnhmdr->code)
			{
			default:
				return FALSE;
			
			case EN_DROPFILES:
				if (pcsp->m_uiSend.FDragDrop((ENDROPFILES*)lParam))
				{
					//::PostMessage(hWnd, WM_COMMAND, MAKEWPARAM(IDC_SEND, 0), 0);
				}
				// We don't really want the drop.. just to get the file names, 
				// and extract the URLs..
				::SetWindowLong(hWnd, DWL_MSGRESULT, FALSE);
				return TRUE;
			}
			}
			break;
		
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			default:
				break;

			case IDC_SEND:
			case IDC_WHISPER:
			case IDC_TABKEY:
			case IDC_TABKEYSHIFT:
				Assert(pcsp);
				return pcsp->FGiveMsgToParent(uMsg, wParam, lParam);		
			}
		}
		return pcsp->LrCallWindowProc(uMsg, wParam, lParam);
	}
	return (::DefWindowProc(hWnd, uMsg, wParam, lParam));
}
