//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icmain.h"
#include "iclogin.h"
#include "icwizard.h"
#include "icinc.h"

const UINT		IDTIMERCANCEL		= 4120;
const TCHAR*	SZMICSERVERSKEY		= "Servers";
const TCHAR*	SZMICLASTSERVER		= "Last Server";
const TCHAR*	REG_SZLASTNICK		= "Nick";
const TCHAR*	REG_SZUSERNAME		= "User";
const TCHAR*	REG_SZBACKNICK		= "NickBack";
const TCHAR*	REG_SZLOGINANON		= "Anon";
const TCHAR*	REG_SZSECURITY		= "Security";		// primary security model
const TCHAR*	REG_SZSECURITYBAK	= "SecurityBak";	// backup security model

////////////////////////////////////////////////////////////////////////////
static BOOL FGetPcc(HWND hDlg, UINT uMsg, LPARAM lParam, CChatConnect** ppcl);

BOOL CALLBACK ConnectServerDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ConnectCancelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

BOOL CALLBACK LoginUserPassDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

DWORD __stdcall DwConnectThreadProc(PVOID pvData);
DWORD __stdcall DwLoginThreadProc(PVOID pvData);

//
// New login functions
DWORD __stdcall DwConnectProc(PVOID pvData);
BOOL CALLBACK DwCancelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

static BOOL FGetPcs(HWND hDlg, UINT uMsg, LPARAM lParam, CConSettings **ppcs);

BOOL CALLBACK ServerDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK NickDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OptionsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

///////////////////////////////////////////////////////////////////////////////////////
// Keep le time
CKeepTime::CKeepTime(void)
{
	m_uiTime	= 0;
	m_uiTimer	= 0;
	m_uiElapse	= 0;
}

CKeepTime::~CKeepTime(void)
{
}

BOOL CKeepTime::FSetTimer(HWND hWnd, UINT uiId, UINT uiElapse)
{
	Assert(hWnd);

	m_uiTime	= 0;
	m_uiElapse	= uiElapse;

	// Set Timer for every second
	m_uiTimer = ::SetTimer(hWnd, uiId, m_uiElapse * 1000, NULL);
	if (0 == m_uiTimer)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

void CKeepTime::KillTimer(HWND hWnd)
{
	Assert(hWnd);

	if (m_uiTimer)
	{
		::KillTimer(hWnd, m_uiTimer);
		m_uiTimer = 0;
	}
}

void CKeepTime::UpTimer(void)
{
	m_uiTime += m_uiElapse;
}

///////////////////////////////////////////////////////////////////////////////////////
// Display le time
CShowTime::CShowTime(void)
	: CKeepTime()
{
	m_szSeconds[0]	= '\0';
	m_szTimer[0]	= '\0';
}

CShowTime::~CShowTime(void)
{
}

BOOL CShowTime::FInit(HINSTANCE hInst)
{
	if (!::lstrcpy(m_szSeconds, GetSz(hInst, IDS_SECONDS)))
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	return TRUE;
}

BOOL CShowTime::FDisplayTime(HWND hWndParent, int idLbl)
{
	::wsprintf(m_szTimer, "%d %s", m_uiTime, m_szSeconds);

	return ::SetWindowText(HWndGetDlgItem(hWndParent, idLbl), m_szTimer);
}

///////////////////////////////////////////////////////////////////////////////////////
CLogin::CLogin(void)
{
	m_szServer[0]	= '\0';
	m_picsFactry	= NULL;
	m_pics			= NULL;
	m_hr			= NOERROR;
	m_hDlg			= NULL;
	m_hWndParent	= NULL;
	m_fStop			= FALSE;
	m_szNick[0]		= '\0';
	m_szNickBack[0] = '\0';
	m_szUserName[0] = '\0';
	m_szSecurity[0]	= '\0';
	m_fAnon			= FALSE;
	m_picConn		= NULL;
	m_fSettings		= FALSE;
	m_fAuto			= FALSE;
	m_uFirstPage	= 0;
}

CLogin::~CLogin(void)
{
	CleanUp(FALSE);
	if (m_picConn)
	{
		m_picConn->Release();
	}
}

// Initialize.. if any registry information is missing, bail out immediately,
// so caller can launch a Connection settings dialog or something
int CLogin::FInit(HWND hWndParent, CHAR* szServer)
{
	Assert(hWndParent);
	// Make sure everything is hunky dory first..
	CleanUp();
	
	Assert(!(m_picsFactry && m_pics));

	m_hWndParent = hWndParent;
	m_fStop = FALSE;
	m_hr = NOERROR;
	m_uFirstPage = 0;
	// If a server name is provided, connect to that,
	// else use the "last" used server from the registry
	if (szServer)
	{
		if (!::lstrcpy(m_szServer, szServer))
		{
			return FALSE;
		}
		m_fAuto	= TRUE;
	}
	else // load server name from registry
	{
		if (!::FGetRegistrySz(HKEY_CURRENT_USER, SZMICLASTSERVER, m_szServer, MAX_PATH))
		{
			return FALSE;	// Nothing in registry!
		}
		m_fAuto = FALSE;
	}
	// grab the Nick from the registry. If it ain't there, bail
	if (!::FGetRegistrySz(HKEY_CURRENT_USER, REG_SZLASTNICK, m_szNick, CS_CCHMAX_MIC_NICK + 1))
	{
		return FALSE; // ain't be there nothing in the registry
	}
	// grab the backup nick, if any..
	if (!::FGetRegistrySz(HKEY_CURRENT_USER, REG_SZBACKNICK, m_szNickBack, CS_CCHMAX_MIC_NICK + 1))
	{
		m_szNickBack[0] = '\0';
	}
	// Fill user name from Registry
	if (!::FGetRegistrySz(HKEY_CURRENT_USER, REG_SZUSERNAME, m_szUserName, CS_CCHMAX_MIC_USERNAME + 1))
	{
		m_szUserName[0] = '\0';
	}

	if (!FGetRegistryBool(HKEY_CURRENT_USER, REG_SZLOGINANON, &m_fAnon))	// anonymous or authenticated login
	{
		m_fAnon = TRUE;	// no settings. assume anonymous
	}
	// Create the Socket Factory
	m_hr = ::HrCreateChatSocketFactory(IID_CHATSOCKVER1, &m_picsFactry);
	if (FAILED(m_hr))
	{
		FDoAlert(HWndFore(), IDS_ERR_GENERIC, ALERT_ERROR);
		return -1;
	}
	return TRUE;
}

// called by CIChatMain::FInit
BOOL CLogin::FConnect(HWND hWndParent, CHAR *szServer)
{
	BOOL	fRet = FALSE;
	int		iRet = FInit(hWndParent, szServer);
	if (-1 == iRet)
	{
		return FALSE;
	}
	else if (0 == iRet)
	{
		m_fSettings = TRUE;
	}
	// do the dialog
	fRet = FCancelDialog();
	WaitForConnectThread();
	
	return fRet;
}

BOOL CLogin::FStartConnect(HWND hDlg)
{
	// Disable connection and settings buttons
	::EnableWindow(HWndGetDlgItem(hDlg, IDC_CONNECT), FALSE);
	::EnableWindow(HWndGetDlgItem(hDlg, IDC_SETTINGS), FALSE);
	// Update status
	::SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLACTION), GetSz(HInstance(m_hWndParent), IDS_LBL_CONNECT));
	// Launch a thread that will permit us to connect
	m_picsFactry->AddRef();
	if (!m_csConnect.FCreateThread(DwConnectProc, this))
	{
		Assert(FALSE);
		m_picsFactry->Release();
		return FALSE;
	}
	// Start timer
	if (!m_st.FSetTimer(hDlg, IDTIMERCANCEL, 1))
	{
		return FALSE;
	}
	return TRUE;	
}

BOOL CLogin::FDoSettings(void)
{
	m_st.KillTimer(m_hDlg);
	::PostMessage(m_hDlg, WM_COMMAND, MAKEWPARAM(IDC_SETTINGS, 0), 0);
	
	return TRUE;
}

BOOL CLogin::FConnectionSettings(HWND hDlg, UINT uFirstPage)
{
	// Make sure it is enabled
	::EnableWindow(HWndGetDlgItem(hDlg, IDC_SETTINGS), TRUE);
	if (!m_picConn)
	{
		m_picConn = new CConSettings;
		if (!m_picConn)
		{
			AssertGLE(FALSE);
			DoOOM();
			return FALSE;
		}
	}
	// Put up a dialog for users to specify their server preferences
	int	iRet;
	BOOL fRet = m_picConn->FSettingsDlg(hDlg, m_szServer, uFirstPage);
	m_uFirstPage = 0;
	if (fRet)
	{
		m_fSettings = FALSE;
		// Reinit our params to pick up on any changes
		iRet = FInit(m_hWndParent, NULL);
		if (TRUE == iRet)
		{
			fRet = FInitDlg(hDlg, FALSE);
		}
		else 
		{
			::PostMessage(hDlg, WM_COMMAND, MAKEWPARAM(IDCANCEL, 0), 0);
		}
	}
	else
	{
		if (m_fSettings)
		{
			// We had to have settings..
			::PostMessage(hDlg, WM_COMMAND, MAKEWPARAM(IDCANCEL, 0), 0);
		}
	}

	return TRUE;
}

void CLogin::CleanUp(BOOL fClose)
{
	WaitForConnectThread();
	if (m_picsFactry)
	{
		m_picsFactry->Release();
		m_picsFactry = NULL;
	}

	if (m_pics)
	{
		if (fClose)
		{
			m_pics->HrLogOff();
			m_pics->HrCloseSocket();
		}
		m_pics->Release();
		m_pics = NULL;
	}
}

BOOL CLogin::FVerifyLoginParams(void)
{
	BOOL fMic = (NOERROR == m_pics->HrIsMicSocket());
	// Check Nick Name
	int cch		= lstrlen(m_szNick);
	int cchBak	= lstrlen(m_szNickBack);
	if (!fMic)
	{
		CHAR* szNick = NULL;
		if (cch > CS_CCHMAX_IRC_NICK )
		{
			szNick = m_szNick;
		}
		else if (cchBak > CS_CCHMAX_IRC_NICK)
		{
			szNick = m_szNickBack;
		}
		else
		{
			return TRUE;
		}
		
		FDoPrintFAlert(m_hDlg, IDS_ERR_NICKTOOLONG, szNick, ALERT_ERROR);
		return FALSE;
	}
	return TRUE;
}

HRESULT CLogin::HrLogin(void)
{
	Assert(m_pics);
	// Log us in baby
	CS_CONNINFO	csInfo;		
	TCHAR		szPass[1];
	BOOL		fDoneBack = FALSE;
	BOOL		fStop;

	TCHAR* szNick = m_szNick;
	// Set the action label
	::SetWindowText(HWndGetDlgItem(m_hDlg, IDC_LBLACTION), GetSz(HInstance(m_hWndParent), IDS_LBL_LOGINNICK));
	// Verify settings
	if (!FVerifyLoginParams())
	{
		m_hr = E_INVALIDARG;
		m_uFirstPage = 1;
		goto LReturn;
	}
LLogin:
	fStop = TRUE;
	if ('\0' == szNick[0])
	{
		goto LReturn;
	}
	// Build login structs
	::ZeroMemory(&csInfo, sizeof(CS_CONNINFO));
	szPass[0] = '\0';
	if (m_fAnon)
	{
		// User wants anonymous login. Does this server allow that?
		if (!FCanAnonymous())
		{
			if (IDNO == ::FDoAlert(m_hDlg, IDS_ERR_NOANONASK, ALERT_YESNO))
			{
				m_hr = E_FAIL;
				goto LReturn;
			}
			else
			{
				m_fAnon = FALSE;
			}
		}
	}
	if (!m_fAnon)
	{
		// User wants authenticated login. Can we do that?
		int iRet = FCanAuthenticate();
		if (FALSE == iRet)	// can't authenticate
		{
			if (IDNO == FDoAlert(m_hDlg, IDS_ERR_NOAUTHASK, ALERT_YESNO))
			{
				m_hr = CS_E_AUTHNOTAVAIL;
				goto LReturn;
			}
			else
			{
				m_fAnon = TRUE;
			}
		}
	}
	csInfo.dwcb		= sizeof(CS_CONNINFO);
	csInfo.bType	= m_fAnon ? CS_CONNECT_ANONYMOUS : CS_CONNECT_AUTHENTICATE;
	csInfo.pvUser	= m_szUserName;
	csInfo.pvPass	= NULL;		// force a popup of a login dialog to authenticate
	csInfo.pvNick	= szNick;
	if (!m_fAnon)
	{
		csInfo.szSecurityPackage = m_szSecurity;
	}
	// Login. NOTE: the socket DLL will return a success or failure ASYNC
LRetry:
	m_hr = m_pics->HrLoginA(&csInfo);
	if (FAILED(m_hr))
	{
		switch (m_hr)
		{
		default:
			FHandleChatSockErrors(m_hDlg, m_hr, TRUE);
			m_uFirstPage = 1;
			break;

		case CS_E_SZTOOLONG:
		case E_INVALIDARG:
		case CS_E_NOTMIC:
			FDoAlert(m_hDlg, IDS_ERR_CONNSETTINGS, ALERT_ERROR);
			m_uFirstPage = 1;
			break;
		
		case CS_E_AUTHNOTAVAIL:
			m_uFirstPage = 2;
			FHandleChatSockErrors(m_hDlg, m_hr, TRUE);
			break;

		}		
		goto LReturn;
	}
	// Now check the Wait Q for acknowledgement
	PCS_MSGBASE pcsMsg;

	m_hr = m_pics->HrWaitForMsg(&pcsMsg, INFINITE);
	if (FAILED(m_hr))
	{
		FHandleChatSockErrors(m_hDlg, m_hr, TRUE);
		goto LReturn;
	}
	DebugMessageType("CIChat::DwMessageThread", pcsMsg->csMsgType);
	// Did we log in or get an error?
	switch (pcsMsg->csMsgType)
	{
	default:
		Assert(FALSE);
		break;

	case CSMSG_TYPE_ERROR:
		PCS_ERROR	pErr;

		pErr = (PCS_ERROR) (pcsMsg + 1);
		m_hr = pErr->hr;
		if (m_hr == CS_E_ILLEGALUSER)
		{
			FHandleChatSockErrors(m_hDlg, m_hr, TRUE);
			goto LRetry;
		}
		// if fatal error, or we've already tried the backup nick, then bail
		if (!FCheckError() || fDoneBack || '\0' == m_szNickBack[0])
		{
			if (fDoneBack || '\0' == m_szNickBack[0])
			{
				m_uFirstPage = 1;
			}
			m_pics->HrCloseSocket();
			FHandleChatSockErrors(m_hDlg, m_hr, TRUE);
			break;
		}
		// Try again
		fDoneBack = TRUE;
		szNick = m_szNickBack;
		SetWindowText(HWndGetDlgItem(m_hDlg, IDC_LBLACTION), GetSz(HInstance(m_hWndParent), IDS_LBL_NICKBAK));
		fStop = FALSE;
		break;

	case CSMSG_TYPE_LOGIN:
		m_hr = NOERROR;
		break;
	}
   
	::HrFreeMsg(pcsMsg);
	if (!fStop)
	{
		goto LLogin;
	}

LReturn:
	if (NOERROR != m_hr)
	{
		FDoSettings();
	}
	else
	{
		FStopDlg(FALSE);
	}
	return m_hr;
}

// Is desired authentication available on this server?
int CLogin::FCanAuthenticate(void)
{
	// Grab security details
	PCS_SECURITY	pcsSecurity;
	m_hr = m_pics->HrGetSecurityInfo(&pcsSecurity);
	if (FAILED(m_hr))
	{
		return FALSE;
	}
	// Does this server do authentication?
	if (pcsSecurity->cPackages <= 0)
	{
		return FALSE;
	}
	// Find a security package match. As a last resort, try NTLM
	// If nothing is available, alert the user
	BOOL	fDoneBak = FALSE;
	CHAR*	szPackage;
	TCHAR*	szRegistry;
	DWORD	dwcb, cb;

	szRegistry = (TCHAR*)&REG_SZSECURITY[0];
	m_szSecurity[0] = '\0';

LSearch:
	// Load Registry Key
	if (::FGetRegistrySz(HKEY_CURRENT_USER, szRegistry, m_szSecurity, 256))
	{
		szPackage = (CHAR*)(pcsSecurity + 1);
		dwcb = pcsSecurity->dwcb - sizeof(CS_SECURITY);
		while (dwcb > 0)
		{
			if (0 == ::lstrcmpi(szPackage, m_szSecurity))
			{
				// Got a match
				return TRUE;
			}
			cb = ::lstrlen(szPackage) + 1;
			dwcb -= cb;
			szPackage += cb;
		}
	}

	m_szSecurity[0] = '\0';
	if (fDoneBak)
	{
		szPackage = (CHAR*)(pcsSecurity + 1);
		::lstrcpy(&m_szSecurity[0], szPackage);		// try first security package
	}
	else
	{
		szRegistry = (TCHAR *) &REG_SZSECURITYBAK[0];
		fDoneBak = TRUE;
		goto LSearch;
	}
	return TRUE;
}

// Does this server support anonymous logins?
BOOL CLogin::FCanAnonymous(void)
{
	// Grab security details
	PCS_SECURITY	pcsSecurity;
	m_hr = m_pics->HrGetSecurityInfo(&pcsSecurity);
	if (FAILED(m_hr))
	{
		return TRUE;	//assume anon
	}
	return pcsSecurity->fAnonAllowed;
}

BOOL CLogin::FCheckError(void)
{
	switch(m_hr)
	{
	default:
		return FALSE;	// abort
	
	case CS_E_ALIASINUSE:
		break;
	}
	
	return TRUE;	// ok to retry
}

HRESULT CLogin::HrDoConnect(void)
{
	Assert(m_picsFactry);

	m_hr = m_picsFactry->HrMakeSocket(m_szServer, &m_pics);
	m_picsFactry->Release();
	
	if (FAILED(m_hr))
	{
		FHandleChatSockErrors(m_hDlg, m_hr, TRUE);
		FDoSettings();
	}
	else
	{
		if (SUCCEEDED(m_hr))
		{
			HrLogin();		// log us IN...
		}
	}		
	return m_hr;
}

BOOL CLogin::FCancelDialog(void)
{
	return (IDOK == ::DialogBoxParam(HInstance(m_hWndParent), MAKEINTRESOURCE(IDD_CANCELDLG), 
									m_hWndParent, DwCancelDlgProc, (LPARAM)this));
}

BOOL CLogin::FStopDlg(BOOL fCancel)
{
	m_cs.Lock();
	
	if (m_hDlg)
	{
		::PostMessage(m_hDlg, WM_COMMAND, MAKEWPARAM(fCancel ? IDCANCEL : IDOK, 0), 0);
	}
	m_fStop = TRUE;
	m_cs.Unlock();

	return TRUE;
}

BOOL CLogin::FStop(void)
{
	m_cs.Lock();
	BOOL fRet = m_fStop;
	m_cs.Unlock();

	return fRet;
}

BOOL CLogin::FCancel(void)
{
	if (m_picsFactry)
	{
		// Stop it ONLY if we are connecting.
		return SUCCEEDED(m_picsFactry->HrCancelMakeSocket());
	}
	return FALSE;
}

BOOL CLogin::FInitDlg(HWND hDlg, BOOL fAll)
{
	if (fAll)
	{
		m_cs.Lock();
		m_hDlg = hDlg;
		m_cs.Unlock();

		if (FStop())
		{
			return FALSE;
		}

		FCenterWindow(hDlg);
	}
	// Set labels
	if (m_fSettings)
	{
		::PostMessage(hDlg, WM_COMMAND, MAKEWPARAM(IDC_SETTINGS, 0), 0);
		return TRUE;
	}

	::EnableWindow(HWndGetDlgItem(hDlg, IDC_CONNECT), TRUE);
	::SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLSERVERNAME), m_szServer);
	::SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLNICK), m_szNick);
	::SetWindowText(HWndGetDlgItem(hDlg, IDC_LBLNICKBAK), m_szNickBack);
	if (fAll)
	{
		// Set up the timer
		if (!m_st.FInit(HInstance(hDlg)))
		{
			return FALSE;
		}
		if (m_fAuto)
		{
			// Always auto login
			::PostMessage(hDlg, WM_COMMAND, MAKEWPARAM(IDC_CONNECT, 0), 0);
		}
	}	
	return TRUE;
}

BOOL CLogin::FEndDialog(int iRes)
{
	::EndDialog(m_hDlg, iRes);

	return TRUE;
}

void CLogin::WaitForConnectThread(void)
{
	// And wait for the thread
	m_csConnect.DwWaitForThread(INFINITE);
	// Close Handle
	m_csConnect.CloseHandle();
}

/////////////////////////////////////////////////////////////////////////////////////////////
DWORD __stdcall DwConnectProc(PVOID pvData)
{
	Assert(pvData);

	CLogin* pcl = (CLogin*)pvData;

	return (DWORD)pcl->HrDoConnect();
}

/////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK DwCancelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CLogin* pcl = (CLogin*)::GetWindowLong(hDlg, DWL_USER);
	switch (uMsg)
	{
	default:
		break;
	
	case WM_INITDIALOG:
		SetWindowLong(hDlg, DWL_USER, lParam);
		pcl = (CLogin*)lParam;
		Assert(pcl);
		if (!pcl->FInitDlg(hDlg))
		{
			pcl->FEndDialog(IDCANCEL);
		}
		break;
			
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case IDCANCEL:
			pcl->FCancel();
		case IDOK:
			pcl->m_st.KillTimer(hDlg);
			pcl->FEndDialog(LOWORD(wParam));
			return TRUE;

		case IDC_CONNECT:
			pcl->FStartConnect(hDlg);
			break;

		case IDC_SETTINGS:
			pcl->FConnectionSettings(hDlg, pcl->m_uFirstPage);
			break;
		}
		break;
	
	case WM_TIMER:
		pcl->m_st.UpTimer();
		pcl->m_st.FDisplayTime(hDlg, IDC_LBLSECS);
		break;
	}

	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////////////////////
// CConnSettings
CConSettings::CConSettings(void)
{
	m_szServer[0]	= '\0';
	m_szNick[0]		= '\0';
	m_szNickBack[0] = '\0';
	m_szUserName[0] = '\0';
	//m_szPass[0]		= '\0';
}

CConSettings::~CConSettings(void)
{
}

BOOL CConSettings::FInitServer(CHAR* szServer)
{
	Assert(szServer);
	
	::lstrcpy(m_szServer, szServer);

	return TRUE;
}

BOOL CConSettings::FSettingsDlg(HWND hWndParent, CHAR* szServer, UINT uFirstPage)
{
	Assert(hWndParent);
	
	Reset();

	::FGetRegistrySz(HKEY_CURRENT_USER, REG_SZLASTNICK, m_szNick, CS_CCHMAX_MIC_NICK + 1);
	// Init the Wizard. 3 Pages
	if (!FInit(hWndParent, 3, PSH_NOAPPLYNOW, IDS_CONSETTINGS, uFirstPage))
	{
		return FALSE;
	}
	// Add Wizard pages
	if (!FAddPage(IDD_SERVER, ServerDlgProc, (LPARAM)this))
	{
		return FALSE;
	}
	if (!FAddPage(IDD_LOGINGIN, NickDlgProc, (LPARAM)this))
	{
		return FALSE;
	}	
	if (!FAddPage(IDD_LOGINOPTIONS, OptionsDlgProc, (LPARAM)this))
	{
		return FALSE;
	}	
	if (szServer)
	{
		::lstrcpy(m_szServer, szServer);
	}
	return FShow();
}

BOOL CConSettings::FInitServerDlg(HWND hDlg)
{
	HKEY	hkey;
	int		iVal;
	DWORD	cchValue;
	char	szValue[MAX_PATH];
	DWORD	dwType;
		
	Assert(hDlg);
	// Limit text and so forth
	::SendDlgItemMessage(hDlg, IDC_CBSERVER, CB_LIMITTEXT, (WPARAM)MAX_PATH, 0);
	// Populate with server names
	if (::FOpenMicRegKey(HKEY_CURRENT_USER, (char*)SZMICSERVERSKEY, KEY_READ, &hkey))
	{
		iVal = 0;
		cchValue = MAX_PATH;
		// Read in each server name one by one from the registry
		while (ERROR_NO_MORE_ITEMS != ::RegEnumValue(hkey, iVal++, szValue, &cchValue, NULL, &dwType, NULL, NULL))
		{
			if (CB_ERR == ::SendDlgItemMessage(hDlg, IDC_CBSERVER, CB_ADDSTRING, 0, (WPARAM)szValue))
			{
				AssertGLE(FALSE);
			}
			cchValue = MAX_PATH;
		}
		::RegCloseKey(hkey);
		if (::FGetRegistrySz(HKEY_CURRENT_USER, SZMICLASTSERVER, szValue, MAX_PATH))
		{
			iVal = ::SendDlgItemMessage(hDlg, IDC_CBSERVER, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM)szValue);
			if (iVal != CB_ERR)
			{
				::SendDlgItemMessage(hDlg, IDC_CBSERVER, CB_SETCURSEL, iVal, 0);
			}
		}
	}
	// If the server name was prepopulated, stick that in there too.. unless its already in there..
	if ('\0' != m_szServer[0])
	{
		iVal = ::SendDlgItemMessage(hDlg, IDC_CBSERVER, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM)m_szServer);
		if (CB_ERR == iVal)
		{
			iVal = ::SendDlgItemMessage(hDlg, IDC_CBSERVER, CB_ADDSTRING, 0, (WPARAM)m_szServer);
			if (iVal != CB_ERR)
			{
				::SendDlgItemMessage(hDlg, IDC_CBSERVER, CB_SETCURSEL, iVal, 0);
			}
			else
			{
				AssertGLE(FALSE);
			}
		}
	}
	return TRUE;
}

BOOL CConSettings::FInitNickDlg(HWND hDlg)
{
	// Set up user name and password
	if (!::FEditBoxLimitText(hDlg, IDC_EDITNICKBAK, CS_CCHMAX_MIC_USERNAME) ||
		!::FEditBoxLimitText(hDlg, IDC_EDITNICK, CS_CCHMAX_MIC_NICK))
	{
		return FALSE;
	}
	// Fill in names from the Registry
	if (::FGetRegistrySz(HKEY_CURRENT_USER, REG_SZLASTNICK, m_szNick, CS_CCHMAX_MIC_NICK + 1))
	{
		::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITNICK), m_szNick);
	}
	if (::FGetRegistrySz(HKEY_CURRENT_USER, REG_SZBACKNICK, m_szNickBack, CS_CCHMAX_MIC_NICK + 1))
	{
		::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITNICKBAK), m_szNickBack);
	}	
	return TRUE;
}

BOOL CConSettings::FInitOptionsDlg(HWND hDlg)
{
	BOOL fSet = FALSE;

	FEditBoxLimitText(hDlg, IDC_EDITUSERNAME, CS_CCHMAX_MIC_USERNAME);
	::FGetRegistrySz(HKEY_CURRENT_USER, REG_SZUSERNAME, m_szUserName, CS_CCHMAX_MIC_USERNAME + 1);
	::SetWindowText(HWndGetDlgItem(hDlg, IDC_EDITUSERNAME), m_szUserName);

	if (FGetRegistryBool(HKEY_CURRENT_USER, REG_SZLOGINANON, &fSet) && fSet)
	{
		CheckDlgButton(hDlg, IDC_CHECKANON, fSet);
	}
	return TRUE;
}

BOOL CConSettings::FGetServerParams(HWND hDlg)
{
	// get server name.
	if (!FGetText(hDlg, IDC_CBSERVER, IDS_ERR_NOSERVERNAME, (TCHAR *)m_szServer, MAX_PATH))
	{
		goto LError;
	}
	// make sure the chosen server is listed in the registry.
	// on failure, return TRUE because we should continue the connection attempt.
	::FCreateAndSetRegistry(HKEY_CURRENT_USER, (char *)SZMICSERVERSKEY, REG_SZ, m_szServer, ::lstrlen(m_szServer) + 1);	
	::SetRegistryRaw(HKEY_CURRENT_USER, SZMICLASTSERVER, REG_SZ, m_szServer, ::lstrlen(m_szServer) + 1);	

	return TRUE;

LError:
	::SetWindowLong(hDlg, DWL_MSGRESULT, -1);
	
	return FALSE;
}

BOOL CConSettings::FVerifyNick(HWND hDlg)
{
	// verify it
	if (FAILED(HrVerifyNickA(m_szNick)))
	{
		FDoAlert(hDlg, IDS_ERR_ILLEGALNAME, ALERT_ERROR);
		SendSetFocus(hDlg, IDC_EDITNICK);
		goto LError;
	}
	// if backup nick provided, verify that too
	if ('\0' != m_szNickBack[0] && FAILED(HrVerifyNickA(m_szNickBack)))
	{
		FDoAlert(hDlg, IDS_ERR_ILLEGALNAME, ALERT_ERROR);
		SendSetFocus(hDlg, IDC_EDITNICKBAK);
		goto LError;
	}
	// Also save the user name and nick
	::SetRegistryRaw(HKEY_CURRENT_USER, REG_SZLASTNICK, REG_SZ, m_szNick, ::lstrlen(m_szNick) + 1);
	::SetRegistryRaw(HKEY_CURRENT_USER, REG_SZBACKNICK, REG_SZ, m_szNickBack, ::lstrlen(m_szNickBack) + 1);
	
	return TRUE;

LError:
	return FALSE;
}

BOOL CConSettings::FGetNickParams(HWND hDlg)
{
	// Get the Nick
	if (!FGetText(hDlg, IDC_EDITNICK, IDS_ERR_NONICK, (TCHAR*)&m_szNick, CS_CCHMAX_MIC_NICK + 1))
	{
		goto LError;
	}
	FGetText(hDlg, IDC_EDITNICKBAK, -1, (TCHAR *) &m_szNickBack, CS_CCHMAX_MIC_NICK + 1);
	// verify it
	if (!FVerifyNick(hDlg))
	{
		goto LError;
	}
	return TRUE;

LError:
	::SetWindowLong(m_hDlg, DWL_MSGRESULT, -1);
	
	return FALSE;
}

BOOL CConSettings::FGetOptionsParams(HWND hDlg)
{
	// Get the user name 
	FGetText(hDlg, IDC_EDITUSERNAME, -1, (TCHAR *)&m_szUserName, CS_CCHMAX_MIC_USERNAME + 1);
	::SetRegistryRaw(HKEY_CURRENT_USER, REG_SZUSERNAME, REG_SZ, m_szUserName, lstrlen(m_szUserName) + 1);
	
	FRegistryBoolSet(HKEY_CURRENT_USER, REG_SZLOGINANON, ::IsDlgButtonChecked(hDlg, IDC_CHECKANON));
	return TRUE;
}

BOOL CConSettings::FNotifyServer(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;
	
	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, !FGetServerParams(hDlg));
		break;

	case PSN_APPLY:
//		::SetWindowLong(hDlg, DWL_MSGRESULT,
//						FGetServerParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		// make sure that Nicks are OK
		if (!*m_szNick)
		{
			FSelectPage(hDlg, 1);
			::SetWindowLong(hDlg, DWL_MSGRESULT, PSNRET_INVALID_NOCHANGEPAGE);
		}
		break;
	}

	return fRet;
}

BOOL CConSettings::FNotifyNick(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;

	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, !FGetNickParams(hDlg));
		break;

	case PSN_APPLY:
//		::SetWindowLong(hDlg, DWL_MSGRESULT, 
//						FGetNickParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		break;
	}
	return fRet;
}

BOOL CConSettings::FNotifyOptions(HWND hDlg, LPARAM lParam)
{
	BOOL	fRet = TRUE;

	NMHDR* pnhmdr = (NMHDR*)lParam;
	switch (pnhmdr->code)
	{
	default:
		return FALSE;

	case PSN_KILLACTIVE:
		::SetWindowLong(hDlg, DWL_MSGRESULT, !FGetOptionsParams(hDlg));
		break;

	case PSN_APPLY:
		::SetWindowLong(hDlg, DWL_MSGRESULT,
						FGetOptionsParams(hDlg) ? PSNRET_NOERROR : PSNRET_INVALID_NOCHANGEPAGE);
		break;
	}
	return fRet;
}

/////////////////////////////////////////////////////////////////////////////////////////////
static BOOL FGetPcs(HWND hDlg, UINT uMsg, LPARAM lParam, CConSettings** ppcs)
{
	Assert(ppcs);

	if (WM_INITDIALOG == uMsg)
	{
		PROPSHEETPAGE*	ppsp = (PROPSHEETPAGE*)lParam;
		if (!ppsp)
		{
			Assert(FALSE);
			return FALSE;
		}
		*ppcs = (CConSettings*)ppsp->lParam; 
		::SetWindowLong(hDlg, DWL_USER, (LONG)*ppcs);
	}
	else
	{
		*ppcs = (CConSettings*)::GetWindowLong(hDlg, DWL_USER);
	}
	return (NULL != *ppcs);
}

/////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK ServerDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CConSettings*	pcs;
	BOOL			fRet;

	if (!FGetPcs(hDlg, uMsg, lParam, &pcs))
	{
		return FALSE;
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcs->FInitServerDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcs->FNotifyServer(hDlg, lParam);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case ID_SETFOCUS:
			pcs->SetFocus(hDlg, (int)lParam);
			break;
		}
		break;
	}  
	
	return fRet;
} 

/////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK NickDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CConSettings*	pcs;
	BOOL			fRet;

	if (!FGetPcs(hDlg, uMsg, lParam, &pcs))
	{
		return FALSE;
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcs->FInitNickDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcs->FNotifyNick(hDlg, lParam);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case ID_SETFOCUS:
			pcs->SetFocus(hDlg, (int) lParam);
			break;
		}
		break;
	}  
	return fRet;
} 

/////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK OptionsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CConSettings*	pcs;
	BOOL			fRet;

	if (!FGetPcs(hDlg, uMsg, lParam, &pcs))
	{
		return FALSE;
	}

	switch(uMsg)
	{
	default:
		return FALSE;

	case WM_INITDIALOG:
		fRet = !pcs->FInitOptionsDlg(hDlg);
		break;

	case WM_NOTIFY:
		fRet = pcs->FNotifyOptions(hDlg, lParam);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case ID_SETFOCUS:
			pcs->SetFocus(hDlg, (int) lParam);
			break;
		}
		break;
	}  
	return fRet;
} 
