//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "icinst.h"
#include "icmain.h"
#include "iclogin.h"
#include "icchan.h"
#include "icprop.h"
#include "icfind.h"
#include "icref.h"
#include "ictree.h"
#include "icutil.h"

const TCHAR gszAppName[] = "MSFTInternetCHAT";

// Chat GLOBAL ToolBar
static TBBUTTON grgTBar[] = {
	{ 0, IDC_CREATECHANNEL, TBSTATE_ENABLED, 	TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
	{ 1, IDC_JOINCHANNEL, 	TBSTATE_ENABLED, 	TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
	{ 0, 0, 				TBSTATE_ENABLED, 	TBSTYLE_SEP, 	{0, 0}, 0L, -1 },
	{ 2, IDC_SAVE, 			TBSTATE_ENABLED, 	TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
	{ 3, IDC_FAVPLACES, 	0,					TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
	{ 0, 0, 				TBSTATE_ENABLED, 	TBSTYLE_SEP, 	{0, 0}, 0L, -1 },
	{ 4, IDC_CUT, 			TBSTATE_ENABLED, 	TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
	{ 5, IDC_COPY, 			TBSTATE_ENABLED, 	TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
	{ 6, IDC_PASTE, 		TBSTATE_ENABLED, 	TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
	{ 0, 0, 				TBSTATE_ENABLED, 	TBSTYLE_SEP, 	{0, 0}, 0L, -1 },
	{ 7, IDC_GETMEMPROPS, 	TBSTATE_ENABLED, 	TBSTYLE_BUTTON, {0, 0}, 0L, -1 },
};

#define TBAR_BITMAP_COUNT	8

#if defined(_DEBUG)
void DebugMessageType(LPCSTR t, CSMSG_TYPE c)
{
	char szBuf[256];
	switch (c)
	{
	case CSMSG_TYPE_NONE:
		wsprintf(szBuf, "%s\tCSMSG_TYPE_NONE\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_ERROR:				// socket, channel	
		wsprintf(szBuf, "%s\tCSMSG_TYPE_ERROR\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_LOGIN:				// socket	
		wsprintf(szBuf, "%s\tCSMSG_TYPE_LOGIN\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_TEXT_A:				// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_TEXT_A\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_TEXT_W:				// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_TEXT_W\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_DATA:				// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_DATA\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_ADDCHANNEL:			// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_ADDCHANNEL\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_ADDMEMBER:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_ADDMEMBER\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_GOTMEMLIST:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_GOTMEMLIST\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_DELMEMBER:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_DELMEMBER\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_DELCHANNEL:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_DELCHANNEL\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_MODEMEMBER:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_MODEMEMBER\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_MODECHANNEL:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_MODECHANNEL\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_WHISPERTEXT_A:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_WHISPERTEXT_A\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_WHISPERTEXT_W:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_WHISPERTEXT_W\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_WHISPERDATA:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_WHISPERDATA\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_NEWTOPIC:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_NEWTOPIC\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_PROPERTYDATA:		// socket,channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_PROPERTYDATA\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_QUERYDATA:			// socket, channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_QUERYDATA\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_PRIVATEMSG:			// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_PRIVATEMSG\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_NEWNICK:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_NEWNICK\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_INVITE:				// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_INVITE\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_SERVERMSG_TEXT_A:	// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_SERVERMSG_TEXT_A\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_SERVERMSG_TEXT_W:	// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_SERVERMSG_TEXT_W\n", t);	::OutputDebugString(szBuf);	break;
	default:
		wsprintf(szBuf, "%s\tError! Beyond CSMSG_TYPE range(%d)!\n", t, c);	::OutputDebugString(szBuf);	break;
	}
}
#endif

//--------------------------------------------------------------------------------------------
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
DWORD __stdcall DwMessageThreadProc(PVOID pvData);
// DWORD __stdcall DwMainThreadProc(PVOID pvData);
BOOL CALLBACK DwDlgProcStub(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

//////////////////////////////////////////////////////////////////////////////////////
CIChat::CIChat(DWORD dwID)
{
	m_fRegistered	= FALSE;
	m_hWnd			= NULL;
	m_pctLH 		= PCTLHSPLITDEFAULT;
	m_pctLHSav		= PCTLHSPLITDEFAULT;
	m_pctH			= PCTHSPLITDEFAULT;
	m_pctV			= PCTVSPLITDEFAULT;
	m_fInStartUp	= FALSE;
	m_dwID			= dwID;
	m_pChannel		= NULL;
	m_pMemMe		= NULL;
	m_pMemKick		= NULL;
	m_pccfp 		= NULL;
	m_bGotList		= 0;
	m_pcfd			= NULL;
	m_pcfdUsers 	= NULL;
	m_bModeSkip 	= 0;
	::ZeroMemory(&m_userOptions, sizeof(USEROPTIONS));
	m_userOptions.cRefURL = RGB(0, 0, 255);
	m_szReason		= NULL;
}

CIChat::~CIChat(void)
{
	Quit();

	// Find Dialogs
	if (m_pcfd)
	{
		m_pcfd->Release();
	}
	if (m_pcfdUsers)
	{
		m_pcfdUsers->Release();
	}
	// And the find pane
	if (m_pccfp)
	{
		m_pccfp->Release();
	}
}

BOOL CIChat::FInit(HINSTANCE hInst, PICS_CHANNEL picsChan)
{
	Assert(hInst);
	Assert(picsChan);
	Assert(NULL == m_pChannel);

	m_hInst 		= hInst;
	m_fInStartUp	= TRUE;
	m_pChannel		= picsChan;
	// try to allocate the find pane
	m_pccfp = new CChatFindPane;
	if (!m_pccfp)
	{
		AssertGLE(FALSE);
		DoOOM();
		return FALSE;
	}

	return DwMainThread();
}

DWORD CIChat::DwMainThread(void)
{
	Assert(m_hInst);
	Assert(m_pChannel);
	// Register the window class, then create a new chat window
	FRegisterClass();
	// Create the main window
	if (!FCreateWindow())
	{
		goto LError;
	}
	// Next comes the toolbar
	if (!FInitToolBar())
	{
		goto LError;
	}
	// And status bar
	if (!FInitStatusBar())
	{
		goto LError;
	}
	// Now create the panes
	if (!FInitPanes())
	{
		goto LError;
	}
	// Now attach splitters
	if (!FInitSplitters())
	{
		goto LError;
	}
	// Set the Channel name and topic in the window title
	if (!FSetWindowTitle())
	{
		goto LError;
	}
	// Load settings
	FLoadUserSettings();
	// All is well. Show the main window
	m_fInStartUp = FALSE;
	::ShowWindow(m_hWnd, SW_SHOW);
	// This will do things like disable the whisper button if this is a nowhisper chat
	m_ccsp.FChannelModeChange(m_pChannel);
	// And now launch a thread to read our messages
	if (!m_msgThread.FCreateThread(DwMessageThreadProc, this))
	{
		Assert(FALSE);
		goto LError;
	}
	// Give the send pane the focus
	m_ccsp.HWndSetFocus();

	return TRUE;

LError: 
	Quit();

	return FALSE;
}

void CIChat::Quit(void)
{
	if (m_pMemKick)
	{
		m_pMemKick->Release();
		m_pMemKick = NULL;
	}	
	// Cleanup everything
	if (m_pMemMe)
	{
		m_pMemMe->Release();
		m_pMemMe = NULL;
	}
	
	if (m_pChannel)
	{
		m_pChannel->Release();
		m_pChannel = NULL;
	}
	
	if (m_szReason)
	{
		delete [] m_szReason;
		m_szReason = NULL;
	}
	// Make sure the Channel thread terminates..
	m_msgThread.DwWaitForThread(INFINITE);
	// Clean up any posted ChatSock messages FOR THIS CHANNEL
	MSG 	msg;

	while (TRUE == ::PeekMessage(&msg, m_hWnd, ID_MSG_CHATSOCK, ID_MSG_CHATSOCK, PM_REMOVE))
	{
		if (msg.hwnd == m_hWnd && msg.message == ID_MSG_CHATSOCK)
		{
			::HrFreeMsg((PCS_MSGBASE)msg.lParam);	// release it 
		}
	}
	// And then.. goodbye.
	DestroyWindow();
	UnregisterClass();
	FCloseChat(m_dwID);
}

BOOL CIChat::FCloseChannel(void)
{
	// Did they want to save history? If history needs to be saved, 
	if (FAutoSave() && (m_cchp.Pui())->FDirty() && (m_cchp.Pui())->GetTextLength() > 0)
	{
		if (IDYES == FDoAlert(m_hWnd, IDS_SAVEBEFOREEXIT, ALERT_YESNO))
		{
			if (!m_cchp.FSave())
			{
				// If they didn't save, then don't exit the channel
				return TRUE;
			}
		}
	}
	// First, Hide the main window, so nobody has to suffer through the agony of an exit
	::ShowWindow(m_hWnd, SW_HIDE);

	if (m_pChannel)
	{
		m_pChannel->HrLeave(FALSE);
	}
	return TRUE;
}

BOOL CIChat::FAmIHost(void)
{
	PICS_MEMBER pMem;
	if (FAILED(m_pChannel->HrGetMe(&pMem)))
	{
		AssertSz(0, "HrGetMe");
		return FALSE;
	}
	BOOL fRet = (NOERROR == pMem->HrIsMemberHost());
	pMem->Release();
	return fRet;
}

BOOL CIChat::FAmISpeaker(void)
{
	PICS_MEMBER pMem;
	if (FAILED(m_pChannel->HrGetMe(&pMem)))
	{
		AssertSz(0, "HrGetMe");
		return FALSE;
	}
	BOOL fRet = (NOERROR == pMem->HrIsMemberSpeaker());
	pMem->Release();
	return fRet;
}

BOOL CIChat::FIsMemberMe(PICS_MEMBER pMember)
{
	PICS_MEMBER pMem;
	if (FAILED(m_pChannel->HrGetMe(&pMem)))
	{
		return FALSE;
	}
	BOOL fRet = (pMember == pMem);
	if (pMem)
	{
		pMem->Release();
	}
	return fRet;
}

BOOL CIChat::FCanIChangeTopic(void)
{
	DWORD dwType;
	if (FAILED(m_pChannel->HrGetType(&dwType)))
	{
		Assert(0);
		return FALSE;
	}
	PICS_MEMBER pMem;
	if (FAILED(m_pChannel->HrGetMe(&pMem)))
	{
		AssertSz(0, "HrGetMe");
		return FALSE;
	}
	// Only speakers can change the topic
	BOOL fRet = (NOERROR == pMem->HrIsMemberSpeaker());	
	if (fRet && (dwType & CS_CHANNEL_TOPICOP))
	{
		// Only hosts may change topic op flags 
		fRet = (NOERROR == pMem->HrIsMemberHost());
	}
	pMem->Release();
	return fRet;
}

BOOL CIChat::FDoITakeWhispers(void)
{
	PICS_MEMBER pMem;
	if (FAILED(m_pChannel->HrGetMe(&pMem)))
	{
		AssertSz(0, "HrGetMe");
		return FALSE;
	}
	BOOL fRet = (NOERROR == (pMem->HrDoesMemberTakeWhisper()));
	pMem->Release();
	return fRet;
}

BOOL CIChat::FToggleTakeWhispers(void)
{
	PICS_MEMBER pMem;
	if (FAILED(m_pChannel->HrGetMe(&pMem)))
	{
		AssertSz(0, "HrGetMe");
		return FALSE;
	}
	BOOL fSet = (NOERROR == pMem->HrDoesMemberTakeWhisper());
	BOOL fRet = SUCCEEDED(pMem->HrSetNoWhisper(fSet));
	pMem->Release();
	return fRet;
}

BOOL CIChat::FLoadUserSettings(void)
{
	FLoadUserOptions(&m_userOptions);	// update settings
	m_cchp.SetBlank(m_userOptions.fBlankLine);
	m_cchp.SetURLColor(m_userOptions.cRefURL);
	return TRUE;
}

BOOL CIChat::FInitSplitters(void)
{
	Assert(m_hWnd);

	RECT	rc;
//	RECT	rcBounds;	// bounding rectangle to give spliiters

	// The Horizontal splitter splits the parent window into a top and bottom
	GetHSplitterRect(&rc);
	if (!m_cswH.FCreateHorizontal(m_hWnd, ID_HSPLITTER, &rc, &rc))
	{
		return FALSE;
	}
	// The vertical splitters splits the parent window into a left middle and right
	GetVSplitterRect(&rc);
	if (!m_cswV.FCreateVertical(m_hWnd, ID_VPLITTER, &rc, &rc))
	{
		return FALSE;
	}

	GetLVSplitterRect(&rc);
	// Set it to the same bounds as the other..
	return m_cswLV.FCreateVertical(m_hWnd, ID_LVPLITTER, &rc, &rc);
}

BOOL CIChat::FInitPanes(void)
{
	Assert(m_hWnd);

	RECT	rc;
	// Each pane will occupy a certain PERCENTAGE of the screen
	// The history pane is to the left and top of the splitters
	GetHistoryRect(&rc);
	if (!m_cchp.FCreate(m_hWnd, ID_HISTORY, &rc))
	{
		return FALSE;
	}
	// The "send" pane is to the left and bottom of the splitters
	// But remember to leave space for the splitter
	GetSendRect(&rc);
	if (!m_ccsp.FCreate(m_hWnd, ID_MSG, &rc))
	{
		return FALSE;
	}
	
	// The list box pane is to the right of the vertical splitter
	GetListBoxRect(&rc);
	if (!m_cclp.FCreate(m_hWnd, ID_MEMBER, &rc))
	{
		return FALSE;
	}
	// And the find pane, which will not be visible..
	Assert(m_pccfp);
	GetFindRect(&rc);
	if (!m_pccfp->FCreate(m_hWnd, ID_FIND, &rc))
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CIChat::FInitToolBar(void)
{
	Assert(m_hWnd);
	
	RECT	rc;
	// Create the toolbar
	rc.left 	= 0;
	rc.right	= IGetHeightWidth(TOTALWIDTH);
	rc.top		= 0;
	rc.bottom	= 32;
	return m_ctb.FCreate(m_hWnd, ID_TOOLBAR, NULL, sizeof(grgTBar)/sizeof(TBBUTTON), 
					(TBBUTTON*)&grgTBar, TBAR_BITMAP_COUNT, IDB_TOOLBAR);
}

BOOL CIChat::FInitStatusBar(void)
{
	m_csb.FCreate(m_hWnd, ID_STATUSBAR);

	return TRUE;
}

BOOL CIChat::FSizeSplitters(void)
{
	Assert(m_hWnd);

	RECT	rc, rc2;
	int 	iht;
	// The Horizontal splitter splits the parent window into a top and bottom
	GetHSplitterRect(&rc);
	if (!m_cswH.FMoveWindow(&rc))
	{
		return FALSE;
	}
	// Set Bounds
	rc.top		= IGetHeightWidth(TOOLBARHEIGHT) + SPLITSIZE;
	rc.bottom	= IGetHeightWidth(TOTALHEIGHT) - IGetHeightWidth(STATUSBARHEIGHT) - SPLITSIZE;
	if (!m_cswH.FSetBoundingRect(&rc))
	{
		return FALSE;
	}
	// The vertical splitter splits the parent window into a left middle and right.
	// We also have to make sure that the bounding rects are correct,
	// so they don't overlap each other
	GetLVSplitterRect(&rc);
	GetVSplitterRect(&rc2);
	if (!m_cswLV.FMoveWindow(&rc))
	{
		return FALSE;
	}
	if (!m_cswV.FMoveWindow(&rc2))
	{
		return FALSE;
	}
	// Set bounds
	iht = rc.right; 
	rc.left = SPLITSIZE;
	rc.right = rc2.left - SPLITSIZE;
	if (!m_cswLV.FSetBoundingRect(&rc))
	{
		return FALSE;
	}

	rc2.left = iht + SPLITSIZE;
	rc2.right = IGetHeightWidth(TOTALWIDTH) - SPLITSIZE;
	return m_cswV.FSetBoundingRect(&rc2);
}

BOOL CIChat::FSizeBars(void)
{
	RECT	rc;

	GetToolBarRect(&rc);
	m_ctb.FMoveWindow(&rc);
	m_ctb.FRedrawWindow();

	GetStatusBarRect(&rc);
	m_csb.FMoveWindow(&rc);
	// Redraw the user count in the status bar
	m_csb.FUpdateUserCount(m_pChannel);
		
	return TRUE;
}

BOOL CIChat::FSizePanes(void)
{
	Assert(m_hWnd);
	
	RECT	rc;

	GetHistoryRect(&rc);
	m_cchp.FMoveWindow(&rc);

	GetSendRect(&rc);
	m_ccsp.FMoveWindow(&rc);

	GetListBoxRect(&rc);
	m_cclp.FMoveWindow(&rc);
	
	GetFindRect(&rc);
	m_pccfp->FMoveWindow(&rc);

	return TRUE;
}

// Resize all panes and splitters
BOOL CIChat::FSizeAll(void)
{
	if (m_fInStartUp)
	{
		return TRUE;
	}
	// Size toolbar and status bar
	if (!FSizeBars())
	{
		return FALSE;
	}

	if (!FSizePanes())
	{
		return FALSE;
	}

	if (!FSizeSplitters())
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CIChat::FSetPercent(BOOL fSetH, int idCtl)
{
	RECT	rc;
	// Get the splitter's bounding rect.
	if (fSetH)
	{
		if (ID_LVPLITTER == idCtl)
		{
			if (!m_cswLV.FGetWindowRect(&rc))
			{
				return FALSE;
			}
		}
		else if (!m_cswV.FGetWindowRect(&rc))
		{
			return FALSE;
		}
	}
	else
	{
		if (!m_cswH.FGetWindowRect(&rc))
		{
			return FALSE;
		}
	}
	// Convert to local coods
	::MapWindowPoints(NULL, m_hWnd, (LPPOINT)&rc, 2);
	// Computer percentage
	if (fSetH)
	{
		if (ID_LVPLITTER == idCtl)
		{
			m_pctLH = (rc.left * PERCENTSIZE)/IGetHeightWidth(TOTALWIDTH);
			m_pctLHSav = m_pctLH;
		}
		else
		{
			m_pctH = (rc.left * PERCENTSIZE)/IGetHeightWidth(TOTALWIDTH);
		}
	}
	else
	{
		m_pctV = (rc.top * PERCENTSIZE)/IGetHeightWidth(TOTALHEIGHT);
	}

	return TRUE;
}

// Get rect locations..
void CIChat::GetHSplitterRect(RECT* prc)
{
	Assert(prc);
	prc->left	= IGetHeightWidth(LEFTWIDTH) + SPLITSIZE;
	prc->right	= IGetHeightWidth(MIDDLEWIDTH); // add splitbar width for overlap
	prc->top	= IGetHeightWidth(TOPHEIGHT);
	prc->bottom = prc->top + SPLITSIZE;
}

void CIChat::GetLVSplitterRect(RECT* prc)
{
	Assert(prc);
	prc->left	= IGetHeightWidth(LEFTWIDTH);
	prc->right	= prc->left + SPLITSIZE;
	prc->top	= IGetHeightWidth(TOOLBARHEIGHT);
	prc->bottom = IGetHeightWidth(TOTALHEIGHT) - IGetHeightWidth(STATUSBARHEIGHT);
}

void CIChat::GetVSplitterRect(RECT* prc)
{
	Assert(prc);
	prc->left	= IGetHeightWidth(MIDDLEWIDTH);
	prc->right	= prc->left + SPLITSIZE;
	prc->top	= IGetHeightWidth(TOOLBARHEIGHT);
	prc->bottom = IGetHeightWidth(TOTALHEIGHT) - IGetHeightWidth(STATUSBARHEIGHT);

}

void CIChat::GetHistoryRect(RECT* prc)
{
	Assert(prc);
	prc->left	= IGetHeightWidth(LEFTWIDTH);
	if (prc->left)
	{
		prc->left +=  SPLITSIZE;
	}
	prc->right	= IGetHeightWidth(MIDDLEWIDTH);
	prc->top	= IGetHeightWidth(TOOLBARHEIGHT);	// make allowance for the toolbar
	prc->bottom = IGetHeightWidth(TOPHEIGHT);
}

void CIChat::GetFindRect(RECT* prc)
{
	Assert(prc);
	prc->left	= 0;
	prc->right	= IGetHeightWidth(LEFTWIDTH);
	prc->top	= IGetHeightWidth(TOOLBARHEIGHT);	// make allowance for the toolbar
	prc->bottom = IGetHeightWidth(TOTALHEIGHT) - IGetHeightWidth(STATUSBARHEIGHT);
}

void CIChat::GetSendRect(RECT* prc)
{
	Assert(prc);
	prc->left	= IGetHeightWidth(LEFTWIDTH);
	if (prc->left)
	{
		prc->left +=  SPLITSIZE;
	}
	prc->right	= IGetHeightWidth(MIDDLEWIDTH);
	prc->top	= IGetHeightWidth(TOPHEIGHT) + SPLITSIZE;
	prc->bottom = prc->top + IGetHeightWidth(BOTTOMHEIGHT) - IGetHeightWidth(STATUSBARHEIGHT) - SPLITSIZE;
}

void CIChat::GetListBoxRect(RECT* prc)
{
	Assert(prc);
	prc->left	= IGetHeightWidth(MIDDLEWIDTH) + SPLITSIZE;
	prc->right	= prc->left + IGetHeightWidth(RIGHTWIDTH);
	prc->top	= IGetHeightWidth(TOOLBARHEIGHT);
	prc->bottom = IGetHeightWidth(TOTALHEIGHT) - IGetHeightWidth(STATUSBARHEIGHT);
}

void CIChat::GetToolBarRect(RECT* prc)
{
	Assert(prc);
	prc->left	= 0;
	prc->right	= IGetHeightWidth(TOTALWIDTH);
	prc->top	= 0;
	prc->bottom = IGetHeightWidth(TOOLBARHEIGHT);
}

void CIChat::GetStatusBarRect(RECT* prc)
{
	Assert(prc);
	prc->left	= 0;
	prc->right	= IGetHeightWidth(TOTALWIDTH);
	prc->bottom = IGetHeightWidth(TOTALHEIGHT);
	prc->top	= prc->bottom - IGetHeightWidth(STATUSBARHEIGHT);
}

// Main routine that computes heights and widths..call to obtain what informatin you need
int CIChat::IGetHeightWidth(int idType)
{
	switch (idType)
	{
	default:
		break;

	case TOOLBARHEIGHT:
		if (m_ctb.FIsVisible())
		{
			return m_ctb.LGetHeight();
		}
		return 0;
	
	case STATUSBARHEIGHT:
		if (m_csb.FIsVisible())
		{
			return m_csb.LGetHeight();
		}
		return 0;
	}

	RECT	rc;
	int 	dx, dy;
	int 	iRet;

	Assert(m_hWnd);
	if (!::GetClientRect(m_hWnd, &rc))
	{
		AssertGLE(FALSE);
		return 0;
	}
	dx	= rc.right - rc.left;
	dy	= rc.bottom - rc.top;
	
	switch (idType)
	{
	default:
		Assert(FALSE);
		iRet = 0;
		break;
	
	case LEFTWIDTH: 
		if (m_cswLV.FIsVisible())
		{
			iRet = dx * m_pctLH;	
		}
		else
		{
			iRet = 0;
		}
		break;

	case MIDDLEWIDTH:
		iRet = dx * m_pctH;
		break;

	case RIGHTWIDTH: // percent of wnd to the "right" of the splitter
		iRet = dx * (PERCENTSIZE - m_pctH); 
		break;

	case TOPHEIGHT: // percent of wnd to the "top" of the splitter
		iRet = dy * m_pctV; 
		break;

	case BOTTOMHEIGHT: // percent of wnd to the "bottom" of the splitter
		iRet = dy * (PERCENTSIZE - m_pctV); 
		break;
	
	case TOTALWIDTH:
		return dx;

	case TOTALHEIGHT:
		return dy;
	}

	iRet /= (PERCENTSIZE);
	
	return iRet;
}

BOOL CIChat::FRegisterClass(void)
{
	WNDCLASS  wc;
	// Fill in window class structure with parameters that describe the main window.
	wc.style			= 0;								// Class style(s).
	wc.lpfnWndProc		= (WNDPROC)MainWndProc; 			// Window Procedure
	wc.cbClsExtra		= 0;								// No per-class extra data.
	wc.cbWndExtra		= 0;								// No per-window extra data.
	wc.hInstance		= m_hInst;							// Owner of this class
	wc.hIcon			= LoadIcon (m_hInst, "MSFTICHAT");	
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);		// Cursor
	wc.hbrBackground	= (HBRUSH)(COLOR_BTNFACE+1);		// Default color
	wc.lpszMenuName 	= gszAppName;						// Menu name from .RC
	wc.lpszClassName	= gszAppName;						// Name to register as
	if (!::RegisterClass(&wc))
	{
		return FALSE;
	}
	
	m_fRegistered = TRUE;

	return TRUE;
}

void CIChat::UnregisterClass(void)
{
	if (m_fRegistered)
	{
		::UnregisterClass(gszAppName, m_hInst);
		m_fRegistered = FALSE;
	}
}

void CIChat::DestroyWindow(void)
{
	if (m_hWnd)
	{
		::SetWindowLong(m_hWnd, GWL_USERDATA, (LPARAM)NULL);
		::DestroyWindow(m_hWnd);
		m_hWnd = NULL;
	}
}

BOOL CIChat::FCreateWindow(void)
{
	Assert(NULL == m_hWnd);
	Assert(m_hInst);

	m_hWnd = ::CreateWindow(gszAppName, 						// See RegisterClass() call.
							GetSz(m_hInst, IDS_APPTITLE),		// Text for window title bar.
							WS_OVERLAPPEDWINDOW | WS_VISIBLE,	// Window style.
							CW_USEDEFAULT, 0, 
							CW_USEDEFAULT, 0,	// Use default positioning
							NULL, 				// Overlapped windows have no parent.
							NULL, 				// Use the window class menu.
							m_hInst, 			// This instance owns this window.
							NULL);				// We don't use any data in our WM_CREATE
	// If window could not be created, return "failure"
	if (!m_hWnd)
	{
		AssertGLE(FALSE);
		return (FALSE);
	}
	// save  a pointer to this object in the window
	::SetWindowLong(m_hWnd, GWL_USERDATA, (LPARAM)this);

	return TRUE;
}

BOOL CIChat::FSetStatusBar(void)
{
	TCHAR	sz[256];
	TCHAR	szNick[CS_CCHMAX_MIC_USERNAME + 1];
	TCHAR*	szNik;

	if (m_pMemMe)
	{
		szNik	= PszGetName(m_pMemMe, &szNick[0]);
		if (szNik)
		{
			// Update the status bar. Ignore failure
			::wsprintf(sz, "%s %s", GetSz(HInstGet(), IDS_NICKNAME), szNik);
			m_csb.FSetStatusString(sz); 	
		}
	}
	return TRUE;
}

BOOL CIChat::FSetWindowTitle(void)
{
	TCHAR	szTitle[512];
	TCHAR	szChannel[CS_CCHMIN_IRC_CHANNEL + 1];	// these are bigger than MIC names

	TCHAR* szChan = PszGetChannelName(m_pChannel, &szChannel[0]);
	if (!szChan)
	{
		return FALSE;
	}
	BYTE*	pbTopic;
	BOOL	fTopicAnsi;
	if (FAILED(m_pChannel->HrGetTopic(&pbTopic, &fTopicAnsi)))
	{
		return FALSE;
	}
	// Ignore Unicode Topic
	TCHAR* szTopic = (fTopicAnsi) ? (TCHAR*)pbTopic : NULL;
	::wsprintf(szTitle, "%s: %s", szChan, szTopic);

	::SetWindowText(m_hWnd, szTitle);

	return TRUE;
}

BOOL CIChat::FCopyMeOnMsg(TCHAR* psz)
{
	Assert(m_pChannel);

	HRESULT hr = NOERROR;
	// give ourselves a copy of any msg we sent
	if (FIsEchoSourceChat())
	{
		// Server will automatically echo on these chats. No need to do it manually
		return TRUE;
	}
	PICS_MEMBER pMem;
	hr = m_pChannel->HrGetMe(&pMem);
	if (SUCCEEDED(hr))
	{
		Assert(pMem);
		m_cchp.FInsertMsg(pMem, psz, m_pChannel, TRUE, FALSE, TRUE);
		pMem->Release();
		return TRUE;
	}
	return FALSE;
}

BOOL CIChat::FSendText(void)
{
	// FIX ME - for now we send ASCII only
	Assert(m_pChannel);

	if (!FIsCommandActive(IDC_SEND))
	{
		if (m_ccsp.GetSendTextLength() <= 0)
		{
			FDoAlert(m_hWnd, IDS_NOTHINGTOSEND, ALERT_ERROR);
		}
		return FALSE;
	}

	TCHAR	*psz;
	HRESULT hr = NOERROR;
	// Send the text
	psz = m_ccsp.PszSendText(); 
	if (psz)
	{
		hr = m_pChannel->HrSendTextA(psz);
		if (SUCCEEDED(hr))
		{
			return FCopyMeOnMsg(psz);
		}
	}

	return FALSE;
}

BOOL CIChat::FSendWhisper(void)
{
	// FIX ME - for now we send ASCII only
	Assert(m_pChannel);
	// Make sure it is ok to whisper
	if (!FIsCommandActive(IDC_WHISPER))
	{
		FDoAlert(m_hWnd, m_ccsp.GetSendTextLength() <= 0 ? IDS_NOTHINGTOSEND : IDS_WHISPERNOTAVAIL, ALERT_ERROR);
		return FALSE;
	}
	HRESULT hr = NOERROR;
	// Send the text
	TCHAR* psz = m_ccsp.PszSendText(); 
	if (psz)
	{
		return m_cclp.FWhisperToMembers(IDC_WHISPER, m_pChannel, psz, &m_cchp);
	}
	
	return FALSE;
}

BOOL CIChat::FCreateChannel(void)
{
	return FCreateNewChannel(m_hWnd);
}

BOOL CIChat::FJoinChannel(void)
{
	return FJoinNewChannel(m_hWnd, m_pccfp);
}

BOOL CIChat::FChannelProperties(void)
{
	BOOL		fRet = FALSE;
	DWORD		dwType;
	HRESULT 	hr;

	// Channel creation dialog
	IC_CREATECHAN* picChan = new IC_CREATECHAN;
	if (!picChan)
	{
		AssertGLE(FALSE);
		DoOOM();
		goto LReturn;
	} 
	
	hr = m_pChannel->HrGetType(&dwType);
	if (FAILED(hr))
	{
		return hr;
	}

	SetDisableAll(TRUE);
	fRet = picChan->FChannelPropertyDlg(m_hWnd, m_pChannel);
	SetDisableAll(FALSE);
	if (fRet)
	{
		DWORD dwMask;
		DWORD dwNew;
		
		dwNew = picChan->DwType();
		dwMask = dwType ^ dwNew;
		// If something changed, then send a msg to the server
		if (dwMask > 0)
		{
			if (SUCCEEDED(m_pChannel->HrModifyType(dwNew, dwMask)))
			{
				m_bModeSkip++;
			}
		}
		// What about limits..
		if (picChan->DwCUser() > 0)
		{
			m_pChannel->HrSetUserMax(picChan->DwCUser());
		}
	}

LReturn:
	if (picChan)
	{
		picChan->Release();
	}
	return fRet;
}

BOOL CIChat::FListAllChannels(void)
{
	BOOL	fRet = FALSE;
		
	if (!m_pcfd)
	{
		m_pcfd = new CFindDlg;
		if (!m_pcfd)
		{
			AssertGLE(FALSE);
			DoOOM();
			return FALSE;
		}
	}
	// Put up the find dialog
	SetDisableAll(TRUE);
	fRet = m_pcfd->FFindDlg(m_hWnd);
	SetDisableAll(FALSE);
	if (!fRet)
	{
		goto LReturn;
	}	
	// Show the Find window if it is not already visible
	FShowFindPane();

	m_pccfp->AddRef();
	if (!::FListAllChannels(m_pccfp, m_pcfd))
	{
		m_pccfp->Release();
		goto LReturn;
	}
	// Find sent off successfully. Disable the pane
	m_pccfp->FDisablePane();

	fRet = TRUE;

LReturn:
	
	return fRet;
}

BOOL CIChat::FDoHelp(void)
{	
	WinHelp(m_hWnd, "mic.hlp", HELP_FINDER, 0);

	return TRUE;
}

// Shortcuts must feature FULL URLs.. listing server name and channel name
BOOL CIChat::FCreateShortcut(BOOL fDesktop)
{
	// To construct a FULL URL, we need both the server and channel names
	CHAR* szServer;
	if (FAILED(m_pChannel->HrGetServerName(&szServer)))
	{
		AssertSz(0, "HrGetServerName");
		return FALSE;
	}

	BYTE* pbName;
	BOOL fAnsi;
	if (FAILED(m_pChannel->HrGetName(&pbName, &fAnsi)))
	{
		AssertSz(0, "HrGetName");
		return FALSE;
	}
		
	AssertSz(fAnsi, "Unicode Channel!");
	
	TCHAR szURL[2*MAX_PATH + 2];
	if (!FMakeMicURL(szServer, (TCHAR*)pbName, szURL))
	{
		return FALSE;
	}
	
	if (fDesktop)
	{
		// Now create the shortcut file on the Desktop. The file's name is the name of the channel
		TCHAR szShortCut[MAX_PATH + 1]; 
		::wsprintf(szShortCut, "%s.URL", (TCHAR*)pbName);
		return FCreateShortCutOnDesktop(szShortCut, szURL);
	}
	else
	{
		(m_ccsp.Pui())->InsertText(szURL);
	}
	return TRUE;
}


BOOL CIChat::FListAllUsers(void)
{
	BOOL fRet = FALSE;
		
	if (!m_pcfdUsers)
	{
		m_pcfdUsers = new CFindDlg;
		if (!m_pcfdUsers)
		{
			AssertGLE(FALSE);
			DoOOM();
			return FALSE;
		}
	}
	// Put up the find dialog
	SetDisableAll(TRUE);
	fRet = m_pcfdUsers->FFindMemberDlg(m_hWnd);
	SetDisableAll(FALSE);

	if (!fRet)
	{
		goto LReturn;
	}
	// Show the Find window if it is not already visible
	FShowFindPane();

	m_pccfp->AddRef();
	if (!::FListAllUsers(m_pccfp, m_pcfdUsers))
	{
		m_pccfp->Release();
		goto LReturn;
	}
	// Find send successfully. Disable the pane
	m_pccfp->FDisablePane();
	 
	fRet = TRUE;

LReturn:
	return fRet;
}

BOOL CIChat::FIsUserSelectedInBrowser(PICS_PROPERTY *ppProp)
{
	HWND hWnd = ::GetFocus();
	CChatTreeView* pctv = m_pccfp->PTreeView();
	Assert(pctv);
	// If the Browser is in focus, do properties based off that
	if (hWnd == pctv->HWnd())
	{
		HTREEITEM hti = pctv->HtiGetSelection();
		if (hti)
		{
			if (pctv->FIsUser(hti))
			{
				if (ppProp)
				{
					*ppProp = pctv->PicsPropertyGet(hti);
				}
				return TRUE;
			}
		}
	}

	return FALSE;
}

BOOL CIChat::FIsMemberSelectedInBrowser(PICS_PROPERTY *ppProp, BOOL fUsersAlso)
{
	HWND hWnd = ::GetFocus();
	CChatTreeView* pctv = m_pccfp->PTreeView();
	Assert(pctv);
	// If the Browser is in focus, do properties based off that
	if (hWnd == pctv->HWnd())
	{
		HTREEITEM	hti = pctv->HtiGetSelection();
		if (hti)
		{
			if (pctv->FIsMember(hti) || (fUsersAlso && pctv->FIsUser(hti)))
			{
				if (ppProp)
				{
					*ppProp = pctv->PicsPropertyGet(hti);
				}
				return TRUE;
			}
		}
	}

	return FALSE;
}

//
// Get a member's properties.. based on what the user currently selected.. a member
// in the find pane or in the member list
//
BOOL CIChat::FShowMemberProperties(void)
{
	PICS_PROPERTY pp;
	if (FIsMemberSelectedInBrowser(&pp))
	{
		return ::FGetMemberPropsFromBrowser(m_hWnd, pp, FALSE);
	}
	return m_cclp.FShowMemberProps();
}

//
// Invite member
//
BOOL CIChat::FInviteMember(void)
{
	PICS_PROPERTY pp;
	if (FIsMemberSelectedInBrowser(&pp))
	{
		return FInvite(pp);
	}
	return FALSE;
}

BOOL CIChat::FInviteUser(void)
{
	PICS_PROPERTY pp;
	if (FIsUserSelectedInBrowser(&pp))
	{
		return FInvite(pp);
	}
	return FALSE;
}

BOOL CIChat::FInvite(PICS_PROPERTY pp)
{
	// Get the NickName
	CS_PROPDATA csPropData;
	if (FAILED(pp->HrGetProperty(&csPropData, CSINDEX_PROP_MEMBER_NAME)))
	{
		AssertSz(0, "HrGetProperty");
		return FALSE;
	}
	// Invite the bloke
	CS_INVITEINFO csiInfo;
	csiInfo.dwUserID = 0;
	csiInfo.pvNickTo = (PVOID)csPropData.pbData;
	HRESULT hr = (csPropData.fAnsi)	? m_pChannel->HrSendInviteA(&csiInfo)
									: m_pChannel->HrSendInviteW(&csiInfo);
	return (NOERROR == hr);
}

// Display a user's properties.. if they are current selected
BOOL CIChat::FShowUserProperties(void)
{
	PICS_PROPERTY pp;

	if (FIsUserSelectedInBrowser(&pp))
	{
		return ::FGetMemberPropsFromBrowser(m_hWnd, pp, TRUE);
	}
	return FALSE;
}

BOOL CIChat::FIsMemberPropertiesActive(void)
{
	return (m_cclp.IGetSelCount() > 0);
}

BOOL CIChat::FIsUserPropertiesActive(void)
{
	return FIsUserSelectedInBrowser(NULL);
}

// Get a member's Real Name
BOOL CIChat::FGetRealName(void)
{	
	PICS_PROPERTY pp;

	if (FIsMemberSelectedInBrowser(&pp, TRUE))
	{
		return ::FGetRealName(m_hWnd, pp);
	}
	return m_cclp.FChangeMemberStatus(IDC_GETREALNAME, m_pChannel);
}

BOOL CIChat::FGetUserRealName(void)
{
	PICS_PROPERTY pp;

	if (FIsUserSelectedInBrowser(&pp))
	{
		return ::FGetRealName(m_hWnd, pp);
	}
	return FALSE;
}

BOOL CIChat::FIsRealNameActive(void)
{
	return (FIsMemberSelectedInBrowser(NULL, TRUE) || (m_cclp.IGetSelCount() == 1));
}

BOOL CIChat::FInsertURL(void)
{
	return FCreateShortcut(FALSE);
}

BOOL CIChat::FConnectionSettings(void)
{
	CConSettings* pccs = new CConSettings;
	if (!pccs)
	{
		AssertGLE(FALSE);
		DoOOM();
		return FALSE;
	}
	// Put up a dialog for users to specify their server preferences
	SetDisableAll(TRUE);
	BOOL fRet = pccs->FSettingsDlg(m_hWnd, NULL, 0);
	SetDisableAll(FALSE);
	pccs->Release();
	return fRet;
}

// Handle these EditMenu commands
BOOL CIChat::FHandleEditCommand(WPARAM wParam, LPARAM lParam)
{
	int idCmd = LOWORD(wParam);

	if (IDC_CLEARHISTORY == idCmd)
	{
		(m_cchp.Pui())->Clear();
		return TRUE;
	}

	CUIRichEdit* pui = PuiGetFocus();
	if (!pui)
	{
		return FALSE;
	}
	
	switch (idCmd)
	{
	default:
		break;
				
	case IDC_CUT:
		pui->Cut();
		break;
					
	case IDC_COPY:
		pui->Copy();
		break;

	case IDC_PASTE:
		pui->Paste();
		break;
				
	case IDC_SELECTALL: 
		pui->SelectAll();
		break;

	case IDC_CLEAR: 	
		pui->Clear();
		break;
	
	case IDC_INSERTURL:
		FInsertURL();
		break;
	}
	
	return TRUE;
}

BOOL CIChat::FShowFindPane(void)
{
	BOOL		fCheck;
	// Show the Find window if it is not already visible
	FIsCommandActive(IDC_VIEWFINDPANE, &fCheck);
	if (!fCheck)
	{
		return FHandleCommand((WPARAM)IDC_VIEWFINDPANE, 0);
	}
	return FALSE;
}

// Handle these ViewMenu commands
BOOL CIChat::FHandleViewCommand(WPARAM wParam, LPARAM lParam)
{
	int idCmd = LOWORD(wParam);
	switch (idCmd)
	{
	default:
		return TRUE;

	case IDC_VIEWTOOLBAR:
		if (m_ctb.FIsVisible())
		{
			m_ctb.HideWindow();
		}
		else
		{
			m_ctb.ShowWindow();
		}
		break;
	
	case IDC_VIEWFINDPANE:
		Assert(m_pccfp);
		if (m_pctLH > 0 && m_pccfp->FIsVisible())
		{
			m_pctLHSav = m_pctLH;	// save the space occupied by this pane
			m_pctLH = 0;
			m_pccfp->HideWindow();
		}
		else
		{
			m_pctLH = m_pctLHSav;
			m_pccfp->ShowWindow();
		}
		break;					

	case IDC_VIEWSTATUSBAR:
		if (m_csb.FIsVisible())
		{
			m_csb.HideWindow();
		}
		else
		{
			m_csb.ShowWindow();
		}
		break;
	}
	return FSizeAll();
}

BOOL CIChat::FHandleCommand(WPARAM wParam, LPARAM lParam)
{
	int idCmd = LOWORD(wParam);
	switch (idCmd)
	{
	default:
		if (IDC_EDITFIRST <= idCmd && idCmd <= IDC_EDITLAST)
		{
			return FHandleEditCommand(wParam, lParam);
		}
		if (IDC_VIEWFIRST <= idCmd && idCmd <= IDC_VIEWLAST)
		{
			return FHandleViewCommand(wParam, lParam);
		}
		AssertSz(0, "Unknown command");
		return FALSE;
	
	case IDC_SEND:
		FSendText();
		break;

	case IDC_SAVE:
		m_cchp.FSave();
		break;

	case IDC_SAVEAS:
		m_cchp.FSave(TRUE);
		break;

	case IDC_CONSETTINGS:
		FConnectionSettings();
		break;

	case IDC_CREATECHANNEL:
		FCreateChannel();
		break;

	case IDC_JOINCHANNEL:
		FJoinChannel();
		break;
	
	case IDC_CHANNELPROPS:
		FChannelProperties();
		break;

	case IDC_LEAVECHANNEL:
		FCloseChannel();
		break;

	case IDC_SETAWAY:
#ifdef NOTNOW
		FSetAway(m_hWnd, PChatSocket());
#else
		AssertSz(0, "We removed Away!");
#endif
		break;

	case IDC_SHORTCUT:
		FCreateShortcut(TRUE);
		break;

	case IDC_MAKESPECTATOR:
	case IDC_MAKESPEAKER:
	case IDC_MAKEHOST:
	case IDC_EJECTMEMBER:
	case IDC_IGNORE:
	case IDC_DONTIGNORE:
	case IDC_BAN:
	case IDC_UNBAN:
	case IDC_KILLUSER:
		m_cclp.FChangeMemberStatus(idCmd, m_pChannel);
		break;
		
	case IDC_GETREALNAME:
		FGetRealName();
		break;
	
	case IDC_GETUSERREALNAME:
		FGetUserRealName();
		break;

	case IDC_GETMEMPROPS:
		FShowMemberProperties();
		break;
	
	case IDC_GETUSERPROPS:
		FShowUserProperties();
		break;

	case IDC_WHISPER:
		FSendWhisper();
		break;
	
	case IDC_NOWHISPER:
		FToggleTakeWhispers();
		break;

	case IDC_CHANGETOPIC:
		// fix me - THIS IS JUST TO TEST
		Assert(m_pChannel);
		FSetTopic(m_hWnd, m_pChannel);
		break;

	case IDC_LISTCHANNELS:
		FListAllChannels();
		break;
	
	case IDC_LISTUSERS:
		FListAllUsers();
		break;

	case IDC_ABOUT:
		DialogBox(HInstance(m_hWnd), MAKEINTRESOURCE(IDD_ABOUTMIC), m_hWnd, DwDlgProcStub);
		break;
	
	case IDC_INVITE:
		FInviteMember();
		break;
	
	case IDC_INVITEUSER:
		FInviteUser();
		break;

	case IDC_USEROPTIONS:
		if (FDoOptionsDlg(m_hWnd, &m_userOptions))
		{
			FLoadUserSettings();	// update settings
		}
		break;
	
	case IDC_HELPTOPICS:
		FDoHelp();
		break;

	case USER_HSPLITDONE:
		FSetVPercent((int) lParam);
		FSizeAll();
		break;

	case USER_VSPLITDONE:
		FSetHPercent((int) lParam);
		FSizeAll();
		break;
	}
	return TRUE;
}

BOOL CIChat::FHandleNotify(NMHDR *pnmhdr)
{
	LPTOOLTIPTEXT pttt;

	switch (pnmhdr->code)
	{
	case TTN_NEEDTEXT:
		pttt = (LPTOOLTIPTEXT)pnmhdr;
		pttt->hinst = m_hInst;
		pttt->lpszText = MAKEINTRESOURCE(pttt->hdr.idFrom);
		return TRUE;

	}
	return FALSE;
}

// Get the UI window currently with Focus
CUIRichEdit* CIChat::PuiGetFocus(void)
{
	HWND hWnd = ::GetFocus();
	if (hWnd == (m_cchp.Pui())->HWnd())
	{
		return m_cchp.Pui();
	}
	else if (hWnd == (m_ccsp.Pui())->HWnd())
	{
		return m_ccsp.Pui();
	}
	
	return NULL;
}

// Are these Edit Menu commanda disabled or enabled?
int CIChat::FCheckEditCommandStatus(UINT idCmd, int* pidStr, int* pidHelp)
{
	Assert(pidStr && pidHelp);

	int cmdRet			= CMD_ACTIVE;
	*pidStr				= -1;
	*pidHelp			= -1;
	CUIRichEdit* pui	= PuiGetFocus();

	switch (idCmd)
	{
	default:
		break;
				
	case IDC_CUT:
		if (pui && pui->FCutAvailable())
		{
			break;
		}
		else
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_COPY:
		if (pui && pui->FCopyAvailable())
		{
			break;
		}
		cmdRet &= ~CMD_ACTIVE;
		break;

	case IDC_PASTE:
		if (pui && pui->FPasteAvailable())
		{
			break;
		}
		cmdRet &= ~CMD_ACTIVE;
		break;
				
	case IDC_SELECTALL: 
	case IDC_CLEAR: 	
		if (pui)
		{
			break; // since a richedit control currently has focus
		}
		cmdRet &= ~CMD_ACTIVE;	// disabled for now
		break;
	
	case IDC_INSERTURL:
		if (pui && !pui->FReadOnly())
		{
			break;
		}
		else
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;
	}
	return cmdRet;
}

int CIChat::FCheckViewCommandStatus(UINT idCmd, int* pidStr, int* pidHelp)
{
	BOOL	fCheck = FALSE;

	Assert(pidStr && pidHelp);

	int cmdRet	= CMD_ACTIVE;
	*pidStr 	= -1;
	*pidHelp	= -1;
	switch (idCmd)
	{
	default:
		break;
	
	case IDC_VIEWTOOLBAR:
		fCheck = m_ctb.FIsVisible();
		break;
	
	case IDC_VIEWFINDPANE:
		Assert(m_pccfp);
		fCheck = (m_pccfp->FIsVisible() && m_pctLH > 0);
		break;
	
	case IDC_VIEWSTATUSBAR:
		fCheck = m_csb.FIsVisible();
		break;
	}

	if (fCheck)
	{
		cmdRet |= CMD_CHECK;
	}
	return cmdRet;
}

// Are these common commands disabled or enabled?
int CIChat::FCheckCommandStatus(UINT idCmd, int* pidStr, int* pidHelp)
{
	Assert(pidStr && pidHelp);

	int cmdRet	= CMD_ACTIVE;
	*pidStr 	= -1;
	*pidHelp	= -1;
	switch (idCmd)
	{
	default:
		if (IDC_EDITFIRST <= idCmd && idCmd <= IDC_EDITLAST)
		{
			return FCheckEditCommandStatus(idCmd, pidStr, pidHelp);
		}
		if (IDC_VIEWFIRST <= idCmd && idCmd <= IDC_VIEWLAST)
		{
			return FCheckViewCommandStatus(idCmd, pidStr, pidHelp);
		}
		break;

	case IDC_SEND:
		if (!FAmISpeaker() || m_ccsp.GetSendTextLength() <= 0)
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_MAKESPECTATOR:
		if (!FIsMicSocket() && !FIsModeratedChat())
		{
			cmdRet &= ~CMD_ACTIVE;
			break;
		}
	// Fall through
	case IDC_MAKESPEAKER:
	case IDC_MAKEHOST:
	case IDC_EJECTMEMBER:
		if (m_cclp.IGetSelCount() <= 0 || !FAmIHost())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;
	
	case IDC_GETREALNAME:
		if (!FIsRealNameActive())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;
	
	case IDC_INVITE:
		if (!FIsMemberSelectedInBrowser(NULL))
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_GETMEMPROPS:
		if (!FIsMemberPropertiesActive())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;
	
	case IDC_BAN:
	case IDC_UNBAN:
		if (!FIsRealNameActive())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_GETUSERREALNAME:
	case IDC_GETUSERPROPS:
	case IDC_INVITEUSER :
		if (!FIsUserPropertiesActive())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_WHISPER:
		if (!FIsWhisperActive())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_CHANGETOPIC:
		if (!FCanIChangeTopic())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_LISTCHANNELS:
	case IDC_LISTUSERS:
		// If already doing a list.. disable all other lists..
		if (m_pccfp->FWaiting())
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;

	case IDC_NOWHISPER:
		if (!FDoITakeWhispers())
		{
			cmdRet |= CMD_CHECK;
		}
		break;
	
	case IDC_DONTIGNORE:
	case IDC_IGNORE:
		if (m_cclp.IGetSelCount() <= 0)
		{
			cmdRet &= ~CMD_ACTIVE;
		}
		break;
	}
	return cmdRet;
}

BOOL CIChat::FIsCommandActive(UINT idCmd, BOOL *pfChecked)
{
	int idStr, idHelp;
	int iCmdStat = FCheckCommandStatus(idCmd, &idStr, &idHelp);
	
	if (pfChecked)
	{
		*pfChecked = (iCmdStat & CMD_CHECK);
	}
	return (iCmdStat & CMD_ACTIVE);
}

BOOL CIChat::FInitMenu(HMENU hMenu, UINT uPos)
{
	int cMenu = ::GetMenuItemCount(hMenu);
	if (-1 == cMenu)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	for (int iMenu = 0; iMenu < cMenu; iMenu++)
	{
		UINT id = ::GetMenuItemID(hMenu, iMenu);

		if (0xffffffff == id || 0 == id)
		{
			continue;	// popup menu or seperator
		}

		int idStr, idHelp;
		int iCmdStat = FCheckCommandStatus(id, &idStr, &idHelp);

		UINT uFlag = (iCmdStat & CMD_CHECK) ? MF_CHECKED : MF_UNCHECKED;
		::CheckMenuItem(hMenu, iMenu, MF_BYPOSITION | uFlag);

		uFlag = (iCmdStat & CMD_ACTIVE) ? MF_ENABLED : MF_GRAYED;
		::EnableMenuItem(hMenu, iMenu, MF_BYPOSITION | uFlag);
	}

	return TRUE;
} // end FInitMenu

PICS_CHANNEL CIChat::PicsChannel(void)
{
	m_csData.Lock();
	PICS_CHANNEL pics = m_pChannel;
	if (m_pChannel)
	{
		m_pChannel->AddRef();
	}
	m_csData.Unlock();
	return pics;
}

void CIChat::SetGotList(BYTE bGot)
{
	m_csData.Lock();
	m_bGotList = bGot;
	m_csData.Unlock();
}

BYTE CIChat::BGotList(void)
{
	m_csData.Lock();
	BYTE bGot = m_bGotList;
	m_csData.Unlock();
	return bGot;
}

BOOL CIChat::FHandleServerErrors(HRESULT hr)
{
	// FIX ME - for MIC ONLY 
	return FHandleChatSockErrors(m_hWnd, hr);
}

BOOL CIChat::FHandleChannelMsg(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	if (!pcsMsg)
	{
		return FALSE;
	}

	switch (pcsMsg->csMsgType)
	{
	default:
		break;

	case CSMSG_TYPE_ERROR:
		{
		PCS_ERROR pErr = (PCS_ERROR)(pcsMsg + 1);
		if (!FHandleServerErrors(pErr->hr))
		{
			// Server problems. Gotta stop
			AssertSz(0, "server problems. Exiting!");
			::PostMessage(m_hWnd, WM_COMMAND, MAKEWPARAM(IDC_LEAVECHANNEL, 0), 0);
		}
		break;
		}
	case CSMSG_TYPE_TEXT_A:
		m_cchp.FHandleMsg(pcsMsg, m_pChannel);
		break;

	case CSMSG_TYPE_ADDMEMBER:
		FAddMember(pcsMsg);
		break;

	case CSMSG_TYPE_GOTMEMLIST:
		SetGotList(1);
		break;

	case CSMSG_TYPE_DELMEMBER:
		FDelMember(pcsMsg);
		break;

	case CSMSG_TYPE_DELCHANNEL:
		// Exit this chat
		FKickAlert();	// if we were kicked, this will alert the user
		::PostMessage(m_hWnd, WM_COMMAND, MAKEWPARAM(IDC_EXIT, 0), 0);
		break;

	case CSMSG_TYPE_MODEMEMBER:
		FUpdateMember(pcsMsg);
		break;
	
	case CSMSG_TYPE_MODECHANNEL:
		FHandleModeChannel(pcsMsg);
		break;

	case CSMSG_TYPE_WHISPERTEXT_A:
		m_cchp.FHandleWhisper(pcsMsg, m_pChannel);
		break;

	case CSMSG_TYPE_NEWTOPIC:
		FSetWindowTitle();
		break;

	case CSMSG_TYPE_PROPERTYDATA:
		ParsePropertyData(pcsMsg, m_cchp.Pui(), m_hWnd);
		break;

	case CSMSG_TYPE_NEWNICK:
		// Nick name changed
		FUpdateNick(pcsMsg);
		FSetStatusBar();
		break;
	}

	::HrFreeMsg(pcsMsg);

	return TRUE;
}

// THREADS
DWORD CIChat::DwMessageThread(void)
{
	Assert(m_pChannel);
	PICS_CHANNEL pChannel = PicsChannel();
	if (!pChannel)
	{
		AssertSz(0, "Whoa!Channel vanished");
		return FALSE;
	}

	PCS_MSGBASE pcsMsg;
	HRESULT hr;
	while (SUCCEEDED(hr = pChannel->HrWaitForMsg(&pcsMsg, INFINITE)))
	{
		// Got another message. Post the msg to the GUI thread.. and let it do the FREEING
		// i.e it will call HrFreeMsg. The only one we should specifically handle is DEL_CHANNEL..
		// because we want to free this thread..
		/*
		switch (pcsMsg->csMsgType)
		{
		default:
			::PostMessage(m_hWnd, ID_MSG_CHATSOCK, 0, (LPARAM)pcsMsg);
			break;
					
		case CSMSG_TYPE_DELCHANNEL:
			::HrFreeMsg(pcsMsg);
			// Exit this chat
			::PostMessage(m_hWnd, WM_COMMAND, MAKEWPARAM(IDC_EXIT, 0), 0);
			break;
		}
		*/
		DebugMessageType("CIChat::DwMessageThread", pcsMsg->csMsgType);
		::PostMessage(m_hWnd, ID_MSG_CHATSOCK, 0, (LPARAM)pcsMsg);
	}
	pChannel->Release();
	return (DWORD)hr;
}

BOOL CIChat::FIsEchoSourceChat(void)
{
	DWORD dwFlags;
	if (FAILED(m_pChannel->HrGetFlags(&dwFlags)))
	{
		AssertSz(0, "HrGetFlags");
		return FALSE;
	}
	return (0 != (dwFlags & CS_CHANNEL_FLAG_ECHOSOURCE));
}

BOOL CIChat::FIsRoomChat(void)
{
	DWORD dwFlags;
	if (FAILED(m_pChannel->HrGetFlags(&dwFlags)))
	{
		AssertSz(0, "HrGetFlags");
		return FALSE;
	}
	return (0 != (dwFlags & CS_CHANNEL_FLAG_ROOM));
}

BOOL CIChat::FIsModeratedChat(void)
{
	DWORD dwType;
	if (FAILED(m_pChannel->HrGetType(&dwType)))
	{
		AssertSz(0, "HrGetType");
		return FALSE;
	}
	return (0 != (dwType & CS_CHANNEL_MODERATED));
}

BOOL CIChat::FIsWhisperActive(void)
{
	DWORD	dwMode;
	if (FAILED(m_pChannel->HrGetType(&dwMode)))
	{
		AssertSz(0, "HrGetFlags");
		return FALSE;
	}

	BOOL fNoWhisper = (0 != (dwMode & CS_CHANNEL_NOWHISPER));
	int iCount = m_cclp.IGetSelCount();
	if (fNoWhisper || !FAmISpeaker() || iCount <= 0 || iCount > CS_CMAX_WHISPERMEMBERS ||
		m_ccsp.GetSendTextLength() <= 0 || FIsRoomChat())
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CIChat::FAddMember(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	PCS_MSGMEMBER pMsgMem = (PCS_MSGMEMBER)(pcsMsg + 1);
	Assert(pMsgMem->picsMember);
	// Update user count
	m_csb.FUpdateUserCount(m_pChannel);

	if (!m_cclp.FAddMember(pcsMsg))
	{
		return FALSE;
	}
	
	if (FIsMemberMe(pMsgMem->picsMember))
	{
		// Save us in a local variable for fast access
		m_pMemMe = pMsgMem->picsMember;
		m_pMemMe->AddRef();
		// If the member is US..the Send Pane may want to disable stuff based on our settings
		m_ccsp.FMemberModeChange(m_pChannel, m_pMemMe);
		// And redo the statusbar to contain the Nick
		FSetStatusBar();
	}
	// Room chats do not need any UI..
	if (FNotifyJoin() && 1 == BGotList() && !FIsRoomChat())
	{
		BOOL fRet = m_cchp.FHandleAddMember(pMsgMem->picsMember);
	}
	// Make sure there is something selected
	if (m_cclp.IGetSelCount() < 1)
	{
		(m_cclp.PListBox())->SelectItem(0);
	}

	return TRUE;
}

BOOL CIChat::FDelMember(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);

	PCS_MSGMEMBER pMsgMem = (PCS_MSGMEMBER)(pcsMsg + 1);
	Assert(pMsgMem->picsMember);
	// Update user count
	m_csb.FUpdateUserCount(m_pChannel);
	
	if (!m_cclp.FDelMember(pcsMsg))
	{
		return FALSE;
	}
	// Someone was kicked..
	if (pMsgMem->picsMemSrc)
	{
		// If the member being kicked was US.. notify the user
		if (m_pMemMe == pMsgMem->picsMember)
		{
			m_pMemKick = pMsgMem->picsMemSrc;
			m_pMemKick->AddRef();
			// Also save the reason, if any.. and only if its ANSI
			if (pMsgMem->pvReason && pMsgMem->fAnsi)
			{
				int cch = ::lstrlen((CHAR *)pMsgMem->pvReason);
				m_szReason = new CHAR[++cch];
				if (m_szReason)
				{
					::CopyMemory((PVOID)&m_szReason[0], pMsgMem->pvReason, cch);
				}
			}
		}
	}
	else if (!FNotifyLeave() || FIsRoomChat())
	{
		return TRUE;	// no formatting for room chats
	}
	return m_cchp.FHandleDelMember(pMsgMem->picsMember);
}

BOOL CIChat::FKickAlert(void)
{
	if (!m_pMemKick)
	{
		return FALSE;
	}
	// Who kicked us?
	BYTE*		pbKick;
	BOOL		fAnsi;
	HRESULT		hr		= m_pMemKick->HrGetName(&pbKick, &fAnsi);
	TCHAR*		szKick	= (FAILED(hr) || !fAnsi) ? "" : (TCHAR*)pbKick;
	HINSTANCE	hInst	= HInstGet();
	TCHAR*		szFormat = GetSz(hInst, IDS_ERR_KICKED);
	if (szFormat)
	{
		TCHAR szTemp[512];
		::wsprintf(szTemp, szFormat, szKick, (m_szReason) ? m_szReason : "");
		::MessageBox(m_hWnd, szTemp, GetSz(hInst, IDS_APPTITLE), MB_ICONEXCLAMATION | MB_OK);
	}
	return TRUE;
}

BOOL CIChat::FUpdateMember(PCS_MSGBASE pcsMsg, BOOL fMode)
{
	Assert(pcsMsg);
	PCS_MSGMEMBER pMsgMem = (PCS_MSGMEMBER)(pcsMsg + 1);
	Assert(pMsgMem->picsMember);

	if (fMode)
	{
		// Status update
		m_cchp.FHandleModeChannel(pMsgMem->picsMember);
		// The Send Pane may wish to take some action ..such as disable buttons
		m_ccsp.FMemberModeChange(m_pChannel, pMsgMem->picsMember);
	}

	if (!m_cclp.FUpdateMember(pcsMsg))
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CIChat::FUpdateNick(PCS_MSGBASE pcsMsg)
{	
	if (m_cclp.FUpdateNick(pcsMsg))
	{
		m_cchp.FHandleNickChange(pcsMsg);
	}
	
	return TRUE;
}

BOOL CIChat::FHandleModeChannel(PCS_MSGBASE pcsMsg)
{
	Assert(pcsMsg);
	// Send pane may want take some action for this mode change
	m_ccsp.FChannelModeChange(m_pChannel);
	// As may the list pane
	m_cclp.FChannelModeChange(m_pChannel);

	if (m_bModeSkip <= 0)
	{
		if (IDYES == FDoAlert(m_hWnd, IDS_CHANMODECHANGED, ALERT_YESNO))
		{
			return FChannelProperties();
		}
	}
	else
	{
		--m_bModeSkip;
	}
	return TRUE;
}

BOOL CIChat::FTabKeyNav(int idCmd, BOOL fShift)
{
	HWND hWnd = ::GetFocus();
	if (hWnd == (m_cchp.Pui())->HWnd())
	{
		// history -> List/Browser
		if (fShift)
		{
			goto LFocusBrowser;
		}
		else
		{
			goto LFocusList;
		}
	}
	else if (hWnd == (m_ccsp.Pui())->HWnd())
	{
		// Send -> Browser/List
		if (fShift)
		{
			goto LFocusList;
		}
		else
		{
			goto LFocusBrowser;
		}
	}
	else if (hWnd == (m_cclp.PListBox())->HWnd())
	{
		// List->Send/History
		if (fShift)
		{
			goto LFocusHistory;
		}
		else
		{
			goto LFocusSend;
		}
	}
	else if (hWnd == (m_pccfp->PTreeView())->HWnd())
	{
		// Browser -> History/Send
		if (fShift)
		{
			goto LFocusSend;
		}
		else
		{
			goto LFocusHistory;
		}
	}

LFocusSend:
	(m_ccsp.Pui())->HWndSetFocus();
	goto LReturn;

LFocusList:
	(m_cclp.PListBox())->HWndSetFocus();
	goto LReturn;

LFocusBrowser:
	if (m_pccfp->FIsVisible() && m_pctLH > 0)
	{
		(m_pccfp->PTreeView())->HWndSetFocus();
		goto LReturn;
	}
	else
	{
		goto LFocusHistory;
	}

LFocusHistory:
	(m_cchp.Pui())->HWndSetFocus();
	goto LReturn;

LReturn:
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////////////
// WndProc
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CIChat* pci = (CIChat*)::GetWindowLong(hWnd, GWL_USERDATA);
	if (pci)
	{
		switch (uMsg)
		{
		default:
			break;
		
		case WM_ACTIVATE: 
			::EnableWindow(hWnd, (WA_INACTIVE == LOWORD(wParam)) ? TRUE : !FDisableAll());
			break;

		case WM_CLOSE:
			Assert(pci);
			return pci->FCloseChannel();

		case WM_SIZE:
			if (wParam != SIZE_MINIMIZED && wParam != SIZE_MAXHIDE)
			{
				Assert(pci);
				pci->FSizeAll();
			}
			return(0); 

		case WM_SETFOCUS:
			SetForeInstance(hWnd);
			pci->SetDefaultFocus();
			break;
		
		case WM_INITMENUPOPUP:
			if ((BOOL)HIWORD(lParam))
			{
				break;	// system menu
			}

			if (pci->FInitMenu((HMENU)wParam, (UINT)LOWORD(lParam)))
			{
				return FALSE;
			}
			break;

		case WM_NOTIFY:
			Assert(pci);
			return pci->FHandleNotify((NMHDR *)lParam);

		case WM_COMMAND:
			Assert(pci);
			switch (LOWORD(wParam))
			{
			default:
				return pci->FHandleCommand(wParam, lParam);

			case IDC_EXIT:
				delete pci;
				return TRUE;

			case ID_GETUIPTR:
				return (LRESULT)pci->m_cchp.Pui(); 
			
			case IDC_TABKEY:
			case IDC_TABKEYSHIFT:
				// Shift focus based on what is current in focus
				pci->FTabKeyNav(LOWORD(wParam), IDC_TABKEYSHIFT == LOWORD(wParam));
				break;
			}
			break;

		case WM_HELP:
			pci->FDoHelp();
			break;

		case ID_MSG_CHATSOCK:
			return pci->FHandleChannelMsg((PCS_MSGBASE)lParam);
		}
	}
	return (::DefWindowProc(hWnd, uMsg, wParam, lParam));
}

////////////////////////////////////////////////////////////////////////////////////////
// Main Proc
// Thread that is the main thread for this instance
// DWORD __stdcall DwMainThreadProc(PVOID pvData)
// {
//	Assert(pvData);
//	PCI_CHAT pChat = (PCI_CHAT)pvData;
//	return pChat->DwMainThread();
//}

////////////////////////////////////////////////////////////////////////////////////////
// Msg Proc - from ChatSock
// Separate thread that is launched to poll ChatSock for messages
DWORD __stdcall DwMessageThreadProc(PVOID pvData)
{
	Assert(pvData);
	PCI_CHAT pChat = (PCI_CHAT)pvData;
	return pChat->DwMessageThread();
}

////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK DwDlgProcStub(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	default:
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		default:
			break;

		case IDOK:
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;
	}
	return FALSE;
}
