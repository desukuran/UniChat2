//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICLOGIN__
#define __ICLOGIN__

#include "icinc.h"
#include "icwizard.h"
#include "icref.h"

class	CKeepTime;
class	CShowTime;

class	CChatConnect;
class	CConSettings;

typedef CKeepTime		IC_KEEPTIME, *PIC_KEEPTIME;
typedef CShowTime		IC_SHOWTIME, *PIC_SHOWTIME;
typedef CChatConnect	IC_CONNECT, *PIC_CONNECT;

typedef CConSettings	IC_SETTINGS;

////////////////////////////////////////////////////////////////////////////
class CKeepTime
{
// Interfaces
public:
	CKeepTime(void);
	~CKeepTime(void);

	BOOL	FSetTimer(HWND hWnd, UINT uiId, UINT uiElapse);
	void	KillTimer(HWND hWnd);
	void	UpTimer(void);
// Data
protected:
	UINT	m_uiTime;		// time elapsed
	UINT	m_uiTimer;	
	UINT	m_uiElapse;
};

class CShowTime : public CKeepTime
{
// Interfaces
public:
	CShowTime(void);
	~CShowTime(void);

	BOOL	FDisplayTime(HWND hWndParent, int idLbl);
	BOOL	FInit(HINSTANCE hInst);
// Data
protected:
	TCHAR	m_szSeconds[32];
	TCHAR	m_szTimer[64];
};

/*
class CChatConnect : public CChatWizard
{
friend BOOL CALLBACK ConnectServerDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam); 
friend BOOL CALLBACK ConnectCancelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
//
// Interfaces
//
public:
	CChatConnect(void);
	~CChatConnect(void);

	BOOL	FConnectDlg(HWND hWndParent, TCHAR *szServer = NULL);
	CHAR*	PszServer(void) { return m_szServer; }
	TCHAR*	PszUser(void)	{ return m_szUserName; }
	TCHAR*	PszPass(void)	{ return m_szPassword; }
	TCHAR*	PszNick(void)	{ return m_szNick; }

	HRESULT	Hr(void)	{ return m_hr; }

	HRESULT	HrConnect(void);
	HRESULT	HrLogin(void);

	virtual	void	Free(void)	{ delete this; }
	
protected:
	BOOL	FInitServerDlg(HWND hDlg);
	BOOL	FNotifyServer(HWND hDlg, LPARAM lParam);
	BOOL	FGetServerParams(void);
	BOOL	FSetServerActive(HWND hDlg);

	BOOL	FInitCancelDlg(HWND hDlg);
	BOOL	FNotifyCancel(HWND hDlg, LPARAM lParam);
	BOOL	FSetCancelActive(HWND hDlg);

	BOOL	FCancelConnect(HWND hDlg);
	BOOL	FCreateChatSocket(BYTE csType = CS_MIC);
	
	void	WaitForConnectThread(void);

	BOOL	FBuildConnInfo(PCS_CONNINFO pcs, BYTE bConnType = CS_CONNECT_ANONYMOUS);
// Data
protected:
	CHAR			m_szServer[MAX_PATH + 1];			
	TCHAR			m_szNick[CS_CCHMAX_MIC_NICK + 1];	
	TCHAR			m_szUserName[CS_CCHMAX_MIC_USERNAME + 1];
	TCHAR			m_szPassword[CS_CCHMAX_MIC_PASS + 1];
	HRESULT			m_hr;

	IC_SHOWTIME		m_st;
	CS_THREAD		m_csConnect;

	PICS_FACTORY	m_picsFactry;
};
*/

// New class for Logging IN. Much smarter than before
class CLogin
{
friend DWORD __stdcall DwConnectProc(PVOID pvData);
friend BOOL CALLBACK DwCancelDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CLogin(void);
	~CLogin(void);
					
	BOOL			FConnect(HWND hWndParent, CHAR* szServer);			
	PICS			Pics(void)		{ return m_pics; }
	HRESULT			HResult(void)	{ return m_hr; }
protected:
	void			WaitForConnectThread(void);
	BOOL			FCancel(void);
	int				FInitDlg(HWND hDlg, BOOL fAll = TRUE);
			
	BOOL			FInit(HWND hWndParent, CHAR* szServer);
	BOOL			FCancelDialog(void);
	BOOL			FStop(void);
	BOOL			FStopDlg(BOOL fCancel);
	BOOL			FEndDialog(int iRes);

	BOOL			FStartConnect(HWND hDlg);
	HRESULT			HrDoConnect(void);
	HRESULT			HrLogin(void);
	BOOL			FCheckError(void);
	int				FCanAuthenticate(void);
	BOOL			FCanAnonymous(void);
	BOOL			FVerifyLoginParams(void);
	BOOL			FDoSettings(void);
	BOOL			FConnectionSettings(HWND hDlg, UINT uFirstPage);

	void			CleanUp(BOOL fClose = TRUE);
// Data
protected:
	// Connection
	CHAR			m_szServer[MAX_PATH + 1];
	PICS_FACTORY	m_picsFactry;
	PICS			m_pics;
	HRESULT			m_hr;
	BOOL			m_fAnon;
	// Login
	TCHAR			m_szNick[CS_CCHMAX_MIC_NICK + 1];
	TCHAR			m_szNickBack[CS_CCHMAX_MIC_NICK + 1];
	TCHAR			m_szUserName[CS_CCHMAX_MIC_USERNAME + 1];
	TCHAR			m_szSecurity[256];
	// Settings
	CConSettings*	m_picConn;
	// Cancel Dialogs
	HWND			m_hWndParent;
	HWND			m_hDlg;
	CS_THREAD		m_csConnect;
	BOOL			m_fStop;
	CS_LOCK			m_cs;
	IC_SHOWTIME		m_st;
	BOOL			m_fSettings;
	BOOL			m_fAuto;
	UINT			m_uFirstPage;
};

// Connection settings
class CConSettings : public CChatPropertyPage
{
friend BOOL CALLBACK ServerDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
friend BOOL CALLBACK NickDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
friend BOOL CALLBACK OptionsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
// Interfaces
public:
	CConSettings(void);
	~CConSettings(void);

	BOOL			FSettingsDlg(HWND hWndParent, CHAR *szServer, UINT uFirstPage = 0);
	BOOL			FInitServer(CHAR *szServer);
	CHAR*			PszServer(void)	{ return m_szServer; }
	virtual	void	Free(void)		{ delete this; }

protected:
	BOOL			FInitServerDlg(HWND hDlg);
	BOOL			FInitNickDlg(HWND hDlg);
	BOOL			FInitOptionsDlg(HWND hDlg);

	BOOL			FGetServerParams(HWND hDlg);
	BOOL			FGetNickParams(HWND hDlg);
	BOOL			FGetOptionsParams(HWND hDlg);

	BOOL			FNotifyServer(HWND hDlg, LPARAM lParam);
	BOOL			FNotifyNick(HWND hDlg, LPARAM lParam);
	BOOL			FNotifyOptions(HWND hDlg, LPARAM lParam);

	BOOL			FVerifyNick(HWND hDlg);
// Data
protected:
	CHAR			m_szServer[MAX_PATH + 1];	
	TCHAR			m_szNick[CS_CCHMAX_MIC_NICK + 1];
	TCHAR			m_szNickBack[CS_CCHMAX_MIC_NICK + 1];
	TCHAR			m_szUserName[CS_CCHMAX_MIC_USERNAME + 1];
};

#endif
