//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __ICBTN__
#define __ICBTN__

//--------------------------------------------------------------------------------------------
//
// INCLUDES
//
//--------------------------------------------------------------------------------------------
#include "icinc.h"
#include "icpane.h"
#include "ownbtn.h"

//--------------------------------------------------------------------------------------------
//
// CLASSES
//
//--------------------------------------------------------------------------------------------

//
// USUALLY a Sub pane in the send pane. This contains various buttons
// The buttons live inside a standard Windows TOOLBAR. This provides great flexibility
//
//
class CChatBtnPane:public CChatPane
{
friend	LRESULT CALLBACK BtnWndProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
//
// interfaces
//
public:
	CChatBtnPane(void);
	~CChatBtnPane(void);

			BOOL		FEnableButtons(BOOL fEnable);
			BOOL		FEnableSendButton(BOOL fEnable);
			BOOL		FEnableWhisperButton(BOOL fEnable);

protected:
	virtual	BOOL		FInitElements(void);
	virtual	BOOL		FHandleWMSize(WPARAM wParam,LPARAM lParam);
			BOOL		FGetSendBtnRect(RECT *prc);
			BOOL		FGetWhisperBtnRect(RECT *prc);
//
// Data
//
protected:
			CLiteFontButton		m_clfb;			// the lite font button
			CLiteFontButton		m_clfbWhisper;	// the lite font button
			SIZE				m_sizeExtent;	// text extent

};


#endif
