//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#include "icpch.h"
#include "ownbtn.h"

//--------------------------------------------------------------------------------------------
// GLOBALS
//--------------------------------------------------------------------------------------------
const TCHAR	gBtnClass[] = TEXT("BUTTON");

CFontButton::CFontButton(void)
	:CChatChildWnd()
{
	m_hFont = NULL;
}

CFontButton::~CFontButton(void)
{
	if (m_hFont)
	{
		::DeleteObject((HGDIOBJ)m_hFont);
	}
}

BOOL CFontButton::FCreate(HWND hWndParent, int idCtl, RECT *prc, BOOL fDefault)
{
	// First create the button
	if (!CChatChildWnd::FCreate(hWndParent, idCtl, prc, (TCHAR*)gBtnClass,
								WS_CHILD | WS_VISIBLE | BS_TEXT |
								((fDefault) ? BS_DEFPUSHBUTTON : BS_PUSHBUTTON),
								0, NULL))
	{
		return FALSE;
	}

	// Now tweak the font
	// Get current font
	HFONT	hFont = (HFONT) SendMessage(WM_GETFONT);
	if (!hFont)
	{
		hFont = (HFONT) GetStockObject(SYSTEM_FONT);
	}
	if (!hFont)
	{
		Assert(FALSE);
		return FALSE;
	}
	// set font to lite
	GetFont(hFont);
	if (!m_hFont)
	{
		return FALSE;
	}
	
	SendMessage(WM_SETFONT, (WPARAM)m_hFont);

	return TRUE;
}

// LITE font button
void CLiteFontButton::GetFont(HFONT hFont)
{
	Assert(hFont);
	// set font to lite
	m_hFont = HfontChangeFontWeight(hFont, FW_THIN);
}

// HEAVY font button
void CHeavyFontButton::GetFont(HFONT hFont)
{
	Assert(hFont);
	// set font to lite
	m_hFont = HfontChangeFontWeight(hFont, FW_NORMAL);
}

// COLOR button
CColorButton::CColorButton(void)
{
	m_wndProc	= NULL;
	m_hWnd		= NULL;
	m_cRef		= RGB(0, 0, 255);
	m_hBrush	= NULL;
	m_fButton	= FALSE;
}

CColorButton::~CColorButton(void)
{
	if (m_hBrush)
	{
		::DeleteObject(m_hBrush);
	}
}

BOOL CColorButton::FInit(HWND hDlg, int idBtn)
{
	Assert(hDlg);
	// Subclass the window
	m_hWnd = HWndGetDlgItem(hDlg, idBtn);
	if (m_hWnd)
	{
		m_wndProc = (WNDPROC) ::SetWindowLong(m_hWnd, GWL_WNDPROC, (LONG)ColorButtonProc);	    	
		if (!m_wndProc)
		{
			AssertGLE(FALSE);
			return FALSE;
		}
		::SetWindowLong(m_hWnd, GWL_USERDATA, (LONG)this); 
	}

	m_hBlack = (HBRUSH) ::GetStockObject(BLACK_BRUSH);
	SetColor(m_cRef);
	// Save the client Rect
	return (::GetClientRect(m_hWnd, &m_rc));
}

void CColorButton::SetColor(COLORREF cRef)
{
	if (m_hWnd)
	{
		// Create a new brush
		if (FCreateBrush(cRef))
		{
			// Force a redraw with the new color 
			if (!::InvalidateRect(m_hWnd, &m_rc, TRUE))
			{
				AssertGLE(FALSE);
			}
		}
	}
}

BOOL CColorButton::FCreateBrush(COLORREF cRef)
{
	HBRUSH hBrush = ::CreateSolidBrush(cRef);	// make a new brush to draw the button
	if (!hBrush)
	{
		AssertGLE(FALSE);
		return FALSE;
	}
	// Delete what we have and save the new guy
	if (m_hBrush)
	{
		::DeleteObject(m_hBrush);
	}
	m_hBrush = hBrush;
	m_cRef = cRef;

	return TRUE;
}

BOOL CColorButton::FDrawButton(LPARAM lParam, BOOL fMouse)
{
	if (!m_hBrush || !m_hBlack)
	{
		return FALSE;
	}

	RECT	rc;
	BOOL	fRet = FALSE;

	HDC hDC = ::GetDC(m_hWnd);
	if (NULL == hDC)
	{
		AssertGLE(FALSE);
		goto LCleanUp;
	}
	// Fill the rect and draw a white bounding rect
	::CopyMemory(&rc, &m_rc, sizeof(RECT));
	// Is the mouse in the client region?
	rc.left +=4;
	rc.right -= 5;
	rc.top += 4;
	rc.bottom -= 5;
	if (m_fButton && fMouse)
//if (fMouse)
	{
//		POINT pt;

//		pt.x = LOWORD(lParam);
//		pt.y = HIWORD(lParam);
//		if (::PtInRect(&m_rc, pt))
		{
			rc.left += 1;
			rc.right += 1;
			rc.top += 1;
			rc.bottom += 1;
		}
	}

	if (!::FillRect(hDC, &rc, m_hBrush) || !::FrameRect(hDC, &rc, m_hBlack))
	{
		AssertGLE(FALSE);
		goto LCleanUp;
	}
	fRet = TRUE;

LCleanUp:
	if (hDC)
	{
		::ReleaseDC(m_hWnd, hDC);
	}
	return fRet;
}

BOOL CColorButton::FDoPopUp(void)
{
	COLORREF cRef;

	if (FChooseColor(m_hWnd, m_cRef, &cRef))
	{
		SetColor(cRef);
	}
	
	return ::InvalidateRect(m_hWnd, &m_rc, TRUE);
}

LRESULT CColorButton::LCallWindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lr;

#ifdef STRICT
	lr = ::CallWindowProc((WNDPROC)m_wndProc, m_hWnd, uMsg, wParam, lParam);
#else
	lr = ::CallWindowProc((FARPROC)m_wndProc, m_hWnd, uMsg, wParam, lParam);
#endif
	return lr;
}

// Subclass button
LRESULT CALLBACK ColorButtonProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CColorButton* pcb = (CColorButton*)::GetWindowLong(hWnd, GWL_USERDATA);
	LRESULT lr = pcb->LCallWindowProc(uMsg, wParam, lParam);

	switch (uMsg)
	{
	default:
		break;
	
	case BM_SETSTATE:
		pcb->m_fButton = (BOOL)wParam;
		pcb->FDrawButton(0, TRUE);
		break;

	case WM_PAINT:
		// Let the button draw itself first, then we'll draw the color on top
		pcb->FDrawButton(0, TRUE);
		return TRUE;
	}
	return lr;
}
