 /*--------------------------------------------------------------------------
	mtlist.h
		
    Copyright (C) 1993-96 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef __MTLIST__
#define __MTLIST__

#include "stlist.h"

/////////////////////////////////////////////////////////////////////////////

class CMtList : public CStList
{
public:

// Construction
	CMtList(int nBlockSize=10);
	
// Attributes (head and tail)
	// count of elements
	int GetCount(); 
	BOOL IsEmpty() const;

	// peek at head or tail
	//VOID*& GetHead();
	VOID* GetHead();
	//VOID*& GetTail();
	VOID* GetTail();

// Operations
	// get head or tail (and remove it) - don't call on empty list !
	VOID* RemoveHead();
	VOID* RemoveTail();

	// add before head or after tail
	POSITION AddHead(VOID* newElement);
	POSITION AddTail(VOID* newElement);

	// add another list of elements before head or after tail
	void AddHead(CMtList* pNewList);
	void AddTail(CMtList* pNewList);

	// remove all elements
	void RemoveAll();

	// iteration
	POSITION GetHeadPosition();
	POSITION GetTailPosition();
	VOID*& GetNext(POSITION& rPosition); // return *Position++
	//VOID* GetNext(POSITION& rPosition); const // return *Position++
	VOID*& GetPrev(POSITION& rPosition); // return *Position--
	//VOID* GetPrev(POSITION& rPosition) const; // return *Position--

	// getting/modifying an element at a given position
	VOID*& GetAt(POSITION position);
	VOID* GetAt(POSITION position) const;
	void SetAt(POSITION pos, VOID* newElement);
	void RemoveAt(POSITION position);

	// inserting before or after a given position
	POSITION InsertBefore(POSITION position, VOID* newElement);
	POSITION InsertAfter(POSITION position, VOID* newElement);

	// helper functions (note: O(n) speed)
	POSITION Find(VOID* searchValue, POSITION startAfter = NULL);
						// defaults to starting at the HEAD
						// return NULL if not found
	POSITION FindIndex(int nIndex);
						// get the 'nIndex'th element (may return NULL)

// Implementation
protected:
	CRITICAL_SECTION	m_cs;	// thread-safety

public:
	~CMtList();

};

#endif // MTLIST_H

