//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __CSMEMORY__
#define __CSMEMORY__

#include <windows.h>

#ifdef DEBUG
	void CheckForLeaks(TCHAR* pszApp);
	void InitLeakCheck(void);
	void ReleaseLeakCheck(void);
	void ClearLeakCount(void);
#endif

void*	MemoryAlloc(size_t cb);
void	MemoryDeAlloc(void* pv);

#endif
