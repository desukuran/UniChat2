//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation,  1996
//
//--------------------------------------------------------------------------------------------

#ifndef __CSLIB__
#define __CSLIB__

#include <windows.h>

BOOL	FSzDuplicateA(CHAR* psz, CHAR** ppszCopy);
BOOL	FSzCopyBufAsSzA(BYTE* psb, DWORD dwcb, CHAR** ppszCopy);
BOOL	FSzDuplicateW(WCHAR* psz, WCHAR** ppszCopy);
BOOL	FSzCopyBufAsSzW(BYTE* psb, DWORD dwcb, WCHAR** ppszCopy);

int		GetCbSz(CHAR* psz);
int		GetCbSz(WCHAR* psz);

int		CChSz(CHAR* psz);
int		CChSz(WCHAR* psz);

void	CopyBytes(BYTE** ppbCopy, BYTE* pbSrc, int cbData, BOOL fNull, BOOL fAnsi);
#endif
