//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996-97
//
//--------------------------------------------------------------------------------------------

#ifndef __CSLOCK__
#define __CSLOCK__

#include <windows.h>

class CSLock;

typedef CSLock	CS_LOCK;

class CSLock
{
public:
	CSLock(void)		{ ::InitializeCriticalSection(&m_cs); }
	~CSLock(void)		{ ::DeleteCriticalSection(&m_cs); }
	void Lock(void)		{ ::EnterCriticalSection(&m_cs); }
	void Unlock(void)	{ ::LeaveCriticalSection(&m_cs); }
protected:
	CRITICAL_SECTION	m_cs;
};

#endif

