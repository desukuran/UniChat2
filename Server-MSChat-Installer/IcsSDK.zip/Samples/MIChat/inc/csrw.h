//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996-97
//
//--------------------------------------------------------------------------------------------

#ifndef __CSREADWRITE__
#define __CSREADWRITE__

#include "cslock.h"

class CSReadWrite;

typedef CSReadWrite CS_READWRITE;

//--------------------------------------------------------------------------------------------
class CSReadWrite
{
// Interfaces
public:
	CSReadWrite(void);
	~CSReadWrite(void);
	
	BOOL	FInitReadWrite(void);

	void	ReadLock(void);
	void	ReadUnlock(void);

	void	WriteLock(void);
	void	WriteUnlock(void);
protected:
	BOOL	FWaitForEvent(void);
// Data
protected:
	HANDLE	m_hEvent;		// event for write synch
	CS_LOCK	m_csRead;		// use to synchronize writers
	CS_LOCK	m_csWrite;		// and use to allow writers to have precedence on readers!
	DWORD	m_cReaders;		// how many readers?
};

#endif
