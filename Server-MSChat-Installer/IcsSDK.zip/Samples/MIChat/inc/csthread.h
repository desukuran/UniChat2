//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __CSTHREAD__
#define __CSTHREAD__

#include <windows.h>

class	CSThread;
class	CSEvent;

typedef CSThread	CS_THREAD;
typedef CSEvent		CS_EVENT;

class CSSystemObj
{
// Interfaces
public:
	CSSystemObj(void);
	~CSSystemObj(void);

	DWORD		DwWaitForObject(DWORD dwTimeOut);
	void		CloseHandle(void);
	HANDLE		Handle(void)	{ return m_handle; }
// Data
protected:
	HANDLE		m_handle;
};

class CSThread : public CSSystemObj
{
// Interfaces
public:
	CSThread(void);
	~CSThread(void);

	BOOL		FIsThreadActive(void);
	BOOL		FCreateThread(LPTHREAD_START_ROUTINE lpProc,LPVOID lpParam);
	inline		DWORD DwGetThreadID(void) { return m_dwID; }

	DWORD		DwWaitForThread(DWORD dwTimeOut) { return DwWaitForObject(dwTimeOut); }

	BOOL		FTerminateThread(void);
	void		StopThread(void);
	void		CloseThreadHandle(void) { CloseHandle(); }

	BOOL		FGetExitCode(DWORD* pdw);
// Data
protected:
	DWORD		m_dwID;
};

// Operating system event
class CSEvent : public CSSystemObj
{
// Interfaces
public:
	CSEvent(void);
	~CSEvent(void);

	BOOL		FCreate(TCHAR* pszName);
	BOOL		FSetEvent(void)		{ return (m_handle) ? ::SetEvent(m_handle) : FALSE; }
	BOOL		FResetEvent(void)	{ return (m_handle) ? ::ResetEvent(m_handle) : FALSE; }
// Data
protected:
};

// Operating system mutex
class CSMutex : public CSSystemObj
{
// Interfaces
public:
	CSMutex(void);
	~CSMutex(void);
	BOOL		FCreate(TCHAR* pszName);
	BOOL		FRelease(void)	{ return (m_handle) ? ::ReleaseMutex(m_handle) : FALSE; }
// Data
protected:
};

#endif

