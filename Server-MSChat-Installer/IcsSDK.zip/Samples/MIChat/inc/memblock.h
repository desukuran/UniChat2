//--------------------------------------------------------------------------------------------
//
//	Copyright (c) Microsoft Corporation, 1996
//
//--------------------------------------------------------------------------------------------

#ifndef __MEMBLOCK__
#define __MEMBLOCK__

#include <windows.h>

class CMemoryBlockChain;
class CMemBlock;
class CHeap;

typedef CMemoryBlockChain	MEM_BLOCK, *PMEM_BLOCK;
typedef CMemoryBlockChain	MEM_CHAIN, *PMEM_CHAIN;

typedef CHeap				HEAP, *PHEAP;

// A class to manages a chain of memory blocks allocated from the SYSTEM. 
// This class can manage a list of VARIED sized blocks and keeps them in a chain.
// To allocate a new block of memory, call PmbCreate.
class CMemoryBlockChain
{
// Interfaces
public:
	CMemoryBlockChain(void);
	~CMemoryBlockChain(void);

	PMEM_BLOCK	PmbCreate(DWORD dwcb);
	void		FreeBlockAndChain(void);
	PVOID		PvData(void)	{ return this+1; } // the memory block hangs below the class header
// Data
public:
	PMEM_BLOCK	m_pmbNext;	// this allows chaining of memory blocks
};

// Classes that enable suballocation within large blocks allocated from the OS
class CMemBlock
{
// Interfaces
public:
	CMemBlock(void)							{ m_pNext = NULL; }
	PVOID		Pv(void)					{ return (this + 1); }
	CMemBlock*	PNext(void)					{ return m_pNext; }
	void		SetNext(CMemBlock* pNext)	{ m_pNext = pNext; }
// Data
protected:
	CMemBlock*	m_pNext;
};

// And the actual Memory Manager
class CHeap
{
// Interfaces
public:
	CHeap(DWORD dwcBlocksGrow, DWORD dwcbBlock);
	~CHeap(void);

	BYTE*		Alloc(void);
	void		Free(BYTE* pb);
	void		CleanUp(void);
// Data
protected:
	MEM_CHAIN		m_memChain;
	DWORD			m_cBlocks;

	DWORD			m_cBlocksGrow;	// how many blocks to grow the heap when required
	DWORD			m_cbBlock;		// size of each sub block
	CMemBlock*		m_pFreeList;	// a list of free nodes	
};

#endif
