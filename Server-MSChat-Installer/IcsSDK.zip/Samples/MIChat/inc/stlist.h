/*--------------------------------------------------------------------------
	stlist.h
		
    Copyright (C) 1993-96 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef __STLIST__
#define __STLIST__

#include <windef.h>

/////////////////////////////////////////////////////////////////////////////

struct CStPlex    // warning variable length structure
{
	CStPlex* pNext;
	UINT nMax;
	UINT nCur;
	/* BYTE data[maxNum*elementSize]; */

	void* data() { return this+1; }

	static CStPlex* PASCAL Create(CStPlex*& head, UINT nMax, UINT cbElement);
			// like 'calloc' but no zero fill
			// may throw memory exceptions

	void FreeDataChain();       // free this one and links
};

/////////////////////////////////////////////////////////////////////////////

typedef void* POSITION;   // abstract iteration position

class CStList
{
protected:
	struct CNode
	{
		CNode* pNext;
		CNode* pPrev;
		VOID* data;
	};
public:
// Construction
	CStList(int nBlockSize=10);
	
// Attributes (head and tail)
	// count of elements
	int GetCount();
	BOOL IsEmpty() const;

	// peek at head or tail
	//VOID*& GetHead();
	VOID* GetHead();
	//VOID*& GetTail();
	VOID* GetTail();

// Operations
	// get head or tail (and remove it) - don't call on empty list !
	VOID* RemoveHead();
	VOID* RemoveTail();

	// add before head or after tail
	POSITION AddHead(VOID* newElement);
	POSITION AddTail(VOID* newElement);

	// add another list of elements before head or after tail
	void AddHead(CStList* pNewList);
	void AddTail(CStList* pNewList);

	// remove all elements
	void RemoveAll();

	// iteration
	POSITION GetHeadPosition();
	POSITION GetTailPosition();
	VOID*& GetNext(POSITION& rPosition); // return *Position++
	//VOID* GetNext(POSITION& rPosition); const // return *Position++
	VOID*& GetPrev(POSITION& rPosition); // return *Position--
	//VOID* GetPrev(POSITION& rPosition) const; // return *Position--

	// getting/modifying an element at a given position
	VOID*& GetAt(POSITION position);
	VOID* GetAt(POSITION position) const;
	void SetAt(POSITION pos, VOID* newElement);
	void RemoveAt(POSITION position);

	// inserting before or after a given position
	POSITION InsertBefore(POSITION position, VOID* newElement);
	POSITION InsertAfter(POSITION position, VOID* newElement);

	// helper functions (note: O(n) speed)
	POSITION Find(VOID* searchValue, POSITION startAfter = NULL);
						// defaults to starting at the HEAD
						// return NULL if not found
	POSITION FindIndex(int nIndex);
						// get the 'nIndex'th element (may return NULL)

// Implementation
protected:
	CNode*	m_pNodeHead;
	CNode*	m_pNodeTail;
	int		m_nCount;
	CNode*	m_pNodeFree;
	struct CStPlex*	m_pBlocks;
	int		m_nBlockSize;

	CNode* NewNode(CNode*, CNode*);
	void FreeNode(CNode*);


#ifdef DEBUG
	VOID WalkCStList();
	VOID WalkTheList(CNode* pNode, CNode* pPrevNode, CNode* pNextNode);

	BOOL m_fInList;			// make sure no reentrancy problems
#endif

public:
	~CStList();
};

#endif // STLIST_H

