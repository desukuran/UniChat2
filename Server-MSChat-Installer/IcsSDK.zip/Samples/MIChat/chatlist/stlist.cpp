/*--------------------------------------------------------------------------
	stlist.cpp
		
    Copyright (C) 1993-96 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include <windows.h>
#include "..\inc\cldbg.h"
#include "..\inc\stlist.h"
#define _AFXCOLL_INLINE 

/////////////////////////////////////////////////////////////////////////////

CStPlex* PASCAL CStPlex::Create(CStPlex*& pHead, UINT nMax, UINT cbElement)
{
	Assert(nMax > 0 && cbElement > 0);

	CStPlex* p = (CStPlex*) ::LocalAlloc(LPTR, sizeof(CStPlex) + nMax * cbElement);
	
	if (p)
	{
		p->nMax = nMax;
		p->nCur = 0;
		p->pNext = pHead;
		pHead = p;  // change head (adds in reverse order for simplicity)
	}

	return p;
}

void CStPlex::FreeDataChain()     // free this one and links
{
	CStPlex* p = this;

	while (p != NULL)
	{
		BYTE* bytes = (BYTE*) p;
		CStPlex* pNext = p->pNext;

		::LocalFree(bytes);
		p = pNext;
	}
}

/////////////////////////////////////////////////////////////////////////////

_AFXCOLL_INLINE int CStList::GetCount() 
{ 
	return m_nCount; 
}

_AFXCOLL_INLINE BOOL CStList::IsEmpty() const 
{ 
	return m_nCount == 0; 
}

//_AFXCOLL_INLINE VOID*& CStList::GetHead()
//	{ Assert(m_pNodeHead != NULL); 
//	  VOID*& data=m_pNodeHead->data; 
//	  return data; }
_AFXCOLL_INLINE VOID* CStList::GetHead() 
{
	Assert(m_pNodeHead);
	if (!m_pNodeHead) 
	{
		return NULL;
	}
	return m_pNodeHead->data;
}

//_AFXCOLL_INLINE VOID*& CStList::GetTail()
//	{ Assert(m_pNodeTail != NULL);
//	  VOID*& data=m_pNodeTail->data;
//	  return data; 
//	}
_AFXCOLL_INLINE VOID* CStList::GetTail() 
{
	Assert(m_pNodeTail);
	if (!m_pNodeTail) 
	{
		return NULL;
	}
	return m_pNodeTail->data; 
}

_AFXCOLL_INLINE POSITION CStList::GetHeadPosition() 
{ 
	return m_pNodeHead; 
}
_AFXCOLL_INLINE POSITION CStList::GetTailPosition()	
{ 
	return m_pNodeTail; 
}
_AFXCOLL_INLINE VOID*& CStList::GetNext(POSITION& rPosition) // return *Position++
{ 
	CNode* pNode = (CNode*) rPosition;
	rPosition = (POSITION) pNode->pNext;
	return pNode->data; 
}
//_AFXCOLL_INLINE VOID* CStList::GetNext(POSITION& rPosition) // return *Position++
//	{ CNode* pNode = (CNode*) rPosition;
//		rPosition = (POSITION) pNode->pNext;
//		return pNode->data; }
_AFXCOLL_INLINE VOID*& CStList::GetPrev(POSITION& rPosition) // return *Position--
{ 
	CNode* pNode = (CNode*) rPosition;
	rPosition = (POSITION) pNode->pPrev;
	return pNode->data;
}
//_AFXCOLL_INLINE VOID* CStList::GetPrev(POSITION& rPosition) const // return *Position--
//	{ CNode* pNode = (CNode*) rPosition;
//		rPosition = (POSITION) pNode->pPrev;
//		return pNode->data; }
_AFXCOLL_INLINE VOID*& CStList::GetAt(POSITION position)
{ 
	CNode* pNode = (CNode*) position;
	return pNode->data; 
}
_AFXCOLL_INLINE VOID* CStList::GetAt(POSITION position) const
{ 
	CNode* pNode = (CNode*) position;
	return pNode->data; 
}
_AFXCOLL_INLINE void CStList::SetAt(POSITION pos, VOID* newElement)
{ 
	CNode* pNode = (CNode*) pos;
	pNode->data = newElement; 
}

/////////////////////////////////////////////////////////////////////////////

CStList::CStList(int nBlockSize)
{
	Assert(nBlockSize > 0);

	m_nCount = 0;
	m_pNodeHead = m_pNodeTail = m_pNodeFree = NULL;
	m_pBlocks = NULL;
	m_nBlockSize = nBlockSize;
#ifdef DEBUG
	m_fInList = FALSE;
#endif
}

void CStList::RemoveAll()
{
	Assert(this);

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

	// destroy elements
	
	m_nCount = 0;
	m_pNodeHead = m_pNodeTail = m_pNodeFree = NULL;
	m_pBlocks->FreeDataChain();
	m_pBlocks = NULL;

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));
}

CStList::~CStList()
{
	RemoveAll();
	Assert(m_nCount == 0);
}

/////////////////////////////////////////////////////////////////////////////
// Node helpers
/*
 * Implementation note: CNode's are stored in CStPlex blocks and
 *  chained together. Free blocks are maintained in a singly linked list
 *  using the 'pNext' member of CNode with 'm_pNodeFree' as the head.
 *  Used blocks are maintained in a doubly linked list using both 'pNext'
 *  and 'pPrev' as links and 'm_pNodeHead' and 'm_pNodeTail'
 *   as the head/tail.
 *
 * We never free a CStPlex block unless the List is destroyed or RemoveAll()
 *  is used - so the total number of CStPlex blocks may grow large depending
 *  on the maximum past size of the list.
 */
CStList::CNode* CStList::NewNode(CStList::CNode* pPrev, CStList::CNode* pNext)
{
	if (m_pNodeFree == NULL)
	{
		// add another block
		CStPlex* pNewBlock = CStPlex::Create(m_pBlocks, m_nBlockSize, sizeof(CNode));

		// chain them into free list
		CNode* pNode = (CNode*) pNewBlock->data();
		// free in reverse order to make it easier to debug
		pNode += m_nBlockSize - 1;
		for (int i = m_nBlockSize-1; i >= 0; i--, pNode--)
		{
			pNode->pNext = m_pNodeFree;
			if (m_pNodeFree)
			{
				m_pNodeFree->pPrev = pNode;
			}
			m_pNodeFree = pNode;
		}
	}
	Assert(m_pNodeFree != NULL);  // we must have something

	CStList::CNode* pNode = m_pNodeFree;
	m_pNodeFree = m_pNodeFree->pNext;
	if (m_pNodeFree)
	{
		m_pNodeFree->pPrev = NULL;
	}
	pNode->pPrev = pPrev;
	pNode->pNext = pNext;
	m_nCount++;
	Assert(m_nCount > 0);  // make sure we don't overflow

	::ZeroMemory(&pNode->data,sizeof(VOID*));  // zero fill

	return pNode;
}

void CStList::FreeNode(CStList::CNode* pNode)
{
	pNode->pNext = m_pNodeFree;
	if (m_pNodeFree) 
	{
		Assert(!m_pNodeFree->pPrev);
		m_pNodeFree->pPrev = pNode;
	}
	m_pNodeFree = pNode;
	m_pNodeFree->pPrev = NULL;
	m_nCount--;
	Assert(m_nCount >= 0);  // make sure we don't underflow
}

/////////////////////////////////////////////////////////////////////////////

POSITION CStList::AddHead(VOID* newElement)
{
	Assert(this);

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	CNode* pNewNode = NewNode(NULL, m_pNodeHead);
	pNewNode->data = newElement;
	if (m_pNodeHead != NULL)
	{
		m_pNodeHead->pPrev = pNewNode;
	}
	else
	{
		m_pNodeTail = pNewNode;
	}
	m_pNodeHead = pNewNode;

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return (POSITION) pNewNode;
}

POSITION CStList::AddTail(VOID* newElement)
{
	Assert(this);

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	CNode* pNewNode = NewNode(m_pNodeTail, NULL);
	pNewNode->data = newElement;
	if (m_pNodeTail != NULL)
	{
		m_pNodeTail->pNext = pNewNode;
	}
	else
	{
		m_pNodeHead = pNewNode;
	}
	m_pNodeTail = pNewNode;

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return (POSITION) pNewNode;
}

void CStList::AddHead(CStList* pNewList)
{
	Assert(this);

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

	Assert(pNewList != NULL);
	Assert(pNewList);

#ifdef DEBUG
	WalkCStList();
#endif

	// add a list of same elements to head (maintain order)
	POSITION pos = pNewList->GetTailPosition();
	while (pos != NULL)
	{
		AddHead(pNewList->GetPrev(pos));
	}

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));
}

void CStList::AddTail(CStList* pNewList)
{
	Assert(this);

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

	Assert(pNewList != NULL);
	Assert(pNewList);

#ifdef DEBUG
	WalkCStList();
#endif

	// add a list of same elements
	POSITION pos = pNewList->GetHeadPosition();
	while (pos)
	{
		AddTail(pNewList->GetNext(pos));
	}

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));
}

VOID* CStList::RemoveHead()
{
	Assert(this);

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	// The following line is removed to enable calling RemoveHead in multi-threaded conditions --
	//  IsEmpty() will be called, and if list is empty, NULL is returned to caller

	// Assert(m_pNodeHead != NULL);  // don't call on empty list !!!

	// check if the list is empty -- this call is not standard part of MFC and was added
	//  by genek to allow for multi-threaded calling of RemoveHead()
	if (IsEmpty()) 
		{
		// protect against reentrancy
		Assert(m_fInList);
		Assert(!(m_fInList = FALSE));
		return NULL;
		}

	CNode* pOldNode = m_pNodeHead;
	VOID* returnValue = pOldNode->data;

	m_pNodeHead = pOldNode->pNext;
	if (m_pNodeHead != NULL)
	{
		m_pNodeHead->pPrev = NULL;
	}
	else
	{
		m_pNodeTail = NULL;
	}
	FreeNode(pOldNode);

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return returnValue;
}

VOID* CStList::RemoveTail()
{
	Assert(this);
	// The following line is removed to enable calling RemoveHead in multi-threaded conditions --
	//  IsEmpty() will be called, and if list is empty, NULL is returned to caller

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	// Assert(m_pNodeTail != NULL);  // don't call on empty list !!!

	// check if the list is empty -- this call is not standard part of MFC and was added
	//  by genek to allow for multi-threaded calling of RemoveHead()
	if (IsEmpty()) 
	{
		// protect against reentrancy
		Assert(m_fInList);
		Assert(!(m_fInList = FALSE));
		return NULL;
	}

	CNode* pOldNode = m_pNodeTail;
	VOID* returnValue = pOldNode->data;

	m_pNodeTail = pOldNode->pPrev;
	if (m_pNodeTail != NULL)
	{
		m_pNodeTail->pNext = NULL;
	}
	else
	{
		m_pNodeHead = NULL;
	}
	FreeNode(pOldNode);

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return returnValue;
}

POSITION CStList::InsertBefore(POSITION position, VOID* newElement)
{
	Assert(this);

	if (position == NULL) 
	{
		return AddHead(newElement); // insert before nothing -> head of the list
	}

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	// Insert it before position
	CNode* pOldNode = (CNode*) position;
	CNode* pNewNode = NewNode(pOldNode->pPrev, pOldNode);
	pNewNode->data = newElement;

	if (pOldNode->pPrev != NULL)
	{
		pOldNode->pPrev->pNext = pNewNode;
	}
	else
	{
		Assert(pOldNode == m_pNodeHead);
		m_pNodeHead = pNewNode;
	}
	pOldNode->pPrev = pNewNode;

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return (POSITION) pNewNode;
}

POSITION CStList::InsertAfter(POSITION position, VOID* newElement)
{
	Assert(this);

	if (position == NULL) 
	{
		return AddTail(newElement); // insert after nothing -> tail of the list
	}

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	// Insert it before position
	CNode* pOldNode = (CNode*) position;
	CNode* pNewNode = NewNode(pOldNode, pOldNode->pNext);
	pNewNode->data = newElement;

	if (pOldNode->pNext != NULL)
	{
		pOldNode->pNext->pPrev = pNewNode;
	}
	else
	{
		Assert(pOldNode == m_pNodeTail);
		m_pNodeTail = pNewNode;
	}
	pOldNode->pNext = pNewNode;

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return (POSITION) pNewNode;
}

void CStList::RemoveAt(POSITION position)
{
	Assert(this);

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	CNode* pOldNode = (CNode*)position;

	// remove pOldNode from list
	if (pOldNode == m_pNodeHead)
	{
		m_pNodeHead = pOldNode->pNext;
	}
	else
	{
		pOldNode->pPrev->pNext = pOldNode->pNext;
	}
	if (pOldNode == m_pNodeTail)
	{
		m_pNodeTail = pOldNode->pPrev;
	}
	else
	{
		pOldNode->pNext->pPrev = pOldNode->pPrev;
	}
	FreeNode(pOldNode);

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));
}


/////////////////////////////////////////////////////////////////////////////
// slow operations

POSITION CStList::FindIndex(int nIndex)
{
	Assert(this);
	Assert(nIndex >= 0);

	if (nIndex >= m_nCount)
	{
        return NULL;  // went too far
	}

	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	CNode* pNode = m_pNodeHead;
	while (nIndex--)
	{
		pNode = pNode->pNext;
	}

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return (POSITION) pNode;
}

POSITION CStList::Find(VOID* searchValue, POSITION startAfter)
{
	Assert(this);
	
	// protect against reentrancy
	Assert(!m_fInList);
	Assert(m_fInList = TRUE);

#ifdef DEBUG
	WalkCStList();
#endif

	CNode* pNode = (CNode*) startAfter;
	if (pNode == NULL)
	{
		pNode = m_pNodeHead;  // start at head
	}
	else
	{
		pNode = pNode->pNext;  // start after the one specified
	}

	for (; pNode != NULL; pNode = pNode->pNext)
		if (pNode->data == searchValue)
		{
#ifdef DEBUG
			WalkCStList();
#endif

			// protect against reentrancy
			Assert(m_fInList);
			Assert(!(m_fInList = FALSE));

			return (POSITION) pNode;
		}

#ifdef DEBUG
	WalkCStList();
#endif

	// protect against reentrancy
	Assert(m_fInList);
	Assert(!(m_fInList = FALSE));

	return NULL;
}

#ifdef DEBUG
VOID CStList::WalkCStList()
{
#ifdef DEBUG_WALK
	if (m_pNodeHead) 
	{
		Assert(m_pNodeTail);
		Assert(!m_pNodeHead->pPrev);
		WalkTheList(m_pNodeHead, NULL, m_pNodeHead->pNext);
	}
	else 
	{
		Assert(!m_pNodeTail);
	}

	if (m_pNodeTail) 
	{
		Assert(m_pNodeHead);
		Assert(!m_pNodeTail->pNext);
		WalkTheList(m_pNodeTail, m_pNodeTail->pPrev, NULL);
	}
	else 
	{
		Assert(!m_pNodeHead);
	}

	if (m_pNodeFree) 
	{
		Assert(!m_pNodeFree->pPrev);
		WalkTheList(m_pNodeFree, NULL, m_pNodeFree->pNext);
	}
#endif	// #ifdef DEBUG_WALK
}

VOID CStList::WalkTheList(CNode* pNode, CNode* pPrevNode, CNode* pNextNode)
{
	CNode* pCurNode = pNode;
	CNode* pCurPrevNode = pPrevNode;
	CNode* pCurNextNode = pNextNode;

	// first walk up the list
	while (pCurNextNode) 
	{
		Assert(pCurNextNode->pPrev == pCurNode);
		if (pCurPrevNode)
		{
			Assert(pCurPrevNode->pNext == pCurNode);
		}

		pCurPrevNode = pCurNode;
		pCurNode = pCurNextNode;
		pCurNextNode = pCurNextNode->pNext;
	}

	// reset the list
	pCurNode = pNode;
	pCurPrevNode = pPrevNode;
	pCurNextNode = pNextNode;

	// now walk back the list
	while (pCurPrevNode) 
	{
		Assert(pCurPrevNode->pNext == pCurNode);
		if (pCurNextNode)
		{
			Assert(pCurNextNode->pPrev == pCurNode);
		}

		pCurNextNode = pCurNode;
		pCurNode = pCurPrevNode;
		pCurPrevNode = pCurPrevNode->pPrev;
	}
}

#endif

/////////////////////////////////////////////////////////////////////////////
