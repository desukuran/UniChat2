/*--------------------------------------------------------------------------
	mtlist.cpp
		
    Copyright (C) 1993-96 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include <windows.h>
#include "..\inc\mtlist.h"
#include "..\inc\cldbg.h"

#define _AFXCOLL_INLINE 

/////////////////////////////////////////////////////////////////////////////

_AFXCOLL_INLINE int CMtList::GetCount()
	{ ::EnterCriticalSection(&m_cs); int nCount = CStList::GetCount(); ::LeaveCriticalSection(&m_cs); return nCount; }
_AFXCOLL_INLINE BOOL CMtList::IsEmpty() const
	{ return CStList::IsEmpty(); }
_AFXCOLL_INLINE VOID* CMtList::GetHead()
	{ ::EnterCriticalSection(&m_cs);
	  VOID* data=CStList::GetHead();
	  ::LeaveCriticalSection(&m_cs); 
	  return data;
	}
_AFXCOLL_INLINE VOID* CMtList::GetTail()
	{ ::EnterCriticalSection(&m_cs);
	  VOID* data=CStList::GetTail();
	  ::LeaveCriticalSection(&m_cs);
	  return data; 
	}
_AFXCOLL_INLINE POSITION CMtList::GetHeadPosition()
	{ ::EnterCriticalSection(&m_cs);
	  POSITION pos = CStList::GetHeadPosition();
	  ::LeaveCriticalSection(&m_cs);
	  return pos; 
	}
_AFXCOLL_INLINE POSITION CMtList::GetTailPosition()
	{ ::EnterCriticalSection(&m_cs);
	  POSITION pos = CStList::GetTailPosition();
	  ::LeaveCriticalSection(&m_cs);
	  return pos; 
	}
_AFXCOLL_INLINE VOID*& CMtList::GetNext(POSITION& rPosition) // return *Position++
	{ ::EnterCriticalSection(&m_cs);
	  VOID*& data = CStList::GetNext(rPosition);
	  ::LeaveCriticalSection(&m_cs);
	  return data; 
	}
_AFXCOLL_INLINE VOID*& CMtList::GetPrev(POSITION& rPosition) // return *Position--
	{ ::EnterCriticalSection(&m_cs);
	  VOID*& data = CStList::GetPrev(rPosition);
	  ::LeaveCriticalSection(&m_cs);
	  return data;
	}
_AFXCOLL_INLINE VOID*& CMtList::GetAt(POSITION position) { return CStList::GetAt(position); }
_AFXCOLL_INLINE VOID* CMtList::GetAt(POSITION position) const { return  CStList::GetAt(position); }
_AFXCOLL_INLINE void CMtList::SetAt(POSITION pos, VOID* newElement) { CStList::SetAt(pos, newElement); }

/////////////////////////////////////////////////////////////////////////////

CMtList::CMtList(int nBlockSize) : CStList(10) 
{ 
	::InitializeCriticalSection(&m_cs); 
}

void CMtList::RemoveAll()
{
	CStList::RemoveAll();
}

CMtList::~CMtList()
{
	::DeleteCriticalSection(&m_cs);
}

/////////////////////////////////////////////////////////////////////////////

POSITION CMtList::AddHead(VOID* newElement)
{
	Assert(this);

	::EnterCriticalSection(&m_cs);
	POSITION pos = CStList::AddHead(newElement);
	::LeaveCriticalSection(&m_cs);
	return pos;
}

POSITION CMtList::AddTail(VOID* newElement)
{
	Assert(this);

	::EnterCriticalSection(&m_cs);
	POSITION pos = CStList::AddTail(newElement);
	::LeaveCriticalSection(&m_cs);
 	return pos;
}

void CMtList::AddHead(CMtList* pNewList)
{
	Assert(this);

	Assert(pNewList != NULL);
	Assert(pNewList);

	::EnterCriticalSection(&m_cs);
	CStList::AddHead(pNewList);
	::LeaveCriticalSection(&m_cs);
}

void CMtList::AddTail(CMtList* pNewList)
{
	Assert(this);
	Assert(pNewList != NULL);
	Assert(pNewList);

	::EnterCriticalSection(&m_cs);
	CStList::AddTail(pNewList);
	::LeaveCriticalSection(&m_cs);
}

VOID* CMtList::RemoveHead()
{
	Assert(this);

	::EnterCriticalSection(&m_cs);
	VOID* pData = CStList::RemoveHead();
	::LeaveCriticalSection(&m_cs);
	return pData;
}

VOID* CMtList::RemoveTail()
{
	Assert(this);

	::EnterCriticalSection(&m_cs);
	VOID* pData = CStList::RemoveTail();
	::LeaveCriticalSection(&m_cs);
	return pData;
}

POSITION CMtList::InsertBefore(POSITION position, VOID* newElement)
{
	Assert(this);

	if (position == NULL)
		return AddHead(newElement); // insert before nothing -> head of the list

	::EnterCriticalSection(&m_cs);
	POSITION pos = CStList::InsertBefore(position, newElement);
	::LeaveCriticalSection(&m_cs);
	return pos;
}

POSITION CMtList::InsertAfter(POSITION position, VOID* newElement)
{
	Assert(this);

	if (position == NULL)
		return AddTail(newElement); // insert after nothing -> tail of the list

	::EnterCriticalSection(&m_cs);
	POSITION pos = CStList::InsertAfter(position, newElement);
	::LeaveCriticalSection(&m_cs);
	return pos;
}

void CMtList::RemoveAt(POSITION position)
{
	Assert(this);

	::EnterCriticalSection(&m_cs);
	CStList::RemoveAt(position);
	::LeaveCriticalSection(&m_cs);
}

/////////////////////////////////////////////////////////////////////////////
// slow operations

POSITION CMtList::FindIndex(int nIndex)
{
	Assert(this);
	Assert(nIndex >= 0);

	::EnterCriticalSection(&m_cs);
	POSITION pos = CStList::FindIndex(nIndex);
	::LeaveCriticalSection(&m_cs);
	return pos;
}

POSITION CMtList::Find(VOID* searchValue, POSITION startAfter)
{
	Assert(this);
	
	::EnterCriticalSection(&m_cs);
	POSITION pos = CStList::Find(searchValue, startAfter);
	::LeaveCriticalSection(&m_cs);
	return pos;
}

/////////////////////////////////////////////////////////////////////////////
