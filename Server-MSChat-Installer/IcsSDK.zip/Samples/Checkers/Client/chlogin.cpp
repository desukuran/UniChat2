/*--------------------------------------------------------------------------
	chlogin.cpp
	
		Checkers client login-related code.

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "precomp.h"
#include "..\checkpro.h"
#include "checkers.h"
#include "resource.h"

/*--------------------------------------------------------------------------+
// Local Prototypes
+--------------------------------------------------------------------------*/
BOOL CALLBACK ConnectSettingsDlgProc(HWND hwnd, UINT uMsg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK ConnectDlgProc(HWND hwnd, UINT uMsg, WPARAM wparam, LPARAM lparam);

/*--------------------------------------------------------------------------+
// Global Variables/Definitions
+--------------------------------------------------------------------------*/
char g_szServer[MIC_MAX_SERVER_NAME_LENGTH + 1];
char g_szChannel[MIC_MAX_CHANNEL_NAME_LENGTH + 1];
char g_szNick[MIC_MAX_USER_ALIAS_LENGTH + 1];

HANDLE g_hthreadConnect = NULL;
PICS_FACTORY g_pfactory = NULL;

CSPROP_TYPE g_rgpropGuid[1] = {CSPROP_CHANNEL_SERVICEGUID_MIC};

const GUID guidCheckers = {0x379ad880, 0xb472, 0x11cf,
						   {0x87, 0xa7, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00}};

HWND g_hwndDlg = NULL;

int		g_csec = 0;
char	g_szTimeMsg[64];

// FLogin()
//	Logs into the server.  Our initialization sequence looks like:
// (1) connect to server
// (2) check for the channel service guid
// (3) send a hello message
// (4) wait for a hello response from the server
//	Based on the hello response, 3 things could happen.  Either:
// (a) we're red
// (b) we're black
// (c) there are already two people playing in this channel, so we can't play.
BOOL FLogin()
{
	CS_CONNINFO		conninfo;
	PCS_MSGBASE		pmsg = NULL;
	PCS_MSGCHANNEL	pmsgChannel;
	PCS_PROPERTY	pmsgPropData;
	CS_CINFO		cinfo;
	CS_PROPDATA		propdata;
	HELLOMSG		hellomsg;
	PCS_MSG			pmsgData;
	PHEADER			pheader;
	PHELLORESMSG	phelloresmsg;
	BOOL			fRet = FALSE;

	if (g_psocket->HrIsMicSocket() != NOERROR)
	{
		::MessageBox(NULL, "The server you have specified is not a MIC server.  Checkers cannot run.",
				   "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	
	::FillMemory(&conninfo, sizeof(CS_CONNINFO), 0);
	conninfo.dwcb	= sizeof(CS_CONNINFO);
	conninfo.bType	= CS_CONNECT_ANONYMOUS;
	conninfo.pvUser	= g_szNick;
	conninfo.pvPass	= "";
	conninfo.pvNick	= g_szNick;

	if (FAILED(g_psocket->HrLoginA(&conninfo)))
	{
		::MessageBox(NULL, "Couldn't send login message", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	if (FAILED(g_psocket->HrWaitTillMsgType(CSMSG_TYPE_LOGIN, &pmsg, INFINITE)))
	{
		::MessageBox(NULL, "Couldn't get login message", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}

	::FillMemory(&cinfo, sizeof(CS_CINFO), 0);
	cinfo.dwcb			= sizeof(cinfo);
	cinfo.dwType		= CS_CHANNEL_PUBLIC;
	cinfo.dwFlags		= CS_CHANNEL_FLAG_MICONLY;
	cinfo.bCreateFlags	= CS_CHANNEL_CREATE_JOIN;
	cinfo.pvChannelName	= g_szChannel;
	cinfo.pvTopic		= "";
	cinfo.pvPassword	= "";

	if (FAILED(g_psocket->HrCreateChannelA(&cinfo)))
	{
		MessageBox(NULL, "Couldn't create channel!", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	HrFreeMsg(pmsg);
	pmsg = NULL; // for cleanup

	if (FAILED(g_psocket->HrWaitTillMsgType(CSMSG_TYPE_ADDCHANNEL, &pmsg, INFINITE)))
	{
		::MessageBox(NULL, "Couldn't get new channel message", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}

	pmsgChannel = (PCS_MSGCHANNEL)(pmsg + 1);
	if (!pmsgChannel->picsChannel)
	{
		::MessageBox(NULL, "Couldn't get new channel", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
		
	g_pchannel = pmsgChannel->picsChannel;
	g_pchannel->AddRef();
	HrFreeMsg(pmsg);
	pmsg = NULL;

	// now we need to verify that we have the right channel...  check the guid
	if (FAILED(g_pchannel->HrGetPropertiesA(g_rgpropGuid, 1)))
	{
		::MessageBox(NULL, "Couldn't send getproperties message", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}

	if (FAILED(g_pchannel->HrWaitTillMsgType(CSMSG_TYPE_PROPERTYDATA, &pmsg, INFINITE)))
	{
		::MessageBox(NULL, "Couldn't get properties", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}

	pmsgPropData = (PCS_PROPERTY)(pmsg + 1);
	if (!pmsgPropData->picsProperty)
	{
		::MessageBox(NULL, "Couldn't get property data", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	if (FAILED(pmsgPropData->picsProperty->HrGetProperty(&propdata, 1)))
	{
		::MessageBox(NULL, "Couldn't get property", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	if (propdata.csPropType != CSPROP_CHANNEL_SERVICEGUID_MIC || propdata.dwcb != sizeof(GUID))
	{
		::MessageBox(NULL, "Couldn't get guid", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
// Commented out since I can't run this service in the Server directly with the response file.
// Tortoise
//	if (!::IsEqualGUID(*(GUID*)propdata.pbData, guidCheckers))
//	{
//		::MessageBox(NULL, "Channel doesn't have correct GUID", "Error", MB_OK | MB_ICONERROR);
//		goto LBail;
//	}
	HrFreeMsg(pmsg);
	pmsg = NULL;

	// Yay!  We finally know that we're talking to the checkers server.
	// Now we tell it we're here.
	hellomsg.header.cmsg	= cmsgHello;
	hellomsg.iVersion		= CHECKERS_CURRENT_VERSION;
	if (FAILED(g_pchannel->HrSendData(&hellomsg, sizeof(hellomsg))))
	{
		::MessageBox(NULL, "Couldn't send hello message", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}

	if (FAILED(g_pchannel->HrWaitTillMsgType(CSMSG_TYPE_DATA, &pmsg, INFINITE)))
	{
		::MessageBox(NULL, "Couldn't get hello response", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	pmsgData = (PCS_MSG)(pmsg + 1);
	if (pmsgData->dwcbData < sizeof(HEADER))
	{
		::MessageBox(NULL, "Invalid response", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	pheader = (PHEADER)(pmsgData->pbData);
	if (pheader->cmsg == cmsgError)
	{
		goto LBail;
	}
	else if (pheader->cmsg != cmsgHelloResponse)
	{
		::MessageBox(NULL, "Invalid hello response", "Error", MB_OK | MB_ICONERROR);
		goto LBail;
	}
	phelloresmsg = (PHELLORESMSG)pheader;
	g_fRed = phelloresmsg->fRed;
		
	fRet = TRUE;
	
LBail:
	if (pmsg)
		HrFreeMsg(pmsg);
	return fRet;
}

// Gets settings from the user and connects/logs in to the specified
// server with the specified nickname.
BOOL FConnect()
{
	BOOL fRet = FALSE;

	// Get the settings (server name, etc).
	if (::DialogBox(g_hinst, MAKEINTRESOURCE(IDD_CONNECT_SETTINGS), NULL, (DLGPROC)ConnectSettingsDlgProc) == IDOK)
	{
		if (FAILED(HrCreateChatSocketFactory(IID_CHATSOCKVER1, &g_pfactory)))
		{
			::MessageBox(NULL, "Couldn't create socket factory", "Error", MB_OK | MB_ICONERROR);
			return FALSE;
		}

		// Actually do the connection
		fRet = (::DialogBox(g_hinst, MAKEINTRESOURCE(IDD_CONNECT), NULL, (DLGPROC)ConnectDlgProc) == IDOK);
		
		g_pfactory->Release();

		// We want to make sure that the connection thread has had time to
		// clean its resources up.  If the dialog was cancelled, we may well
		// get back to here before the thread has terminated.
		::WaitForSingleObject(g_hthreadConnect, INFINITE);
		
		if (fRet)
			fRet = FLogin();
	}

	return fRet;
}

// Dialog proc for the connection settings dlg.
BOOL CALLBACK ConnectSettingsDlgProc(HWND hwnd, UINT uMsg, WPARAM wparam, LPARAM lparam)
{
	BOOL fHandledMsg = FALSE;
	
	switch (uMsg)
	{
	case WM_INITDIALOG:
		fHandledMsg = TRUE;
		break;
		
	case WM_COMMAND:
		switch (LOWORD(wparam))
		{
		case IDOK:
			::GetDlgItemText(hwnd, IDC_EDIT_SERVER,		g_szServer,		sizeof(g_szServer)-1);
			::GetDlgItemText(hwnd, IDC_EDIT_CHANNEL,	g_szChannel,	sizeof(g_szChannel)-1);
			::GetDlgItemText(hwnd, IDC_EDIT_NICKNAME,	g_szNick,		sizeof(g_szNick)-1);

			// fall through
		case IDCANCEL:
			fHandledMsg = TRUE;
			::EndDialog(hwnd, LOWORD(wparam));
			break;
		}
	}
	return fHandledMsg;
}

// Secondary thread to do the HrMakeSocket in a cancellable way.
DWORD __stdcall DwConnectThreadProc(PVOID pvData)
{
	int idcEnd = IDCANCEL;

	::SetDlgItemText(g_hwndDlg, IDC_STATIC_STATUS, "Connecting...");

	if (SUCCEEDED(g_pfactory->HrMakeSocket(g_szServer, &g_psocket)))
	{
		idcEnd = IDOK;
	}
	else
	{
		::MessageBox(NULL, "Couldn't connect to server", "Error", MB_OK | MB_ICONERROR);
	}
	::PostMessage(g_hwndDlg, WM_COMMAND, idcEnd, 0);
	return 0;
}

// Called if the cancel button is pressed during the connection attempt.
void CancelLogin()
{
	g_pfactory->HrCancelMakeSocket();
}

// Dialog proc for the "Connecting..." dialog.
BOOL CALLBACK ConnectDlgProc(HWND hwnd, UINT uMsg, WPARAM wparam, LPARAM lparam)
{
	BOOL	fHandledMsg = FALSE;
	DWORD	tid;
	char	szMsg[64];
	char	szT[64];
	
	switch (uMsg)
	{
	case WM_INITDIALOG:
	
		g_hwndDlg = hwnd;
	
		::GetDlgItemText(hwnd, IDC_STATIC_CONNECTING, szT, 63);
		wsprintf(szMsg, szT, g_szServer);
		::SetDlgItemText(hwnd, IDC_STATIC_CONNECTING, szMsg);
	
		::GetDlgItemText(hwnd, IDC_STATIC_ELAPSED, g_szTimeMsg, 63);
		wsprintf(szMsg, g_szTimeMsg, g_csec);
		::SetDlgItemText(hwnd, IDC_STATIC_ELAPSED, szMsg);
		
		g_hthreadConnect = ::CreateThread(NULL, 0, DwConnectThreadProc, NULL, 0, &tid);
		if (!g_hthreadConnect)
		{
			::MessageBox(NULL, "Can't create thread!", "Error", MB_OK | MB_ICONERROR);
			return FALSE;
		}
			
		::SetTimer(hwnd, 1, 1000, NULL);
		
		fHandledMsg = TRUE;
		break;
		
	case WM_TIMER:
		wsprintf(szMsg, g_szTimeMsg, ++g_csec);
		::SetDlgItemText(hwnd, IDC_STATIC_ELAPSED, szMsg);
		break;
		
	case WM_COMMAND:
		switch (LOWORD(wparam))
		{
		case IDCANCEL:
			CancelLogin();
		
			// fall through
		case IDOK:
			fHandledMsg = TRUE;
			::EndDialog(hwnd, LOWORD(wparam));
			break;
		}
	}
	return fHandledMsg;
}
