//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by checkers.rc
//
#define IDD_CONNECT_SETTINGS            101
#define IDD_CONNECT                     103
#define IDC_EDIT_SERVER                 1001
#define IDC_EDIT_CHANNEL                1002
#define IDC_EDIT_NICKNAME               1003
#define IDC_LABEL_CHANNEL               1004
#define IDC_LABEL_NICKNAME              1005
#define IDC_LABEL_STATUS                1006
#define IDC_STATIC_STATUS               1007
#define IDC_LABEL_ELAPSED               1008
#define IDC_STATIC_ELAPSED              1009
#define IDC_STATIC_CONNECTING           1010
#define IDC_LABEL_SERVER                -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
