/*--------------------------------------------------------------------------
	checkers.cpp
	
		Checkers client sample

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "precomp.h"
#include "..\checkpro.h"
#include "resource.h"
#include "chlogin.h"	// extern BOOL FConnect();

#ifndef _DEBUG
	#define DebugMessageType(t, c)	// Do nothing
#else
	void DebugMessageType(LPCSTR t, CSMSG_TYPE c);
#endif

/*--------------------------------------------------------------------------+
// Local Prototypes
+--------------------------------------------------------------------------*/
BOOL FInitApp(HINSTANCE);
BOOL FInitGame();
BOOL FTermApp();
BOOL FRegisterWndClass(UINT, WNDPROC, HICON, char*, char*);

/*--------------------------------------------------------------------------+
// Global Variables/Definitions
+--------------------------------------------------------------------------*/
HINSTANCE	g_hinst			= NULL;
char		g_szClassMain[]	= "CheckersSampleWndClass";
HWND		g_hwndMain		= NULL;
int			g_cxSquare		= 40;
int			g_cySquare		= 40;
HBRUSH		g_hbrRed		= NULL;
HBRUSH		g_hbrBlack		= NULL;
HBRUSH		g_hbrDkRed		= NULL;
HBRUSH		g_hbrGrey		= NULL;
HPEN		g_hpenBlack		= NULL;
HPEN		g_hpenGrey		= NULL;

PICS			g_psocket			= NULL;
PICS_CHANNEL	g_pchannel			= NULL;
HANDLE			g_hthreadChannel	= NULL;

BOOL	g_fMyTurn	= FALSE;
BOOL	g_fRed		= FALSE;

// Our board is laid out as follows:  We have an array of 64 squares.  They
// will be addressed as g_rgbBoard[x + (8 * y)], where (0,0) is the lower
// left square on RED's side of the board.  This means that when the
// player is RED, (0,0) is in the lower left of the board, but when the
// player is BLACK, (0,0) is in the upper right of the board (as drawn
// on the screen).  All the hit-testing and drawing code has to be
// aware of this.
BYTE g_rgbBoard[8 * 8];

#define PIECEAT(i, j)			(g_rgbBoard[(i) + (8 * (j))])
#define SETPIECEAT(i, j, p)		g_rgbBoard[(i) + (8 * (j))] = (p)

#define cxBorder 1
#define cyBorder 1

BOOL	g_fDragging = FALSE;
int		g_pieceDrag;
PL		g_plDragStart;
PL		g_plDragEnd;
int		g_xDrag, g_yDrag;

// While we're dragging, there are at most 4 squares that are touched by the
// current position of the dragging piece, so we just keep track of however
// many squares we have to redraw.
int		g_cplDrag;
PL		g_rgplDrag[4];

// When our channel-reader thread receives ChatSock messages, it reposts the
// data to our main thread in the form of custom window messages.
#define WM_INVALIDMOVE			(WM_USER + 1)		// wparam = 0, lparam = 0
#define WM_MOVEOK				(WM_USER + 2)		// wparam = fContinueJump, lparam = 0
#define WM_PLAYERMOVE			(WM_USER + 3)		// wparam = from, lparam = to
#define WM_TURNCHANGE			(WM_USER + 4)		// wparam = fRedTurn, lparam = 0
#define WM_KING					(WM_USER + 5)		// wparam = iKing, lparam = jKing
#define WM_JUMP					(WM_USER + 6)		// wparam = iJump, lparam = jJump
#define WM_YOUWIN				(WM_USER + 7)		// wparam = lparam = 0
#define WM_YOULOSE				(WM_USER + 8)		// wparam = lparam = 0
#define WM_YOUWINBYFORFEIT		(WM_USER + 9)		// wparam = lparam = 0

////////////////////////////////////////////////////////////////////////////////
// Reads messages off the ChatSock channel message queue.
DWORD __stdcall DwChannelThreadProc(PVOID pvData)
{
	PCS_MSGBASE	pmsg;
	PCS_MSG		pmsgData;
	PHEADER		pheader;
	
	while (SUCCEEDED(g_pchannel->HrWaitForMsg(&pmsg, INFINITE)))
	{
		DebugMessageType("=> DwChannelThreadProc", pmsg->csMsgType);
		switch (pmsg->csMsgType)
		{
		// We actually don't really care about any other messages than
		// CSMSG_TYPE_DATA at this point, but we may eventually want
		// to track, for example, CSMSG_TYPE_ADDMEMBER/DELMEMBER, or
		// CSMSG_TYPE_WHISPERTEXT_A/W to show whispers.
		
		case CSMSG_TYPE_DATA:
			pmsgData = (PCS_MSG)(pmsg + 1);
			if (pmsgData->dwcbData < sizeof(HEADER))
				break;
				
			// The data messages start with our CMSG header.
			pheader = (PHEADER)pmsgData->pbData;
			switch (pheader->cmsg)
			{
			default:
				break;
				
			case cmsgMoveOk:
				{
				PMOVEOKMSG pmoveokmsg = (PMOVEOKMSG)pheader;
				::PostMessage(g_hwndMain, WM_MOVEOK, pmoveokmsg->fContinueJump, 0);
				break;
				}
			case cmsgError:
				{
				PERRORMSG perrormsg = (PERRORMSG)pheader;
				if (perrormsg->cerr == cerrInvalidMove)
				{
					::PostMessage(g_hwndMain, WM_INVALIDMOVE, 0, 0);
				}
				break;
				}
			case cmsgMove:
				{
				PMOVEMSG pmovemsg = (PMOVEMSG)pheader;
				::PostMessage(g_hwndMain, WM_PLAYERMOVE,
							MAKELONG(pmovemsg->iFrom,	pmovemsg->jFrom),
							MAKELONG(pmovemsg->iTo,		pmovemsg->jTo));
				break;
				}
			case cmsgTurnChange:
				{
				PTURNMSG pturnmsg = (PTURNMSG)pheader;
				::PostMessage(g_hwndMain, WM_TURNCHANGE, pturnmsg->fRedTurn, 0);
				break;
				}
			case cmsgKing:
				{
				PKINGMSG pkingmsg = (PKINGMSG)pheader;
				::PostMessage(g_hwndMain, WM_KING, pkingmsg->iKing, pkingmsg->jKing);
				break;
				}
			case cmsgJump:
				{
				PJUMPMSG pjumpmsg = (PJUMPMSG)pheader;
				::PostMessage(g_hwndMain, WM_JUMP, pjumpmsg->iJump, pjumpmsg->jJump);
				break;
				}
			case cmsgYouWin:
				::PostMessage(g_hwndMain, WM_YOUWIN, 0, 0);
				break;
				
			case cmsgYouLose:
				::PostMessage(g_hwndMain, WM_YOULOSE, 0, 0);
				break;
				
			case cmsgYouWinByForfeit:
				::PostMessage(g_hwndMain, WM_YOUWINBYFORFEIT, 0, 0);
				break;
			}
			break;
			
		default:
			break;
		}
		HrFreeMsg(pmsg);
	}
	g_pchannel->Release();
	return 0;
}

// Draws the borders of the checkerboard.
void DrawBorders(HDC hdc)
{
	int i;

	for (i = 0; i < 9; i++)
	{
		::MoveToEx(hdc, 0, i * (g_cySquare + cyBorder), NULL);
		::LineTo(hdc, 8 * (g_cxSquare + cxBorder), i * (g_cySquare + cyBorder));
	}
	for (i = 0; i < 9; i++)
	{
		::MoveToEx(hdc, i * (g_cxSquare + cxBorder), 0, NULL);
		::LineTo(hdc, i * (g_cxSquare + cxBorder), 8 * (g_cySquare + cyBorder));
	}
}

// Draws whatever piece is in the square at (i, j).
void DrawSquare(HDC hdc, int i, int j)
{
	// iScreen and jScreen take into account the fact that the board is
	// reversed for BLACK; they also take into account the fact that
	// higher Y coordinate are further down the screen.
	int iScreen = g_fRed ? i : (7 - i);
	int jScreen = g_fRed ? (7 - j) : j;

	RECT rect;
	rect.bottom = (jScreen + 1) * (cyBorder + g_cySquare);
	rect.right = (iScreen + 1) * (cxBorder + g_cxSquare);
	rect.top = rect.bottom - g_cySquare;
	rect.left = rect.right - g_cxSquare;

	::FillRect(hdc, &rect, ((i + j) & 1) ? g_hbrDkRed : g_hbrGrey);

	int piece = PIECEAT(i, j);
	if (piece)
	{
		switch (piece)
		{
		case pieceRed:
		case pieceRedKing:
			::SelectObject(hdc, g_hbrRed);
			::SelectObject(hdc, g_hpenBlack);
			break;
	
		case pieceBlack:
		case pieceBlackKing:
			::SelectObject(hdc, g_hbrBlack);
			::SelectObject(hdc, g_hpenGrey);
			break;
		}
		::InflateRect(&rect, -3, -3);
		::Ellipse(hdc, rect.left, rect.top, rect.right, rect.bottom);
		
		if (piece == pieceBlackKing || piece == pieceRedKing)
		{
			::InflateRect(&rect, -3, -3);
			::Ellipse(hdc, rect.left, rect.top, rect.right, rect.bottom);
		}
	}
}

// Returns the piece at pixel location (x, y).  Used in hit-testing code.
void GetPlForLocation(int x, int y, PPL ppl)
{
	ppl->i = x / (cxBorder + g_cxSquare);
	ppl->j = 7 - (y / (cyBorder + g_cySquare));
	
	if (!g_fRed)
	{
		ppl->i = 7 - ppl->i;
		ppl->j = 7 - ppl->j;
	}
}

// Redraws the squares stored in g_rgplDrag.  Used during drag-drop.
void DrawRgplDrag(HDC hdc)
{
	DrawBorders(hdc);
	for (int i = 0; i < g_cplDrag; i++)
	{
		DrawSquare(hdc, g_rgplDrag[i].i, g_rgplDrag[i].j);
	}
}

// Provides drag feedback by drawing the piece being dragged at the current mouse position.
void DrawDragPiece(HDC hdc)
{
	DrawRgplDrag(hdc);
	switch (g_pieceDrag)
	{
	case pieceRed:
	case pieceRedKing:
		::SelectObject(hdc, g_hbrRed);
		::SelectObject(hdc, g_hpenBlack);
		break;

	case pieceBlack:
	case pieceBlackKing:
		::SelectObject(hdc, g_hbrBlack);
		::SelectObject(hdc, g_hpenGrey);
		break;
	}
	RECT rect;
	rect.left = g_xDrag - ((g_cxSquare - 6) / 2);
	rect.right = g_xDrag + ((g_cxSquare - 6) / 2);
	rect.top = g_yDrag - ((g_cySquare - 6) / 2);
	rect.bottom = g_yDrag + ((g_cySquare - 6) / 2);
	::Ellipse(hdc, rect.left, rect.top, rect.right, rect.bottom);
	
	if (g_pieceDrag == pieceRedKing || g_pieceDrag == pieceBlackKing)
	{
		::InflateRect(&rect, -3, -3);
		::Ellipse(hdc, rect.left, rect.top, rect.right, rect.bottom);
	}
	
	// set g_cplDrag, g_rgplDrag.  we do this totally naively.
	g_cplDrag = 4;
	GetPlForLocation(rect.left, rect.top, &g_rgplDrag[0]);
	GetPlForLocation(rect.left, rect.bottom, &g_rgplDrag[1]);
	GetPlForLocation(rect.right, rect.top, &g_rgplDrag[2]);
	GetPlForLocation(rect.right, rect.bottom, &g_rgplDrag[3]);
}

// Called to end a drag-drop operation.
void CancelDrag(HDC hdc)
{
	g_fDragging = FALSE;
	SETPIECEAT(g_plDragStart.i, g_plDragStart.j, g_pieceDrag);
	DrawRgplDrag(hdc);
	DrawSquare(hdc, g_plDragStart.i, g_plDragStart.j);
}

// Moves a piece, both in the checkerboard array and onscreen.
void MovePiece(HDC hdc, int iFrom, int jFrom, int iTo, int jTo)
{
	int piece = PIECEAT(iFrom, jFrom);
	SETPIECEAT(iTo, jTo, piece);
	SETPIECEAT(iFrom, jFrom, pieceNone);

	DrawSquare(hdc, iFrom, jFrom);
	DrawSquare(hdc, iTo, jTo);
}

// Undoes the last drag-drop piece move.
void UndoMove(HDC hdc)
{
	SETPIECEAT(g_plDragEnd.i, g_plDragEnd.j, pieceNone);
	SETPIECEAT(g_plDragStart.i, g_plDragStart.j, g_pieceDrag);
	
	DrawSquare(hdc, g_plDragStart.i, g_plDragStart.j);
	DrawSquare(hdc, g_plDragEnd.i, g_plDragEnd.j);
}

// Turns the piece at (iKing, jKing) into a king.
void KingPiece(HDC hdc, int iKing, int jKing)
{
	int piece = PIECEAT(iKing, jKing);
	
	if (piece == pieceRed)
	{
		SETPIECEAT(iKing, jKing, pieceRedKing);
	}
	else
	{
		SETPIECEAT(iKing, jKing, pieceBlackKing);
	}
	DrawSquare(hdc, iKing, jKing);
}


// Removes the piece at (iJump, jJump).
void JumpOverPiece(HDC hdc, int iJump, int jJump)
{
	SETPIECEAT(iJump, jJump, pieceNone);
	DrawSquare(hdc, iJump, jJump);
}

// Helper routine.
void SetTitleMessage(HWND hwnd, char *szMsg)
{
	char szT[256];
	wsprintf(szT, "Checkers: %s", szMsg);
	SetWindowText(hwnd, szT);
}

////////////////////////////////////////////////////////////////////////////////
// Window proc for the main checkers window.
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT uMsg, WPARAM wparam, LPARAM lparam)
{
	LONG		lRet = 0;
	HDC			hdc;
	PAINTSTRUCT	ps;
	MOVEMSG		movemsg;

	switch (uMsg)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
		
	case WM_KILLFOCUS:
		g_fDragging = FALSE;
		break;

	case WM_LBUTTONDOWN:
		if (!g_fMyTurn)
			break;
	
		// Start dragging.
		GetPlForLocation(LOWORD(lparam), HIWORD(lparam), &g_plDragStart);
		g_pieceDrag = PIECEAT(g_plDragStart.i, g_plDragStart.j);
		if (g_pieceDrag == pieceNone)
			break;

		if (g_fRed)
		{
			if (g_pieceDrag != pieceRed && g_pieceDrag != pieceRedKing)
				break;
		}
		else
		{
			if (g_pieceDrag != pieceBlack && g_pieceDrag != pieceBlackKing)
				break;
		}

		SETPIECEAT(g_plDragStart.i, g_plDragStart.j, pieceNone);
		hdc = ::GetDC(hwnd);
		DrawSquare(hdc, g_plDragStart.i, g_plDragStart.j);
		
		g_fDragging = TRUE;
		g_xDrag = LOWORD(lparam);
		g_yDrag = HIWORD(lparam);
		g_cplDrag = 0;
		DrawDragPiece(hdc);
		::ReleaseDC(hwnd, hdc);
		break;
		
	case WM_MOUSEMOVE:
		if (!g_fDragging)
			break;

		// Track drag-drop.
		g_xDrag = LOWORD(lparam);
		g_yDrag = HIWORD(lparam);
		hdc = ::GetDC(hwnd);
		DrawDragPiece(hdc);
		::ReleaseDC(hwnd, hdc);
		break;
		
	case WM_LBUTTONUP:
		if (!g_fDragging)
			break;
	
		// Drag-drop is done.  Move the piece.
		g_fDragging = FALSE;
		GetPlForLocation(LOWORD(lparam), HIWORD(lparam), &g_plDragEnd);
		
		hdc = ::GetDC(hwnd);
		
		if (PIECEAT(g_plDragEnd.i, g_plDragEnd.j) != pieceNone ||
			(g_plDragStart.i == g_plDragEnd.i && g_plDragStart.j == g_plDragEnd.j))
		{
			CancelDrag(hdc);
		}
		else
		{
			SETPIECEAT(g_plDragEnd.i, g_plDragEnd.j, g_pieceDrag);
			DrawRgplDrag(hdc);
			DrawSquare(hdc, g_plDragEnd.i, g_plDragEnd.j);
			
			// Send move to server for validation
			movemsg.header.cmsg = cmsgMove;
			movemsg.iFrom = g_plDragStart.i;
			movemsg.jFrom = g_plDragStart.j;
			movemsg.iTo = g_plDragEnd.i;
			movemsg.jTo = g_plDragEnd.j;
			if (FAILED(g_pchannel->HrSendData(&movemsg, sizeof(movemsg))))
			{
				::MessageBox(NULL, "Couldn't send move!", "Error", MB_OK | MB_ICONERROR);
				::PostQuitMessage(0);
			}
		}
		::ReleaseDC(hwnd, hdc);
		break;
		
	case WM_KEYDOWN:
		if (!g_fDragging)
			break;

		hdc = ::GetDC(hwnd);
		CancelDrag(hdc);
		::ReleaseDC(hwnd, hdc);
		
	case WM_PAINT:
		{
		hdc = ::BeginPaint(hwnd, &ps);
		DrawBorders(hdc);
 		for (int i = 0; i < 8; i++)
			for (int j = 0; j < 8; j++)
			{
				DrawSquare(hdc, i, j);
			}
		::EndPaint(hwnd, &ps);
		break;
		}

	// The remainder of the messages are our custom window messages sent
	// by the channel reader thread.
	case WM_INVALIDMOVE:
		hdc = ::GetDC(hwnd);
		UndoMove(hdc);
		::ReleaseDC(hwnd, hdc);
		
		SetTitleMessage(hwnd, "Invalid move...Move again");
		break;

	case WM_MOVEOK:
		// wparam = fContinueJump
		if (wparam)
			SetTitleMessage(hwnd, "Keep jumping");
		else
			SetTitleMessage(hwnd, "");
		break;
		
	case WM_PLAYERMOVE:
		// wparam = from, lparam = to
		hdc = ::GetDC(hwnd);
		MovePiece(hdc, LOWORD(wparam), HIWORD(wparam), LOWORD(lparam), HIWORD(lparam));
		::ReleaseDC(hwnd, hdc);
		
		break;
		
	case WM_TURNCHANGE:
		// wparam = fRedTurn
		if (g_fRed)
			g_fMyTurn = wparam;
		else
			g_fMyTurn = !wparam;
			
		if (g_fMyTurn)
			SetTitleMessage(hwnd, "Your turn");
		break;
		
	case WM_KING:
		// wparam = iKing, lparam = jKing
		hdc = ::GetDC(hwnd);
		KingPiece(hdc, wparam, lparam);
		::ReleaseDC(hwnd, hdc);
		break;
		
	case WM_JUMP:
		// wparam = iJump, lparam = jJump
		hdc = ::GetDC(hwnd);
		JumpOverPiece(hdc, wparam, lparam);
		::ReleaseDC(hwnd, hdc);
		break;
		
	case WM_YOUWIN:
		MessageBox(hwnd, "You win!", "Checkers", MB_OK);
		break;

	case WM_YOULOSE:
		MessageBox(hwnd, "You lose!", "Checkers", MB_OK);
		break;

	case WM_YOUWINBYFORFEIT:
		MessageBox(hwnd, "You win by forfeit!", "Checkers", MB_OK);
		break;

	default:
		lRet = ::DefWindowProc(hwnd, uMsg, wparam, lparam);
		break;
	}
	return lRet;
}

////////////////////////////////////////////////////////////////////////////////
// Standard Win32 WinMain.
int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR szCmdLine, int nshow)
{
	MSG msg;

	if (!FInitApp(hinst))
		return FALSE;

	if (!FConnect())
		return FALSE;

	if (!FInitGame())
		return FALSE;
		
	::ShowWindow(g_hwndMain, nshow);
	::UpdateWindow(g_hwndMain);
	
	while (::GetMessage(&msg, NULL, 0, 0))
	{
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}

	FTermApp();
	return msg.wParam;
}

// Initializes the window-related constants.
BOOL FInitApp(HINSTANCE hinst)
{
	g_hinst = hinst;
	
	g_hbrDkRed	= ::CreateSolidBrush(RGB(64, 0, 0));
	g_hbrRed	= ::CreateSolidBrush(RGB(255, 0, 0));
	if (!g_hbrRed)
		return FALSE;
	g_hbrBlack	= ::GetStockObject(BLACK_BRUSH);
	g_hbrGrey	= ::GetStockObject(GRAY_BRUSH);
	g_hpenBlack	= ::GetStockObject(BLACK_PEN);
	g_hpenGrey	= ::CreatePen(PS_SOLID, 1, RGB(128,128,128));
	
	if (!FRegisterWndClass(CS_HREDRAW | CS_VREDRAW, MainWndProc, NULL, NULL, g_szClassMain))
		return FALSE;
		
	return TRUE;
}

// Helper routine.
BOOL FRegisterWndClass(UINT style, WNDPROC wndproc, HICON hicon, char* szMenu, char* szClass)
{
	WNDCLASS wc;
	
	wc.style			= style;
	wc.lpfnWndProc		= wndproc;
	wc.cbClsExtra		= 0;
	wc.cbWndExtra		= 0;
	wc.hInstance		= g_hinst;
	wc.hIcon			= hicon;
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground	= (HBRUSH)(COLOR_BTNFACE + 1);
	wc.lpszMenuName		= szMenu;
	wc.lpszClassName	= szClass;
	return RegisterClass(&wc);
}

// Cleans up all resources allocated by the app, including all the ChatSock objects.
BOOL FTermApp()
{
	if (g_pchannel)
	{
		g_pchannel->HrLeave(TRUE);
		g_pchannel->Release();
	}
	if (g_psocket)
	{
		g_psocket->HrLogOff();
		g_psocket->HrCloseSocket();
		g_psocket->Release();
	}

	// We wait for our reader thread to return so we can be sure that
	// it has released its reference to g_pchannel.
	::WaitForSingleObject(g_hthreadChannel, INFINITE);
	::DeleteObject(g_hbrRed);
	::DeleteObject(g_hbrDkRed);
	::DeleteObject(g_hpenGrey);
	return TRUE;
}

// For simplicity's sake, we just hard-code a list of all red's pieces.
// We get black's pieces by symmetry.  {-1, -1} terminates the list.
PL rgplRed[] = 
{
	{0, 0},	{1, 1},	{0, 2},	{2, 0},	{3, 1},	{2, 2},	{4, 0},	{5, 1},
	{4, 2},	{6, 0},	{7, 1},	{6, 2},	{-1, -1}
};

// Creates main window.  Starts channel reader thread.
// Initializes game-related constants including board.
BOOL FInitGame()
{
	int cyTitle	= ::GetSystemMetrics(SM_CYCAPTION);
	int cxEdge	= ::GetSystemMetrics(SM_CXFIXEDFRAME);
	int cyEdge	= ::GetSystemMetrics(SM_CYFIXEDFRAME);

	g_hwndMain = ::CreateWindow(g_szClassMain, "Checkers",
							  WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX,
							  CW_USEDEFAULT, 0,
							  8 * (g_cxSquare + cxBorder) + cxBorder + (2 * cxEdge),
							  8 * (g_cySquare + cyBorder) + cyBorder + cyTitle + (2 * cyEdge),
							  NULL, NULL, g_hinst, NULL);
							  
	if (!g_hwndMain)
		return FALSE;

	DWORD tid;
	g_pchannel->AddRef(); // for thread
	g_hthreadChannel = ::CreateThread(NULL, 0, DwChannelThreadProc, NULL, 0, &tid);
	if (!g_hthreadChannel)
	{
		g_pchannel->Release();
		return FALSE;
	}
	::FillMemory(g_rgbBoard, 8*8, 0);

	PPL ppl = rgplRed;
	while (ppl->i != -1)
	{
		SETPIECEAT(ppl->i, ppl->j, pieceRed);
		SETPIECEAT((7 - ppl->i), (7 - ppl->j), pieceBlack);
		ppl++;
	}

	g_fMyTurn = !g_fRed;
		
	if (g_fMyTurn)
		SetTitleMessage(g_hwndMain, "Your turn");
	return TRUE;
}

#if defined(_DEBUG)
void DebugMessageType(LPCSTR t, CSMSG_TYPE c)
{
	char szBuf[256];
	switch (c)
	{
	case CSMSG_TYPE_NONE:
		wsprintf(szBuf, "%s\tCSMSG_TYPE_NONE\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_ERROR:				// socket, channel	
		wsprintf(szBuf, "%s\tCSMSG_TYPE_ERROR\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_LOGIN:				// socket	
		wsprintf(szBuf, "%s\tCSMSG_TYPE_LOGIN\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_TEXT_A:				// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_TEXT_A\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_TEXT_W:				// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_TEXT_W\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_DATA:				// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_DATA\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_ADDCHANNEL:			// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_ADDCHANNEL\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_ADDMEMBER:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_ADDMEMBER\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_GOTMEMLIST:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_GOTMEMLIST\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_DELMEMBER:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_DELMEMBER\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_DELCHANNEL:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_DELCHANNEL\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_MODEMEMBER:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_MODEMEMBER\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_MODECHANNEL:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_MODECHANNEL\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_WHISPERTEXT_A:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_WHISPERTEXT_A\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_WHISPERTEXT_W:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_WHISPERTEXT_W\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_WHISPERDATA:		// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_WHISPERDATA\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_NEWTOPIC:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_NEWTOPIC\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_PROPERTYDATA:		// socket,channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_PROPERTYDATA\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_QUERYDATA:			// socket, channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_QUERYDATA\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_PRIVATEMSG:			// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_PRIVATEMSG\n", t);		::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_NEWNICK:			// channel
		wsprintf(szBuf, "%s\tCSMSG_TYPE_NEWNICK\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_INVITE:				// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_INVITE\n", t);			::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_SERVERMSG_TEXT_A:	// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_SERVERMSG_TEXT_A\n", t);	::OutputDebugString(szBuf);	break;
	case CSMSG_TYPE_SERVERMSG_TEXT_W:	// socket
		wsprintf(szBuf, "%s\tCSMSG_TYPE_SERVERMSG_TEXT_W\n", t);	::OutputDebugString(szBuf);	break;
	default:
		wsprintf(szBuf, "%s\tError! Beyond CSMSG_TYPE range(%d)!\n", t, c);	::OutputDebugString(szBuf);	break;
	}
}
#endif