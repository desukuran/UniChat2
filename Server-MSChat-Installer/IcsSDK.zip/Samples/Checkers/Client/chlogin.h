/*--------------------------------------------------------------------------
	chlogin.h
	
		Checkers client login-related code.

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _CHLOGIN_H
#define _CHLOGIN_H

extern BOOL FConnect();

#endif // _CHLOGIN_H
