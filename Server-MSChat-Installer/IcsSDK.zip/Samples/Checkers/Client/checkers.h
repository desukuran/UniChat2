/*--------------------------------------------------------------------------
	checkers.h
	
		Main Checkers client header.

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _CHECKERS_H
#define _CHECKERS_H

extern HINSTANCE		g_hinst;
extern PICS				g_psocket;
extern PICS_CHANNEL		g_pchannel;
extern HANDLE			g_hthreadSocket;
extern DWORD			g_tidSocket;
extern HANDLE			g_hthreadChannel;
extern DWORD			g_tidChannel;

extern BOOL				g_fRed;
extern BOOL				g_fPlaying;

#endif // _CHECKERS_H
