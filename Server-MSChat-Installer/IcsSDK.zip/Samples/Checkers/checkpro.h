/*--------------------------------------------------------------------------
	checkpro.h
	
		Checkers protocol definition for Checkers/CheckSvc samples

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _CHECKPRO_H
#define _CHECKPRO_H

// MIC data messages are used to transfer data for the checkers game.
// Every message has a header and optional additional data.

// CMSG is a checkers message ID.
typedef DWORD CMSG, *PCMSG;
const CMSG cmsgNil				= 0x00;
const CMSG cmsgHello			= 0x01;
const CMSG cmsgHelloResponse	= 0x02;
const CMSG cmsgError			= 0x03;
const CMSG cmsgMove				= 0x04;
const CMSG cmsgMoveOk			= 0x05;
const CMSG cmsgTurnChange		= 0x06;
const CMSG cmsgKing				= 0x07;
const CMSG cmsgJump				= 0x08;
const CMSG cmsgYouWin			= 0x09;
const CMSG cmsgYouLose			= 0x0a;
const CMSG cmsgYouWinByForfeit	= 0x0b;

// CERR is a checkers error
typedef DWORD CERR, *PCERR;
const CERR cerrNil				= 0x00;
const CERR cerrGameFull			= 0x01;
const CERR cerrVersion			= 0x02;
const CERR cerrInvalidMove		= 0x03;
const CERR cerrJumpForced		= 0x04;

// These are never actually sent over the wire, but both sides need them.
typedef struct _piecelocation
{
	int i;
	int j;
} PL, *PPL;

#define pieceNone		0
#define pieceRed		1
#define pieceBlack		2
#define pieceRedKing	3
#define pieceBlackKing	4

#define CHECKERS_CURRENT_VERSION 1

#include "pshpack1.h"
typedef struct _checkmsgheader
{
	CMSG	cmsg;
} HEADER, *PHEADER;

// Hello messages:
typedef struct _hellomsg
{
	HEADER		header;
	int			iVersion;		// should be CHECKERS_CURRENT_VERSION
} HELLOMSG, *PHELLOMSG;

// Hello response message:
typedef struct _helloresponsemsg
{
	HEADER		header;
	BOOL		fRed;			// if this is true, the player is red
} HELLORESMSG, *PHELLORESMSG;

// Error message:
typedef struct _errormsg
{
	HEADER		header;
	CERR		cerr;
} ERRORMSG, *PERRORMSG;

// Move message:
typedef struct _movemsg
{
	HEADER		header;
	int			iFrom;
	int			jFrom;
	int			iTo;
	int			jTo;
} MOVEMSG, *PMOVEMSG;

// Move-ok message:
typedef struct _moveokmsg
{
	HEADER		header;
	BOOL		fContinueJump;
} MOVEOKMSG, *PMOVEOKMSG;

// Turn-a-piece-into-a-king message:
typedef struct _kingmsg
{
	HEADER		header;
	int			iKing;
	int			jKing;
} KINGMSG, *PKINGMSG;

// Turn indication message:
typedef struct _turnmsg
{
	HEADER		header;
	BOOL		fRedTurn;
} TURNMSG, *PTURNMSG;

// Jump indication message:
typedef struct _jumpmsg
{
	HEADER		header;
	int			iJump;			// piece removed by jump
	int			jJump;
} JUMPMSG, *PJUMPMSG;

#include "poppack.h"

#endif // _CHECKPRO_H
