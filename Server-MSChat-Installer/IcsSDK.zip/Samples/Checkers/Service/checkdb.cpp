/*--------------------------------------------------------------------------
	checkdb.cpp
	
		class CCheckersDB

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

// class CCheckersDB

//	CCheckersDB maintains a simple flat-file database that keeps track
// of how many games a given nickname has won.  When FInit() is called, it
// reads in the database and stores it in memory as a linked list of DBE structures.

#include "checkpch.h"
#include "checkdb.h"

CCheckersDB::CCheckersDB()
{
	m_pdbeHead = NULL;
	
	::InitializeCriticalSection(&m_cs);
}

CCheckersDB::~CCheckersDB()
{
	this->WriteDB();

	this->DeletePdbeChain(m_pdbeHead);
	::DeleteCriticalSection(&m_cs);
}

// Stores szDBFile and calls FLoadDB to load the data.
BOOL CCheckersDB::FInit(char* szDBFile)
{
//	HKEY hkey;
//	HKEY hkeySvc;
//	DWORD dwType;
	DWORD cb = sizeof(m_szDBFile);
	
	lstrcpy(m_szDBFile, szDBFile);
	
	return this->FLoadDB(m_szDBFile);
}

// Helper routine.
int IchNextTab(char* pch, int ichCur, int chTotal)
{
	int ich = 0;
	
	while (ich + ichCur < chTotal)
	{
		if (pch[ich + ichCur] == '\t')
			return ich + ichCur;
		ich++;
	}
	return -1;
}

// Helper routine.
int IchNextCR(char* pch, int ichCur, int chTotal)
{
	int ich = 0;
	
	while (ich + ichCur < chTotal)
	{
		if (pch[ich + ichCur] == '\r' || pch[ich + ichCur] == '\n')
			return ich + ichCur;
		ich++;
	}
	return -1;
}

// Helper routine.
int IFromRgch(char* rgch, int cch)
{
	int i = 0;
	int ich = 0;
	int ch;
	
	while (cch)
	{
		i *= 10;
		ch = rgch[ich];
		if (ch < '0' || ch > '9')
			return -1;
		i += ch - '0';
		ich++;
		cch--;
	}
	return i;
}

// Loads the flat-text-file database into a linked list of DBE structures.
BOOL CCheckersDB::FLoadDB(char *szFile)
{
	HANDLE hfm = NULL;
	char* pch = NULL;
	int cch;
	BOOL fRet = FALSE;
	int ich = 0;
	int ichTab;
	int ichCR;
	PDBE pdbe;
	int cwins;
	
	::EnterCriticalSection(&m_cs);
	
	m_pdbeHead = NULL;
	
	HANDLE hfile = ::CreateFile(szFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (INVALID_HANDLE_VALUE == hfile)
		goto LBail;
	cch = ::GetFileSize(hfile, NULL);
	hfm = ::CreateFileMapping(hfile, NULL, PAGE_READONLY, 0, 0, NULL);
	if (!hfm)
		goto LBail;
	pch = (char*)::MapViewOfFile(hfm, FILE_MAP_READ, 0, 0, 0);
	if (!pch)
		goto LBail;
	
	while (ich < cch)
	{
		ichTab = IchNextTab(pch, ich, cch);
		if (ichTab == -1)
			break;

		ichCR = IchNextCR(pch, ichTab + 1, cch);
		if (ichCR == -1)
			break;
			
		cwins = IFromRgch(&pch[ichTab + 1], ichCR - ichTab - 1);
		if (cwins == -1)
			break;
			
		pdbe = new DBE;
		lstrcpyn(pdbe->szNick, &pch[ich], min(ichTab - ich, MIC_MAX_USER_ALIAS_LENGTH) + 1);
		pdbe->cwins = cwins;
		
		pdbe->pdbeNext = m_pdbeHead;
		m_pdbeHead = pdbe;

		ich = ichCR;
		while (pch[ich] == '\r' || pch[ich] == '\n')
			ich++;
	}
	
	fRet = TRUE;
LBail:
	if (pch)
		UnmapViewOfFile(pch);
	if (hfm)
		CloseHandle(hfm);
	if (hfile != INVALID_HANDLE_VALUE)
		CloseHandle(hfile);
	::LeaveCriticalSection(&m_cs);
	return fRet;
}

// Finds out how many wins a given user has.
BOOL CCheckersDB::FGetScore(char* szNick, int* pcwins)
{
	::EnterCriticalSection(&m_cs);
	PDBE pdbe = this->PdbeForNick(szNick);
	if (!pdbe)
	{
		::LeaveCriticalSection(&m_cs);
		return FALSE;
	}
	*pcwins = pdbe->cwins;
	::LeaveCriticalSection(&m_cs);
	return TRUE;
}

// Helper routine.
PDBE CCheckersDB::PdbeForNick(char* szNick)
{
	PDBE pdbe = m_pdbeHead;
	
	while (pdbe)
	{
		if (!lstrcmpi(szNick, pdbe->szNick))
			break;
		pdbe = pdbe->pdbeNext;
	}
	return pdbe;
}

// Helper routine.
void CCheckersDB::DeletePdbeChain(PDBE pdbe)
{
	PDBE pdbeNext;

	while (pdbe)
	{
		pdbeNext = pdbe->pdbeNext;
		delete pdbe;
		
		pdbe = pdbeNext;
	}
}

// Records a win.  If the specified user doesn't have a DBE for their score,
// FAddWin creates a new one and adds it to the chain.
BOOL CCheckersDB::FAddWin(char* szNick)
{
	::EnterCriticalSection(&m_cs);
	PDBE pdbe = this->PdbeForNick(szNick);
	if (pdbe)
	{
		(pdbe->cwins)++;
		::LeaveCriticalSection(&m_cs);
		return TRUE;
	}
	pdbe = new DBE;
	lstrcpy(pdbe->szNick, szNick);
	pdbe->cwins = 1;
	
	pdbe->pdbeNext = m_pdbeHead;
	m_pdbeHead = pdbe;
	
	::LeaveCriticalSection(&m_cs);
	return TRUE;
}

// Saves the contents of the DBE list to a flat text file.
void CCheckersDB::WriteDB()
{
	PDBE pdbe;
	char szWins[20];
	DWORD cbWritten;

	::EnterCriticalSection(&m_cs);

	HANDLE hfile = ::CreateFile(m_szDBFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
	if (hfile == INVALID_HANDLE_VALUE)
		goto LDone;

	pdbe = m_pdbeHead;
	while (pdbe)
	{
		if (!WriteFile(hfile, pdbe->szNick, lstrlen(pdbe->szNick), &cbWritten, NULL)
				|| cbWritten != (DWORD)lstrlen(pdbe->szNick))
			goto LDone;
		if (!WriteFile(hfile, "\t", 1, &cbWritten, NULL)
				|| cbWritten != (DWORD)1)
			goto LDone;
		wsprintf(szWins, "%d", pdbe->cwins);
		if (!WriteFile(hfile, szWins, lstrlen(szWins), &cbWritten, NULL)
				|| cbWritten != (DWORD)lstrlen(szWins))
			goto LDone;
		if (!WriteFile(hfile, "\r\n", 2, &cbWritten, NULL)
				|| cbWritten != (DWORD)2)
			goto LDone;
			
		pdbe = pdbe->pdbeNext;
	}
LDone:
	if (hfile != INVALID_HANDLE_VALUE)
		::CloseHandle(hfile);
	::LeaveCriticalSection(&m_cs);
}
