/*--------------------------------------------------------------------------
	checkdb.h
	
		class CCheckersDB

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

//	class CCheckersDB
//		CCheckersDB maintains a simple flat-file database that keeps track
//	of how many games a given nickname has won.  When FInit() is called, it
//	reads in the database and stores it in memory as a linked list of
//	DBE structures.

typedef struct _dbentry
{
	struct _dbentry* pdbeNext;
	char			szNick[MIC_MAX_USER_ALIAS_LENGTH + 1];
	int				cwins;
} DBE, *PDBE;

class CCheckersDB
{
public:
	CCheckersDB(void);
	~CCheckersDB(void);

	BOOL				FInit(char* szDBFile);
	BOOL				FAddWin(char* szNick);
	BOOL				FGetScore(char* szNick, int* pcwins);
	
private:
	char				m_szDBFile[MAX_PATH];
	BOOL				FLoadDB(char* szFile);
	void				WriteDB();
	PDBE				PdbeForNick(char* szNick);
	void				DeletePdbeChain(PDBE pdbe);
	
	CRITICAL_SECTION	m_cs;
	PDBE				m_pdbeHead;
};
