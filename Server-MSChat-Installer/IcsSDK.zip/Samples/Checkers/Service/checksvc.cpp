/*--------------------------------------------------------------------------
	checksvc.cpp
	
		CheckSvc -- main service file

	Copyright (C) 1996 Microsoft Corporation
	All rights reserved.

  --------------------------------------------------------------------------*/

#include "checkpch.h"
#include "..\checkpro.h"

#include "checkdb.h"
#include "checksvc.h"

// This service's GUID is {379AD880-B472-11cf-87A7-444553540000}.

CCheckersDB g_db;

#define PIECEAT(i, j)			(m_rgbBoard[(i) + (8 * (j))])
#define SETPIECEAT(i, j, p) 	m_rgbBoard[(i) + (8 * (j))] = (p)

//	MicCreateService
//	Main entry point for channel services.	Creates a CCheckersService object.
// __declspec(dllexport) 
extern "C" PMICSERVICE STDAPICALLTYPE MicCreateService(REFIID riid)
{
	return new CCheckersService();
}

// CCheckersService implements a checkers game as a MIC channel service.
CCheckersService::CCheckersService()
{
	::InitializeCriticalSection(&m_csMembers);
	m_pmemberRed		= NULL;
	m_pmemberBlack		= NULL;
	m_fGameInProgress	= FALSE;
}

CCheckersService::~CCheckersService()
{
	::DeleteCriticalSection(&m_csMembers);
}

// Called by the MIC server on initialization/termination of the channel service.
// If pMicChannel is non-NULL, the service is being initialized;
// if it is NULL, the service is being terminated.
MICERR CCheckersService::SetChannel(PMICCHANNEL pMicChannel)
{
	if (pMicChannel)
	{
		m_pChannel = pMicChannel;
		DWORD cwch;
		WCHAR wszDBFile[256];
		char szDBFile[256];
		if (m_pChannel->GetServiceValue(L"Data", wszDBFile, &cwch) != MICERR_NONE)
			return MICERR_INTERNAL;

		WideCharToMultiByte(CP_ACP, 0, wszDBFile, -1, szDBFile, sizeof(szDBFile), NULL, NULL);
		
		if (!g_db.FInit(szDBFile))
			return MICERR_INTERNAL;
	}
	return MICERR_NONE;
}

// Called by the MIC server when a member joins the channel.
MICERR CCheckersService::AddMember(PMICMEMBER pMicMember)
{
	pMicMember->SendTextA(NULL, "Welcome to the Checkers Channel Service!");
	return MICERR_NONE;
}

// Called by the MIC server when a member leaves the channel.
// Leaving a channel while playing forfeits the game,
// so we have to check to see if the member leaving is one of our two players.
MICERR CCheckersService::DelMember(PMICMEMBER pMicMember)
{
	if (m_fGameInProgress)
	{
		if (pMicMember == m_pmemberBlack)
		{
			this->HandleWin(TRUE, TRUE);
		}
		else if (pMicMember == m_pmemberRed)
		{
			this->HandleWin(FALSE, TRUE);
		}
	}
	return MICERR_NONE;
}

// Called by the MIC server when a text message is sent within the channel.
// This implementation handles questions of the form "Get score for bob";
// in response to such a question, this routine queries the score DB
// for bob's score and tells the channel.
#define szQuestion "get score for "
#define cchQuestion (lstrlen(szQuestion))
MICERR CCheckersService::RecvTextA(PMICMEMBER pMicMember, PCSTR pTextA, ULONG cText)
{
	char szT[128];
	char szNick[MIC_MAX_USER_ALIAS_LENGTH + 1];
	char szMsg[256];
	int cwins;
	
	if (cText > (ULONG)cchQuestion)
	{
		lstrcpyn(szT, pTextA, cchQuestion + 1);
		if (!lstrcmpi(szT, szQuestion))
		{
			lstrcpyn(szNick, pTextA + cchQuestion, min(cText - cchQuestion, MIC_MAX_USER_ALIAS_LENGTH) + 1);
			if (g_db.FGetScore(szNick, &cwins))
				wsprintf(szMsg, "%s has won %d game%s.", szNick, cwins, cwins > 1 ? "s" : "");
			else
				wsprintf(szMsg, "Sorry, I've never heard of %s.", szNick);

			m_pChannel->SendTextA(pMicMember, NULL, pTextA, cText);
			m_pChannel->SendTextA(NULL, NULL, szMsg);
			return MICERR_NONE;
		}
	}
	return MICERR_NOTHANDLED;
}

// Called by the MIC server when a Unicode message is sent within the channel.
// This service does not handle Unicode messages.
MICERR CCheckersService::RecvTextW(PMICMEMBER pMicMember, PCWSTR pTextW, ULONG cText)
{
	return MICERR_NOTHANDLED;
}

// Called by the MIC server when a data message is sent to the channel.
// The checkers protocol uses data messages to send move and game-state information,
// so this routine has to handle all game-related messages.
// See the checkers client and ..\checkpro.h for a description of the checkers protocol.
MICERR CCheckersService::RecvData(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	PHEADER 	pheader;
	PHELLOMSG	phellomsg;
	ERRORMSG	errormsg;
	HELLORESMSG helloresmsg;
	PMOVEMSG	pmovemsg;

	// Is the message big enough?
	if (cData < sizeof(HEADER))
		return MICERR_NONE;
		
	pheader = (PHEADER)pData;
	switch (pheader->cmsg)
	{
	case cmsgNil:
		break;
		
	case cmsgHello:
		// A client wants to join the game.  Is there room?
		if (m_fGameInProgress)
			goto LGameFull;
		phellomsg = (PHELLOMSG)pheader;
		if (phellomsg->iVersion != CHECKERS_CURRENT_VERSION)
		{
			errormsg.header.cmsg	= cmsgError;
			errormsg.cerr			= cerrVersion;
			pMicMember->SendData(NULL, &errormsg, sizeof(errormsg));
		}
		else
		{
			::EnterCriticalSection(&m_csMembers);
			if (m_pmemberRed && m_pmemberBlack)
			{
LGameFull:
				errormsg.header.cmsg	= cmsgError;
				errormsg.cerr			= cerrGameFull;
				pMicMember->SendData(NULL, &errormsg, sizeof(errormsg));
			}
			else
			{
				if (!m_pmemberRed)
				{
					m_pmemberRed = pMicMember;
					helloresmsg.fRed = TRUE;
				}
				else
				{
					m_pmemberBlack = pMicMember;
					helloresmsg.fRed = FALSE;
					m_fGameInProgress = TRUE;
					m_fRedTurn = FALSE;
					this->InitBoard();
				}
				helloresmsg.header.cmsg = cmsgHelloResponse;
				pMicMember->SendData(NULL, &helloresmsg, sizeof(helloresmsg));
			}
			::LeaveCriticalSection(&m_csMembers);
		}
		break;
		
	case cmsgMove:
		// A client's trying to move.  Validate the move and send out
		// new state if appropriate.
		if (!m_fGameInProgress)
			break;
		if (pMicMember != m_pmemberBlack && pMicMember != m_pmemberRed)
			break;
		
		if (cData != sizeof(MOVEMSG))
			break;

		pmovemsg = (PMOVEMSG)pheader;
		this->HandleMove(pMicMember, pmovemsg);
		break;
	}

	return MICERR_NONE;
}

// Called when a broadcast message is sent to the channel.
// The checkers service simply ignores broadcast data.
MICERR CCheckersService::RecvBroadcast(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	return MICERR_NOTHANDLED;
}

/////////////////////////////////////////////////////////////////////////////
// Checkers-specific code

PL rgplRed[] = 
{
	{0, 0},	{1, 1},	{0, 2},	{2, 0},	{3, 1},	{2, 2},	{4, 0},	{5, 1},
	{4, 2},	{6, 0},	{7, 1},	{6, 2},	{-1, -1}
};

// Sets the board to its initial state.
void CCheckersService::InitBoard()
{
	::FillMemory(m_rgbBoard, 8 * 8, 0);
	PPL ppl = rgplRed;
	while (ppl->i != -1)
	{
		SETPIECEAT(ppl->i, ppl->j, pieceRed);
		SETPIECEAT((7 - ppl->i), (7 - ppl->j), pieceBlack);
		ppl++;
	}
	m_cPiecesRed = 12;
	m_cPiecesBlack = 12;
}

// Validates an attempted move and returns information about
// whether pieces were jumped and/or kinged as a result of the move.
BOOL CCheckersService::FValidMove(PMICMEMBER pmember, PMOVEMSG pmovemsg,
							 BOOL* pfJump, BOOL* pfKing, CERR* pcerr)
{
	int piece;
	int di, dj;
	int absdi, absdj;
	int iJump, jJump;
	int pieceJump;

	*pcerr = cerrInvalidMove;

	if (PIECEAT(pmovemsg->iTo, pmovemsg->jTo) != pieceNone)
		return FALSE;

	piece = PIECEAT(pmovemsg->iFrom, pmovemsg->jFrom);
	if (m_fRedTurn)
	{
		if (piece != pieceRed && piece != pieceRedKing)
			return FALSE;
		if (pmember != m_pmemberRed)
			return FALSE;
	}
	else
	{
		if (piece != pieceBlack && piece != pieceBlackKing)
			return FALSE;
		if (pmember != m_pmemberBlack)
			return FALSE;
	}
		
	*pfKing = FALSE;
	if (piece == pieceRed)
	{
		if (pmovemsg->jTo == 7)
			*pfKing = TRUE;
	}
	else if (piece == pieceBlack)
	{
		if (pmovemsg->jTo == 0)
			*pfKing = TRUE;
	}
	
	di = pmovemsg->iTo - pmovemsg->iFrom;
	dj = pmovemsg->jTo - pmovemsg->jFrom;
	
	if (piece != pieceRedKing && piece != pieceBlackKing)
	{
		if (m_fRedTurn)
		{
			if (dj < 0)
				return FALSE;
		}
		else
		{
			if (dj > 0)
				return FALSE;
		}
	}
	
	absdi = (di < 0) ? -di : di;
	absdj = (dj < 0) ? -dj : dj;
	if (absdi != absdj)
		return FALSE;

	if (absdi != 1 && absdi != 2)
		return FALSE;
		
	*pfJump = (absdi == 2);
	if (absdi == 1)
	{
		// non-jump move

		if (this->FJumpAvailable())
		{
			*pcerr = cerrJumpForced;
			return FALSE;
		}
	}
	else
	{
		// jump move
		iJump = pmovemsg->iFrom + (di > 0 ? 1 : -1);
		jJump = pmovemsg->jFrom + (dj > 0 ? 1 : -1);
		
		pieceJump = PIECEAT(iJump, jJump);
		if (!pieceJump)
			return FALSE;
		if (m_fRedTurn)
		{
			if (pieceJump == pieceRed || pieceJump == pieceRedKing)
				return FALSE;
		}
		else
		{
			if (pieceJump == pieceBlack || pieceJump == pieceBlackKing)
				return FALSE;
		}
	}
		
	return TRUE;
}

// Called in RecvData() when a move message arrives.
// This routine sends out all appropriate new-state and/or error messages.
void CCheckersService::HandleMove(PMICMEMBER pmember, PMOVEMSG pmovemsg)
{
	PMICMEMBER	pmemberOther;
	ERRORMSG	errormsg;
	BOOL		fJump;
	BOOL		fKing;
	BOOL		fContinueJump = FALSE;
	MOVEOKMSG	moveokmsg;
	JUMPMSG		jumpmsg;
	KINGMSG		kingmsg;
	TURNMSG		turnmsg;
	int			piece;
	CERR		cerr;

	if (!this->FValidMove(pmember, pmovemsg, &fJump, &fKing, &cerr))
	{
		errormsg.header.cmsg = cmsgError;
		errormsg.cerr = cerr;
		pmember->SendData(NULL, &errormsg, sizeof(errormsg));
		return;
	}
		
	pmemberOther = (pmember == m_pmemberBlack) ? m_pmemberRed : m_pmemberBlack;

	piece = PIECEAT(pmovemsg->iFrom, pmovemsg->jFrom);
	SETPIECEAT(pmovemsg->iTo, pmovemsg->jTo, piece);
	SETPIECEAT(pmovemsg->iFrom, pmovemsg->jFrom, pieceNone);
	
	pmemberOther->SendData(NULL, pmovemsg, sizeof(MOVEMSG));

	if (fJump)
	{
		jumpmsg.header.cmsg = cmsgJump;
		
		if (pmovemsg->iTo > pmovemsg->iFrom)
			jumpmsg.iJump = pmovemsg->iFrom + 1;
		else
			jumpmsg.iJump = pmovemsg->iFrom - 1;
		if (pmovemsg->jTo > pmovemsg->jFrom)
			jumpmsg.jJump = pmovemsg->jFrom + 1;
		else
			jumpmsg.jJump = pmovemsg->jFrom - 1;

		SETPIECEAT(jumpmsg.iJump, jumpmsg.jJump, pieceNone);
		this->SendPlayerMessage(&jumpmsg, sizeof(jumpmsg));
		
		if (pmember == m_pmemberRed)
		{
			m_cPiecesBlack--;
			if (!m_cPiecesBlack)
			{
				this->HandleWin(TRUE, FALSE);
				return;
			}
		}
		else
		{
			m_cPiecesRed--;
			if (!m_cPiecesBlack)
			{
				this->HandleWin(FALSE, FALSE);
				return;
			}
		}
	}

	if (fKing)
	{
		kingmsg.header.cmsg = cmsgKing;
		kingmsg.iKing = pmovemsg->iTo;
		kingmsg.jKing = pmovemsg->jTo;
		SETPIECEAT(kingmsg.iKing, kingmsg.jKing, (piece == pieceRed) ? pieceRedKing : pieceBlackKing);
		this->SendPlayerMessage(&kingmsg, sizeof(kingmsg));
	}
	
	if (fJump)
		fContinueJump = this->FPieceCanJump(pmovemsg->iTo, pmovemsg->jTo);
	
	moveokmsg.header.cmsg = cmsgMoveOk;
	moveokmsg.fContinueJump = fContinueJump;
	pmember->SendData(NULL, &moveokmsg, sizeof(moveokmsg));
	
	if (!fContinueJump)
	{
		m_fRedTurn = !m_fRedTurn;
		turnmsg.header.cmsg = cmsgTurnChange;
		turnmsg.fRedTurn = m_fRedTurn;
		this->SendPlayerMessage(&turnmsg, sizeof(turnmsg));
	}
}

// Helper routine.
void CCheckersService::SendPlayerMessage(PVOID pvMsg, int cbMsg)
{
	m_pmemberBlack->SendData(NULL, pvMsg, cbMsg);
	m_pmemberRed->SendData(NULL, pvMsg, cbMsg);
}

// Helper routine.
BOOL CCheckersService::FPieceCanJumpTo(int i, int j, int iTo, int jTo)
{
	int iJump, jJump;
	int pieceJump;

	if (iTo < 0 || iTo > 7 || jTo < 0 || jTo > 7)
		return FALSE;

	if (PIECEAT(iTo, jTo) != pieceNone)
		return FALSE;
		
	iJump = i + ((iTo > i) ? 1 : -1);
	jJump = j + ((jTo > j) ? 1 : -1);
	pieceJump = PIECEAT(iJump, jJump);
	if (m_fRedTurn)
	{
		if (pieceJump == pieceBlack || pieceJump == pieceBlackKing)
			return TRUE;
	}
	else
	{
		if (pieceJump == pieceRed || pieceJump == pieceRedKing)
			return TRUE;
	}
	return FALSE;
}

// Helper routine.
BOOL CCheckersService::FPieceCanJump(int i, int j)
{
	int piece = PIECEAT(i, j);
	BOOL fKing;
	int djForward = (m_fRedTurn ? 2 : -2);

	fKing = (piece == pieceRedKing || piece == pieceBlackKing);
	if (this->FPieceCanJumpTo(i, j, i - 2, j + djForward) ||
		this->FPieceCanJumpTo(i, j, i + 2, j + djForward))
		return TRUE;
	if (!fKing)
		return FALSE;

	if (this->FPieceCanJumpTo(i, j, i - 2, j - djForward) ||
		this->FPieceCanJumpTo(i, j, i + 2, j - djForward))
		return TRUE;

	return FALSE;
}

// Helper routine.
BOOL CCheckersService::FJumpAvailable()
{
	int pieceMove = m_fRedTurn ? pieceRed : pieceBlack;
	int pieceMoveKing = m_fRedTurn ? pieceRedKing : pieceBlackKing;
	int piece;
	
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			piece = PIECEAT(i, j);
			if (piece == pieceMove || piece == pieceMoveKing)
			{
				if (this->FPieceCanJump(i, j))
					return TRUE;
			}
		}
	
	return FALSE;
}

// Called when a player wins. Also handles forfeits.
// Sends out you-win/you-lose messages and updates the score DB.
void CCheckersService::HandleWin(BOOL fRed, BOOL fForfeit)
{
	PMICMEMBER pmember;
	PMICMEMBER pmemberOther;
	HEADER header;
	PCWSTR wszAlias;
	char szAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];

	if (fRed)
	{
		pmember = m_pmemberRed;
		pmemberOther = m_pmemberBlack;
	}
	else
	{
		pmember = m_pmemberBlack;
		pmemberOther = m_pmemberRed;
	}
	header.cmsg = fForfeit ? cmsgYouWinByForfeit : cmsgYouWin;
	pmember->SendData(NULL, &header, sizeof(HEADER));

	if (!fForfeit)
	{
		header.cmsg = cmsgYouLose;
		pmemberOther->SendData(NULL, &header, sizeof(HEADER));
	}
		
	pmember->GetAlias(&wszAlias);
	WideCharToMultiByte(CP_ACP, 0, wszAlias, -1, szAlias, sizeof(szAlias), NULL, NULL);
	g_db.FAddWin(szAlias);
			
	m_fGameInProgress = FALSE;
	m_pmemberRed = NULL;
	m_pmemberBlack = NULL;
}
