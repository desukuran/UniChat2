/*--------------------------------------------------------------------------
	checksvc.h
	
		class CCheckersService

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

// class CCheckersService
// CCheckersService implements a checkers game as a MIC channel service.
  
#ifndef _CHECKSVC_H
#define _CHECKSVC_H

class CCheckersService : public IMicService
{
public:
	CCheckersService(void);
	~CCheckersService(void);
   
    // IMicService Methods
	STDMETHODIMP_(MICERR)	SetChannel(PMICCHANNEL pMicChannel);
    STDMETHODIMP_(MICERR)	AddMember(PMICMEMBER pMicMember);
    STDMETHODIMP_(MICERR)	DelMember(PMICMEMBER pMicMember);
    STDMETHODIMP_(MICERR)	RecvTextA(PMICMEMBER pMicMember,	PCSTR pTextA,	ULONG cText);
    STDMETHODIMP_(MICERR)	RecvTextW(PMICMEMBER pMicMember,	PCWSTR pTextW,	ULONG cText);
    STDMETHODIMP_(MICERR)	RecvData(PMICMEMBER pMicMember,		PVOID pData,	ULONG cData);
    STDMETHODIMP_(MICERR)	RecvBroadcast(PMICMEMBER pMicMember, PVOID pData,	ULONG cData);

private:
	PMICCHANNEL			m_pChannel;

	PMICMEMBER			m_pmemberRed;
	PMICMEMBER			m_pmemberBlack;
	CRITICAL_SECTION	m_csMembers;
	
	void				InitBoard();
	BOOL				m_fRedTurn;			// true if it's red's turn
	BOOL				m_fGameInProgress;
	BYTE				m_rgbBoard[8 * 8];	// holds board; same layout as the client's g_rgbBoard
	int					m_cPiecesRed;
	int					m_cPiecesBlack;

	BOOL				FValidMove(PMICMEMBER pmember, PMOVEMSG pmovemsg,
								   BOOL* pfJump, BOOL* pfKing, CERR* pcerr);
	void				HandleMove(PMICMEMBER pmember, PMOVEMSG pmovemsg);
	
	void				SendPlayerMessage(PVOID pvMsg, int cbMsg);
	
	BOOL				FJumpAvailable();	// uses m_fRedTurn
	BOOL				FPieceCanJump(int i, int j);
	BOOL				FPieceCanJumpTo(int i, int j, int iTo, int jTo);
	
	void				HandleWin(BOOL fRed, BOOL fForfeit);
};

#endif // _CHECKSVC_H

