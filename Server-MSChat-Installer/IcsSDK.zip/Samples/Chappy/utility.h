//****************************************************************************
//  Module:     Chappy.EXE
//  File:       Utility.h
//              
//
//  Copyright (c) Microsoft Corporation 1996-1997
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE.
//****************************************************************************


#ifndef __UTILITY_H__
#define __UTILITY_H__


void PopMenu (long iSubMenu_p, CPoint point);

#endif //__UTILITY_H__