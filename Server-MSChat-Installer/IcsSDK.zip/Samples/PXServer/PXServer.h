// PXServer.h : main header file for the PXSERVER DLL
//
//	(C) Programmed by Kim, Soomin, Nov 1996
//	SDS Media Lab
//	Information Technology Institue
//	Samsung Data Systems, Co., Seoul, South Korea

#ifndef	__PXSERVER_H
#define __PXSERVER_H

#include "stdafx.h"

#include "micmsg.h"
#include "micsvc.h"

/////////////////////////////////////////////////////////////////////////////
// CPXServerApp
// See PXServer.cpp for the implementation of this class
//

class CPXServerApp : public CWinApp
{
public:
	CPXServerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPXServerApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CPXServerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
class CPXService : public IMicService
{
public:
	CPXService(void);
	~CPXService(void);
   
	// IMicService Methods
	STDMETHODIMP_(MICERR)	SetChannel(PMICCHANNEL pMicChannel);
	STDMETHODIMP_(MICERR)	AddMember(PMICMEMBER pMicMember);
	STDMETHODIMP_(MICERR)	DelMember(PMICMEMBER pMicMember);
	STDMETHODIMP_(MICERR)	RecvTextA(PMICMEMBER pMicMember,	PCSTR pTextA,	ULONG cText);
	STDMETHODIMP_(MICERR)	RecvTextW(PMICMEMBER pMicMember,	PCWSTR pTextW,	ULONG cText);
	STDMETHODIMP_(MICERR)	RecvData(PMICMEMBER pMicMember,		PVOID pData,	ULONG cData);
	STDMETHODIMP_(MICERR)	RecvBroadcast(PMICMEMBER pMicMember, PVOID pData,	ULONG cData);

private:
	PMICCHANNEL		m_pChannel;
};

#endif