// PXServer.cpp : Defines the initialization routines for the DLL.
//
//	(C) Programmed by Kim, Soomin, Nov 1996
//	SDS Media Lab
//	Information Technology Institue
//	Samsung Data Systems, Co., Seoul, South Korea

#include "stdafx.h"
#include <afxdllx.h>

#include "PXServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static AFX_EXTENSION_MODULE PXServerDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("PXSERVER.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		AfxInitExtensionModule(PXServerDLL, hInstance);

		// Insert this DLL into the resource chain
		new CDynLinkLibrary(PXServerDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("PXSERVER.DLL Terminating!\n");
	}
	return 1;   // ok
}

/////////////////////////////////////////////////////////////////////////////
// Top-level exported function from a channel service.
// The MIC server calls MicCreateService() to initialize the channel service DLL
// and to instantiate the service's IMicService object.
//
// The riid parameter will contain the service GUID for the channel being loaded.
// This is provided so that a single DLL could implement more than one channel service.
extern "C" PMICSERVICE /*STDAPICALLTYPE*/ MicCreateService(REFIID riid)
{
	PMICSERVICE pMicService = new CPXService();
	return pMicService;
}

////////////////////////////////////////////////////////////////////////////////////
//	Class CPXService is the ProjectX service's implementation of IMicService.
//	All channel service calls go to it.

CPXService::CPXService(void)
{
}

CPXService::~CPXService()
{
}

// This function is called by the MIC server to initialize and clean up the channel service.
// If pMicChannel is non-NULL, a channel is being created;
// the channel service should generally save a pointer to that channel.
// If pMicChannel is NULL, the channel is being closed,
// and the service should clean up all its resources related to that channel.
MICERR CPXService::SetChannel(PMICCHANNEL pMicChannel)
{
	if (pMicChannel)
	{
		m_pChannel = pMicChannel;
	}
	else
	{
		// TODO: Release channel-related resources.
	}
	return MICERR_NONE;
}

// Called by the MIC server when a member enters the channel.
// A more complex channel service can either save the member pointer away,
// associate some of its own data with the pointer by calling
// pMicMember->SetUserParam(), or both.
MICERR CPXService::AddMember(PMICMEMBER pMicMember)
{
	// Host PXServer whispers to pMicMember
	// NULL -> Message from the Channel
	pMicMember->SendTextA(NULL, "Welcome to the ProjectX Beta Service!");
	return MICERR_NONE;
}

// Called by the server when a member leaves.
// If the channel service has allocated any resources to deal with that member,
// they should be released now, and the member pointer should be removed
// from any internal data structures.
// As soon as this method returns, the member pointer is considered invalid.
MICERR CPXService::DelMember(PMICMEMBER pMicMember)
{
	return MICERR_NONE;
}

// Called when ANSI text is sent to the channel.
// The PX service ,
// then sends the message out to the channel.
MICERR CPXService::RecvTextA(PMICMEMBER pMicMember, PCSTR pTextA, ULONG cText)
{
	// This SendTextA() call relies on the IMPERSONATE channel flag...
	m_pChannel->SendTextA(pMicMember, NULL, pTextA, cText);

	return MICERR_NONE;
}

// Support Unicode messages.
MICERR CPXService::RecvTextW(PMICMEMBER pMicMember, PCWSTR pTextW, ULONG cText)
{
	// TODO: Support Unicode messages.
	return MICERR_NONE;
}

//
MICERR CPXService::RecvData(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	return MICERR_NONE;
}

//
MICERR CPXService::RecvBroadcast(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	return MICERR_NONE;
}
