/*--------------------------------------------------------------------------
	evtq.cpp
	
		CServiceEventQueue class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "trivpch.h"
#include "evtq.h"

////////////////////////////////////////////////////////////////////////////
// class CServiceEventQueue

// CServiceEventQueue maintains a queue of events which occur on the
// channel service.  It has two main functions: FEnqueue() and FDequeue().
// FEnqueue simply adds the specified event to the queue.  FDequeue is more
// complicated, however, since it has to deal with waiting for events to
// arrive.  A semaphore, m_hsemQueue, is used to signal the arrival of events
// on the queue.  An event, m_hevtEnd, allows the caller to stop waiting
// for new events (by calling CServiceEventQueue::EndWait()).
//
// CServiceEventQueue also maintains a free list for ENTRY structs that
// aren't currently in use.

CServiceEventQueue::CServiceEventQueue()
{
	::InitializeCriticalSection(&m_cs);
	
	m_pentryQueue	= NULL;
	m_ptailQueue	= NULL;
	m_pentryFree	= NULL;
	m_ptailFree		= NULL;
	m_hsemQueue		= NULL;
	m_hevtEnd		= NULL;
}

CServiceEventQueue::~CServiceEventQueue()
{
	::DeleteCriticalSection(&m_cs);
	
	if (m_hevtEnd)
		::CloseHandle(m_hevtEnd);
	if (m_hsemQueue)
		::CloseHandle(m_hsemQueue);
	this->DeleteEventQueue(m_pentryQueue);
	this->DeleteEventQueue(m_pentryFree);
}

// Initializes the event queue.  cEventInitial is the number of empty
// EVENT structs the queue should pre-allocate and place on the free list.
BOOL CServiceEventQueue::FInit(int cEventInitial)
{
	if (m_pentryQueue)
		return FALSE;
	
	m_hsemQueue = ::CreateSemaphore(NULL, 0, cEventInitial, NULL);
	if (!m_hsemQueue)
		return FALSE;
	m_hevtEnd = ::CreateEvent(NULL, TRUE, FALSE, NULL);
	if (!m_hevtEnd)
		return FALSE;
	
	m_rghWait[0] = m_hevtEnd;
	m_rghWait[1] = m_hsemQueue;
	
	// Create cEventInitial ENTRYs and put them on the free list.
	PENTRY pentry = NULL;
	PENTRY pentryPrev = NULL;
	for (int i = 0; i < cEventInitial; i++)
	{
		pentry = new ENTRY;
		if (!pentry)
		{
			// don't bother cleaning up; the destructor will take care of it.
			return FALSE;
		}
		::FillMemory(pentry, sizeof(ENTRY), 0);
		
		if (pentryPrev)
			pentryPrev->pentryNext = pentry;
		pentryPrev = pentry;
		if (!m_pentryFree)
			m_pentryFree = pentry;
	}
	m_ptailFree = pentry;

	return TRUE;
}

// Places the specified event on the queue and signals m_hsemQueue.  Note
// that if the free list is empty, a new ENTRY struct will be allocated and
// used.  This ENTRY struct is not reclaimed until the service is stopped.
// It would be possible to add code in FDequeue to reclaim extra ENTRY structs
// when there are more than a certain number on the free list, but it is
// probably not necessary.  In a scenario when a service would expect more-
// or-less even usage, occasionally adding new ENTRY structs will not
// significantly affect memory use, but in a situation where a service gets
// enormous amounts of load but only infrequently, the extra ENTRY structs
// should probably be reclaimed.

BOOL CServiceEventQueue::FEnqueue(EVT_TYPE evt, PMD pmd, PBYTE pbData, ULONG cbData)
{
	PENTRY pentry = this->PentryDequeue(&m_pentryFree, &m_ptailFree);
	if (!pentry)
	{
		pentry = new ENTRY;
		if (!pentry)
			return FALSE;
	}
	pentry->evt = evt;
	pentry->pmd = pmd;
	pentry->cbData = cbData;
	::CopyMemory(pentry->rgbData, pbData, cbData);
	this->Enqueue(pentry, &m_pentryQueue, &m_ptailQueue);
	::ReleaseSemaphore(m_hsemQueue, 1, NULL);
	return TRUE;
}

// Waits (via m_hsemQueue) for an event to arrive; when one does, 
// FDequeue() removes it from the queue and returns it.  If m_hevtEnd is
// signaled, FDequeue stops waiting and returns FALSE.
BOOL CServiceEventQueue::FDequeue(EVT_TYPE* pevt, PMD* ppmd, PBYTE pbData, ULONG* pcbData)
{
//	HANDLE rgh[2];

	DWORD dwWait = ::WaitForMultipleObjects(2, m_rghWait, FALSE, INFINITE);
	if (dwWait == WAIT_OBJECT_0)
	{
		return FALSE;
	}
	if (dwWait != WAIT_OBJECT_0 + 1)
		return FALSE;

	PENTRY pentry = this->PentryDequeue(&m_pentryQueue, &m_ptailQueue);
	if (!pentry)
		return FALSE;

	*pevt = pentry->evt;
	*ppmd = pentry->pmd;
	*pcbData = pentry->cbData;
	::CopyMemory(pbData, pentry->rgbData, pentry->cbData);
	this->Enqueue(pentry, &m_pentryFree, &m_ptailFree);
	return TRUE;
}

// Causes threads currently sitting at CServiceEventQueue::FDequeue to
// stop waiting and return immediately.
void CServiceEventQueue::EndWait()
{
	::SetEvent(m_hevtEnd);
}

// The rest of this file is queue-manipulation code.

void CServiceEventQueue::DeleteEventQueue(PENTRY pentry)
{
	while (pentry)
	{
		PENTRY pentryNext = pentry->pentryNext;
		delete pentry;
		pentry = pentryNext;
	}
}

PENTRY CServiceEventQueue::PentryDequeue(PENTRY* ppq, PENTRY* pptail)
{
	::EnterCriticalSection(&m_cs);
	PENTRY pentry;
	if (*ppq)
	{
		pentry = *ppq;
		*ppq = pentry->pentryNext;
		if (pentry == *pptail)
			*pptail = NULL;
	}
	else
		pentry = NULL;
	::LeaveCriticalSection(&m_cs);
	return pentry;
}

void CServiceEventQueue::Enqueue(PENTRY pentry, PENTRY* ppq, PENTRY* ppt)
{
	::EnterCriticalSection(&m_cs);
	if (*ppq)
	{
		pentry->pentryNext = NULL;
		(*ppt)->pentryNext = pentry;
		*ppt = pentry;
	}
	else
	{
		*ppq = *ppt = pentry;
		pentry->pentryNext = NULL;
	}
	::LeaveCriticalSection(&m_cs);
}
