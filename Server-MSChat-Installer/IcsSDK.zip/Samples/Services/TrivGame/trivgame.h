/*--------------------------------------------------------------------------
	trivgame.h
	
		CTrivGameService class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _TRIVGAME_H
#define _TRIVGAME_H

#include "thdserv.h"

//--------------------------------------------------------------------------+
// class CTrivGameService

// CTrivGameService derives from CThreadingService and implements
// the skeleton of the trivia game.

class CTrivGameService : public CThreadingService
{
public:
	CTrivGameService();
	~CTrivGameService();
	
	STDMETHODIMP_(MICERR)	SetChannel(PMICCHANNEL pchannel);

	virtual void			OnAddMember(PMD pmd);
	virtual void			OnDelMember(PMD pmd);
	virtual void			OnRecvTextA(PMD pmd, PCSTR pchText, ULONG cchText);
	virtual void			OnRecvTextW(PMD pmd, PCWSTR pwchText, ULONG cchText);
	
	virtual BOOL			FInitialize();
	
private:
	BOOL					FGetDBPath(char* szPath);
};

#endif // _TRIVGAME_H

