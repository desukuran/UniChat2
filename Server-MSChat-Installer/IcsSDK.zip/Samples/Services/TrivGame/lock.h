/*--------------------------------------------------------------------------
	lock.h
	
		CLock -- Critical section class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _LOCK_H
#define _LOCK_H

// CLock is a simple wrapper around the Win32 CRITICAL_SECTION.
class CLock
{
public:
	CLock();
	~CLock();
	
	void				Get();
	void				Release();
	
private:
	CRITICAL_SECTION	m_cs;
};

#endif // _LOCK_H

