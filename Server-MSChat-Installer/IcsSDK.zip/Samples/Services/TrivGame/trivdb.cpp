/*--------------------------------------------------------------------------
	trivdb.cpp
	
		Trivia game question/score databases

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/
  
#include "trivpch.h"
#include "trivdb.h"
#include "parser.h"

// Database handling for CTrivGameService
// The two DB classes implement simple databases that use disk files
// as their persistent storage mechanisms.
// There is nothing about them that is MIC-channel-service-specific.

QDB g_qdb;
SDB g_sdb;

///////////////////////////////////////////////////////////////////////////////
// class CTrivGameQuestionDB

CTrivGameQuestionDB::CTrivGameQuestionDB()
{
	m_hfileTopics = INVALID_HANDLE_VALUE;
	m_hfmTopics = NULL;
	m_pchTopics = NULL;
	m_ctopics = 0;

	m_hfileQuestions = INVALID_HANDLE_VALUE;
	m_hfmQuestions = NULL;
	m_pchQuestions = NULL;
	m_cquestions = 0;
}

CTrivGameQuestionDB::~CTrivGameQuestionDB()
{
	this->CloseTopic();

	if (m_pchTopics)
		UnmapViewOfFile((void*)m_pchTopics);
	if (m_hfmTopics)
		::CloseHandle(m_hfmTopics);
	if (m_hfileTopics != INVALID_HANDLE_VALUE)
		::CloseHandle(m_hfileTopics);
}

BOOL CTrivGameQuestionDB::FInit(char* szDBDir)
{
	char szT[MAX_PATH];

	lstrcpy(m_szDBDir, szDBDir);
	
	wsprintf(szT, "%s\\%s", szDBDir, "Topics");
	m_hfileTopics = ::CreateFile(szT, GENERIC_READ, 0, NULL, OPEN_ALWAYS, 0, NULL);
	if (m_hfileTopics == INVALID_HANDLE_VALUE)
		return FALSE;
	m_hfmTopics = ::CreateFileMapping(m_hfileTopics, NULL, PAGE_READONLY, 0, 0, NULL);
	if (!m_hfmTopics)
		return FALSE;
	m_pchTopics = (char*)::MapViewOfFile(m_hfmTopics, FILE_MAP_READ, 0, 0, 0);
	if (!m_pchTopics)
		return FALSE;
	m_cbTopics = ::GetFileSize(m_hfileTopics, NULL);
		
	::FillMemory(m_rgszTopics, sizeof(m_rgszTopics), 0);
	if (!this->FReadTopics())
		return FALSE;

	return TRUE;
}

BOOL CTrivGameQuestionDB::FReadTopics()
{
	char* pch = m_pchTopics;
	char* pchEol;
	char* pchNext;
	char* pchEnd = m_pchTopics + m_cbTopics;

	while (pch && pch < pchEnd)
	{
		pchNext = PchNextLine(pch, pchEnd, &pchEol);
		if (pchEol == pch)
		{
			pch = pchNext;
			continue;
		}
		m_rgszTopics[m_ctopics] = new char[(pchEol - pch) + 1];
		if (!m_rgszTopics[m_ctopics])
			return FALSE;
		CopyMemory(m_rgszTopics[m_ctopics], pch, pchEol - pch);
		m_rgszTopics[m_ctopics][pchEol - pch] = 0;
		m_ctopics++;
		
		pch = pchNext;
	}
	return TRUE;
}

BOOL CTrivGameQuestionDB::FGetTopic(int iTopic, char* szBuf, int cchBuf)
{
	if (iTopic >= (int)m_ctopics)
		return FALSE;
	lstrcpyn(szBuf, m_rgszTopics[iTopic], cchBuf - 1);
	szBuf[cchBuf - 1] = 0;
	return TRUE;
}

BOOL CTrivGameQuestionDB::FOpenTopic(int iTopic)
{
	char szT[MAX_PATH];
	
	this->CloseTopic();

	wsprintf(szT, "%s\\%08X.tpc", m_szDBDir, iTopic);
	m_hfileQuestions = ::CreateFile(szT, GENERIC_READ, 0, NULL, OPEN_ALWAYS, 0, NULL);
	if (m_hfileQuestions == INVALID_HANDLE_VALUE)
		return FALSE;
	m_hfmQuestions = ::CreateFileMapping(m_hfileQuestions, NULL, PAGE_READONLY, 0, 0, NULL);
	if (!m_hfmQuestions)
		return FALSE;
	m_pchQuestions = (char*)::MapViewOfFile(m_hfmQuestions, FILE_MAP_READ, 0, 0, 0);
	if (!m_pchQuestions)
		return FALSE;
	m_cbQuestions = ::GetFileSize(m_hfileQuestions, NULL);

	::FillMemory(m_rgszQuestions, sizeof(m_rgszQuestions), 0);
	if (!this->FReadQuestions())
		return FALSE;

	return TRUE;
}

BOOL CTrivGameQuestionDB::FReadQuestions()
{
	char* pch = m_pchQuestions;
	char* pchEol;
	char* pchNext;
	char* pchEnd = m_pchQuestions + m_cbQuestions;

	while (pch && pch < pchEnd)
	{
		pchNext = PchNextLine(pch, pchEnd, &pchEol);
		if (pchEol == pch)
		{
			pch = pchNext;
			continue;
		}
		m_rgszQuestions[m_cquestions] = new char[(pchEol - pch) + 1];
		if (!m_rgszQuestions[m_cquestions])
			return FALSE;
		::CopyMemory(m_rgszQuestions[m_cquestions], pch, pchEol - pch);
		m_rgszQuestions[m_cquestions][pchEol - pch] = 0;
		m_cquestions++;
		
		pch = pchNext;
	}
	return TRUE;
}

void CTrivGameQuestionDB::CloseTopic()
{
	if (m_pchQuestions)
		::UnmapViewOfFile((void*)m_pchQuestions);
	if (m_hfmQuestions)
		::CloseHandle(m_hfmQuestions);
	if (m_hfileQuestions != INVALID_HANDLE_VALUE)
		::CloseHandle(m_hfileQuestions);
		
	m_cquestions = 0;
	m_pchQuestions = NULL;
	m_hfmQuestions = NULL;
	m_hfileQuestions = INVALID_HANDLE_VALUE;
}

BOOL CTrivGameQuestionDB::FGetQuestion(int iQuestion, char* szBuf, int cchBuf)
{
	if (iQuestion >= m_cquestions)
		return FALSE;

	char* szQ = m_rgszQuestions[iQuestion];
	char* pchSep = PchSep(szQ);
	if (!pchSep)
		return FALSE;
	if (cchBuf < 1 + (pchSep - szQ))
		return FALSE;
	::CopyMemory(szBuf, szQ, pchSep - szQ);
	szBuf[pchSep - szQ] = 0;
	return TRUE;
}

BOOL CTrivGameQuestionDB::FGetAnswer(int iQuestion, char* szBuf, int cchBuf)
{
	if (iQuestion >= m_cquestions)
		return FALSE;

	char* szQ = m_rgszQuestions[iQuestion];
	char* pchSep = PchSep(szQ);
	if (!pchSep)
		return FALSE;

	szQ = pchSep + 2;
	pchSep = PchSep(szQ);
	if (!pchSep)
		pchSep = szQ + lstrlen(szQ);

	if (cchBuf < 1 + (pchSep - szQ))
		return FALSE;
	::CopyMemory(szBuf, szQ, pchSep - szQ);
	szBuf[pchSep - szQ] = 0;
	return TRUE;
}

BOOL CTrivGameQuestionDB::FCheckAnswer(int iQuestion, char *szAnswer)
{
	char* pchSep;
	int cchAns;
	
	if (iQuestion >= m_cquestions)
		return FALSE;
		
	char* szQ = m_rgszQuestions[iQuestion];
	char* pchAns = PchSep(szQ);
	if (!pchAns)
		return FALSE;
		
	pchAns += 2; // skip sep
	while (pchAns)
	{
		pchSep = PchSep(pchAns);
		cchAns = (pchSep) ? pchSep - pchAns : lstrlen(pchAns);
		if (FCompareRgchSz(pchAns, cchAns, szAnswer))
			return TRUE;
		pchAns = (pchSep) ? pchSep + 2 : NULL;
	}
	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// class CTrivGameScoreDB

CTrivGameScoreDB::CTrivGameScoreDB()
{
}

CTrivGameScoreDB::~CTrivGameScoreDB()
{
}

BOOL CTrivGameScoreDB::FInit(char* szDBDir)
{
	wsprintf(m_szDBFile, "%s\\Scores", szDBDir);
	
	m_lock.Get();
	BOOL fRet = this->FReadFile();
	m_lock.Release();
	return fRet;
}

BOOL CTrivGameScoreDB::FClose()
{
	m_lock.Get();
	BOOL fRet = this->FWriteFile();
	m_lock.Release();
	return fRet;
}

void CTrivGameScoreDB::GetStatsFor(char* szNickname, int* pcwins, int* pcties)
{
	*pcwins = 0;
	*pcties = 0;

	m_lock.Get();
	PSCORE pscore = this->PscoreFor(szNickname);
	if (pscore)
	{
		*pcwins = pscore->cwins;
		*pcties = pscore->cties;
	}
	m_lock.Release();
}

void CTrivGameScoreDB::AddWin(char* szNickname)
{
	m_lock.Get();
	PSCORE pscore = this->PscoreFor(szNickname);
	if (!pscore)
	{
		pscore = new SCORE;
		if (!pscore)
		{
			m_lock.Release();
			return;
		}
		pscore->pscoreNext = NULL;
		lstrcpy(pscore->szNickname, szNickname);
		pscore->cwins = 0;
		pscore->cties = 0;
		this->AddPscore(pscore);
	}
	pscore->cwins++;
	m_lock.Release();
}

void CTrivGameScoreDB::AddTie(char* szNickname)
{
	m_lock.Get();
	PSCORE pscore = this->PscoreFor(szNickname);
	if (!pscore)
	{
		pscore = new SCORE;
		if (!pscore)
		{
			m_lock.Release();
			return;
		}
		pscore->pscoreNext = NULL;
		lstrcpy(pscore->szNickname, szNickname);
		pscore->cwins = 0;
		pscore->cties = 0;
		this->AddPscore(pscore);
	}
	pscore->cties++;
	m_lock.Release();
}

HANDLE CTrivGameScoreDB::GetFirstEntry(char* szBuf, int cchBuf, int* pcwins, int* pcties)
{
	PSCORE pscore = this->PscoreFirst();
	if (!pscore)
		return NULL;

	lstrcpy(szBuf, pscore->szNickname);
	*pcwins = pscore->cwins;
	*pcties = pscore->cties;
	return (HANDLE)pscore;
}

HANDLE CTrivGameScoreDB::GetNextEntry(HANDLE h, char* szBuf, int cchBuf, int* pcwins, int* pcties)
{
	PSCORE pscore = (PSCORE)h;

	pscore = this->PscoreNext(pscore);
	if (!pscore)
		return NULL;

	lstrcpy(szBuf, pscore->szNickname);
	*pcwins = pscore->cwins;
	*pcties = pscore->cties;
	return (HANDLE)pscore;
}

PSCORE CTrivGameScoreDB::PscoreFor(char* szNickname)
{
	PSCORE pscore = m_pscore;
	
	while (pscore)
	{
		if (!lstrcmpi(pscore->szNickname, szNickname))
			return pscore;
		
		pscore = pscore->pscoreNext;
	}
	return NULL;
}

void CTrivGameScoreDB::AddPscore(PSCORE pscore)
{
	pscore->pscoreNext = m_pscore;
	m_pscore = pscore;
}

PSCORE CTrivGameScoreDB::PscoreFirst()
{
	return m_pscore;
}

PSCORE CTrivGameScoreDB::PscoreNext(PSCORE pscore)
{
	return pscore->pscoreNext;
}

// This always returns TRUE, since the info could just not be there and
// that's okay.  Plus if the info is corrupt, returning TRUE will cause
// us to survive the corrupt data and just lose the score db info.
BOOL CTrivGameScoreDB::FReadFile()
{
	HANDLE hfm = NULL;
	BYTE* pb = NULL;
	int cb;
	PSCORE pscoreFile;
	PSCORE pscore;
	int cscore;
	int i;

	m_pscore = NULL;
	
	HANDLE hfile = ::CreateFile(m_szDBFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	if (hfile == INVALID_HANDLE_VALUE)
		goto LBail;
	hfm = ::CreateFileMapping(hfile, NULL, PAGE_READONLY, 0, 0, NULL);
	if (!hfm)
		goto LBail;
	pb = (BYTE*)::MapViewOfFile(hfm, FILE_MAP_READ, 0, 0, 0);
	if (!pb)
		goto LBail;
	cb = ::GetFileSize(hfile, NULL);
	
	cscore = cb / sizeof(SCORE);
	pscoreFile = (PSCORE)pb;
	for (i = 0; i < cscore; i++)
	{
		pscore = new SCORE;
		if (!pscore)
			goto LBail;
			
		pscore->pscoreNext = NULL;
		pscore->cwins = pscoreFile->cwins;
		pscore->cties = pscoreFile->cties;
		lstrcpy(pscore->szNickname, pscoreFile->szNickname);
		this->AddPscore(pscore);
		
		pscoreFile++;
	}

LBail:
	if (pb)
		::UnmapViewOfFile((void*)pb);
	if (hfm)
		::CloseHandle(hfm);
	if (hfile != INVALID_HANDLE_VALUE)
		::CloseHandle(hfile);
	return TRUE;
}

BOOL CTrivGameScoreDB::FWriteFile()
{
	BOOL fRet = TRUE;
	
	HANDLE hfile = ::CreateFile(m_szDBFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
	if (hfile == INVALID_HANDLE_VALUE)
		return FALSE;

	PSCORE pscore = m_pscore;
	while (pscore)
	{
		PSCORE pscoreNext = pscore->pscoreNext;
		pscore->pscoreNext = NULL;
		if (fRet)
		{
			DWORD cbWritten;
			if (!::WriteFile(hfile, (LPCVOID)pscore, sizeof(SCORE), &cbWritten, NULL) ||
				cbWritten != sizeof(SCORE))
				fRet = FALSE;
		}
		delete pscore;
		pscore = pscoreNext;
	}
	::CloseHandle(hfile);
	return fRet;
}
