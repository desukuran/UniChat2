/*--------------------------------------------------------------------------
	evtq.h
	
		CServiceEventQueue class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _EVTQ_H
#define _EVTQ_H

#include "memdat.h"

//--------------------------------------------------------------------------+
// class CServiceEventQueue

// The CServiceEventQueue class maintains a queue of channel service events.
// CThreadingService uses it to enqueue messages as they come in,
// and to dequeue the events on its worker thread.

typedef enum 
{
	evtAddMember		= 1,
	evtDelMember		= 2,
	evtRecvTextA		= 3,
	evtRecvTextW		= 4,
	evtRecvData			= 5,
	evtRecvBroadcast	= 6,
} EVT_TYPE;

typedef struct _eventQueueEntry
{
	struct _eventQueueEntry*	pentryNext;
	EVT_TYPE					evt;

	// Data about member who sent/caused msg
	PMD							pmd;
			
	// The message data itself.  We always set aside MIC_MAX_MESSAGE bytes
	// of data, even though it may not all be used, to avoid allocating and
	// freeing small chunks of memory for every message that comes in.
	ULONG						cbData;
	BYTE						rgbData[MIC_MAX_MESSAGE];
} ENTRY, *PENTRY;

class CServiceEventQueue
{
public:
	CServiceEventQueue();
	~CServiceEventQueue();
	
	BOOL				FInit(int cEventInitial = 200);
	
	BOOL				FEnqueue(EVT_TYPE evt, PMD pmd, PBYTE pbData, ULONG cbData);
	BOOL				FDequeue(EVT_TYPE* pevt, PMD* ppmd, PBYTE pbData, ULONG* pcbData);
	
	void				EndWait();
	
private:
	CRITICAL_SECTION	m_cs;
	HANDLE				m_hsemQueue;
	PENTRY				m_pentryQueue;
	PENTRY				m_ptailQueue;
	PENTRY				m_pentryFree;
	PENTRY				m_ptailFree;
	HANDLE				m_hevtEnd;
	HANDLE				m_rghWait[2];
	
	void				DeleteEventQueue(PENTRY pentry);
	
	PENTRY				PentryDequeue(PENTRY* ppq, PENTRY* pptail);
	void				Enqueue(PENTRY pentry, PENTRY* ppq, PENTRY* pptail);
};

#endif // _EVTQ_H
