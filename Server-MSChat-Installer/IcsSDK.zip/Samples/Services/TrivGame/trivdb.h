/*--------------------------------------------------------------------------
	trivdb.h
	
		Trivia game question/score databases

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/
  
#ifndef _TRIVDB_H
#define _TRIVDB_H

// Database handling for CTrivGameService
//
//	The two DB classes implement simple databases that use disk files
// as their persistent storage mechanisms.  There is nothing about them
// that is MIC-channel-service-specific.

#include "lock.h"

const int ctopicsMax = 300;
const int cquestionsMax = 50;

//--------------------------------------------------------------------------+
// class CTrivGameQuestionDB

class CTrivGameQuestionDB
{
public:
	CTrivGameQuestionDB();
	~CTrivGameQuestionDB();
	
	BOOL			FInit(char* szDBDir);
	
	int				CTopics()			{ return m_ctopics; };
	
	BOOL			FGetTopic(int iTopic, char* szBuf, int cchBuf);

	BOOL			FOpenTopic(int iTopic);
	void			CloseTopic();
	int				CQuestions()		{ return m_cquestions; };
	BOOL			FGetQuestion(int iQuestion, char* szBuf, int cchBuf);
	BOOL			FGetAnswer(int iQuestion, char* szBuf, int cchBuf);
	BOOL			FCheckAnswer(int iQuestion, char* szAnswer);

private:
	CLock			m_lock;
	char			m_szDBDir[MAX_PATH];

	HANDLE			m_hfileTopics;
	HANDLE			m_hfmTopics;
	char*			m_pchTopics;
	int				m_cbTopics;
	DWORD			m_ctopics;
	char*			m_rgszTopics[ctopicsMax];
	BOOL			FReadTopics();
	
	HANDLE			m_hfileQuestions;
	HANDLE			m_hfmQuestions;
	char*			m_pchQuestions;
	int				m_cbQuestions;
	int				m_cquestions;
	char*			m_rgszQuestions[cquestionsMax];
	BOOL			FReadQuestions();
};

typedef class CTrivGameQuestionDB QDB, *PQDB;

extern QDB g_qdb;

// class CTrivGameScoreDB

typedef struct _score
{
	struct _score*	pscoreNext;
	char			szNickname[MIC_MAX_USER_ALIAS_LENGTH + 1];
	int				cwins;
	int				cties;
} SCORE, *PSCORE;

class CTrivGameScoreDB
{
public:
	CTrivGameScoreDB();
	~CTrivGameScoreDB();

	BOOL			FInit(char* szDBDir);
	BOOL			FClose();
	void			GetStatsFor(char* szNickname, int* pcwins, int* pcties);
	void			AddWin(char* szNickname);
	void			AddTie(char* szNickname);
	
	HANDLE			GetFirstEntry(char* szBuf, int cchBuf, int* pcwins, int* pcties);
	HANDLE			GetNextEntry(HANDLE h, char* szBuf, int cchBuf, int* pcwins, int* pcties);

private:
	CLock			m_lock;
	char			m_szDBFile[MAX_PATH];
	
	// these control the representation of the data
	PSCORE			m_pscore;
	PSCORE			PscoreFor(char* szNickname);
	void			AddPscore(PSCORE pscore);
	BOOL			FReadFile();
	BOOL			FWriteFile(); 
	PSCORE			PscoreFirst();
	PSCORE			PscoreNext(PSCORE pscore);
};

typedef class CTrivGameScoreDB SDB, *PSDB;

extern SDB g_sdb;

#endif // _TRIVDB_H

