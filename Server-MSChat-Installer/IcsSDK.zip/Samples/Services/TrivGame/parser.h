/*--------------------------------------------------------------------------
	parser.h
	
		Text-parsing code for TrivGame

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _PARSER_H
#define _PARSER_H

// CMD: Command Identifier
typedef DWORD CMD;
const CMD cmdNil				= 0;
const CMD cmdGetQuestion		= 1;
const CMD cmdGetScore			= 2;
const CMD cmdGetMyScore			= 3;
const CMD cmdGetScoreFor		= 4;
const CMD cmdAnswer				= 5;
const CMD cmdGiveUp				= 6;
const CMD cmdHelp				= 7;
const CMD cmdGetStatsFor		= 8;
const CMD cmdGetMyStats			= 9;
const CMD cmdGetAllStats		= 10;
#ifdef DEBUG
const CMD cmdShowState			= 100;
#endif

//--------------------------------------------------------------------------+
// Command-parsing code
CMD CmdParse(char* sz, char* szParmBuf, int cchParmBuf);
void Ansify(PCWSTR wszWide, int cchWide, char* szAnsi, int cchAnsi);
void Unicodify(char* szAnsi, int cchAnsi, PCWSTR wszWide, int cchWide);

//--------------------------------------------------------------------------+
// Database-file-parsing code
char* PchNextLine(char* pch, char* pchEnd, char** ppchEol);
char* PchSep(char* sz);
BOOL FCompareRgchSz(char* pchAns, int cchAns, char* szAnswer);

#endif // _PARSER_H

