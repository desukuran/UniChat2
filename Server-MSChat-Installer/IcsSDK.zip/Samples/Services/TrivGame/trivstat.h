/*--------------------------------------------------------------------------
	trivstat.h
	
		CTrivGameStateMachine class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _TRIVSTAT_H
#define _TRIVSTAT_H

#include "memdat.h"
#include "lock.h"

// Some scoring- and gameplay-related constants.
// Number of questions per topic and topics per game:
const int cquestionsTopic = 5;
const int ctopicsGame = 5;

// Number of members who have to pass to skip a question:
const int cmembersPass = 5;

// Number of points each question is worth:
const int cpointsQuestion = 100;

//--------------------------------------------------------------------------+
// class CTrivGameStateMachine

// This class manages the current internal state of the trivia game.
// Based on user input and timers, it moves through the steps required to
// play the game, asking questions, getting answers, and scoring points as
// appropriate.

class CTrivGameStateMachine
{
public:
	CTrivGameStateMachine();
	~CTrivGameStateMachine();
	
	BOOL			FStart(PMICCHANNEL pchannel);
	void			Stop();
	
	void			HandleMessage(PMD pmd, char* szMsg);
	
	void			OnAddMember(PMD pmd);
	void			OnDelMember(PMD pmd);

private:
	CLock			m_lock;
	PMICCHANNEL		m_pchannel;

	int				m_state;
	int				m_csecLeft;
	
	// Pass-handling
	long			m_cmembers;
	long			m_cPass;
	void			ClearPassList();
	void			Pass(PMD pmd);
	
	// Timer-related stuff
	BOOL			FStartTimer(int cmsec);
	void			StopTimer();
	void			FireTimer();
	BOOL			m_fRunTimer;
	HANDLE			m_hthreadTimer;
	void			ChangeState(int state);
	void			FireStateTimeout();
	
	// Question/topic tracking
	void			PickTopics();
	void			PickQuestions();
	int				m_rgTopic[ctopicsGame];
	int				m_rgQuestion[cquestionsTopic];
	int				m_iTopic;
	int				m_iQuestion;
	int				m_cTopics;
	int				m_cQuestions;
	
	// Command-/scoring-related stuff
	void			TellScores(PMD pmd);
	void			TellScoreFor(PMD pmd, char* szNickname);
	void			ShowAnswer();
	void			ClearScores();
	void			TellWinners();
	void			AddWin(PMD pmd);
	void			AddTie(PMD pmd);
	void			ShowStatsFor(PMD pmd, char* szNickname);
	void			ShowAllStats(PMD pmd);
	void			Help(PMD pmd);
	
	void			SetChannelTopic(char* szTopic);

protected:
	friend DWORD __stdcall DwTimerThreadProc(PVOID pvData);
	DWORD __stdcall	DwTimerThreadProc(int cmsec);
};

typedef class CTrivGameStateMachine TSM, *PTSM;

extern TSM g_tsm;

#endif // _TRIVSTAT_H

