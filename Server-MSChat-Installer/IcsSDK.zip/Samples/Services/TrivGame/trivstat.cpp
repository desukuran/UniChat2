/*--------------------------------------------------------------------------
	trivstat.cpp
	
		CTrivGameStateMachine class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "trivpch.h"
#include "memdat.h"
#include "trivstat.h"
#include "trivdb.h"
#include "parser.h"
#include <time.h>

///////////////////////////////////////////////////////////////////////////
// Game state table

// We define a large table which lists each state that the machine can be in.
// Based on the current state, we show different messages when users
// join the channel; each state also has its own timeout length.
//
// Some of the states, such as stateStartCat and stateWaitForQuestion, only
// really exist to serve as short delays; without them, gameplay is too
// frenetic.  Note that "Cat", short for "Category", is just another word
// for "Topic".

#define stateNone				0
#define stateStartGame			1
#define stateStartCat			2
#define stateWaitForQuestion	3
#define stateQuestion			4
#define stateDoneWithQuestion	5
#define stateEndGame			6
#define cstates					7

// The #ifdef DEBUG stuff below is to support the DEBUG-only command "show state".
typedef struct _stateinfo
{
	int		csec;
	char*	szWelcomeMsg;
	char*	szAnnounceMsg;
	char*	szTopicMsg;
#ifdef DEBUG
	char*	szName;
#endif
} SI, *PSI;

#ifdef DEBUG
#define DEFINE_STATE(csec, szName, szWelcome, szAnnounce, szTopic) {csec, szWelcome, szAnnounce, szTopic, szName},
#else
#define DEFINE_STATE(csec, szName, szWelcome, szAnnounce, szTopic) {csec, szWelcome, szAnnounce, szTopic},
#endif

SI g_rgsi[cstates] =
{
DEFINE_STATE(2,
	"None",	
	NULL,
	NULL,
	NULL)
DEFINE_STATE(5,
	"StartGame",
	"A new game is about to begin.",
	"Please wait while I set up a new game.",
	"Starting a new game...")
DEFINE_STATE(5,
	"StartCat",
	"We're about to start a new category.",
	"Please wait while I start a new category.",
	NULL)
DEFINE_STATE(5,
	"GetQuestion",
	"I'm about to ask a new question.",
	"Please wait while I pick a new question.",
	NULL)
DEFINE_STATE(60,
	"Question",
	"Type \"what's the question?\" to see the current question.",
	NULL,		// this has its own announcement style
	NULL)
DEFINE_STATE(0,
	"DoneQuestion",
	NULL,
	NULL,
	NULL)
DEFINE_STATE(10,
	"EndGame",
	"A game just ended.",
	NULL,
	NULL)
};

CTrivGameStateMachine g_tsm;

/////////////////////////////////////////////////////////////////////////////
// class CTrivGameStateMachine
// This class manages the current internal state of the trivia game.
// Based on user input and timers, it moves through the steps required to
// play the game, asking questions, getting answers, and scoring points as
// appropriate.

CTrivGameStateMachine::CTrivGameStateMachine()
{
	m_fRunTimer = FALSE;
	m_hthreadTimer = NULL;
	
	m_cmembers = 0;
}

CTrivGameStateMachine::~CTrivGameStateMachine()
{
}

// These functions basically control the internal timer thread.
// The timer thread should be kept running for as long as the channel
// service is around.
BOOL CTrivGameStateMachine::FStart(PMICCHANNEL pchannel)
{
	srand(GetTickCount());

	m_pchannel = pchannel;

	m_csecLeft = g_rgsi[m_state].csec;
	if (!this->FStartTimer(1000))
		return FALSE;

	this->ChangeState(stateNone);
	return TRUE;
}

void CTrivGameStateMachine::Stop()
{
	this->StopTimer();
	g_sdb.FClose();
}

// Called from CTrivGameService while dequeuing text messages.
// Messages are parsed (via CmdParse()) and checked for commands.
// Any commands typed are executed.
// If the command was `answer *', scoring is performed.
void CTrivGameStateMachine::HandleMessage(PMD pmd, char* szMsg)
{
	WCHAR* wszAlias;
	char szParmBuf[128];
	char szT[256];
	char szAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];
	
	*szParmBuf = 0;
	CMD cmdParse = CmdParse(szMsg, szParmBuf, sizeof(szParmBuf));
	if (cmdParse != cmdNil)
	{
		switch (cmdParse)
		{
		case cmdGetQuestion:
			if (m_state != stateQuestion)
				break;
			
			g_qdb.FGetQuestion(m_rgQuestion[m_iQuestion], szT, sizeof(szT));
			pmd->SendTextA(NULL, szT);
			break;

		case cmdGetScore:
			if (m_state == stateEndGame)
				pmd->SendTextA(NULL, "The final score is:");
			else
				pmd->SendTextA(NULL, "The current score is:");
			this->TellScores(pmd);
			break;
		
		case cmdGetMyScore:
			wsprintf(szT, "Your score is %d points.", pmd->m_score);
			pmd->SendTextA(NULL, szT);
			break;
		
		case cmdGetScoreFor:
			this->TellScoreFor(pmd, szParmBuf);
			break;
		
		case cmdAnswer:
			if (m_state != stateQuestion)
				break;
			
			m_lock.Get();
			if (g_qdb.FCheckAnswer(m_rgQuestion[m_iQuestion], szParmBuf))
			{
				pmd->m_score += cpointsQuestion;
				pmd->GetAlias((PCWSTR *)&wszAlias);
				Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
				wsprintf(szT, "RIGHT!  %s now has %d points!", szAlias, pmd->m_score);
				m_pchannel->SendTextA(NULL, NULL, szT);
				this->ChangeState(stateDoneWithQuestion);
			}
			else
			{
				pmd->m_score -= cpointsQuestion;
				pmd->GetAlias((PCWSTR *)&wszAlias);
				Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
				wsprintf(szT, "WRONG!  %s now has %d points!", szAlias, pmd->m_score);
				m_pchannel->SendTextA(NULL, NULL, szT);
			}
			m_lock.Release();
			
			break;
			
		case cmdGiveUp:
			if (m_state != stateQuestion)
				break;

			this->Pass(pmd);
			break;
		
		case cmdHelp:
			this->Help(pmd);
			break;
			
		case cmdGetStatsFor:
			this->ShowStatsFor(pmd, szParmBuf);
			break;
			
		case cmdGetMyStats:
			pmd->GetAlias((PCWSTR*)&wszAlias);
			Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
			this->ShowStatsFor(pmd, szAlias);
			break;
			
		case cmdGetAllStats:
			this->ShowAllStats(pmd);
			break;
			
#ifdef DEBUG
		case cmdShowState:
			wsprintf(szT, "Current state: %s, %d seconds left", g_rgsi[m_state].szName, m_csecLeft);
			m_pchannel->SendTextA(NULL, NULL, szT);
			break;
#endif
		}
	}
}

// Helper function.
void CTrivGameStateMachine::SetChannelTopic(char* szTopic)
{
	WCHAR wszTopic[MIC_MAX_CHANNEL_TOPIC_LENGTH + 1];

	Unicodify(szTopic, -1, wszTopic, sizeof(wszTopic));
	m_pchannel->SetTopic(wszTopic);
}

// Sets the state machine to a new state.
// Takes any appropriate actions based on the new state
// (e.g., if the new state is stateQuestion, ChangeState() asks the new question).
// NOTE: The calling thread must own m_lock!
void CTrivGameStateMachine::ChangeState(int state)
{
	char szT[256];
	char szBuf[128];

	m_state = state;

	if (g_rgsi[m_state].szAnnounceMsg)
		m_pchannel->SendTextA(NULL, NULL, g_rgsi[m_state].szAnnounceMsg);
		
	if (g_rgsi[m_state].szTopicMsg)
		this->SetChannelTopic(g_rgsi[m_state].szTopicMsg);

	m_csecLeft = g_rgsi[m_state].csec;

	m_cPass = 0;
	
	switch (m_state)
	{
	case stateNone:
		break;
		
	case stateStartGame:
		m_iTopic = 0;
		m_iQuestion = 0;
		this->PickTopics();
		this->ClearScores();
		break;
		
	case stateStartCat:
		g_qdb.FGetTopic(m_rgTopic[m_iTopic], szBuf, sizeof(szBuf));
		this->SetChannelTopic(szBuf);
		wsprintf(szT, "Topic #%d: %s", m_iTopic + 1, szBuf);
		m_pchannel->SendTextA(NULL, NULL, szT);
		g_qdb.FOpenTopic(m_rgTopic[m_iTopic]);
		this->PickQuestions();
		break;
		
	case stateWaitForQuestion:
		break;

	case stateQuestion:
		this->ClearPassList();
		
		g_qdb.FGetQuestion(m_rgQuestion[m_iQuestion], szBuf, sizeof(szBuf));
		wsprintf(szT, "Question #%d: %s", m_iQuestion + 1, szBuf);
		m_pchannel->SendTextA(NULL, NULL, szT);
		break;
		
	case stateDoneWithQuestion:
		// stateDoneWithQuestion is a special state that indicates that a
		// question has just timed out or been answered.  It needs some
		// special handling, because it's not a real state--we need to
		// make sure to leave the machine in either stateWaitForQuestion or
		// stateEndGame.
		m_iQuestion++;
		if (m_iQuestion >= m_cQuestions)
		{
			m_iQuestion = 0;
			m_iTopic++;
			if (m_iTopic >= m_cTopics)
			{
				this->ChangeState(stateEndGame);
				return;
			}
			this->ChangeState(stateStartCat);
			return;
		}
		this->ChangeState(stateQuestion);
		return;
		
	case stateEndGame:
		m_pchannel->SendTextA(NULL, NULL, "GAME OVER!  The final score is:");
		this->TellScores(NULL);
		this->TellWinners();
		break;
	}
}

// Called on the timer thread when the current state has ended.
// Basically just transitions to the next state, although if the state
// that's ending is stateQuestion, we need to show the answer to the question.
// NOTE: The calling thread must own m_lock!
void CTrivGameStateMachine::FireStateTimeout()
{
	int stateNew = m_state;

	switch (m_state)
	{
	case stateNone:
		stateNew = stateStartGame;
		break;
		
	case stateStartGame:
		stateNew = stateStartCat;
		break;
		
	case stateStartCat:
		stateNew = stateWaitForQuestion;
		break;
		
	case stateWaitForQuestion:
		stateNew = stateQuestion;
		break;
		
	case stateQuestion:
		this->ShowAnswer();
		stateNew = stateDoneWithQuestion;
		break;

	case stateEndGame:
		stateNew = stateStartGame;
		break;
	}
	this->ChangeState(stateNew);
}


///////////////////////////////////////////////////////////////////////////
// Timer thread handling
// For handling the state timeouts, we use a simple worker thread that
// simply wakes up every second and checks the number of seconds left in
// the current state; if it's 0, it calls this->FireStateTimeout.  It
// would have been possible to do a scheme that waited for exactly the right
// number of seconds before waking up, but it would have required much more
// complicated code to deal with, for example, stateQuestion ending early
// because someone answered the question.

DWORD __stdcall DwTimerThreadProc(PVOID pvData)
{
	int cmsec = (int)pvData;
	return g_tsm.DwTimerThreadProc(cmsec);
}

DWORD CTrivGameStateMachine::DwTimerThreadProc(int cmsec)
{
	while (m_fRunTimer)
	{
		::Sleep(cmsec);
		if (m_fRunTimer)
			this->FireTimer();
	}
	return 0;
}

BOOL CTrivGameStateMachine::FStartTimer(int cmsec)
{
	if (m_hthreadTimer || m_fRunTimer)
		return FALSE;
		
	m_fRunTimer = TRUE;
	DWORD tid;
	m_hthreadTimer = ::CreateThread(NULL, 0, ::DwTimerThreadProc, (LPVOID)cmsec, 0, &tid);
	if (!m_hthreadTimer)
	{
		m_fRunTimer = FALSE;
	}
	return m_fRunTimer;
}

void CTrivGameStateMachine::StopTimer()
{
	m_fRunTimer = FALSE;
	::WaitForSingleObject(m_hthreadTimer, INFINITE);
	m_hthreadTimer = NULL;
}

void CTrivGameStateMachine::FireTimer()
{
	m_lock.Get();
	m_csecLeft--;
	if (!m_csecLeft)
	{
		this->FireStateTimeout();
	}
	m_lock.Release();
}

////////////////////////////////////////////////////////////////////////////
// Pass handling
//
// The pass rules are:  if either cmembersPass (see trivstat.h) members pass,
// or all the members currently in the channel pass, the question ends.
// We keep track of who has and hasn't passed by storing some game-specific
// information (m_fPass) in the CMemberData object.

// CTrivGameStateMachine needs to keep track of the number of members
// in the channel so it knows if everyone has passed on the current question.
// We also take the opportunity in OnAddMember() to greet the user and tell
// him or her what's going on.

void CTrivGameStateMachine::OnAddMember(PMD pmd)
{
	WCHAR* wszAlias;
	char szAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];
	char szMsg[128];
	
	pmd->GetAlias((PCWSTR*)&wszAlias);
	Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
	
	if (g_rgsi[m_state].szWelcomeMsg)
		wsprintf(szMsg, "Welcome to TrivGame, %s!  %s  Type \"help\" for help.", szAlias, g_rgsi[m_state].szWelcomeMsg);
	else
		wsprintf(szMsg, "Welcome to TrivGame, %s!", szAlias);

	m_pchannel->SendTextA(NULL, NULL, szMsg);
	
	// We don't need a critical section here because this is only ever called
	// from the CTrivGameService/CThreadingService worker thread.  If there
	// were more than one worker thread, we would need to protect this.
	m_cmembers++;
}

void CTrivGameStateMachine::OnDelMember(PMD pmd)
{
	// We don't need a critical section here because this is only ever called
	// from the CTrivGameService/CThreadingService worker thread.  If there
	// were more than one worker thread, we would need to protect this.
	m_cmembers--;
}

void CTrivGameStateMachine::Pass(PMD pmd)
{
	if (pmd->m_fPass)
		return;
	pmd->m_fPass = TRUE;

	m_lock.Get();
	m_cPass++;
	if (m_cPass >= m_cmembers || m_cPass >= cmembersPass)
	{
		m_pchannel->SendTextA(NULL, NULL, "Question passed...");
		this->ShowAnswer();
		this->ChangeState(stateDoneWithQuestion);
	}
	m_lock.Release();
}

// Once the current question has ended, we need to clear the m_fPass
// flag in all the current CMemberData objects.
void CTrivGameStateMachine::ClearPassList()
{
	g_mdlInUse.Lock();
	PMD pmd = g_mdlInUse.PmdFirst();
	
	while (pmd)
	{
		pmd->m_fPass = FALSE;
		pmd = g_mdlInUse.PmdNext(pmd);
	}
	g_mdlInUse.Unlock();
}

// Called at the beginning of a game; clears out the per-member
// score data in CMemberData.
void CTrivGameStateMachine::ClearScores()
{
	g_mdlInUse.Lock();
	PMD pmd = g_mdlInUse.PmdFirst();
	
	while (pmd)
	{
		pmd->m_score = 0;
		pmd = g_mdlInUse.PmdNext(pmd);
	}
	g_mdlInUse.Unlock();
}

/////////////////////////////////////////////////////////////////////////////
// Topic/question handling

// IRand and FInArray are helper functions.
int IRand(int c)
{
	return (rand() * c) / RAND_MAX;
}

BOOL FInArray(int* rg, int c, int n)
{
	if (c == 0)
		return FALSE;
	
	for (int i = 0; i < c; i++)
	{
		if (rg[i] == n)
			return TRUE;
	}
	return FALSE;
}

// At the beginning of the game, we pick all the topics for the game;
// at the beginning of each topic, we pick all the questions.
void CTrivGameStateMachine::PickTopics()
{
	int ctopics = g_qdb.CTopics();
	int topic;

	m_cTopics = ctopicsGame;
	if (ctopics < ctopicsGame)
		m_cTopics = ctopics;

	for (int iTopic = 0; iTopic < m_cTopics; iTopic++)
	{
		do
		{
			topic = IRand(ctopics);
		} while (FInArray(m_rgTopic, iTopic, topic));
		m_rgTopic[iTopic] = topic;
	}
}

void CTrivGameStateMachine::PickQuestions()
{
	int cquestions = g_qdb.CQuestions();
	int question;

	m_cQuestions = cquestionsTopic;
	if (cquestions < cquestionsTopic)
		m_cQuestions = cquestions;

	for (int iQuestion = 0; iQuestion < m_cQuestions; iQuestion++)
	{
		do
		{
			question = IRand(cquestions);
		} while (FInArray(m_rgQuestion, iQuestion, question));
		m_rgQuestion[iQuestion] = question;
	}
}

//////////////////////////////////////////////////////////////////////////////
// Command/score handling

void CTrivGameStateMachine::TellScoreFor(PMD pmd, char* szNickname)
{
	char szT[256];
	
	PMD pmdScore = g_mdlInUse.PmdForNick(szNickname);
	if (!pmdScore)
		wsprintf(szT, "I don't recognize the nickname \"%s\".", szNickname);
	else
		wsprintf(szT, "%s's score is %d.", szNickname, pmdScore->m_score);
		
	pmd->SendTextA(NULL, szT);
}

void CTrivGameStateMachine::TellScores(PMD pmd)
{
	WCHAR* wszAlias;
	char szT[256];
	char szAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];

	g_mdlInUse.Lock();
	PMD pmdScore = g_mdlInUse.PmdFirst();
	while (pmdScore)
	{
		pmdScore->GetAlias((PCWSTR*)&wszAlias);
		Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
		wsprintf(szT, "%s: %d", szAlias, pmdScore->m_score);
		if (pmd)
			pmd->SendTextA(NULL, szT);
		else
			m_pchannel->SendTextA(NULL, NULL, szT);
		pmdScore = g_mdlInUse.PmdNext(pmdScore);
	}
	g_mdlInUse.Unlock();
}

void CTrivGameStateMachine::ShowAnswer()
{
	char szT[256];
	char szAnswer[128];
	
	g_qdb.FGetAnswer(m_rgQuestion[m_iQuestion], szAnswer, sizeof(szAnswer));
	wsprintf(szT, "The answer was: %s", szAnswer);
	m_pchannel->SendTextA(NULL, NULL, szT);
}

char *g_rgszHelp[] =
{
	"This is a list of the commands TrivGame understands:",
	"\"What's the question?\" asks for the current question.",
	"\"What's the score?\" asks for the current score.",
	"\"What's Bob's score?\" asks for Bob's current score.",
	"\"What's my score?\" asks for your current score.",
	"\"Answer xxx\" answers a question.",
	"\"I pass\" passes a question.",
	"\"show Bob's stats\" shows Bob's current statistics.",
	"\"show my stats\" shows your current statistics.",
	"\"show all stats\" shows all current statistics--this could be a lot of data!",
	NULL
};

void CTrivGameStateMachine::Help(PMD pmd)
{
	char** psz = g_rgszHelp;
	while (*psz)
	{
		pmd->SendTextA(NULL, *psz);
		psz++;
	}
}

void CTrivGameStateMachine::TellWinners()
{
	PMD pmdBest;
	int scoreBest = 0;
	int cBest = 0;
	int cBestLeft = 0;
	WCHAR *wszAlias;
	char szAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];
	char szT[512];

	g_mdlInUse.Lock();
	PMD pmd = g_mdlInUse.PmdFirst();
	while (pmd)
	{
		if (pmd->m_score > scoreBest)
		{
			pmdBest = pmd;
			scoreBest = pmd->m_score;
			cBest = 1;
		}
		else if (pmd->m_score == scoreBest)
		{
			pmdBest = pmd;
			cBest++;
		}
		pmd = g_mdlInUse.PmdNext(pmd);
	}
		
	if (cBest == 1)
	{
		pmdBest->GetAlias((PCWSTR*)&wszAlias);
		Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
		wsprintf(szT, "%s is the winner!", szAlias);
		m_pchannel->SendTextA(NULL, NULL, szT);
		
		this->AddWin(pmdBest);
	}
	else
	{
		pmd = g_mdlInUse.PmdFirst();
		szT[0] = 0;
		cBestLeft = cBest;
		while (pmd)
		{
			if (pmd->m_score == scoreBest)
			{
				pmd->GetAlias((PCWSTR*)&wszAlias);
				Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
				lstrcat(szT, szAlias);
				cBestLeft--;
				if (cBest == 2)
				{
					// just do "XXX and YYY"
					if (cBestLeft)
						lstrcat(szT, " and ");
				}
				else
				{
					// do "XXX, YYY, ZZZ, and AAA"
					if (cBestLeft == 1)
						lstrcat(szT, ", and ");
					else if (cBestLeft)
						lstrcat(szT, ", ");
				}
				this->AddTie(pmd);
			}
			pmd = g_mdlInUse.PmdNext(pmd);
		}
		lstrcat(szT, " tied for first place!");
		m_pchannel->SendTextA(NULL, NULL, szT);
	}
	g_mdlInUse.Unlock();
}

void CTrivGameStateMachine::AddWin(PMD pmd)
{
	WCHAR* wszAlias;
	char szAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];
	
	pmd->GetAlias((PCWSTR*)&wszAlias);
	Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
	g_sdb.AddWin(szAlias);
}

void CTrivGameStateMachine::AddTie(PMD pmd)
{
	WCHAR* wszAlias;
	char szAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];
	
	pmd->GetAlias((PCWSTR*)&wszAlias);
	Ansify(wszAlias, -1, szAlias, sizeof(szAlias));
	g_sdb.AddTie(szAlias);
}

void CTrivGameStateMachine::ShowStatsFor(PMD pmd, char* szNickname)
{
	int cwins;
	int cties;
	g_sdb.GetStatsFor(szNickname, &cwins, &cties);
	char szT[256];
	wsprintf(szT, "%s has %d wins and %d ties.", szNickname, cwins, cties);
	pmd->SendTextA(NULL, szT);
}

void CTrivGameStateMachine::ShowAllStats(PMD pmd)
{
	int cwins;
	int cties;
	char szNickname[MIC_MAX_USER_ALIAS_LENGTH + 1];
	HANDLE h = g_sdb.GetFirstEntry(szNickname, sizeof(szNickname), &cwins, &cties);
	while (h)
	{
		char szT[256];
		wsprintf(szT, "%s has %d wins and %d ties.", szNickname, cwins, cties);
		pmd->SendTextA(NULL, szT);
		
		h = g_sdb.GetNextEntry(h, szNickname, sizeof(szNickname), &cwins, &cties);
	}
}
