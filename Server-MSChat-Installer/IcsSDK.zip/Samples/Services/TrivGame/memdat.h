/*--------------------------------------------------------------------------
	memdat.h
	
		CMemberData, CMemberDataList classes

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _MEMDAT_H
#define _MEMDAT_H

#include "lock.h"

class CMemberDataList;
class CMemberData;
typedef class CMemberData MD, *PMD;
typedef class CMemberDataList MDL, *PMDL;

//--------------------------------------------------------------------------+
// class CMemberData

// CMemberData is a thread-safe wrapper around IMicMember.  It is used
// in CThreadingService instead of passing IMicMember objects around on
// the message queue, because IMicMember objects can disappear before all
// messages from that member have been dequeued.
class CMemberData : public IMicMember
{
public:
	CMemberData();
	~CMemberData();
	
	void					ClearPmember();
	void					Reset();

	void					SetPmember(PMICMEMBER pmember);
	
	// IMicMember
    STDMETHODIMP_(MICERR)	SendTextA(PMICMEMBER pMicMember, PCSTR pTextA, ULONG cText=(ULONG)-1);
    STDMETHODIMP_(MICERR)	SendTextW(PMICMEMBER pMicMember, PCWSTR pTextW, ULONG cText=(ULONG)-1);
    STDMETHODIMP_(MICERR)	SendData(PMICMEMBER pMicMember, PVOID pData, ULONG cData);
    STDMETHODIMP_(MICERR)	Broadcast(PMICMEMBER pMicMember, PVOID pData, ULONG cData);
    STDMETHODIMP_(MICERR)	GetUserId(MIC_ID* pUid);
    STDMETHODIMP_(MICERR)	GetMemberId(MIC_ID* pMid);
    STDMETHODIMP_(MICERR)	GetMemberMode(MIC_MODE* pMode);
    STDMETHODIMP_(MICERR)	SetMemberMode(MIC_MODE Mode, MIC_MODE Mask);
    STDMETHODIMP_(MICERR)	GetAlias(PCWSTR* ppAlias);
    STDMETHODIMP_(MICERR)	GetUserParam(DWORD* pdwParam);
    STDMETHODIMP_(MICERR)	SetUserParam(DWORD dwParam);
    STDMETHODIMP_(MICERR)	Kick(PCWSTR pReason);
	
	// Game-specific member data
	BOOL					m_fPass;
	int						m_score;
	
protected:
	friend class CMemberDataList;
	PMD						m_pmdNext;
	PMD						m_pmdPrev;
	
private:
	BOOL					m_fValid;

	PMICMEMBER				m_pmember;
	
	// Local buffers to store IMicMember stuff in after the IMicMember
	// object becomes invalid.
	MIC_ID					m_userid;
	MIC_ID					m_memberid;
	MIC_MODE				m_membermode;
	WCHAR					m_wszAlias[MIC_MAX_USER_ALIAS_LENGTH + 1];
	DWORD					m_dwParam;
	
	void					Lock();
	void					Unlock();
};

//--------------------------------------------------------------------------+
// class CMemberDataList

extern MDL g_mdlInUse;
extern MDL g_mdlFree;

// CMemberDataList is simply a list of CMemberData objects.
// The m_pmdNext/m_pmdPrev protected members of CMemberData are used to maintain
// the doubly-linked list.
class CMemberDataList
{
public:
	CMemberDataList();
	~CMemberDataList();
	
	PMD			PmdGet();
	void		PutPmd(PMD pmd);
	void		RemovePmd(PMD pmd);

	void		Lock();
	void		Unlock();
	PMD			PmdFirst()			{ return m_pmd; }
	PMD			PmdNext(PMD pmd)	{ return pmd->m_pmdNext; }
	PMD			PmdForNick(char* szNickname);
	
private:
	PMD			m_pmd;
	CLock		m_lock;
	
	void		DeletePmdChain(PMD pmd);
};

#endif // _MEMDAT_H
