/*--------------------------------------------------------------------------
	lock.cpp
	
		CLock -- Critical section class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "trivpch.h"
#include "lock.h"

// CLock is a simple wrapper around the Win32 CRITICAL_SECTION.

CLock::CLock()
{
	::InitializeCriticalSection(&m_cs);
}

CLock::~CLock()
{
	::DeleteCriticalSection(&m_cs);
}

void CLock::Get()
{
	::EnterCriticalSection(&m_cs);
}

void CLock::Release()
{
	::LeaveCriticalSection(&m_cs);
}

