/*--------------------------------------------------------------------------
	trivgame.cpp
	
		CTrivGameService class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "trivpch.h"
#include "trivgame.h"
#include "memdat.h"
#include "trivstat.h"
#include "trivdb.h"
#include "parser.h"

// The GUID for the TrivGame service is 
// {174CE060-DB04-11cf-B2F0-209A02C10627}.

CTrivGameService* g_psvc = NULL;

// This function is called by name by the MIC server to create a new IMicService object.
// We create an instance of CTrivGameService.
extern "C" PMICSERVICE STDAPICALLTYPE MicCreateService(REFIID riid)
{
	return (g_psvc = new CTrivGameService);
}

////////////////////////////////////////////////////////////////////////////////
// class CTrivGameService
// CTrivGameService derives from CThreadingService and
// implements the skeleton of the trivia game.

CTrivGameService::CTrivGameService()
{
}

CTrivGameService::~CTrivGameService()
{
}

// We override IMicService::SetChannel
// so that we can save away a copy of the channel pointer.
STDMETHODIMP_(MICERR) CTrivGameService::SetChannel(PMICCHANNEL pchannel)
{
	// Always make sure to call parent class!
	MICERR micerr = CThreadingService::SetChannel(pchannel);
	if (micerr != MICERR_NONE)
		return micerr;
		
	if (pchannel)
	{
		if (!g_tsm.FStart(pchannel))
			return MICERR_INTERNAL;
	}
	else
		g_tsm.Stop();

	return MICERR_NONE;
}

// We notify the state machine (g_tsm) of arrivals/departures.
void CTrivGameService::OnAddMember(PMD pmd)
{
	CThreadingService::OnAddMember(pmd);
	g_tsm.OnAddMember(pmd);
}

void CTrivGameService::OnDelMember(PMD pmd)
{
	g_tsm.OnDelMember(pmd);

	// Do this AFTER doing anything else we need to do, because it will delete pmd!
	CThreadingService::OnDelMember(pmd);
}

// We simply take the text (turning it into ANSI if necessary) and
// call out to the state machine (g_tsm) to do the real work.

char g_szBuf[MIC_MAX_MESSAGE];
void CTrivGameService::OnRecvTextA(PMD pmd, PCSTR pchText, ULONG cchText)
{
	CThreadingService::OnRecvTextA(pmd, pchText, cchText);

	CopyMemory(g_szBuf, pchText, cchText);
	g_szBuf[cchText] = 0;
	g_tsm.HandleMessage(pmd, (char*)g_szBuf);
}

void CTrivGameService::OnRecvTextW(PMD pmd, PCWSTR pwchText, ULONG cchText)
{
	CThreadingService::OnRecvTextW(pmd, pwchText, cchText);
	
	Ansify(pwchText, cchText, g_szBuf, sizeof(g_szBuf));
	g_tsm.HandleMessage(pmd, g_szBuf);
}

// Initializes our question and score databases.
BOOL CTrivGameService::FInitialize()
{
// To run with MicBot, the tortoise commented out and hard-coded the path.
//	char szPath[MAX_PATH];
	char* szPath = "E:\\icssdk\\samples\\services\\trivgame\\db";
//	if (!this->FGetDBPath(szPath))
//		return FALSE;
	if (!g_qdb.FInit(szPath) || !g_sdb.FInit(szPath))
		return FALSE;

	return CThreadingService::FInitialize();
}

BOOL CTrivGameService::FGetDBPath(char* szPath)
{
	WCHAR wszDBPath[128];
	DWORD cb = 127;

	if (m_pchannel->GetServiceValue(L"Data", wszDBPath, &cb) != MICERR_NONE)
		return FALSE;
		
	::WideCharToMultiByte(CP_ACP, 0, wszDBPath, -1, szPath, MAX_PATH, NULL, NULL);

	return TRUE;
}

BOOL WINAPI DllMain(HINSTANCE hinst, DWORD dwReason, LPVOID lpReserved)
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		break;

	case DLL_PROCESS_DETACH:
		if (g_psvc)
			delete g_psvc;
		break;
	}
	return TRUE;
}

