/*--------------------------------------------------------------------------
	thdserv.cpp
	
	CThreadingService class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "trivpch.h"
#include "thdserv.h"
#include "memdat.h"

////////////////////////////////////////////////////////////////////////////
// class CThreadingService

// Wrapper around the MIC Channel Service API which implements a message
// queue and an internal worker thread.  Channel services should derive
// from this class and override the virtuals as appropriate.  Note that
// while it is possible for children of CThreadingService to override the
// IMicService members, they should generally not do so; if they do,
// they MUST ensure that the CThreadingService members are still called.

// All overridden members must call their parent class' implementation
// of the member functions.

CThreadingService::CThreadingService()
{
	m_pevtqueue = NULL;
	m_hthread = NULL;
	m_pchannel = NULL;
}

CThreadingService::~CThreadingService()
{
	this->Terminate();
	delete m_pevtqueue;
}


// Called by the MIC server on initialization/termination of the channel service.
// It is expected that children of CThreadingService will override FInitialize
// and Terminate, although they should make sure to call the overridden
// CThreaingService members.
STDMETHODIMP_(MICERR) CThreadingService::SetChannel(PMICCHANNEL pchannel)
{
	m_pchannel = pchannel;
	
	if (pchannel)
	{
		if (!this->FInitialize())
			return MICERR_INTERNAL;
	}
	else
	{
		this->Terminate();
	}
	return MICERR_NONE;
}


// Called by the MIC server when members join/leave the channel.
// We use the SetUserParam/GetUserParam members in IMicMember to store
// a pointer to a CMemberData object.  DelMember() calls
// pmd->ClearPmember() to have the CMemberData object relinquish its
// copy of the IMicMember object, so that when DelMember() returns, the
// MIC server can delete the object.

STDMETHODIMP_(MICERR) CThreadingService::AddMember(PMICMEMBER pmember)
{
	PMD pmd = g_mdlFree.PmdGet();
	if (!pmd)
	{
		pmd = new MD;
		if (!pmd)
			return MICERR_INTERNAL;
	}

	pmember->SetUserParam((DWORD)pmd);
	pmd->SetPmember(pmember);
	g_mdlInUse.PutPmd(pmd);

	if (!m_pevtqueue->FEnqueue(evtAddMember, pmd, NULL, 0))
		return MICERR_INTERNAL;
	return MICERR_NONE;
}

STDMETHODIMP_(MICERR) CThreadingService::DelMember(PMICMEMBER pmember)
{
	PMD pmd;
	pmember->GetUserParam((DWORD*)&pmd);
	
	pmd->ClearPmember();

	if (!m_pevtqueue->FEnqueue(evtDelMember, pmd, NULL, 0))
		return MICERR_INTERNAL;
	return MICERR_NONE;
}

// These methods simply enqueue the appropriate events.

STDMETHODIMP_(MICERR) CThreadingService::RecvTextA(PMICMEMBER pmember, PCSTR pchText, ULONG cchText)
{
	PMD pmd;
	pmember->GetUserParam((DWORD*)&pmd);
	
	if (!m_pevtqueue->FEnqueue(evtRecvTextA, pmd, (BYTE*)pchText, cchText))
		return MICERR_INTERNAL;
	return MICERR_NOTHANDLED;
}

STDMETHODIMP_(MICERR)
CThreadingService::RecvTextW(PMICMEMBER pmember, PCWSTR pwchText, ULONG cchText)
{
	PMD pmd;
	pmember->GetUserParam((DWORD*)&pmd);
	
	if (!m_pevtqueue->FEnqueue(evtRecvTextW, pmd, (BYTE*)pwchText, cchText * 2))
		return MICERR_INTERNAL;
	return MICERR_NOTHANDLED;
}

STDMETHODIMP_(MICERR)
CThreadingService::RecvData(PMICMEMBER pmember, PVOID pvData, ULONG cbData)
{
	PMD pmd;
	pmember->GetUserParam((DWORD*)&pmd);
	
	if (!m_pevtqueue->FEnqueue(evtRecvData, pmd, (BYTE*)pvData, cbData))
		return MICERR_INTERNAL;
	return MICERR_NOTHANDLED;
}

STDMETHODIMP_(MICERR)
CThreadingService::RecvBroadcast(PMICMEMBER pmember, PVOID pvData, ULONG cbData)
{
	PMD pmd;
	pmember->GetUserParam((DWORD*)&pmd);
	
	if (!m_pevtqueue->FEnqueue(evtRecvBroadcast, pmd, (BYTE*)pvData, cbData))
		return MICERR_INTERNAL;
	return MICERR_NOTHANDLED;
}

/////////////////////////////////////////////////////////////////////////////
// CThreadingService overrideables

// Children of CThreadingService should override these methods as appropriate.
// In all cases they should ensure that they call
// the overridden CThreaingService members.

void CThreadingService::OnAddMember(PMD pmd)
{
}

void CThreadingService::OnDelMember(PMD pmd)
{
	pmd->Reset();
	g_mdlInUse.RemovePmd(pmd);
	g_mdlFree.PutPmd(pmd);
}

void CThreadingService::OnRecvTextA(PMD pmd, PCSTR pchText, ULONG cchText)
{
}

void CThreadingService::OnRecvTextW(PMD pmd, PCWSTR pwchText, ULONG cchText)
{
}

void CThreadingService::OnRecvData(PMD pmd, PVOID pvData, ULONG cbData)
{
}

void CThreadingService::OnRecvBroadcast(PMD pmd, PVOID pvData, ULONG cbData)
{
}

/////////////////////////////////////////////////////////////////////////////
// CThreadingService initialization/termination

// Initial number of CMemberData objects to put on the free list.
const int g_cmembersInitial = 20;

// Sets up some variables and starts the worker thread.
BOOL CThreadingService::FInitialize()
{
	for (int i = 0; i < g_cmembersInitial; i++)
	{
		PMD pmd = new MD;
		if (!pmd)
			return FALSE;
		g_mdlFree.PutPmd(pmd);
	}

	m_pevtqueue = new CServiceEventQueue;
	if (!m_pevtqueue)
		return FALSE;
	if (!m_pevtqueue->FInit())
		return FALSE;

	if (!this->FStartThread())
		return FALSE;

	return TRUE;
}

// Stops the worker thread.
void CThreadingService::Terminate()
{
	if (m_hthread)
	{
		this->EndThread();
	}
}

///////////////////////////////////////////////////////////////////////////
// Thread management
void CThreadingService::OnStartThread()
{
}

void CThreadingService::OnEndThread()
{
}

// We use a shared buffer as temporary storage for dequeued message data.
// Using a shared buffer is okay because there's only one worker thread.
BYTE g_rgb[MIC_MAX_MESSAGE];

DWORD CThreadingService::DwThreadProc()
{
	this->OnStartThread();

	EVT_TYPE evt;
	PMD pmd;
	ULONG cbData;
	while (m_pevtqueue->FDequeue(&evt, &pmd, g_rgb, &cbData))
	{
		switch (evt)
		{
		case evtAddMember:
			this->OnAddMember(pmd);
			break;
		case evtDelMember:
			this->OnDelMember(pmd);
			break;
		case evtRecvTextA:
			this->OnRecvTextA(pmd, (char*)g_rgb, cbData);
			break;
		case evtRecvTextW:
			this->OnRecvTextW(pmd, (WCHAR*)g_rgb, cbData / 2);
			break;
		case evtRecvData:
			this->OnRecvData(pmd, (void*)g_rgb, cbData);
			break;
		case evtRecvBroadcast:
			this->OnRecvBroadcast(pmd, (void*)g_rgb, cbData);
			break;
		}
	}
	this->OnEndThread();
	return 0;
}

void CThreadingService::EndThread()
{
	if (!m_hthread)
		return;

	m_pevtqueue->EndWait();
	
	// We wait for the thread to terminate just so we're sure that we've
	// cleaned up all our resources...
	::WaitForSingleObject(m_hthread, INFINITE);
	m_hthread = NULL;
}

BOOL CThreadingService::FStartThread()
{
	DWORD tid;
	m_hthread = ::CreateThread(NULL, 0, ::DwThreadProc, (LPVOID)this, 0, &tid);
	if (!m_hthread)
		return FALSE;

	return TRUE;
}

DWORD __stdcall DwThreadProc(PVOID pvData)
{
	CThreadingService* psvc = (CThreadingService*)pvData;
	return psvc->DwThreadProc();
}
