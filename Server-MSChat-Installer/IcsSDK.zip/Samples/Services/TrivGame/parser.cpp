/*--------------------------------------------------------------------------
	parser.h
	
		Text-parsing code for TrivGame

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "trivpch.h"
#include "parser.h"

/////////////////////////////////////////////////////////////////////////////
// Command table

// For command parsing, the parser maintains a table of commands and matches
// those commands against strings typed by users.  We support some very
// simple grouping characters:
//
// [] -- text within [] is optional; the command matches whether the text
//		  is present or not.
//	*  -- indicates a parameter.  Text matching the * is treated as a
//		  parameter for the command and returned in the szParmBuf buffer.

typedef struct _cmdparseinfo
{
	CMD		cmd;
	char*	szCmd;
} CPI, *PCPI;

CPI g_rgcpi[] = 
{
	{cmdGetQuestion,			"what's the question[?]"},
	{cmdGetScore, 				"what's the score[?]"},
	{cmdGetScoreFor,			"what's *'s score[?]"},
	{cmdGetMyScore,				"what's my score[?]"},
	{cmdAnswer,					"answer *"},
	{cmdGiveUp,					"i pass[.][!]"},
	{cmdHelp,					"help[.][?]"},
	{cmdGetStatsFor,			"show *'s stats[.]"},
	{cmdGetMyStats,				"show my stats[.]"},
	{cmdGetAllStats,			"show all stats[.]"},
#ifdef DEBUG
	{cmdShowState,				"show state[.]"},
#endif
	{0,							NULL},
};

/////////////////////////////////////////////////////////////////////////////
// Command-matching code

typedef enum
{
	cmsNormal,
	cmsWhitespace,
	cmsStar,
	cmsOptional,
	cmsOptionalWhitespace
} CMS; // Command Matcher State

// Takes a user-typed string and a command template and returns TRUE if
// the string matches the template.  A substring which matches a * inside
// the command template is returned in the szParmBuf buffer.
BOOL FMatch(char* sz, char* szCmd, char* szParmBuf, int cchParmBuf)
{
	CMS cms = cmsNormal;
	int ch;
	int chCmd;
	char* pch = sz;
	char* pchCmd = szCmd;
	char* pchWord;
	char* pchStartOpt;
	
	while (chCmd = *pchCmd)
	{
		switch (cms)
		{
		case cmsNormal:
			if (!*pch && chCmd != '[')
				return FALSE;
				
			switch (chCmd)
			{
			case ' ':
				cms = cmsWhitespace;
				if (*pch != ' ' && *pch != '\t')
					return FALSE;
				pchCmd++;
				break;
				
			case '*':
				pchWord = pch;
				cms = cmsStar;
				break;
				
			case '[':
				cms = cmsOptional;
				pchStartOpt = pch;
				pchCmd++;
				break;
				
			default:
				if (CharLower((char*)chCmd) != CharLower((char*)*pch))
					return FALSE;
				pch++;
				pchCmd++;
				break;
			}
			break;
			
		case cmsOptional:
			switch (chCmd)
			{
			case ' ':
				cms = cmsOptionalWhitespace;
				if (*pch != ' ' && *pch != '\t')
					return FALSE;
				pchCmd++;
				break;
				
			case '*':
				return FALSE;
				
			case ']':
				pchCmd++;
				cms = cmsNormal;
				break;
				
			default:
				if (CharLower((char*)chCmd) != CharLower((char*)*pch))
				{
					pch = pchStartOpt;
					while (*pchCmd && *pchCmd != ']')
						pchCmd++;
					if (*pchCmd)
						pchCmd++;
					if (!*pchCmd)
						return (!*pch) ? TRUE : FALSE;
					cms = cmsNormal;
					break;
				}
				pch++;
				pchCmd++;
				break;
			}
			break;
			
		case cmsOptionalWhitespace:
			if (!*pch)
				return FALSE;
			switch (*pch)
			{
			case ' ':
			case '\t':
				pch++;
				break;
			default:
				switch (chCmd)
				{
				case ' ':
				case '*':
				case '[':
					return FALSE;
					
				default:
					cms = cmsOptional;
					break;
				}
			}
			break;
			
		case cmsWhitespace:
			if (!*pch)
				return FALSE;
			switch (*pch)
			{
			case ' ':
			case '\t':
				pch++;
				break;
			default:
				switch (chCmd)
				{
				case ' ':
					return FALSE;
				case '*':
					pchWord = pch;
					cms = cmsStar;
					break;
				case '[':
					cms = cmsOptional;
					pchStartOpt = pch;
					pchCmd++;
					break;
				default:
					cms = cmsNormal;
					break;
				}
				break;
			}
			break;

		case cmsStar:
			ch = *pch;
			if (!ch && *(pchCmd + 1))
				return FALSE;
			if (!ch || ch == *(pchCmd + 1))
			{
				if ((pch - pchWord) + 1 > cchParmBuf)
					return FALSE;

				::CopyMemory(szParmBuf, pchWord, pch - pchWord);
				szParmBuf[pch - pchWord] = 0;

				if (!ch || FMatch(pch, pchCmd + 1, NULL, 0))
				{
					return TRUE;
				}
				else
				{
					pch++;
				}
			}
			else
				pch++;
			break;
		}
	}
	if (*pch)
		return FALSE;
	return TRUE;
}

// Takes a user-typed string and tries to match it against the commands
// in the command table.  Returns any command parameter in szParmBuf.
CMD CmdParse(char* sz, char* szParmBuf, int cchParmBuf)
{
	PCPI pcpi = g_rgcpi;
	
	while (pcpi->szCmd)
	{
		if (FMatch(sz, pcpi->szCmd, szParmBuf, cchParmBuf))
			return pcpi->cmd;
		pcpi++;
	}
	return cmdNil;
}

/////////////////////////////////////////////////////////////////////////////
// Database-file-parsing code

// Given a pointer to some text (delineated by pchEnd), returns a pointer
// to the start of the next line in the text.  *ppchEol is filled with the
// end of the current line.
char* PchNextLine(char* pch, char* pchEnd, char** ppchEol)
{
	while (pch < pchEnd)
	{
		if (*pch == '\r' || *pch == '\n')
		{
			*ppchEol = pch;
			while (pch < pchEnd && (*pch == '\r' || *pch == '\n'))
				pch++;
			return pch;
		}
		pch++;
	}
	*ppchEol = pch;
	return NULL;
}

// Given a pointer to a null-terminated string, returns a pointer to the
// first field-separator (";;") within that string; returns NULL if there is
// no field-separator in the string.
char* PchSep(char* sz)
{
	char* pch = sz;

	while (*pch)
	{
		if (*pch == ';' && *(pch + 1) == ';')
			return pch;
			
		pch++;
	}
	return NULL;
}

// Compares a character array with an answer string.
// Returns TRUE if they match.
BOOL FCompareRgchSz(char* pchAns, int cchAns, char* szAnswer)
{
	if (cchAns != lstrlen(szAnswer))
		return FALSE;
		
	while (*szAnswer)
	{
		if (CharLower((char*)*szAnswer) != CharLower((char *)*pchAns))
			return FALSE;
		
		szAnswer++;
		pchAns++;
	}
	return TRUE;
}

// Helper routines to convert between ANSI and Unicode.
void Ansify(PCWSTR wszWide, int cchWide, char* szAnsi, int cchAnsi)
{
	::WideCharToMultiByte(CP_ACP, 0, wszWide, cchWide, szAnsi, cchAnsi, NULL, NULL);
}

void Unicodify(char* szAnsi, int cchAnsi, PCWSTR wszWide, int cchWide)
{
	::MultiByteToWideChar(CP_ACP, 0, szAnsi, cchAnsi, (WCHAR*)wszWide, cchWide);
}
