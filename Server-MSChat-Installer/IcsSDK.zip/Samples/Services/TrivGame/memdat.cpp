/*--------------------------------------------------------------------------
	memdat.cpp
	
		CMemberData, CMemberDataList classes

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include "trivpch.h"
#include "lock.h"
#include "memdat.h"
#include "parser.h"

// We only use one global lock for all member data objects in order to save
// space; it is too costly to have one CLock per member data object.
CLock g_lockMemData;

// Every CMemberData should be a member of one of these two lists--if it's in
// g_mdlFree, it's available; if it's in g_mdlInUse, it's in use.
MDL g_mdlFree;
MDL g_mdlInUse;

/////////////////////////////////////////////////////////////////////////////
// class CMemberData

// CMemberData is a thread-safe wrapper around IMicMember.  It is used
// in CThreadingService instead of passing IMicMember objects around on
// the message queue, because IMicMember objects can disappear before all
// messages from that member have been dequeued.

CMemberData::CMemberData()
{
	m_pmember	= NULL;
	m_pmdNext	= NULL;
	m_pmdPrev	= NULL;
	m_dwParam	= 0;
	m_fValid	= FALSE;
	
	// Initialize game-specific data
	m_fPass		= FALSE;
	m_score		= 0;
}

CMemberData::~CMemberData()
{
	// nothing to do--all cleanup is done externally.
}

// This routine is called by CThreadingService in response to a DelMember
// call from the MIC server; it should make local copies of all the
// IMicMember data.
void CMemberData::ClearPmember()
{
	WCHAR* wszT;
	
	if (!m_fValid)
		return;

	this->Lock();
	if (m_pmember)
	{
		// If any of these fail, que sera sera; we can't much do anything
		// about it at this point...
		m_pmember->GetUserId(&m_userid);
		m_pmember->GetMemberId(&m_memberid);
		m_pmember->GetMemberMode(&m_membermode);
		m_pmember->GetAlias((PCWSTR*)&wszT);
		lstrcpyW(m_wszAlias, wszT);
	}
	this->Unlock();
}

// Called by CThreadingService to reinitialize a CMemberData object for use.
void CMemberData::Reset()
{
	this->Lock();
	m_pmember = NULL;
	m_pmdNext = NULL;
	m_fValid  = FALSE;
	m_dwParam = 0;

	// Re-init game-specific data
	m_fPass	  = FALSE;
	m_score	  = 0;
	this->Unlock();
}

void CMemberData::SetPmember(PMICMEMBER pmember)
{
	this->Lock();
	m_fValid = TRUE;
	m_pmember = pmember;
	this->Unlock();
}

// CMemberData's IMicMember implementation follows.  The IMicMember methods
// are implemented as follows:
//
// If m_pmember is still valid (i.e., this->ClearPMember() hasn't been
// called, m_pmember is used; otherwise the local copies of the data made
// in ClearPMember() are used.  Data-sending methods will fail after the
// member object has been cleared.
MICERR CMemberData::SendTextA(PMICMEMBER pmember, PCSTR szText, ULONG cchText)
{
	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	MICERR micerr = (m_pmember)	? m_pmember->SendTextA(pmember, szText, cchText)
								: MICERR_INTERNAL;
	this->Unlock();
	return micerr;
}

MICERR CMemberData::SendTextW(PMICMEMBER pmember, PCWSTR wszText, ULONG cchText)
{
	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	MICERR micerr = (m_pmember) ? m_pmember->SendTextW(pmember, wszText, cchText)
								: MICERR_INTERNAL;
	this->Unlock();
	return micerr;
}

MICERR CMemberData::SendData(PMICMEMBER pmember, PVOID pvData, ULONG cbData)
{
	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	MICERR micerr = (m_pmember) ? m_pmember->SendData(pmember, pvData, cbData)
								: MICERR_INTERNAL;
	this->Unlock();
	return micerr;
}

MICERR CMemberData::Broadcast(PMICMEMBER pmember, PVOID pvData, ULONG cbData)
{
	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	MICERR micerr = (m_pmember) ? m_pmember->Broadcast(pmember, pvData, cbData)
								: MICERR_INTERNAL;
	this->Unlock();
	return micerr;
}

MICERR CMemberData::GetUserId(MIC_ID* pUid)
{
	MICERR micerr;

	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	if (m_pmember)
	{
		micerr = m_pmember->GetUserId(pUid);
	}
	else
	{
		*pUid = m_userid;
		micerr = MICERR_NONE;
	}
	this->Unlock();
	return micerr;
}

MICERR CMemberData::GetMemberId(MIC_ID* pMid)
{
	MICERR micerr;

	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	if (m_pmember)
	{
		micerr = m_pmember->GetMemberId(pMid);
	}
	else
	{
		*pMid = m_memberid;
		micerr = MICERR_NONE;
	}
	this->Unlock();
	return micerr;
}

MICERR CMemberData::GetMemberMode(MIC_MODE* pMode)
{
	MICERR micerr;

	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	if (m_pmember)
	{
		micerr = m_pmember->GetMemberMode(pMode);
	}
	else
	{
		*pMode = m_membermode;
		micerr = MICERR_NONE;
	}
	this->Unlock();
	return micerr;
}

MICERR CMemberData::SetMemberMode(MIC_MODE Mode, MIC_MODE Mask)
{
	MICERR micerr;

	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	if (m_pmember)
	{
		micerr = m_pmember->SetMemberMode(Mode, Mask);
		}
	else
	{
		m_membermode &= Mask;
		m_membermode |= (Mask & Mode);
		micerr = MICERR_NONE;
	}
	this->Unlock();
	return micerr;
}

MICERR CMemberData::GetAlias(PCWSTR* pwszAlias)
{
	MICERR micerr;

	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	if (m_pmember)
	{
		micerr = m_pmember->GetAlias(pwszAlias);
	}
	else
	{
		*pwszAlias = m_wszAlias;
		micerr = MICERR_NONE;
	}
	this->Unlock();
	return micerr;
}

MICERR CMemberData::GetUserParam(DWORD* pdwParam)
{
	if (!m_fValid)
		return MICERR_INTERNAL;

	*pdwParam = m_dwParam;
	return MICERR_NONE;
}

MICERR CMemberData::SetUserParam(DWORD dwParam)
{
	if (!m_fValid)
		return MICERR_INTERNAL;

	m_dwParam = dwParam;
	return MICERR_NONE;
}

MICERR CMemberData::Kick(PCWSTR wszReason)
{
	if (!m_fValid)
		return MICERR_INTERNAL;

	this->Lock();
	MICERR micerr = (m_pmember)	? m_pmember->Kick(wszReason)
								: MICERR_INTERNAL;
	this->Unlock();
	return micerr;
}

void CMemberData::Lock()
{
	g_lockMemData.Get();
}

void CMemberData::Unlock()
{
	g_lockMemData.Release();
}

/////////////////////////////////////////////////////////////////////////////
// class CMemberDataList

// CMemberDataList uses the m_pmdPrev/m_pmdNext members of CMemberData
// to implement a doubly-linked list of CMemberData objects.

CMemberDataList::CMemberDataList()
{
	m_pmd = NULL;
}

CMemberDataList::~CMemberDataList()
{
	this->DeletePmdChain(m_pmd);
}

void CMemberDataList::Lock()
{
	m_lock.Get();
}

void CMemberDataList::Unlock()
{
	m_lock.Release();
}

void CMemberDataList::DeletePmdChain(PMD pmd)
{
	PMD pmdNext;

	this->Lock();
	while (pmd)
	{
		pmdNext = pmd->m_pmdNext;
		delete pmd;
		pmd = pmdNext;
	}
	this->Unlock();
}

// Retrieves the first PMD on the list.
PMD CMemberDataList::PmdGet()
{
	this->Lock();
	PMD pmd = m_pmd;
	m_pmd = pmd->m_pmdNext;
	if (m_pmd)
		m_pmd->m_pmdPrev = NULL;

	pmd->m_pmdNext = NULL;
	pmd->m_pmdPrev = NULL;
	this->Unlock();
	return pmd;
}

// Places the given PMD on the list.
void CMemberDataList::PutPmd(PMD pmd)
{
	this->Lock();
	pmd->m_pmdNext = m_pmd;
	pmd->m_pmdPrev = NULL;
	if (m_pmd)
		m_pmd->m_pmdPrev = pmd;
	m_pmd = pmd;
	this->Unlock();
}

// Removes the given PMD from the list.
void CMemberDataList::RemovePmd(PMD pmd)
{
	this->Lock();
	PMD pmdPrev = pmd->m_pmdPrev;
	PMD pmdNext = pmd->m_pmdNext;

	if (pmd == m_pmd)
		m_pmd = pmdNext;
	
	if (pmdPrev)
	{
		pmdPrev->m_pmdNext = pmdNext;
	}
	if (pmdNext)
	{
		pmdNext->m_pmdPrev = pmdPrev;
	}
	pmd->m_pmdPrev = NULL;
	pmd->m_pmdNext = NULL;
	this->Unlock();
}

// Given a nickname, returns the PMD for that member.
PMD CMemberDataList::PmdForNick(char* szNickname)
{
	WCHAR wszNickname[MIC_MAX_USER_ALIAS_LENGTH + 1];
	WCHAR* wszT;
	
	Unicodify(szNickname, -1, wszNickname, sizeof(wszNickname) / 2);

	this->Lock();
	
	PMD pmd = m_pmd;
	while (pmd)
	{
		pmd->GetAlias((PCWSTR *)&wszT);
		if (!lstrcmpiW(wszNickname, wszT))
			goto LBail;
			
		pmd = pmd->m_pmdNext;
	}

LBail:
	this->Unlock();
	return pmd;
}
