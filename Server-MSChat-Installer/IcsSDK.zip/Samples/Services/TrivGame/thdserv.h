/*--------------------------------------------------------------------------
	thdserv.h
	
		CThreadingService class

	Copyright (C) 1996 Microsoft Corporation
	All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _THDSERV_H
#define _THDSERV_H

#include "evtq.h"
#include "memdat.h"

////////////////////////////////////////////////////////////////////////////
// class CThreadingService
//
// Wrapper around the MIC Channel Service API which implements a message
// queue and an internal worker thread.
// Channel services should derive from this class and override the virtuals
// as appropriate.  Note that while it is possible for children
// of CThreadingService to override the IMicService members,
// they should generally not do so; if they do, they MUST ensure that
// the CThreadingService members are still called.
// All overridden members must call their parent class' implementation
// of the member functions.

class CThreadingService : public IMicService
{
public:

	CThreadingService();
	~CThreadingService();
	
	// IMicService members
	STDMETHODIMP_(MICERR)	SetChannel(PMICCHANNEL pchannel);
	STDMETHODIMP_(MICERR)	AddMember(PMICMEMBER pmember);
	STDMETHODIMP_(MICERR)	DelMember(PMICMEMBER pmember);
	STDMETHODIMP_(MICERR)	RecvTextA(PMICMEMBER pmember,	PCSTR pchText,		ULONG cchText);
	STDMETHODIMP_(MICERR)	RecvTextW(PMICMEMBER pmember,	PCWSTR pwchText,	ULONG cchText);
	STDMETHODIMP_(MICERR)	RecvData(PMICMEMBER pmember,	PVOID pvData,		ULONG cbData);
	STDMETHODIMP_(MICERR)	RecvBroadcast(PMICMEMBER pmember, PVOID pvData,		ULONG cbData);
	
	// CThreadingService overrideables.
	// These will be called on a worker thread,
	// so they don't have to return immediately
	// (although they should still be as efficient as possible).
	virtual void			OnAddMember(PMD pmd);
	virtual void			OnDelMember(PMD pmd);
	virtual void			OnRecvTextA(PMD pmd,	PCSTR pchText,		ULONG cchText);
	virtual void			OnRecvTextW(PMD pmd,	PCWSTR pwchText,	ULONG cchText);
	virtual void			OnRecvData(PMD pmd,		PVOID pvData,		ULONG cbData);
	virtual void			OnRecvBroadcast(PMD pmd, PVOID pvData,		ULONG cbData);
	
	virtual BOOL			FInitialize();
	virtual void			Terminate();
	virtual void			OnStartThread();
	virtual void			OnEndThread();

protected:	
	friend DWORD __stdcall	DwThreadProc(PVOID pvData);
	DWORD __stdcall 		DwThreadProc();

	PMICCHANNEL 			m_pchannel;

private:
	HANDLE					m_hthread;
	CServiceEventQueue* 	m_pevtqueue;
	
	void					EndThread();
	BOOL					FStartThread();
};

#endif _THDSERV_H
