/*--------------------------------------------------------------------------
	piglatin.cpp
	
	Piglatin -- a simple MIC channel service.

	Copyright (C) 1996 Microsoft Corporation
	All rights reserved.

  --------------------------------------------------------------------------*/

#include "piglatin.h"

/////////////////////////////////////////////////////////////////////////////

//		Top-level exported function from a channel service.
//	The MIC server calls MicCreateService() to initialize the channel service DLL
//	and to instantiate the service's IMicService object.
//
//		The riid parameter will contain the service GUID for the channel
//	being loaded.  This is provided so that a single DLL could implement
//	more than one channel service.
extern "C" PMICSERVICE /*STDAPICALLTYPE*/ MicCreateService(REFIID riid)
{
	return new CPiglatinService();
}

////////////////////////////////////////////////////////////////////////////////////
//	Class CPiglatinService is the Piglatin service's implementation of IMicService.
//	All channel service calls go to it.

CPiglatinService::CPiglatinService(void)
{
	// No data to initialize.
}

CPiglatinService::~CPiglatinService()
{
	// No data to clean up.
}

//		This function is called by the MIC server to initialize and clean
//	up the channel service.  If pMicChannel is non-NULL, a channel is being
//	created; the channel service should generally save a pointer to that
//	channel.  If pMicChannel is NULL, the channel is being closed, and the
//	service should clean up all its resources related to that channel.
MICERR CPiglatinService::SetChannel(PMICCHANNEL pMicChannel)
{
	if (pMicChannel)
	{
		m_pChannel = pMicChannel;
	}
	else
	{
		// TODO: Release channel-related resources.
	}
	return MICERR_NONE;
}

//		Called by the MIC server when a member enters the channel.
//	A more complex channel service can either save the member pointer away,
//	associate some of its own data with the pointer by calling
//	pMicMember->SetUserParam(), or both.
MICERR CPiglatinService::AddMember(PMICMEMBER pMicMember)
{
	pMicMember->SendTextA(NULL, "Welcome to the Piglatin Channel Service!");
	return MICERR_NONE;
}

//		Called by the server when a member leaves.	If the channel service
//	has allocated any resources to deal with that member, they should be
//	released now, and the member pointer should be removed from any internal
//	data structures.  As soon as this method returns, the member pointer is
//	considered invalid.
//	The Piglatin service does not need to do anything for this method.
MICERR CPiglatinService::DelMember(PMICMEMBER pMicMember)
{
	return MICERR_NONE;
}

//		Called when ANSI text is sent to the channel.  The Piglatin service
//	calls this->Piglatinize() to turn the text into Pig Latin, then sends
//	the message out to the channel.
MICERR CPiglatinService::RecvTextA(PMICMEMBER pMicMember, PCSTR pTextA, ULONG cText)
{
	char szPig[256];
	char szIn[129];
	
	if (cText > 128)
	{
		pMicMember->SendTextA(NULL, "[String too long...]");
		return MICERR_NONE;
	}

	::CopyMemory(szIn, pTextA, cText);
	szIn[cText] = 0;
	this->Piglatinize(szIn, szPig);
	
	// This SendTextA() call relies on the IMPERSONATE channel flag...
	m_pChannel->SendTextA(pMicMember, NULL, szPig);

	return MICERR_NONE;
}

//		Not implemented for Piglatin.
MICERR CPiglatinService::RecvTextW(PMICMEMBER pMicMember, PCWSTR pTextW, ULONG cText)
{
	// TODO: Support Unicode messages.
	return MICERR_NONE;
}

//		Not implemented for Piglatin.
MICERR CPiglatinService::RecvData(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	return MICERR_NONE;
}

//		Not implemented for Piglatin.
MICERR CPiglatinService::RecvBroadcast(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	return MICERR_NONE;
}

//	Pig-Latin-izing code.
//		The rest of this file deals with turning English text into Pig Latin.
BOOL FVowel(int ch)
{
	return (ch == 'a' || ch == 'A' ||
			ch == 'e' || ch == 'E' ||
			ch == 'i' || ch == 'I' ||
			ch == 'o' || ch == 'O' ||
			ch == 'u' || ch == 'U');
}

BOOL FLetter(int ch)
{
	return ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'));
}

char* PchFirstVowel(char *sz)
{
	while (*sz && !FVowel(*sz))
		sz++;
	return sz;
}

char* PchEndOfWord(char *sz)
{
	while (*sz && (*sz != ' ' && *sz != ',' && *sz != '?' && *sz != '!' && *sz != ':' && *sz != ';' && *sz != '.'))
		sz++;
	return sz;
}

void CPiglatinService::Piglatinize(char* szIn, char* szOut)
{
	char* pchFV;
	char* pchEOW;
	int cchOut = 0;

	while (*szIn)
	{
		pchFV = PchFirstVowel(szIn);
		pchEOW = PchEndOfWord(szIn);
		
		if (pchFV == szIn)
		{
			CopyMemory(&szOut[cchOut], szIn, pchEOW - pchFV);
			cchOut += pchEOW - pchFV;
			CopyMemory(&szOut[cchOut], "way", 3);
			cchOut += 3;
		}
		else
		{
			CopyMemory(&szOut[cchOut], pchFV, pchEOW - pchFV);
			cchOut += pchEOW - pchFV;
			CopyMemory(&szOut[cchOut], szIn, pchFV - szIn);
			cchOut += pchFV - szIn;
			CopyMemory(&szOut[cchOut], "ay", 2);
			cchOut += 2;
		}
		
		szIn = pchEOW;
		if (!*szIn)
			break;
		while (*szIn && !FLetter(*szIn))
		{
			szOut[cchOut++] = *szIn++;
		}
	}
	szOut[cchOut] = 0;
}
