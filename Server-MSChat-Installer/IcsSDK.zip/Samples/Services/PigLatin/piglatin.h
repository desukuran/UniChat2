/*--------------------------------------------------------------------------
	piglatin.h

		Main header for Piglatin sample

	Copyright (C) 1996 Microsoft Corporation
	All rights reserved.

  --------------------------------------------------------------------------*/

#include <windows.h>
#include "micmsg.h"
#include "micsvc.h"

class CPiglatinService : public IMicService
{
public:
	CPiglatinService(void);
	~CPiglatinService(void);
   
	void Piglatinize(char* szIn, char* szOut);

	// IMicService Methods
	STDMETHODIMP_(MICERR)	SetChannel(PMICCHANNEL pMicChannel);
	STDMETHODIMP_(MICERR)	AddMember(PMICMEMBER pMicMember);
	STDMETHODIMP_(MICERR)	DelMember(PMICMEMBER pMicMember);
	STDMETHODIMP_(MICERR)	RecvTextA(PMICMEMBER pMicMember, PCSTR pTextA, ULONG cText);
	STDMETHODIMP_(MICERR)	RecvTextW(PMICMEMBER pMicMember, PCWSTR pTextW, ULONG cText);
	STDMETHODIMP_(MICERR)	RecvData(PMICMEMBER pMicMember, PVOID pData, ULONG cData);
	STDMETHODIMP_(MICERR)	RecvBroadcast(PMICMEMBER pMicMember, PVOID pData, ULONG cData);

private:
	PMICCHANNEL m_pChannel;
};
