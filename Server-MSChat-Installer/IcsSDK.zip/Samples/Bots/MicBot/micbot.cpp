/*--------------------------------------------------------------------------
	micbot.cpp

	MicBot -- Bot used for testing channel services

	Copyright (C) 1996 Microsoft Corporation
	All rights reserved.
  --------------------------------------------------------------------------*/

#include "micbot.h"
#include "mbchan.h"

// Global variables

// Global CMBChannel object which is passed to the channel service.
CMBChannel *g_pChannel;

// PMICSERVICE provided by the channel service.
PMICSERVICE g_pService;

// Our console control handler function.
BOOL __stdcall CtrlHandler(DWORD dwCode);

void usage()
{
	printf("usage:	micbot <server> <channel> <nick> <dll>\n");
	exit(1);
}

////////////////////////////////////////////////////////////////////////////////////
//	main() Main entry point.
int __cdecl main(int argc, char** argv)
{
	GUID		guidBogus;
	// guidBogus is used to pass to the channel service.
	::FillMemory(&guidBogus, sizeof(guidBogus), 0);

	WSADATA 	WSAData;
	//	Initialize the socket library.
	if (::WSAStartup(MAKEWORD(1,1), &WSAData))
	{
		fprintf(stderr, "WSAStartup failed %d\n", ::WSAGetLastError());
		exit(1);
	}

	if (argc != 5)
		usage();

	char* szServer		= argv[1];
	char* szChannel		= argv[2];
	char* szNickname	= argv[3];
	char* szDll			= argv[4];

	HINSTANCE hinstDll = ::LoadLibrary(szDll);
	if (!hinstDll)
	{
		fprintf(stderr, "Sorry, can't find %s.\n", szDll);
		exit(1);
	}
	// A channel service DLL must export the MicCreateService entry point.
	FnMicCreateService* pfnMCS = (FnMicCreateService*)::GetProcAddress(hinstDll, "MicCreateService");
	if (!pfnMCS)
	{
		fprintf(stderr, "Can't get address of MicCreateService.\n");
		exit(1);
	}
	//	Create a new service.
	printf("...Initializing channel service...\n");
	// Call the channel service function with a parameter.
	// This will return a pointer to  an IMicService object.
	// This IMicService object is used by the server to notify the channel service of events
	// that take place within the channel.
	g_pService = (*pfnMCS)(guidBogus);

	//	Create a proxy channel object to simulate the chat server environment.
	g_pChannel = new CMBChannel(g_pService);

	//	Connect to the server and start the service.
	::SetConsoleCtrlHandler(CtrlHandler, TRUE);
	printf("...Running MicBot...\n");
	g_pChannel->Run(szServer, szNickname, szChannel);
	::SetConsoleCtrlHandler(CtrlHandler, FALSE);

	printf("...Shutting down channel service...\n");
	g_pService->SetChannel(NULL);

	//	Delete resources.
	delete g_pChannel;
//	delete g_pService;

	//	Uninitialize the socket library.
	if (::WSACleanup())
	{
		fprintf(stderr, "WSACleanup failed %d\n", WSAGetLastError());
		exit(1);
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////
BOOL __stdcall CtrlHandler(DWORD dwCode)
{
	//	Stop the channel service.
	printf("...Stopping channel service...\n");
	g_pChannel->Stop();

	return TRUE;
}
