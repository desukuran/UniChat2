/*--------------------------------------------------------------------------
	mbmemb.h
	
	MicBot -- Header for IMicMember implementation

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.
------------------------------------------------------------------------*/

#ifndef _MBMEMB_H
#define _MBMEMB_H

class CMBChannel;

class CMBMember : public IMicMember
{
public:
	CMBMember(CMBChannel *pChannel, DWORD Mid);
	~CMBMember(void);

	// IMicMember Methods
	STDMETHODIMP_(MICERR)	SendTextA(PMICMEMBER pMicMember, PCSTR pTextA, ULONG cText = (ULONG)-1);
	STDMETHODIMP_(MICERR)	SendTextW(PMICMEMBER pMicMember, PCWSTR pTextW, ULONG cText = (ULONG)-1);
	STDMETHODIMP_(MICERR)	SendData(PMICMEMBER pMicMember, PVOID pData, ULONG cData);
	STDMETHODIMP_(MICERR)	Broadcast(PMICMEMBER pMicMember, PVOID pData, ULONG cData);
	STDMETHODIMP_(MICERR)	GetUserId(MIC_ID* pUid);
	STDMETHODIMP_(MICERR)	GetMemberId(MIC_ID* pMid);
	STDMETHODIMP_(MICERR)	GetMemberMode(MIC_MODE* pMode);
	STDMETHODIMP_(MICERR)	SetMemberMode(MIC_MODE Mode, MIC_MODE Mask);
	STDMETHODIMP_(MICERR)	GetAlias(PCWSTR* ppAlias);
	STDMETHODIMP_(MICERR)	GetUserParam(DWORD* pdwParam);
	STDMETHODIMP_(MICERR)	SetUserParam(DWORD dwParam);
	STDMETHODIMP_(MICERR)	Kick(PCWSTR pReason);

	// Other methods used by MicBot
	DWORD			GetId(void) const { return m_Id; };
	BOOL			SetAlias(PCWSTR pAlias, ULONG cAlias);
	BOOL			SetAlias(PCSTR pAlias, ULONG cAlias);

	void			SetNext(CMBMember* pMember) { m_pNext = pMember; };
	CMBMember*		GetNext(void) const	{ return m_pNext; };

private:
	CMBMember*		m_pNext;
	CMBChannel*		m_pChannel;
	DWORD			m_Id;
	DWORD			m_User;
	PWSTR			m_pAlias;
};

#endif // _MBMEMB_H
