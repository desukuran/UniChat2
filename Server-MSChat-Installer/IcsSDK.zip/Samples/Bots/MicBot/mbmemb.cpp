/*--------------------------------------------------------------------------
	mbmemb.cpp
	
	MicBot -- IMicMember implementation

	Copyright (C) 1996 Microsoft Corporation
	All rights reserved.
  --------------------------------------------------------------------------*/

#include "micbot.h"
#include "mbchan.h"
#include "mbmemb.h"

//	CMBMember
//	Implementation of IMicMember for MicBot.
CMBMember::CMBMember(CMBChannel* pChannel, DWORD Mid)
{
	m_Id		= Mid;
	m_pChannel	= pChannel;
	m_User		= 0;
	m_pAlias	= NULL;
}

CMBMember::~CMBMember()
{
	if (m_pAlias)
		delete m_pAlias;
}

MICERR CMBMember::SendTextA(PMICMEMBER pMicMember, PCSTR pTextA, ULONG cTextA)
{
	if (cTextA == 0)
		return MICERR_NODATA;

	if (cTextA == (ULONG)-1)
		cTextA = lstrlen(pTextA);

	// Build a MICMSG_SENDMSG message to send.
	ULONG cSendMsg = sizeof(MICMSG_SENDMSG) + cTextA;
	MICMSG_SENDMSG* pSendMsg = (MICMSG_SENDMSG*)_alloca(cSendMsg);	// allocates memory on the stack

	pSendMsg->Type		= MIC_MSGTYPE_SENDMSG;
	pSendMsg->Flags		= MIC_MSGFLAG_ANSI;
	pSendMsg->Length	= (USHORT)cSendMsg;
	pSendMsg->Oid		= GetId();

	// the data simply follows the message header
	memcpy(pSendMsg + 1, pTextA, cTextA);

	return m_pChannel->Send((PBYTE)pSendMsg, cSendMsg);
}

MICERR CMBMember::SendTextW(PMICMEMBER pMicMember, PCWSTR pTextW, ULONG cTextW)
{
	if (cTextW == 0)
		return MICERR_NODATA;

	if (cTextW == (ULONG)-1)
		cTextW = lstrlenW(pTextW);

	// Build a MICMSG_SENDMSG message to send.
	ULONG cSendMsg = sizeof(MICMSG_SENDMSG) + (cTextW * 2);
	MICMSG_SENDMSG* pSendMsg = (MICMSG_SENDMSG*)_alloca(cSendMsg);

	pSendMsg->Type		= MIC_MSGTYPE_SENDMSG;
	pSendMsg->Flags		= MIC_MSGFLAG_NONE;
	pSendMsg->Length	= (USHORT)cSendMsg;
	pSendMsg->Oid		= GetId();

	memcpy(pSendMsg + 1, pTextW, cTextW * 2);

	return m_pChannel->Send((PBYTE)pSendMsg, cSendMsg);
}

MICERR CMBMember::SendData(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	if (cData == 0)
		return MICERR_NODATA;

	// Build a MICMSG_SENDMSG message to send.
	ULONG cMsg = sizeof(MICMSG_SENDMSG) + cData;
	MICMSG_SENDMSG* pMsg = (MICMSG_SENDMSG*) _alloca(cMsg);

	pMsg->Type		= MIC_MSGTYPE_SENDMSG;
	pMsg->Flags		= MIC_MSGFLAG_DATA;
	pMsg->Length	= (USHORT)cMsg;
	pMsg->Oid		= GetId();

	memcpy(pMsg + 1, pData, cData);

	return m_pChannel->Send((PBYTE)pMsg, cMsg);
}

// We simply don't handle Broadcast() calls in MicBot.
MICERR CMBMember::Broadcast(PMICMEMBER pMicMember, PVOID pData, ULONG cData)
{
	return MICERR_NOTHANDLED;
}

// We don't handle userid/memberid calls in MicBot.
MICERR CMBMember::GetUserId(MIC_ID* pUid)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBMember::GetMemberId(MIC_ID* pMid)
{
	return MICERR_NOTHANDLED;
}

// We don't handle member mode calls in MicBot.
MICERR CMBMember::GetMemberMode(MIC_MODE* pMode)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBMember::SetMemberMode(MIC_MODE Mode, MIC_MODE Mask)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBMember::GetAlias(PCWSTR* ppAlias)
{
	*ppAlias = m_pAlias;
	return MICERR_NONE;
}

MICERR CMBMember::GetUserParam(DWORD* pdwParam)
{
	*pdwParam = m_User;
	return MICERR_NONE;
}

MICERR CMBMember::SetUserParam(DWORD dwParam)
{
	m_User = dwParam;
	return MICERR_NONE;
}

MICERR CMBMember::Kick(PCWSTR pReason)
{
	ULONG cReason = (pReason) ? wcslen(pReason) * 2 : 0;

	// Build a MICMSG_CLOSE message to send.
	ULONG cMsg = sizeof(MICMSG_CLOSE) + cReason;
	MICMSG_CLOSE* pMsg = (MICMSG_CLOSE*)_alloca(cMsg);

	pMsg->Type		= MIC_MSGTYPE_CLOSE;
	pMsg->Flags		= 0;
	pMsg->Length	= (USHORT)cMsg;
	pMsg->Oid		= GetId();

	if (cReason)
	{
		// The reason data follows the message header.
		memcpy(pMsg + 1, pReason, cReason);
	}
	return m_pChannel->Send((PBYTE)pMsg, cMsg);
}

BOOL CMBMember::SetAlias(PCWSTR pAlias, ULONG cAlias)
{
	delete m_pAlias;

	m_pAlias = new WCHAR[cAlias + 1];
	memcpy(m_pAlias, pAlias, cAlias * 2);
	m_pAlias[cAlias] = L'\0';

	return TRUE;
}

BOOL CMBMember::SetAlias(PCSTR pAlias, ULONG cAlias)
{
	delete m_pAlias;

	m_pAlias = new WCHAR[cAlias + 1];
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, pAlias, cAlias, m_pAlias, cAlias);
	m_pAlias[cAlias] = L'\0';

	return TRUE;
}
