/*--------------------------------------------------------------------------
	mbchan.cpp

	MicBot -- Implementation of IMicChannel

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.
  --------------------------------------------------------------------------*/

#include "micbot.h"
#include "mbchan.h"
#include "mbmemb.h"
#include <malloc.h>

//	CMBChannel
//	Implementation of IMicChannel for MicBot.

CMBChannel::CMBChannel(IMicService* pMicService)
{
	m_pService	= pMicService;
	m_hSocket	= INVALID_SOCKET;
	m_pMembers	= NULL;
}

CMBChannel::~CMBChannel()
{
	if (m_hSocket != INVALID_SOCKET)
		::closesocket(m_hSocket);
}

/*
	MIC_MSGTYPE_EVENTADDUSER
	MIC_MSGTYPE_EVENTRESULT
	MIC_MSGTYPE_EVENTADDCHANNEL
	MIC_MSGTYPE_EVENTADDMEMBER
	MIC_MSGTYPE_PING
	MIC_MSGTYPE_EVENTMSG
	MIC_MSGTYPE_EVENTDELMEMBER
*/
//	Run() is the main loop for MicBot.
//	It's responsible for connecting to the server and opening a channel.
//	It also performs a recv() loop on its socket to read data from the server.
HRESULT CMBChannel::Run(PCSTR pServerName, PCSTR pUserAlias, PCSTR pChannelName)
{
	//  Initialize the socket address with everything but the ip address.
	SOCKADDR_IN	sin;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family	= AF_INET;
	sin.sin_port	= htons(6667);

	//  Look up the remote server's IP address and fill in the sin.
	PHOSTENT pHostEnt = ::gethostbyname(pServerName);
	if (pHostEnt == NULL)
	{
		fprintf(stderr, "Can't determine IP address of server \"%s\".\n", pServerName);
		exit(1);
	}

	//  Fill in the ip address.
	memcpy(&sin.sin_addr, *pHostEnt->h_addr_list, pHostEnt->h_length);

	//  Create a socket.
	printf("...Connecting to server %s...\n", pServerName);
	m_hSocket = ::socket(PF_INET, SOCK_STREAM, 0);
	if (m_hSocket == INVALID_SOCKET)
	{
		fprintf(stderr, "Socket creation failure %d.\n", WSAGetLastError());
		exit(1);
	}

	//  Connect to the host. 
	if (::connect(m_hSocket, (SOCKADDR*)&sin, sizeof(sin)))
		return S_OK;

    //  Create the initial connect service message for the chat server.
	printf("...Logging in...\n");
	int cSend = sizeof(MICMSG_CONNECTUSER) + lstrlen(pUserAlias);
	BYTE	aBuffer[4096];
	memset(aBuffer, 0, cSend);

	MICMSG_CONNECTUSER* pMsgConnectUser = (MICMSG_CONNECTUSER*)aBuffer;
	memset(pMsgConnectUser, 0, sizeof(MICMSG_CONNECTUSER));
	pMsgConnectUser->Type			= MIC_MSGTYPE_CONNECTUSER;
	pMsgConnectUser->Flags			= MIC_MSGFLAG_ANSI;
	pMsgConnectUser->Length			= cSend;
	pMsgConnectUser->Version		= 0;
	pMsgConnectUser->AliasLength	= lstrlen(pUserAlias);
	memcpy(pMsgConnectUser + 1, pUserAlias, pMsgConnectUser->AliasLength);

	//  Send the initial connect service message.
	int cBytes = ::send(m_hSocket, (PCSTR)pMsgConnectUser, cSend, 0);
	if (cBytes != cSend)
		return S_OK;

	//  Read data from the input socket port and parse it.
	int iBuffer = 0;
	while (1)
	{
		cBytes = ::recv(m_hSocket, (PSTR)&aBuffer[iBuffer], sizeof(aBuffer) - iBuffer, 0);
		if (cBytes <= 0)
		{
			return S_OK;
		}
		//  Update the number of bytes in our internal buffer.
		iBuffer += cBytes;

		while (iBuffer)
		{
			//	We may not have the full message header yet. If not, just loop and read again.
			cBytes = sizeof(MICMSG_HEADER);
			if (cBytes > iBuffer)
				break;
			//	We have a full message header.
			// Check the Length field to see if we've received a full message or not.
			cBytes = ((MICMSG_HEADER*)aBuffer)->Length;
			if (cBytes > iBuffer)
				break;

			//	We have a full message.
			// Check the first byte of the message to determine the type of the message.
			switch (aBuffer[0])
			{
			case MIC_MSGTYPE_DATAMEMBERLIST:
				OutputDebugString("	MIC_MSGTYPE_DATAMEMBERLIST\n");
				printf("	MIC_MSGTYPE_DATAMEMBERLIST\n");
				break;

			case MIC_MSGTYPE_EVENTADDCHANNEL:
				{
				MICMSG_EVENTADDCHANNEL* pMsgEventAddChannel = (MICMSG_EVENTADDCHANNEL*)&aBuffer[0];
				m_Cid = pMsgEventAddChannel->Cid;
				m_Mid = 0;
				OutputDebugString("	MIC_MSGTYPE_EVENTADDCHANNEL\n");
				printf("	MIC_MSGTYPE_EVENTADDCHANNEL Cid = %lx\n", m_Cid);
				break;
				}
			case MIC_MSGTYPE_EVENTADDMEMBER:
				{
				MICMSG_EVENTADDMEMBER* pMsgEventAddMember = (MICMSG_EVENTADDMEMBER*)&aBuffer[0];
				if (m_Mid == 0)
				{
					m_Mid = pMsgEventAddMember->Mid;
					m_pService->SetChannel(this);
				}
				else
				{
					CMBMember* pMember = new CMBMember(this, pMsgEventAddMember->Mid);

					if (pMsgEventAddMember->Flags & MIC_MSGFLAG_ANSI)
						pMember->SetAlias((PCSTR)(pMsgEventAddMember+1), pMsgEventAddMember->AliasLength);
					else
						pMember->SetAlias((PCWSTR)(pMsgEventAddMember+1), pMsgEventAddMember->AliasLength);

					LinkMember(pMember);

					m_pService->AddMember(pMember);
				}
				OutputDebugString("	MIC_MSGTYPE_EVENTADDMEMBER\n");
				char szName[128];
				memcpy(szName, (PCSTR)(pMsgEventAddMember+1), pMsgEventAddMember->AliasLength);
				szName[pMsgEventAddMember->AliasLength] = NULL;
				printf("	MIC_MSGTYPE_EVENTADDMEMBER Mid = %lx[%s]\n",
							pMsgEventAddMember->Mid, szName);
				break;
				}
			case MIC_MSGTYPE_EVENTADDUSER:
				{
				MICMSG_EVENTADDUSER* pMsgEventAddUser = (MICMSG_EVENTADDUSER*)&aBuffer[0];
				OutputDebugString("	MIC_MSGTYPE_EVENTADDUSER\n");
				printf("	MIC_MSGTYPE_EVENTADDUSER\n");
				//  Create the channel.
				printf("...Creating channel [%s]...\n", pChannelName);
				cSend = sizeof(MICMSG_CREATECHANNEL) + lstrlen(pChannelName);

				MICMSG_CREATECHANNEL* pMsgCreateChannel = (MICMSG_CREATECHANNEL*)aBuffer;
				memset(pMsgCreateChannel, 0, sizeof(MICMSG_CREATECHANNEL));
				pMsgCreateChannel->Type		= MIC_MSGTYPE_CREATECHANNEL;
				pMsgCreateChannel->Flags	= MIC_MSGFLAG_ANSI;
				pMsgCreateChannel->Length	= cSend;
				pMsgCreateChannel->ChannelMode = MIC_CHANNELMODE_PUBLIC |
												 MIC_CHANNELMODE_NOEXTERN |
												 MIC_CHANNELMODE_TOPICOP;
				pMsgCreateChannel->ChannelFlags = MIC_CHANNELFLAG_MICONLY;
				pMsgCreateChannel->NameLength = lstrlen(pChannelName);
				memcpy(pMsgCreateChannel + 1, pChannelName, pMsgCreateChannel->NameLength);

				cBytes = ::send(m_hSocket, (PCSTR)pMsgCreateChannel, cSend, 0);
				if (cBytes != cSend)
					goto Error;
				break;
				}
			case MIC_MSGTYPE_EVENTDELMEMBER:
				{
				MICMSG_EVENTDELMEMBER* pMsgEventDelMember = (MICMSG_EVENTDELMEMBER*)&aBuffer[0];
				CMBMember* pMember = FindMember(pMsgEventDelMember->Mid);
				if (pMember)
				{
					m_pService->DelMember(pMember);
					UnlinkMember(pMember);
				}
				else
				{
					DebugBreak();
				}
				OutputDebugString("	MIC_MSGTYPE_EVENTDELMEMBER\n");
				printf("	MIC_MSGTYPE_EVENTDELMEMBER Mid = %lx\n", pMsgEventDelMember->Mid);
				break;
				}
			case MIC_MSGTYPE_EVENTMSG:
				{
				MICMSG_EVENTMSG* pMsgEventMsg = (MICMSG_EVENTMSG*)&aBuffer[0];
				CMBMember* pMember = FindMember(pMsgEventMsg->From);
				if (pMember)
				{
					if (pMsgEventMsg->Flags & MIC_MSGFLAG_DATA)
						m_pService->RecvData(pMember, (PBYTE)(pMsgEventMsg+1), pMsgEventMsg->Length - sizeof(MICMSG_EVENTMSG));
					else if (pMsgEventMsg->Flags & MIC_MSGFLAG_ANSI)
						m_pService->RecvTextA(pMember, (PCSTR)(pMsgEventMsg+1), pMsgEventMsg->Length - sizeof(MICMSG_EVENTMSG));
					else
						m_pService->RecvTextW(pMember, (PCWSTR)(pMsgEventMsg+1), pMsgEventMsg->Length - sizeof(MICMSG_EVENTMSG));
				}
				OutputDebugString("	MIC_MSGTYPE_EVENTMSG\n");
				((LPSTR)(pMsgEventMsg+1))[pMsgEventMsg->Length - sizeof(MICMSG_EVENTMSG)] = NULL;
				printf("	MIC_MSGTYPE_EVENTMSG \"%s\"\n", (PCSTR)(pMsgEventMsg+1));
				break;
				}
			case MIC_MSGTYPE_EVENTRESULT:
				{
				MICMSG_EVENTRESULT* pMsgResult = (MICMSG_EVENTRESULT*)&aBuffer[0];
				// TODO: Handle this intelligently
				OutputDebugString("	MIC_MSGTYPE_EVENTRESULT\n");
				printf("	MIC_MSGTYPE_EVENTRESULT\n");
				break;
				}
			case MIC_MSGTYPE_PING:
				{
				OutputDebugString("	MIC_MSGTYPE_PING\n");
				printf("	MIC_MSGTYPE_PING\n");
				MICMSG_PING* pMsgPing = (MICMSG_PING*)&aBuffer[0];
				MICMSG_PONG	MsgPong;
				MsgPong.Type	= MIC_MSGTYPE_PONG;
				MsgPong.Flags	= MIC_MSGFLAG_NONE;
				MsgPong.Length	= sizeof(MICMSG_PONG);

				cBytes = ::send(m_hSocket, (PCSTR)&MsgPong, sizeof(MICMSG_PONG), 0);
				if (cBytes != sizeof(MICMSG_PONG))
					goto Error;
				break;
				}
			default:
				break;
			}

			if (iBuffer > cBytes)
			{
				memmove(aBuffer, &aBuffer[cBytes], iBuffer - cBytes);
				iBuffer -= cBytes;
			}
			else
			{
				iBuffer = 0;
			}
		}
	}
Error:
	if (m_hSocket != INVALID_SOCKET)
	{
		::closesocket(m_hSocket);
		m_hSocket = INVALID_SOCKET;
	}
	return S_OK;
}

// Stop() is the counterpart to Run().
// It stops the running of the channel service DLL.
void CMBChannel::Stop()
{
	printf("...Closing socket...\n");
	::closesocket(m_hSocket);
	m_hSocket = INVALID_SOCKET;
}

MICERR CMBChannel::SendTextA(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PCSTR pTextA, ULONG cTextA)
{
	if (cTextA == 0)
		return NO_ERROR;

	if (cTextA == (ULONG)-1)
		cTextA = lstrlen(pTextA);

	ULONG cSendMsg = sizeof(MICMSG_SENDMSG) + cTextA;
	MICMSG_SENDMSG* pSendMsg = (MICMSG_SENDMSG*)_alloca(cSendMsg);

	pSendMsg->Type		= MIC_MSGTYPE_SENDMSG;
	pSendMsg->Flags		= MIC_MSGFLAG_ANSI;
	pSendMsg->Length	= (USHORT)cSendMsg;
	pSendMsg->Oid		= m_Cid;

	memcpy(pSendMsg + 1, pTextA, cTextA);

	return Send((PBYTE)pSendMsg, cSendMsg);
}

MICERR CMBChannel::SendTextW(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PCWSTR pTextW, ULONG cTextW)
{
	if (cTextW == 0)
		return MICERR_NONE;

	if (cTextW == (ULONG)-1)
		cTextW = lstrlenW(pTextW);

	ULONG cSendMsg = sizeof(MICMSG_SENDMSG) + (cTextW * 2);
	MICMSG_SENDMSG* pSendMsg = (MICMSG_SENDMSG*)_alloca(cSendMsg);

	pSendMsg->Type		= MIC_MSGTYPE_SENDMSG;
	pSendMsg->Flags		= MIC_MSGFLAG_NONE;
	pSendMsg->Length	= (USHORT)cSendMsg;
	pSendMsg->Oid		= m_Cid;

	memcpy(pSendMsg + 1, pTextW, (cTextW * 2));

	return Send((PBYTE)pSendMsg, cSendMsg);
}


MICERR CMBChannel::SendData(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PVOID pData, ULONG cData)
{
	if (cData == 0)
		return MICERR_NODATA;

	ULONG cMsg = sizeof(MICMSG_SENDMSG) + cData;
	MICMSG_SENDMSG* pMsg = (MICMSG_SENDMSG*)_alloca(cMsg);

	pMsg->Type		= MIC_MSGTYPE_SENDMSG;
	pMsg->Flags		= MIC_MSGFLAG_DATA;
	pMsg->Length	= (USHORT)cMsg;
	pMsg->Oid		= m_Cid;

	memcpy(pMsg + 1, pData, cData);

	return Send((PBYTE)pMsg, cMsg);
}

// We don't currently handle some of the more complex methods in MicBot...
MICERR CMBChannel::Broadcast(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PVOID pData, ULONG cData)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::SendWhisperTextA(PMICMEMBER pMicMember, PMICMEMBER*, ULONG, PCSTR, ULONG cText)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::SendWhisperTextW(PMICMEMBER pMicMember, PMICMEMBER*, ULONG, PCWSTR pTextW, ULONG cText)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::SendWhisperData(PMICMEMBER pMicMember, PMICMEMBER*, ULONG, PVOID pData, ULONG cData)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::GetName(PCWSTR* ppName, UINT* pcName)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::SetTopic(PCWSTR pTopic, UINT cTopic)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::GetTopic(PCWSTR* ppTopic, UINT* pcTopic)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::GetServiceValue(PCWSTR pName, PWSTR pValue, ULONG* pcValue)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::GetValue(PCWSTR pName, PWSTR pValue, ULONG* pcValue)
{
	return MICERR_NOTHANDLED;
}

MICERR CMBChannel::Send(PBYTE pData, ULONG cData)
{
	ULONG cBytes = ::send(m_hSocket, (PCSTR)pData, cData, 0);
	if (cBytes != cData)
		return MICERR_LOSTCONNECTION;

	return MICERR_NONE;
}

void CMBChannel::LinkMember(CMBMember* pMember)
{
	pMember->SetNext(m_pMembers);
	m_pMembers = pMember;
}

void CMBChannel::UnlinkMember(CMBMember* pMember)
{
	if (m_pMembers == pMember)
	{
		m_pMembers = pMember->GetNext();
	}
	else
	{
		CMBMember* pEntry = m_pMembers;
		while (pEntry->GetNext())
		{
			if (pEntry->GetNext() == pMember)
			{
				pEntry->SetNext(pMember->GetNext());
				break;
			}
			pEntry = pEntry->GetNext();
		}
	}
}

CMBMember* CMBChannel::FindMember(MIC_ID Mid)
{
	CMBMember* pMember = m_pMembers;

	while (pMember)
	{
		if (pMember->GetId() == Mid)
			return pMember;
		pMember = pMember->GetNext();
	}
	return NULL;
}
