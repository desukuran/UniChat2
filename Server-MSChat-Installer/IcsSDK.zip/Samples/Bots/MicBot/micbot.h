/*--------------------------------------------------------------------------
	micbot.h
	
	MicBot -- main header file

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.
  --------------------------------------------------------------------------*/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <MicMsg.h>

