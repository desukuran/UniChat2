/*--------------------------------------------------------------------------
	mbchan.h
	
	MicBot -- Header for IMicChannel implementation

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _MBCHAN_H
#define _MBCHAN_H

#include "micsvc.h"

class CMBMember;

class CMBChannel : public IMicChannel
{
public:
	CMBChannel(PMICSERVICE pMicService);
	~CMBChannel(void);

	// IMicChannel Methods
	STDMETHODIMP_(MICERR)	SendTextA(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PCSTR pTextA, ULONG cText = (ULONG)-1);
	STDMETHODIMP_(MICERR)	SendTextW(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PCWSTR pTextW, ULONG cText = (ULONG)-1);
	STDMETHODIMP_(MICERR)	SendData(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PVOID pData, ULONG cData);
	STDMETHODIMP_(MICERR)	Broadcast(PMICMEMBER pMicMember, MIC_MODE* pModeMask, PVOID pData, ULONG cData);
	STDMETHODIMP_(MICERR)	SendWhisperTextA(PMICMEMBER pMicMember, PMICMEMBER*, ULONG, PCSTR, ULONG cText = (ULONG)-1);
	STDMETHODIMP_(MICERR)	SendWhisperTextW(PMICMEMBER pMicMember, PMICMEMBER*, ULONG, PCWSTR pTextW, ULONG cText = (ULONG)-1);
	STDMETHODIMP_(MICERR)	SendWhisperData(PMICMEMBER pMicMember, PMICMEMBER*, ULONG, PVOID pData, ULONG cData);
	STDMETHODIMP_(MICERR)	GetName(PCWSTR* ppName, UINT* pcName);
	STDMETHODIMP_(MICERR)	SetTopic(PCWSTR pTopic, UINT cTopic = ~0);
	STDMETHODIMP_(MICERR)	GetTopic(PCWSTR* ppTopic, UINT* pcTopic);
	STDMETHODIMP_(MICERR)	GetServiceValue(PCWSTR pName, PWSTR pValue, ULONG* pcValue);
	STDMETHODIMP_(MICERR)	GetValue(PCWSTR pName, PWSTR pValue, ULONG *pcValue);

	DWORD			GetId(void) const { return m_Cid; };
    HRESULT			Run(PCSTR pHostName, PCSTR pAlias, PCSTR pChannelName);
	void			Stop();
	MICERR			Send(PBYTE pData, ULONG cData);

	void			LinkMember(CMBMember * pMember);
	void			UnlinkMember(CMBMember * pMember);
	CMBMember*		FindMember(MIC_ID Mid);

private:
	IMicService*	m_pService;
	SOCKET			m_hSocket;
	DWORD			m_Uid;
	DWORD			m_Cid;
	DWORD			m_Mid;
	CMBMember*		m_pMembers;
};

#endif // _MBCHAN_H
