/*--------------------------------------------------------------------------
	greeter.cpp
	
	Greeterbot -- a simple ChatSock bot. LINK: chatsock.lib csguid.lib

    Copyright (C) 1996-1997 Microsoft Corporation
    All rights reserved.

	THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
  --------------------------------------------------------------------------*/

#include "greeter.h"

/////////////////////////////////////////////////////////////////////////////////
// Global variables

// Our global ChatSock socket
PICS g_psocket = NULL;

// Our global ChatSock channel
PICS_CHANNEL g_pchannel = NULL;

// Globals associated with thread management.
HANDLE g_hthreadSocket	= NULL;
HANDLE g_hthreadChannel	= NULL;
HANDLE g_hevtStop		= NULL;

// Placeholder to hold the name of the channel we wish to join.
char* g_szChannel;

/////////////////////////////////////////////////////////////////////////////////
//	Performs global app initialization.
BOOL FInit()
{
	// Create our global shutdown event.
	g_hevtStop = ::CreateEvent(NULL, TRUE, FALSE, NULL);
	if (!g_hevtStop)
		return FALSE;

	return TRUE;
}

//	Thread proc which monitors g_pchannel.
DWORD __stdcall DwChannelReaderThread(PVOID pvUser)
{
	PCS_MSGBASE		pmsg;
	PCS_MSGMEMBER	pmsgmember;
	PICS_MEMBER		pmemberMe;
	char*			sz;
	BOOL			fAnsi;
	char			szGreet[256];

	// HrWaitForMsg() will fail when the channel is closed.
	while (SUCCEEDED(g_pchannel->HrWaitForMsg(&pmsg, INFINITE)))
	{
		switch (pmsg->csMsgType)
		{
		case CSMSG_TYPE_ADDMEMBER:
			pmsgmember = MSGBASE_TO_MSG(pmsg, PCS_MSGMEMBER);
			pmsgmember->picsMember->HrGetName((BYTE**)&sz, &fAnsi);

			// Upon joining a channel, a client gets a CSMSG_TYPE_ADDMEMBER for itself.
			// It looks pretty silly for Greeterbot to greet itself,
			// so we check to see if this ADDMEMBER is for us.
			g_pchannel->HrGetMe(&pmemberMe);
			if (pmemberMe != pmsgmember->picsMember)
			{
				printf("Greeting %s.\n", sz);
				wsprintf(szGreet, "Hi, %s!", sz);
				g_pchannel->HrSendTextA(szGreet);	// Send Greeting message!
			}
			pmemberMe->Release();
			break;
		}
		// All messages must be freed with HrFreeMsg().
		HrFreeMsg(pmsg);
	}
	// This release matches the extra AddRef in JoinedChannel().
	g_pchannel->Release();

	return 0;
}

//	This function is called when a CSMSG_TYPE_ADDCHANNEL message is received by the socket thread.
//  It creates a subordinate thread to monitor the newly-joined channel.
void JoinedChannel(PICS_CHANNEL pchannel)
{
	printf("Joined channel.\n");

	g_pchannel = pchannel;
	g_pchannel->AddRef();	// this is for g_pchannel
	g_pchannel->AddRef();	// this is for the channel reader thread
	
	DWORD tid;
	g_hthreadChannel = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)DwChannelReaderThread,
									NULL, 0, &tid);
	if (!g_hthreadChannel)
	{
		// The creation failed, so we should release the extra ref for the channel reader thread.
		g_pchannel->Release();
	}
}

//	Thread proc which monitors g_psocket.
DWORD __stdcall DwSocketReaderThread(PVOID pvUser)
{
	PCS_MSGBASE		pmsg;
//	PCS_PROPERTY	pprop;
	PCS_ERROR		perror;
	PCS_MSGCHANNEL	pmsgchannel;
//	CS_PROPDATA		propdata;
	CS_CINFO		cinfo;
//	DWORD			cprop;
//	DWORD			i;
	HRESULT			hr;

	// HrWaitForMsg() will fail when the socket is closed.
	while (SUCCEEDED(g_psocket->HrWaitForMsg(&pmsg, INFINITE)))
	{
		switch (pmsg->csMsgType)
		{
		case CSMSG_TYPE_LOGIN:
			printf("Logged in.\n");

			// We successfully logged in, so now we should try to create/join our channel.
			::FillMemory(&cinfo, sizeof(CS_CINFO), 0);
			cinfo.dwcb			= sizeof(CS_CINFO);
			cinfo.dwType		= CS_CHANNEL_PUBLIC;
			cinfo.dwFlags		= CS_CHANNEL_FLAG_NONE;
			cinfo.bCreateFlags	= CS_CHANNEL_CREATE_JOIN;
			cinfo.pvChannelName	= g_szChannel;
			cinfo.pvTopic		= "";
			cinfo.pvPassword	= "";
			
			if (FAILED(hr = g_psocket->HrCreateChannelA(&cinfo)))
			{
				printf("Couldn't create channel!  Error was %08X\n", hr);
				if (hr == CS_E_FIRSTCHAR)
				{
					printf("The first character of the channel name must be #.\n");
				}
				::SetEvent(g_hevtStop);
			}
			break;

		case CSMSG_TYPE_ERROR:
			perror = MSGBASE_TO_MSG(pmsg, PCS_ERROR);
			printf("Received error on socket: %08X\n", perror->hr);
			break;
			
		case CSMSG_TYPE_ADDCHANNEL:
			// We created or joined a channel.
			pmsgchannel = MSGBASE_TO_MSG(pmsg, PCS_MSGCHANNEL);
			JoinedChannel(pmsgchannel->picsChannel);
			break;
		}
		// As with channel messages, all messages must be freed with HrFreeMsg().
		HrFreeMsg(pmsg);
	}
	// This release matches the extra AddRef in FStartSocketReaderThread().
	g_psocket->Release();
	return 0;
}

//	Creates a thread to monitor the socket.
BOOL FStartSocketReaderThread()
{
	DWORD tid;

	g_psocket->AddRef(); // We add an extra reference for the thread itself.
	g_hthreadSocket = ::CreateThread(NULL, 0, DwSocketReaderThread, NULL, 0, &tid);
	if (!g_hthreadSocket)
	{
		g_psocket->Release(); // don't need the extra ref...
		return FALSE;
	}
	return TRUE;
}

//	Does all the work of connecting to the server and attempting to log in.
BOOL FConnect(char* szServer, char* szNick)
{
	HRESULT			hr			= NOERROR;
	PICS_FACTORY	pfactory	= NULL;
	PICS			psocket		= NULL;
	BOOL			fRet		= FALSE;
	CS_CONNINFO		conninfo;

	// Connect to the server.
	hr = HrCreateChatSocketFactory(IID_CHATSOCKVER1, &pfactory);
	if (FAILED(hr))
		goto LBail;
	hr = pfactory->HrMakeSocket(szServer, &psocket);
	if (FAILED(hr))
		goto LBail;
	hr = psocket->HrConnect(szServer);
	if (FAILED(hr))
		goto LBail;

	// Log in.
	::FillMemory(&conninfo, sizeof(CS_CONNINFO), 0);
	conninfo.dwcb	= sizeof(CS_CONNINFO);
	conninfo.bType	= CS_CONNECT_ANONYMOUS;
	conninfo.pvUser	= szNick;
	conninfo.pvPass	= "";
	conninfo.pvNick	= szNick;
	hr = psocket->HrLoginA(&conninfo);
	if (FAILED(hr))
		goto LBail;

	// AddRef() the socket since we're saving it in g_psocket...
	g_psocket = psocket;
	g_psocket->AddRef();

	// We successfully sent a Login message.
	// Now we should go wait for the CSMSG_TYPE_LOGIN to come.
	if (!FStartSocketReaderThread())
		goto LBail;

	fRet = TRUE;

LBail:
	if (FAILED(hr))
	{
		printf("Error: %08X\n", hr);
	}

	// We can release psocket because we AddRef()ed it above if we wanted to keep it.
	if (psocket)
	{
		psocket->Release();
	}
	if (pfactory)
	{
		pfactory->Release();
	}
	return fRet;
}

//	Cleans up everything.  Closes the channel and socket.
BOOL FTerm()
{
	if (g_pchannel)
	{
		// HrLeave() will close the channel and cause the channel thread to exit.
		g_pchannel->HrLeave(TRUE);
		g_pchannel->Release();
	}

	// We wait for the thread to exit so we can be sure that its call
	// to g_pchannel->Release() happens before we exit our main thread.
	// Otherwise the process will just end and we will leak ChatSock objects.
	::WaitForSingleObject(g_hthreadChannel, INFINITE);

	if (g_psocket)
	{
		// HrCloseSocket() closes the socket;
		// we call HrLogOff() first to make sure to tell the server we're going away.
		g_psocket->HrLogOff();
		g_psocket->HrCloseSocket();
		g_psocket->Release();
	}

	// And wait for the socket thread for the same reason as we waited for the channel thread.
	::WaitForSingleObject(g_hthreadSocket, INFINITE);

	return TRUE;
}

void usage()
{
	printf("usage:	greeter <server> <channel> <nick>\n");
	exit(1);
}

//	Handler()
//	This is our control handler.  It is called by Windows when ctrl-c or ctrl-break are pressed.
BOOL __stdcall Handler(DWORD dwCode)
{
	printf("Exiting...\n");

	// All we need to do is wake up the main thread so it will call FTerm() and shut things down.
	::SetEvent(g_hevtStop);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////////////////
//	main() : Entry point.
//	Arguments: SnowWhite #Greeter Greeter
void __cdecl main(int argc, char** argv)
{
	if (argc < 4)
		usage();

	if (!FInit())
		exit(1);

	g_szChannel = argv[2];
	if (!FConnect(argv[1], argv[3]))
		exit(1);

	::SetConsoleCtrlHandler(Handler, TRUE);

	// Handler() will set this event...
	::WaitForSingleObject(g_hevtStop, INFINITE);

	FTerm();
	exit(0);
}
