/*--------------------------------------------------------------------------
	greeter.h

		Main header for Greeterbot

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include <windows.h>
#include <stdio.h>
#include <csface.h>
#include <cserror.h>
