/*--------------------------------------------------------------------------
	stdafx.h
	
		Precompiled header for ConChat

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#include <windows.h>
#include <stdio.h>
#include <micmsg.h>			// MIC protocol header
#include <csface.h>			// ChatSock header
#include <cserror.h>		// ChatSock errors
#include <crtdbg.h>

#define ASSERT(x)	_ASSERT(x)