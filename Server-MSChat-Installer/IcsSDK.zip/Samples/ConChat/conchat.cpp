/*--------------------------------------------------------------------------
	conchat.cpp
	
		ConChatSocket, ConChatChannel classes

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/
#include "stdafx.h"
#include "ccmd.h"
#include "basechan.h"
#include "basesock.h"
#include "console.h"
#include "conchat.h"

CParser*		g_pParser = NULL;
ConChatSocket*	g_pSocket = NULL;
ConChatChannel*	g_pChannel = NULL;

// The table of commands recognized by conchat
CMD	MPCMD[] =
{
	{"/CONNECT", 	"<server[:port]> <nick> <username> <backup nick>",	HrCmdConnect}, 
	{"/JOIN", 		"<channel> [<topic>]", 								HrCmdJoin}, 
	{"/LIST", 		"[<channel>] [<user min> <user max>]", 				HrCmdList}, 
	{"/LISTMEM", 	"<channel>", 										HrCmdListMembers}, 
	{"/QUIT", 		"Quit the application.", 							HrCmdQuit}, 
	{"/HELP", 		"List ConChat commands.", 							HrCmdHelp}, 
	{"/LEAVE", 		"Leave current channel.", 							HrCmdLeave}, 
	{"/?", 			"List ConChat commands.", 							HrCmdHelp}, 
};

const DWORD DWCCMD = sizeof(MPCMD)/sizeof(CMD);

/////////////////////////////////////////////////////////////////////////////////
// Main routine.  Performs some initialization then starts the console's IO loop.
void __cdecl main(int argc, char **argv)
{	
	if (!FInitGlobals())
	{
		printf("There was a problem completing this task. Please try again later.\n");
		goto LExit;
	}

	About();		// greeting

	g_console.FDoIOLoop();

	FCleanUpGlobals();
	exit(1);
			
LExit:
	exit(0);
}

void About()
{
	g_console.WriteString("\n");
	g_console.WriteString("    - - - - - - -\n");
	g_console.WriteString("    C O N C H A T\n");
	g_console.WriteString("    - - - - - - -\n\n");
	g_console.WriteString("(c) Tortoise Soft, 1996\n");
	g_console.WriteString("All Rights Reserved.\n\n");
	g_console.WriteString("Type /help for help.\n");
}

// Initializes ConChat's global variables.
BOOL FInitGlobals()
{
	if (!g_console.FInit())
		return FALSE;
	
	g_pParser = new CParser;
	g_pSocket = new ConChatSocket;
	if (!g_pParser || !g_pSocket)
		return FALSE;

	if (FAILED(g_pParser->HrInit(MPCMD, DWCCMD, HrConChatHelp, HrSendText, HrConChatError)))
		return FALSE;

	return g_pSocket->FInit();
}

// Cleans up ConChat's global variables.
BOOL FCleanUpGlobals()
{
	if (g_pParser)
		delete g_pParser;

	if (g_pSocket)
		delete g_pSocket;

	g_console.CleanUp();
	return TRUE;
}

// If the user has already connected to a server, this routine simply returns TRUE;
// otherwise it prints an error message and returns FALSE.
BOOL FVerifyConnected()
{
	BOOL fRet = (g_pSocket && g_pSocket->FConnected());
	if (!fRet)
	{
		g_console.WriteString("Error: Not connected to a server.\n");
	}
	return fRet;
}

// If the user has already joined a channel, this routine simply returns TRUE;
// otherwise it prints an error message and returns FALSE.
BOOL FVerifyInChannel()
{
	BOOL fRet = (g_pChannel && g_pChannel->FInChannel());
	if (!fRet)
	{
		g_console.WriteString("Error: Not currently in a channel.\n");
	}
	return fRet;
}

// If the user has not already joined a channel, this routine simply returns TRUE;
// otherwise it prints an error message and returns FALSE.
BOOL FVerifyNotInChannel()
{
	BOOL fRet = !(g_pChannel && g_pChannel->FInChannel());
	if (!fRet)
	{
		g_console.WriteString("Error: Already in channel ");
		g_console.WriteString(g_pChannel->SzName());
		g_console.WriteString(".\n");
	}
	return (fRet);
}
 
// Prints help on a particular command.
HRESULT HrConChatHelp(PCMD pcmd)
{
	_ASSERT(pcmd);

	g_console.WriteString(pcmd->szCmd);
	g_console.WriteString(": ");
	g_console.WriteString(pcmd->szDescription);

	return NOERROR;
}

// Displays an error message when parsing fails for a particular command.
HRESULT HrConChatError(HRESULT hr, char* sz)
{
	char* szError;
	char szBuf[256];

	switch (hr)
	{
	default:
		szError = "";
		break;
	
	case CMD_E_UNKNOWNCMD:
		// The parser shouldn't ever return this error...
		_ASSERT(FALSE);
		szError = "Unknown command";
		break;
	
	case CMD_E_MISSINGPREFIX:
		szError = "Missing prefix in";
		break;
	
	case CMD_E_MISSINGCMD:
		szError = "Missing command in";
		break;
	
	case CMD_E_MISSINGPARAMS:
		szError = "Missing parameters in";
		break;
	}
	
	wsprintf(szBuf, "%s:%s.\n", szError, sz);
	g_console.WriteString(szBuf);
	return NOERROR;
}

// Extracts the parameters from szParams and connects to the specified server.
HRESULT HrCmdConnect(PCMD pcmd, char* szParams)
{
	// If already connected, return an error
	if (g_pSocket->FConnected())
	{
		g_console.WriteString("Error: Already connected.\n");
		return NOERROR;
	}

	// Format: /connect <server> <nick> <username> [<backup nick>]
	char*		szServer;
	char*		szUserName;
	char*		szNick;
	char*		szNickBak;
	if (!g_pParser->FGetNextParam(&szParams, &szServer) ||
		!g_pParser->FGetNextParam(&szParams, &szNick) ||
		!g_pParser->FGetNextParam(&szParams, &szUserName))
	{
		HrConChatHelp(pcmd);
		return E_INVALIDARG;
	}

	if (!g_pParser->FGetNextParam(&szParams, &szNickBak))
	{
		szNickBak = NULL;
	}

	// Now connect
	EC_CONNINFO	ecInfo;
	ecInfo.szServer			= szServer;		// server to connect to
	ecInfo.szNick			= szNick;		// Nick name to use
	ecInfo.szNickBak		= szNickBak;	// A backup nick - optional
	ecInfo.szUserName		= szUserName;	// user name to use 
	ecInfo.szPass			= NULL;
	ecInfo.fAuthenticate	= FALSE;		// Use anonymous connection
	ecInfo.dwTimeOut		= 20000;		// timeout in 20 seconds.
	
	if (!g_pSocket->FConnect(&ecInfo))
	{
		char szBuf[256];
		wsprintf(szBuf, "Error: Could not connect to %s.\n", szServer);
		g_console.WriteString(szBuf);
		return E_FAIL;
	}
	return NOERROR;
}

// Quits ConChat.
HRESULT HrCmdQuit(PCMD pcmd, char* szParams)
{
	_ASSERT(pcmd);
	
	g_console.StopIOLoop();

	if (g_pChannel)
	{
		g_pChannel->FLeave();
		delete g_pChannel;
		g_pChannel = NULL;  
	}
	if (g_pSocket)
	{
		g_pSocket->FDisconnect();
	}

	return NOERROR;
}

// Helper routine.
char*	g_szSpaces = "                                                                                                                                                                ";

char*	SzSpace(int cch)
{
	return (cch > 160) ? g_szSpaces : &(g_szSpaces[159 - cch]);
}

// Shows the ConChat documentation.
HRESULT HrCmdHelp(PCMD pcmd, char* szParams)
{
	g_console.Lock();
	g_console.WriteString("Commands:\n");
	for (DWORD dwc = 0; dwc < DWCCMD; ++dwc)
	{
		PCMD pCmd = &MPCMD[dwc];
		_ASSERT(pCmd);
		
		g_console.WriteString("  ");
		g_console.WriteString(pCmd->szCmd);
		g_console.WriteString(SzSpace(15 - lstrlen(pCmd->szCmd)));
		g_console.WriteString(pCmd->szDescription);
		g_console.WriteString("\n");
	}	
	g_console.WriteString("\n");
	g_console.Unlock();

	return NOERROR;
}

// Joins a channel.
HRESULT HrCmdJoin(PCMD pcmd, char* szParams)
{
	if (!FVerifyConnected() || !FVerifyNotInChannel())
	{
		return S_FALSE;
	}

	// Format: /join <channel> [<topic>]
	CHAR*	szChannel;
	if (!g_pParser->FGetNextParam(&szParams, &szChannel))
	{
		HrConChatHelp(pcmd);
		return E_INVALIDARG;
	}

	CHAR*	szTopic;
	if (!g_pParser->FGetNextParam(&szParams, &szTopic))
	{
		szTopic = "";
	}

	// Join the channel
	EC_CHANNELINFO	ecInfo;
	ecInfo.szName		= szChannel;
	ecInfo.szTopic		= szTopic;
	ecInfo.szPass		= "";
	ecInfo.cUsersMax	= 0;

	// Our chats are public and permit anonymous (all MIC and all IRC) users.
	ecInfo.dwType		= CS_CHANNEL_PUBLIC | CS_CHANNEL_ALLOWANON; 
	ecInfo.dwFlags		= 0;		// and no special flags

	if (!g_pSocket->FCreateJoinChannel(&ecInfo))
	{
		g_console.WriteString("Error: Could not join ");
		g_console.WriteString(szChannel);
		g_console.WriteString(".\n");
		return E_FAIL;
	}
	return NOERROR;
}

// Our default command.  If there is no command in a user-typed string, 
// we simply treat it as a message to send to the current channel.
HRESULT HrSendText(char* szText)
{
	if (!FVerifyInChannel())
	{
		return S_FALSE;
	}
	// Send the text
	return g_pChannel->FSendAnsiText(szText) ? NOERROR : E_INVALIDARG;
}

// Leaves the current channel.
HRESULT HrCmdLeave(PCMD pcmd, char* szParams)
{
	if (!FVerifyInChannel())
	{
		return S_FALSE;
	}
	g_pChannel->FLeave();
	g_pChannel = NULL;

	return NOERROR;
}

// Lists channels.
HRESULT HrCmdList(PCMD pcmd, char* szParams)
{
	if (!FVerifyConnected())
	{
		return S_FALSE;
	}
	// All parameters are optional.
	// However, if a user min is specified, then so must a max
	CHAR* sz = szParams;
	CHAR*	szChannel;
	if (!g_pParser->FGetNextParam(&sz, &szChannel))
	{
		szChannel = "";
	}

	// Get a min and max
	DWORD dwcMin, dwcMax;
	CHAR*	szc;
	if (g_pParser->FGetNextParam(&sz, &szc))
	{
		dwcMin = g_pParser->SzToDw(szc);
		// Make sure there is a max
		if (!g_pParser->FGetNextParam(&sz, &szc))
		{
			// Syntax error
			return HrConChatHelp(pcmd);
		}		
		dwcMax = g_pParser->SzToDw(szc);
	}
	else
	{
		dwcMin = 1;		//defaults
		dwcMax = 1000;	
	}
	
	if (dwcMin >= dwcMax)
	{
		return HrConChatHelp(pcmd);
	}

	// Issue the list call
	if (!g_pSocket->FQueryListChannels(szChannel, dwcMin, dwcMax))
	{
		g_console.WriteString("Error: Could not list channels\n");
		return E_FAIL;
	}
	
	return NOERROR;
}

// Lists members in a given channel.
HRESULT HrCmdListMembers(PCMD pcmd, char* szParams)
{
	if (!FVerifyConnected())
	{
		return S_FALSE;
	}

	CHAR*	sz = szParams;
	CHAR*	szChannel;
	if (!g_pParser->FGetNextParam(&sz, &szChannel))
	{
		return HrConChatHelp(pcmd);
	}

	// List all members in the given channel
	if (!g_pSocket->FQueryChannelMembers(szParams))
	{
		g_console.WriteString("Error: Could not list members\n");
		return E_FAIL;
	}
	
	return NOERROR;
}

//--------------------------------------------------------------------------
// class ConChatSocket
//--------------------------------------------------------------------------
// ConChatSocket derives from CBaseSocket and overrides a number of message handers.

BOOL ConChatSocket::FOnLogin()
{
	g_console.WriteString("Connection Successful\n");

	return TRUE;
}

BOOL ConChatSocket::FOnSocketError(HRESULT hr)
{
	CHAR*	sz = "Error %lx: %s\n";
	CHAR*	szError;

	// We just handle a few sample errors here....
	switch (hr)
	{
	default:
		szError = "This task cannot be completed at this time.";
		break;

	case CS_E_NOMATCHES:
		szError = "No matches found.";
		break;
	
	case CS_E_ALIASINUSE:
		szError = "Your nickname is in use. Please try again.";
		break;
	}

	char szBuf[256];
	wsprintf(szBuf, sz, hr, szError);
	g_console.WriteString(szBuf);

	return TRUE;
}

BOOL ConChatSocket::FOnAddChannel(PCS_MSGCHANNEL pMsg)
{
	// We got a new channel. save it
	_ASSERT(NULL == g_pChannel);

	g_pChannel = new ConChatChannel;
	if (!g_pChannel)
	{
		_ASSERT(0);
		return FALSE;
	}

	// Save the ICSChannel pointer
	if (g_pChannel->FInit(pMsg->picsChannel))
	{
		g_console.WriteString("You are now in channel ");
		g_console.WriteString(g_pChannel->SzName());
		g_console.WriteString(".\n");
		return TRUE;
	}
	
	return FALSE;
}

// We override the CBaseSocket FParseQueryData method so that we can
// add some extra output.
BOOL ConChatSocket::FParseQueryData(PCS_PROPERTY pcsProp)
{
	BOOL	fRet = TRUE;
	_ASSERT(pcsProp);

	if (!pcsProp->picsProperty)
	{
		// Null Property pointers indicate that this is the last record in a data set returned by a qury
		return TRUE;
	}
	// How many properties
	DWORD	dwc;
	if (FAILED((pcsProp->picsProperty)->HrGetCount(&dwc)))
		return FALSE;

	// Make sure nothing else writes to the screen during this time
	g_console.Lock();

	g_console.WriteString(":::\n");; // next line
	for (DWORD dwi = 1; dwi <= dwc && fRet; ++dwi)
	{
		// Retrieve the property
		CS_PROPDATA	cspd;
		if (SUCCEEDED((pcsProp->picsProperty)->HrGetProperty(&cspd, dwi)))
		{
			if (!cspd.pbData || !cspd.fAnsi) // we don't do Unicode
			{
				continue;
			}
			fRet = (cspd.fString)
				? FOnPropString(cspd.csPropType, (CHAR *)cspd.pbData)
				: FOnPropBuffer(cspd.csPropType, cspd.pbData, cspd.dwcb);
		}
	}
	g_console.Unlock();
	return fRet;
}

// When we get string properties, we simply dump them to the console.
BOOL ConChatSocket::FOnPropString(CSPROP_TYPE csType, char* sz)
{
	_ASSERT(sz);

	CHAR* szOut;
	switch (csType)
	{
	default:
		return TRUE;
	
	case CSPROP_MEMBER_NAME:
		szOut = ":::Member Name:   ";
		break;

	case CSPROP_MEMBER_REALNAME:
		szOut = ":::Real Name:     ";
		break;
	
	case CSPROP_CHANNEL_NAME:
		szOut = ":::Channel Name:  ";
		break;
	
	case CSPROP_CHANNEL_TOPIC:
		szOut = ":::Channel Topic: ";
		break;
	}
	g_console.WriteString(szOut);
	g_console.WriteString(sz);
	g_console.WriteString("\n");
	return TRUE;
}

// When we get binary properties, we simply format them then dump them to the console.
BOOL ConChatSocket::FOnPropBuffer(CSPROP_TYPE csType, BYTE* pbBuffer, DWORD dwcb)
{
	_ASSERT(pbBuffer);
	char szBuf[32];

	switch (csType)
	{
	default:
		break;
	
	// DWORD
	case CSPROP_GENERIC_MODE:
		g_console.WriteString(":::Mode:          ");
		wsprintf(szBuf, "%lx", *((DWORD*)pbBuffer));
		g_console.WriteString(szBuf);
		g_console.WriteString("\n");
		break;
	
	// DWORD
	case CSPROP_CHANNEL_CUSER:
		g_console.WriteString(":::Count:         ");
		wsprintf(szBuf, "%d", *((DWORD*)pbBuffer));
		g_console.WriteString(szBuf);
		g_console.WriteString("\n");
		break;
	}
	
	return TRUE;
}

//--------------------------------------------------------------------------
// class ConChatChannel
//--------------------------------------------------------------------------
// ConChatChannel derives from CBaseChannel and overrides a number of message handers.

BOOL ConChatChannel::FOnChannelError(HRESULT hr)
{
	// Error returned asynchronously
	char szBuf[256];
	wsprintf(szBuf, "This task cannot be completed at this time. Error %lx.\n", hr);
	g_console.WriteString(szBuf);

	return TRUE;
}

BOOL ConChatChannel::FOnAddMember(PCS_MSGMEMBER pMsg)
{
	g_console.WriteString(SzMemName(pMsg->picsMember));
	g_console.WriteString(" has joined the conversation.\n");
	return TRUE;
}

BOOL ConChatChannel::FOnDelMember(PCS_MSGMEMBER pMsg)
{
	g_console.WriteString(SzMemName(pMsg->picsMember));
	g_console.WriteString(" has left the conversation.\n");
	return TRUE;
}

BOOL ConChatChannel::FOnNewTopic()
{
	g_console.WriteString("The topic is now: ");
	g_console.WriteString(SzTopic());
	g_console.WriteString("\n");
	return TRUE;
}

BOOL ConChatChannel::FOnAnsiTextMsg(PCS_MSG pMsg)
{
	// Obtain the sender's name
	PICS_MEMBER pMember = pMsg->picsFrom;
	CHAR* szName = SzMemName(pMember);
	if (szName)
	{
		// Is this user a Host?
		char* szStatus = (NOERROR == pMember->HrIsMemberHost()) ? "Host " : "";
		g_console.WriteString(szStatus);
		g_console.WriteString(szName);
		g_console.WriteString(": ");
		g_console.WriteString((CHAR*)pMsg->pbData);
		g_console.WriteString("\n");
		return TRUE;
	}
	return FALSE;
}
