/*--------------------------------------------------------------------------
	console.h
	
		CConsole class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _CONSOLE_H
#define _CONSOLE_H

//--------------------------------------------------------------------------+
// class CConsole

const int g_clinesInput = 3;
const int g_cxMax = 256;

// CConsole provides win32 console input/output functionality.
// It maintains an input `window'--three lines at the bottom of the console--
// and an output `window', which scrolls as data enters it.
class CConsole
{
public:
	CConsole();
	~CConsole();

	BOOL				FInit();
	void				CleanUp();

	BOOL				FDoIOLoop();
	void				StopIOLoop();

	void				WriteString(char* sz);
	void				Newline();

	void				Lock()		{ ::EnterCriticalSection(&m_cs); }
	void				Unlock()	{ ::LeaveCriticalSection(&m_cs); }

private:
	CRITICAL_SECTION	m_cs;

	HANDLE				m_hconsole;
	HANDLE				m_hStdin;

	// Size and attribute information
	int					m_cx;
	int					m_cy;
	int					m_yOutput;
	int					m_cyOutput;
	int					m_yInput;
	int					m_cyInput;
	WORD				m_wcolOrig;
	WORD				m_wcolOutput;
	WORD				m_wcolInput;
	
	// Current cursor positions
	COORD				m_posInput;
	COORD				m_posOutput;

	// Used by SelectWindow()
	COORD*				m_pposCur;
	WORD				m_wcolCur;
	int					m_yCur;
	int					m_cyCur;
	BOOL				m_fInputSel;
	
	BOOL				m_fLoop;	

	void				ClearWindow(BOOL fInput);
	void				SelectWindow(BOOL fInput);
	void				WriteRgch(char* rgch, int cch);
	void				WritePrompt();
	void				WriteInputChar(char ch);
	void				EraseInputChar();

	// m_rgbBuf/m_cbBuf are used for output word-wrapping.  We assume we never
	// have a console wider than 256 bytes...
	char				m_rgbBuf[g_cxMax];
	int					m_cbBuf;
	BOOL				m_fJustDidNewline;
	void				FlushBuffer();
	void				EmptyBuffer();
	void				FlushLeadingSpaces();

	// m_rgbBufInput is the input buffer--the input window never scrolls, so
	// we know we have an upper bound on the amount of text that can be
	// in the input window.
	char				m_rgbBufInput[g_cxMax * g_clinesInput + 1];
	int					m_cbBufInput;
};

extern CConsole g_console;

#endif // _CONSOLE_H
