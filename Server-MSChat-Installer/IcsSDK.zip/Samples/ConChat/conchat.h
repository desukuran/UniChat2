/*--------------------------------------------------------------------------
	conchat.h
	
		ConChatSocket, ConChatChannel classes

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _CONCHAT_H
#define _CONCHAT_H

//--------------------------------------------------------------------------+
// class ConChatSocket
class ConChatSocket: public CBaseSocket
{
public:
	// Overrides
	virtual BOOL	FOnLogin();
	virtual	BOOL	FOnSocketError(HRESULT hr);
	virtual BOOL	FOnAddChannel(PCS_MSGCHANNEL pMsg);
	virtual BOOL	FParseQueryData(PCS_PROPERTY pcsProp);
	virtual BOOL	FOnPropString(CSPROP_TYPE csType, char* sz);
	virtual BOOL	FOnPropBuffer(CSPROP_TYPE csType, BYTE* pbBuffer, DWORD dwcb);
};

//--------------------------------------------------------------------------+
// class ConChatChannel
class ConChatChannel: public CBaseChannel
{
public:
	// Overrides
	virtual	BOOL	FOnChannelError(HRESULT hr);
	virtual BOOL	FOnAddMember(PCS_MSGMEMBER pMsg);
	virtual BOOL	FOnDelMember(PCS_MSGMEMBER pMsg);
	virtual BOOL	FOnNewTopic();
	virtual BOOL	FOnAnsiTextMsg(PCS_MSG pMsg);
};

//--------------------------------------------------------------------------+
// Prototypes

void __cdecl main(int argc, char** argv);

void About();

BOOL FInitGlobals();
BOOL FCleanUpGlobals();

BOOL FVerifyConnected();
BOOL FVerifyInChannel();
BOOL FVerifyNotInChannel();

void PrintPrompt();

BOOL FIOLoop();

HRESULT HrConChatHelp(PCMD pcmd);
HRESULT HrConChatError(HRESULT hr, char* sz);
HRESULT HrSendText(char* szText);

HRESULT HrCmdConnect		(PCMD pcmd, char* szParams);
HRESULT HrCmdQuit			(PCMD pcmd, char* szParams);
HRESULT HrCmdHelp			(PCMD pcmd, char* szParams);
HRESULT HrCmdJoin			(PCMD pcmd, char* szParams);
HRESULT HrCmdLeave			(PCMD pcmd, char* szParams);
HRESULT HrCmdList			(PCMD pcmd, char* szParams);
HRESULT HrCmdListMembers	(PCMD pcmd, char* szParams);

#endif // _CONCHAT_H
