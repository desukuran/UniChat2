/*--------------------------------------------------------------------------
	console.cpp
	
		CConsole class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/
#include "stdafx.h"
#include "console.h"
#include "ccmd.h"

CConsole g_console;
extern CParser* g_pParser;

//--------------------------------------------------------------------------+
// class CConsole

// CConsole provides win32 console input/output functionality.

CConsole::CConsole()
{
	::InitializeCriticalSection(&m_cs);
}

CConsole::~CConsole()
{
	if (m_hconsole)
		::CloseHandle(m_hconsole);

	::DeleteCriticalSection(&m_cs);
}

// Initializes the console.
BOOL CConsole::FInit()
{
//	COORD c;
	m_cbBuf = 0;
	
	// Get a handle to STDIN for reading input, and turn off echo/line input modes.
	m_hStdin = ::GetStdHandle(STD_INPUT_HANDLE);
	DWORD dwMode;
	if (!::GetConsoleMode(m_hStdin, &dwMode))
		return FALSE;
	dwMode &= ~(ENABLE_LINE_INPUT | ENABLE_ECHO_INPUT);
	if (!::SetConsoleMode(m_hStdin, dwMode))
		return FALSE;

	// Create a console handle.
	m_hconsole = ::CreateFile("CONOUT$",
							GENERIC_WRITE | GENERIC_READ,
							FILE_SHARE_READ | FILE_SHARE_WRITE,
							0,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_NORMAL,
							0);
	if (m_hconsole == (HANDLE)-1)
		return FALSE;

	// How big is the console buffer?
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	if (!::GetConsoleScreenBufferInfo(m_hconsole, &csbi))
		return FALSE;

	m_cx = csbi.dwSize.X;
	if (m_cx > g_cxMax)
		m_cx = g_cxMax;
	m_cy = csbi.dwSize.Y;
	m_wcolOrig = csbi.wAttributes;

	m_yOutput = 0;
	m_cyOutput = m_cy - g_clinesInput;

	m_yInput = m_cyOutput;
	m_cyInput = g_clinesInput;

	// These are hardcoded--wouldn't be too hard to add commands to change
	// the colors, but I like these. :-)
	m_wcolOutput = FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_INTENSITY;
	m_wcolInput = BACKGROUND_BLUE | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY;

	this->ClearWindow(FALSE);
	this->ClearWindow(TRUE);
	
	m_posInput.X = 0;
	m_posInput.Y = m_yInput;
	m_posOutput.X = 0;
	m_posOutput.Y = 0;
	
	m_fJustDidNewline = FALSE;
	m_cbBuf = 0;
	m_cbBufInput = 0;
	
	// We assume that the input window is selected by default, so that the
	// blinking input cursor shows up correctly.
	this->SelectWindow(TRUE);
	
	return TRUE;
}

// Clears either the input or the output window.
// Sets the attributes so that the background color is set correctly.
// Also resets the cursor position within the window.
void CConsole::ClearWindow(BOOL fInput)
{
	int y, cy;
	WORD wcol;

	if (fInput)
	{
		y = m_yInput;
		cy = m_cyInput;
		wcol = m_wcolInput;
		
		m_posInput.X = 0;
		m_posInput.Y = m_yInput;
	}
	else
	{
		y = m_yOutput;
		cy = m_cyOutput;
		wcol = m_wcolOutput;
		
		m_posOutput.X = 0;
		m_posOutput.Y = m_yOutput;
	}
	COORD c;
	c.X = 0;
	c.Y = y;
	DWORD cbWritten;

	::FillConsoleOutputCharacter(m_hconsole, ' ', m_cx * cy, c, &cbWritten);
	::FillConsoleOutputAttribute(m_hconsole, wcol, m_cx * cy, c, &cbWritten);
}

// Resets the console to the original colors and clears the screen.
void CConsole::CleanUp()
{
	COORD c;
	DWORD cbWritten;
	c.X = 0;
	c.Y = 0;
	::FillConsoleOutputAttribute(m_hconsole, m_wcolOrig, m_cx * m_cy, c, &cbWritten);
	::FillConsoleOutputCharacter(m_hconsole, ' ', m_cx * m_cy, c, &cbWritten);
	::SetConsoleCursorPosition(m_hconsole, c);
}

// Performs the read loop on the console, sending any entered commands to g_pParser.
// Keeps doing the read loop until this->StopIOLoop() is called.
BOOL CConsole::FDoIOLoop()
{
	m_fLoop = TRUE;
	
	this->WritePrompt();
	
	// m_fLoop is cleared by this->StopIOLoop().
	while (m_fLoop)
	{
		// Read a character...
		char ch;
		DWORD cbRead;
		if (!::ReadFile(m_hStdin, &ch, 1, &cbRead, NULL))
			break;
			
		// ...and process it.
		if (ch == '\r' || ch == '\n')
		{
			// Enter key.  Get the command out of the input buffer and echo it
			// to the output buffer, 
			m_rgbBufInput[m_cbBufInput] = 0;
			this->Lock();
			this->WriteString("> ");
			this->WriteString(m_rgbBufInput);
			this->WriteString("\n");
			this->Unlock();
			
			// Clear the input window.
			this->ClearWindow(TRUE);
			this->SelectWindow(TRUE);
			this->WritePrompt();

			// And execute whatever command had been typed.
			g_pParser->HrParseAndExecute(m_rgbBufInput);
			m_cbBufInput = 0;

			continue;
		}
		else if (ch == 0x08)
		{
			// Backspace.  If there's data in the input buffer, remove one
			// character.
			if (m_cbBufInput > 0)
			{
				m_cbBufInput--;
				this->EraseInputChar();
			}
			else
				::MessageBeep(MB_ICONEXCLAMATION);
		}
		else if (ch >= 32)
		{
			// Normal character.  If there's room, put it in the buffer, else just beep.
			if (m_cbBufInput >= (m_cx * g_clinesInput) - 3)
			{
				::MessageBeep(MB_ICONEXCLAMATION);
				continue;
			}
			m_rgbBufInput[m_cbBufInput++] = ch;
			this->WriteInputChar(ch);
		}
	}
	return TRUE;
}

// Terminates the read loop, causing FDoIOLoop() to return on its next pass through.
void CConsole::StopIOLoop()
{
	::CloseHandle(m_hStdin);
	m_hStdin = 0;
	m_fLoop = FALSE;
}

// Writes a character into the input buffer.  Updates the current cursor position.
void CConsole::WriteInputChar(char ch)
{
	this->Lock();
	_ASSERT(m_fInputSel);

	DWORD cbWritten;
	::WriteConsoleOutputCharacter(m_hconsole, &ch, 1, m_posInput, &cbWritten);
	m_posInput.X++;
	if (m_posInput.X >= m_cx)
	{
		m_posInput.X = 0;
		m_posInput.Y++;
		_ASSERT(m_posInput.Y < m_yInput + m_cyInput);
	}
	::SetConsoleCursorPosition(m_hconsole, m_posInput);
	
	this->Unlock();
}

// Erases the last-typed character from the input buffer.
// Called in response to the user pressing backspace.
void CConsole::EraseInputChar()
{
	this->Lock();
	_ASSERT(m_fInputSel);
	
	if (m_posInput.X == 0)
	{
		m_posInput.Y--;
		m_posInput.X = m_cx - 1;
		_ASSERT(m_posInput.Y >= m_yInput);
	}
	else
		m_posInput.X--;
	::SetConsoleCursorPosition(m_hconsole, m_posInput);
	DWORD cbWritten;
	::WriteConsoleOutputCharacter(m_hconsole, " ", 1, m_posInput, &cbWritten);
	this->Unlock();
}

// Writes the prompt to the input buffer.
void CConsole::WritePrompt()
{
	this->Lock();
	_ASSERT(m_fInputSel);
	this->WriteRgch("> ", 2);
	this->Unlock();
}

// Selects either the input window or the output window for writing text.
// Also sets the console's cursor position to be the given window's
// current cursor position.
void CConsole::SelectWindow(BOOL fInput)
{
	m_fInputSel = fInput;
	if (fInput)
	{
		m_pposCur = &m_posInput;
		m_wcolCur = m_wcolInput;
		m_yCur = m_yInput;
		m_cyCur = m_cyInput;
	}
	else
	{
		m_pposCur = &m_posOutput;
		m_wcolCur = m_wcolOutput;
		m_yCur = m_yOutput;
		m_cyCur = m_cyOutput;
	}
	::SetConsoleTextAttribute(m_hconsole, m_wcolCur);
	::SetConsoleCursorPosition(m_hconsole, *m_pposCur);
}

// Write an array of characters to the currently-selected window.
// We can use WriteConsole() to write most of the characters, but we have to
// use WriteConsoleOutputCharacter() to write the last character on a line
// so that the cursor doesn't wrap to the next line and the console doesn't
// automatically scroll.
void CConsole::WriteRgch(char* rgch, int cch)
{
	int cchWrite = cch;
	
	if (cch + m_pposCur->X >= m_cx)
		cchWrite--;

	DWORD cbWritten;
	::WriteConsole(m_hconsole, rgch, cchWrite, &cbWritten, NULL);

	m_pposCur->X += cch;
	if (cch > cchWrite)
	{
		COORD c;
		c.X = m_cx - 1;
		c.Y = m_yCur + m_pposCur->Y;
		::WriteConsoleOutputCharacter(m_hconsole, &rgch[cchWrite], 1, c, &cbWritten);
		(m_pposCur->X)++;
	}
}

// Used in word-wrapping.  FlushBuffer() writes the current contents of
// the word-wrap buffer to the output window, calling this->Newline() as
// needed to wrap and scroll.  This routine can leave some data in the
// buffer if word-wrapping is in progress.
void CConsole::FlushBuffer()
{
	if (m_fJustDidNewline)
		this->FlushLeadingSpaces();
		
	if (m_cbBuf + m_posOutput.X < m_cx)
	{
		m_fJustDidNewline = FALSE;
		this->WriteRgch(m_rgbBuf, m_cbBuf);
		m_cbBuf = 0;
		return;
	}
		
	while (m_cbBuf + m_posOutput.X >= m_cx)
	{
		m_fJustDidNewline = FALSE;
		int ib = m_cx - m_posOutput.X - 1;
		while (ib >= 0 && m_rgbBuf[ib] != ' ')
			ib--;
		if (ib < 0)
		{
			if (m_cbBuf < m_cx)
			{
				m_fJustDidNewline = TRUE;
				this->Newline();
				continue;
			}
			else
				ib = m_cx - m_posOutput.X - 1;
		}
		
		if (ib > 0)
			this->WriteRgch(m_rgbBuf, ib);
		m_fJustDidNewline = TRUE;
		this->Newline();
		m_cbBuf -= ib;
		::CopyMemory(m_rgbBuf, &m_rgbBuf[ib], m_cbBuf);
		this->FlushLeadingSpaces();
	}
}

// Flushes the entire word-wrap buffer.
void CConsole::EmptyBuffer()
{
	this->FlushBuffer();
	if (m_cbBuf)
		this->WriteRgch(m_rgbBuf, m_cbBuf);
	m_cbBuf = 0;
}

// Removes any leading spaces from the word-wrap buffer.
void CConsole::FlushLeadingSpaces()
{
	int ib = 0;
	while (ib < m_cbBuf && m_rgbBuf[ib] == ' ')
	{
		ib++;
		m_cbBuf--;
	}
	if (ib)
		::CopyMemory(m_rgbBuf, &m_rgbBuf[ib], m_cbBuf);
}

// Public function which writes a string to the output window,
// taking care of word-wrapping and calling this->Newline().
void CConsole::WriteString(char* sz)
{
	this->Lock();
	this->SelectWindow(FALSE);
	
	int ch;
	while (ch = *sz)
	{
		if (ch == '\r')
		{
			if (*sz + 1 == '\n')
				sz++;
			this->EmptyBuffer();
			this->Newline();
		}
		else if (ch == '\n')
		{
			this->EmptyBuffer();
			this->Newline();
		}
		else
		{
			if (m_cbBuf + m_posOutput.X >= m_cx && ch != ' ')
				this->FlushBuffer();
			if (m_cbBuf >= m_cx)
				this->FlushBuffer();
			m_rgbBuf[m_cbBuf++] = ch;
		}
		sz++;
	}
	this->SelectWindow(TRUE);
	this->Unlock();
}

// Moves the cursor to the next line of the currently selected window.
// If the cursor was already at the last line, the window is scrolled.
// Note that the input window should never be scrolled.
void CConsole::Newline()
{
	COORD c;
	
	if (m_pposCur->Y < ((m_yCur + m_cyCur) - 1))
		(m_pposCur->Y)++;
	else
	{
		SMALL_RECT srScroll;
		srScroll.Left	= 0;
		srScroll.Right	= m_cx;
		srScroll.Top	= m_yCur + 1;
		srScroll.Bottom	= (m_yCur + m_cyCur - 1);
		
		SMALL_RECT srClip;
		srClip.Left		= 0;
		srClip.Right	= m_cx;
		srClip.Top		= m_yCur;
		srClip.Bottom	= m_yCur + m_cyCur;
		
		c.X = 0;
		c.Y = m_yCur;
		CHAR_INFO ci;
		ci.Char.AsciiChar = ' ';
		ci.Attributes = m_wcolCur;
		::ScrollConsoleScreenBuffer(m_hconsole, &srScroll, &srClip, c, &ci);
	}
	m_pposCur->X = 0;
	c.X = 0;
	c.Y = m_yCur + m_pposCur->Y;
	::SetConsoleCursorPosition(m_hconsole, c);
}
