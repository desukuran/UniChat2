/*--------------------------------------------------------------------------
	basesock.cpp
	
		CBaseSocket class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/
#include "stdafx.h"
#include "basesock.h"

DWORD __stdcall DwSocketThreadProc(PVOID pvData);

CBaseSocket::CBaseSocket()
{
	m_pics		= NULL;
	m_pFactory	= NULL;
	m_hthread	= NULL;
}

CBaseSocket::~CBaseSocket()
{
	CleanUp();
}

//	Close the socket and kill the worker thread.
void CBaseSocket::CleanUp()
{
	FCloseChatSocket();

	if (m_pFactory)
		m_pFactory->Release();

	if (m_pics)
		m_pics->Release();

	if (m_hthread)
	{
		// We need to make sure to wait for the thread to exit, so we
		// can be sure all the resources have been cleaned up.
		::WaitForSingleObject(m_hthread, INFINITE);
		::CloseHandle(m_hthread);
		m_hthread = NULL;
	}
}

//	Log off and close the socket.
BOOL CBaseSocket::FCloseChatSocket()
{
	if (m_pics)
	{
		m_pics->HrLogOff();
		m_pics->HrCloseSocket();
	}
	return TRUE;
}

void CBaseSocket::SetSocket(PICS pics)
{
	ASSERT(NULL == m_pics);	// make sure we don't already have a socket
	m_pics = pics;
}

PICS CBaseSocket::PChatSocket()
{
	ASSERT(m_pics);

	if (m_pics)
		m_pics->AddRef();

	return m_pics;
}

//	Initialize the object.  We create the socket factory here, so we can
// allow disconnecting during the process of connecting; a connection attempt
// can take a long time, so if the caller wants to cancel the process, 
// it can call HrDisconnect() in another thread.
BOOL CBaseSocket::FInit()
{
	ASSERT(!m_pics);

	HRESULT hr = ::HrCreateChatSocketFactory(IID_CHATSOCKVER1, &m_pFactory);
	if (FAILED(hr))
	{
		FOnSocketError(hr);		// virtual function call
		m_pFactory = NULL;
		return FALSE;
	}
	return TRUE;
}

//	Connecting to a chat server via ChatSock is a 2-step process.
// Since we don't know if the chat server is a MIC or IRC server, 
// we call the socket factory and let it sort out the protocol issues.
// The socket factory will create a socket.
// Once we have the socket, we can then connect and log into the server.
BOOL CBaseSocket::FConnect(PEC_CONNINFO pcInfo)
{
	HRESULT		hr = NOERROR;
	PICS		pics;
	CS_CONNINFO	cInfo;
	BOOL		fDoneBak = FALSE;	// have we tried the backup nick?
	BOOL		fLoop = TRUE;
	PCS_MSGBASE	pcsMsg;

	ASSERT(pcInfo && m_pFactory);

	if (FConnected())
		return TRUE;

	hr = m_pFactory->HrMakeSocket(pcInfo->szServer, &pics);
	if (FAILED(hr))
		goto LReturn;

	::ZeroMemory(&cInfo, sizeof(CS_CONNINFO));
	cInfo.dwcb		= sizeof(CS_CONNINFO);
	cInfo.bType		= pcInfo->fAuthenticate ? CS_CONNECT_AUTHENTICATE : CS_CONNECT_ANONYMOUS;
	cInfo.pvNick	= (PVOID) pcInfo->szNick;
	cInfo.pvUser	= (PVOID) pcInfo->szUserName;
	cInfo.pvPass	= (PVOID) pcInfo->szPass;

	// Loop till we have a result on the login
	while (fLoop)
	{
		hr = pics->HrLoginA(&cInfo);
		if (FAILED(hr))
			goto LReturn;

		hr = pics->HrWaitTillMsgType(CSMSG_TYPE_LOGIN, &pcsMsg, pcInfo->dwTimeOut);
		if (FAILED(hr))
		{
			if (hr == CS_E_ALIASINUSE && !fDoneBak && pcInfo->szNickBak)
			{
				fDoneBak = TRUE;
				cInfo.pvNick = (PVOID) pcInfo->szNickBak;
				continue;
			}
				
			goto LReturn;
		}

		FOnLogin();		// call the virtual function
		fLoop = FALSE;
		::HrFreeMsg(pcsMsg);
	}

LReturn:
	// If successful, save the socket
	if (SUCCEEDED(hr))
	{
		SetSocket(pics);

		// Start a thread to read messages from the message que
		if (!FStartMessageThread())
		{
			FOnSocketError(E_OUTOFMEMORY);	// virtual function call
			CleanUp();
			return FALSE;
		}
		return TRUE;
	}

	// Failure
	if (pics)
	{
		pics->Release();
		pics->HrCloseSocket();	// Fuck you!!!
	}

	FOnSocketError(hr);	// virtual function call
	return FALSE;
}

//	Disconnect from the server.
// Cancels any in-progress connection attempts or other blocking operations.
BOOL CBaseSocket::FDisconnect()
{
	// As long as m_pFactory is alive, HrCancelMakeSocket() will have the same
	// effect as calling HrCloseSocket() on a ChatSocket.
	FCloseChatSocket();
	HRESULT hr;
	if (m_pFactory)
	{
		hr = m_pFactory->HrCancelMakeSocket();
	}
	if FAILED(hr)
	{
		FOnSocketError(hr);	// virtual function call
		return FALSE;
	}
	return TRUE;
}

//	Lists all members in the specified channel.
BOOL CBaseSocket::FQueryChannelMembers(char* szChannel)
{
	ASSERT(m_pics);

	HRESULT hr = m_pics->HrListAllMembersFromNameA(szChannel);
	if (FAILED(hr))
	{
		FOnSocketError(hr);	// virtual function call
		return FALSE;
	}
	return TRUE;
}

//	Lists all channels that meet the following criteria:
//	a) the channel name must contain szChannel, and
//	b) the channel must have a number of members within the specified range.
BOOL CBaseSocket::FQueryListChannels(char* szChannel, DWORD dwcMin, DWORD dwcMax)
{
	ASSERT(m_pics);

	HRESULT hr = m_pics->HrListAllChannelsA(dwcMin, dwcMax, szChannel, CSPROP_QUERY_CONTAINS);
	if (FAILED(hr))
	{
		FOnSocketError(hr);	// virtual function call
		return FALSE;
	}
	return TRUE;
}

//	Uses m_pics->HrCreateChannelA() to create a channel; if a channel
// with the specified name already exists, this function simply joins it.
BOOL CBaseSocket::FCreateJoinChannel(PEC_CHANNELINFO pChanInfo)
{
	ASSERT(pChanInfo);
	ASSERT(m_pics);

	CS_CINFO	cInfo;
	::FillMemory(&cInfo, sizeof(CS_CINFO), 0);	// This line was missing!!!! It's was the BUG! Nov 21thu'96
	cInfo.dwcb			= sizeof(CS_CINFO);
	cInfo.dwType		= pChanInfo->dwType;
	cInfo.dwFlags		= pChanInfo->dwFlags;
	cInfo.bCreateFlags	= CS_CHANNEL_CREATE_JOIN; // if channel exists, join it, else create a new one
	cInfo.pvChannelName = (PVOID) pChanInfo->szName;
	cInfo.pvTopic		= (PVOID) pChanInfo->szTopic;
	cInfo.pvPassword	= pChanInfo->szPass;
	cInfo.dwcUserMax	= pChanInfo->cUsersMax;
	
	HRESULT hr = m_pics->HrCreateChannelA(&cInfo);
	if (FAILED(hr))
	{
		FOnSocketError(hr);	// virtual function call
		return FALSE;
	}
	return TRUE;
}

BOOL CBaseSocket::FConnected()
{
	return (m_pics && NOERROR == m_pics->HrIsConnected());
}

//	Waits for a message to arrive on the message queue.
// Calling FCloseChatSocket on the socket will cause this method to return FALSE immediately.
//	Dispatches the received message using the overrideable virtual methods of CBaseSocket.
BOOL CBaseSocket::FWaitForMessage()
{
	ASSERT(m_pics);

	m_pics->AddRef();		// increase the ref count so that we can be sure that
							// the socket object doesn't go away until this function ends...
	PCS_MSGBASE	pcsMsg;
	while (SUCCEEDED(m_pics->HrWaitForMsg(&pcsMsg, INFINITE)))
	{
		switch (pcsMsg->csMsgType)
		{
		default:
			FUnknownMessage(pcsMsg);	// virtual function call
			break;

		case CSMSG_TYPE_ERROR:
			{
			PCS_ERROR	pErr = MSGBASE_TO_MSG(pcsMsg, PCS_ERROR);
			FOnSocketError(pErr->hr);	// virtual function call
			}
			break;
		
		case CSMSG_TYPE_ADDCHANNEL:
			{
			PCS_MSGCHANNEL pMsgCh = MSGBASE_TO_MSG(pcsMsg, PCS_MSGCHANNEL);
			FOnAddChannel(pMsgCh);		// virtual function call
			}
			break;

		case CSMSG_TYPE_PRIVATEMSG:
			{
			PCS_MSGPRIVATE pMsgPrivate = MSGBASE_TO_MSG(pcsMsg, PCS_MSGPRIVATE);
			FOnPrivateMsg(pMsgPrivate);	// virtual function call
			}
			break;

		case CSMSG_TYPE_QUERYDATA:
			{
			PCS_PROPERTY	pcsProp = MSGBASE_TO_MSG(pcsMsg, PCS_PROPERTY);
			FParseQueryData(pcsProp);	// virtual function call
			}
			break;			
		
		case CSMSG_TYPE_INVITE:
			{
			PCS_MSGINVITE	pcsInvite = MSGBASE_TO_MSG(pcsMsg, PCS_MSGINVITE);
			FOnInvite(pcsInvite);		// virtual function call
			}
			break;
		}
		::HrFreeMsg(pcsMsg);
	}
	m_pics->Release();
	return TRUE;
}

//	Performs default parsing on query data messages.
// If this method is not overridden, it will call FOnPropString and FOnPropBuffer
// as appropriate for the query data.
BOOL CBaseSocket::FParseQueryData(PCS_PROPERTY pcsProp)
{
	ASSERT(pcsProp);

	if (!pcsProp->picsProperty)
		return FALSE;

	DWORD dwc;
	if (FAILED((pcsProp->picsProperty)->HrGetCount(&dwc)))
		return FALSE;
	
	BOOL fRet = TRUE;
	for (DWORD dwi = 1; dwi <= dwc && fRet; dwi++)
	{
		CS_PROPDATA	cspd;
		if (SUCCEEDED((pcsProp->picsProperty)->HrGetProperty(&cspd, dwi)))
		{
			if (!cspd.pbData || !cspd.fAnsi) // For simplicity's sake, ANSI only.
			{
				continue;
			}
			fRet = (cspd.fString)
				? FOnPropString(cspd.csPropType, (CHAR*)cspd.pbData)
				: FOnPropBuffer(cspd.csPropType, cspd.pbData, cspd.dwcb);
		}
	}
	return fRet;
}

BOOL CBaseSocket::FStartMessageThread()
{
	ASSERT(NULL == m_hthread);
	
	DWORD dwID;
	m_hthread = ::CreateThread(NULL, 0, DwSocketThreadProc, this, 0, &dwID);

	return (NULL != m_hthread);
}

DWORD __stdcall DwSocketThreadProc(PVOID pvData)
{
	ASSERT(pvData);

	CBaseSocket* pbasesocket = (CBaseSocket*)pvData;

	return pbasesocket->FWaitForMessage();
}
