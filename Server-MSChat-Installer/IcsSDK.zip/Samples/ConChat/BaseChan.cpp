/*--------------------------------------------------------------------------
	basechan.cpp
	
		CBaseChannel class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/
#include "stdafx.h"
#include "basechan.h"

DWORD __stdcall DwChannelThreadProc(PVOID pvData);

CBaseChannel::CBaseChannel()
{
	m_pChannel = NULL;
	m_hthread = NULL;
}

CBaseChannel::~CBaseChannel()
{
	CleanUp();
}

//	CBaseChannel::FInit()
//	Save the channel pointer returned by ChatSock, then start a message
BOOL CBaseChannel::FInit(PICS_CHANNEL pChannel)
{
	ASSERT(pChannel);

	WaitForMsgThread();

	SetChannel(pChannel);

	if (!FStartMessageThread())
	{
		CleanUp();
		return FALSE;
	}

	return TRUE;
}

//	CBaseChannel::FReInit()
//	Resets the object so it can be restarted with a new channel.
BOOL CBaseChannel::FReInit()
{
	CleanUp();

	return TRUE;
}

//	CBaseChannel::CleanUp()
//	Release our channel pointer.
void CBaseChannel::CleanUp()
{
	WaitForMsgThread();
	if (m_pChannel)
	{
		m_pChannel->Release();
		m_pChannel = NULL;
	}
}

//	CBaseChannel::WaitForMsgThread()
//	Wait for our message thread to terminate; we need to do this
// so we can be sure the thread is cleaned up so we can exit or reinitialize the object.
void CBaseChannel::WaitForMsgThread()
{
	if (m_hthread)
	{
		::WaitForSingleObject(m_hthread, INFINITE);
		::CloseHandle(m_hthread);
		m_hthread = NULL;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBaseChannel accessors
PICS_CHANNEL CBaseChannel::PChannel()
{
	if (m_pChannel)
		m_pChannel->AddRef();
	
	return m_pChannel;
}

BOOL CBaseChannel::FInChannel()
{
	return (NULL != m_pChannel);
}

void CBaseChannel::SetChannel(PICS_CHANNEL pics)
{
	_ASSERT(!m_pChannel);
	
	pics->AddRef();

	m_pChannel = pics;
}

char* CBaseChannel::SzName()
{
	_ASSERT(m_pChannel);

	BYTE*	pb;
	BOOL	fAnsi;
	HRESULT hr = m_pChannel->HrGetName(&pb, &fAnsi);

	// For simplicity, ignore non-ANSI...
	if (FAILED(hr) || !fAnsi)
		return NULL;
	
	return (char*)pb;
}

//	CBaseChannel::SzMemName()
//	Returns the name of the specified member.
char* CBaseChannel::SzMemName(PICS_MEMBER pMember)
{
	_ASSERT(pMember);

	BYTE*	pb;
	BOOL	fAnsi;
	HRESULT hr = pMember->HrGetName(&pb, &fAnsi);

	// For simplicity, ignore non-ANSI...
	if (FAILED(hr) || !fAnsi)
		return NULL;
	
	return (char*)pb;
}

char* CBaseChannel::SzTopic()
{
	_ASSERT(m_pChannel);

	BYTE*	pb;
	BOOL	fAnsi;
	HRESULT hr = m_pChannel->HrGetTopic(&pb, &fAnsi);

	// For simplicity, ignore non-ANSI...
	if (FAILED(hr) || !fAnsi)
		return NULL;
	
	return (char*)pb;
}

/////////////////////////////////////////////////////////////////////////////
// CBaseChannel operations

BOOL CBaseChannel::FSendAnsiText(char* szText)
{
	_ASSERT(m_pChannel);

	HRESULT hr = m_pChannel->HrSendTextA(szText);
	if (FAILED(hr))
	{
		FOnChannelError(hr);	// virtual function call
		return FALSE;
	}
	return TRUE;
}

BOOL CBaseChannel::FSendData(BYTE* pbData, DWORD dwcb)
{
	_ASSERT(m_pChannel);

	HRESULT hr = m_pChannel->HrSendData(pbData, dwcb);
	if (FAILED(hr))
	{
		FOnChannelError(hr);	// virtual function call
		return FALSE;
	}
	return TRUE;
}

DWORD CBaseChannel::DwUserCount()
{
	_ASSERT(m_pChannel);

	DWORD	cUser;
	HRESULT hr = m_pChannel->HrGetUserCount(&cUser);
	if (FAILED(hr))
	{
		FOnChannelError(hr);	// virtual function call
		return 0;
	}
	return cUser;
}

DWORD CBaseChannel::DwType()
{
	_ASSERT(m_pChannel);

	DWORD	dwMode;
	HRESULT hr = m_pChannel->HrGetType(&dwMode);
	if (FAILED(hr))
	{
		FOnChannelError(hr);	// virtual function call
		return 0;
	}
	return dwMode;
}

BOOL CBaseChannel::FSetTopic(char* szTopic)
{
	_ASSERT(m_pChannel);

	HRESULT hr = m_pChannel->HrSetTopicA(szTopic);
	if (FAILED(hr))
	{
		FOnChannelError(hr);	// virtual function call
		return FALSE;
	}
	return TRUE;
}

BOOL CBaseChannel::FLeave()
{
	_ASSERT(m_pChannel);

	if (m_pChannel)
	{
		if (FAILED(m_pChannel->HrLeave(FALSE)))
			return FALSE;

		WaitForMsgThread();
		m_pChannel->Release();
		m_pChannel = NULL;
	}
	return NOERROR;
}

// CBaseChannel::FWaitForMessage()
//	Waits for a message to arrive on the message queue.
// Calling FLeave on the channel will cause this method to return FALSE immediately.
// Dispatches the received message using the overrideable virtual methods of CBaseChannel.
BOOL CBaseChannel::FWaitForMessage()
{
	_ASSERT(m_pChannel);
	m_pChannel->AddRef();	// increase the ref count so that we can be sure that
							// the channel object doesn't go away until this function ends...
	PCS_MSGBASE		pcsMsg;
	while (SUCCEEDED(m_pChannel->HrWaitForMsg(&pcsMsg, INFINITE)))
	{
		switch (pcsMsg->csMsgType)
		{
		default:
			FUnknownMessage(pcsMsg);
			break;

		case CSMSG_TYPE_ERROR:
			{
			PCS_ERROR	pErr = MSGBASE_TO_MSG(pcsMsg, PCS_ERROR);
			FOnChannelError(pErr->hr);	// virtual function call
			}
			break;

		case CSMSG_TYPE_ADDMEMBER:
			{
			PCS_MSGMEMBER	pAddMsg = MSGBASE_TO_MSG(pcsMsg, PCS_MSGMEMBER);
			FOnAddMember(pAddMsg);		// virtual function call
			}
			break;

		case CSMSG_TYPE_GOTMEMLIST:
			m_fGotMemList = TRUE;
			break;

		case CSMSG_TYPE_DELMEMBER:
			{
			PCS_MSGMEMBER	pDelMsg = MSGBASE_TO_MSG(pcsMsg, PCS_MSGMEMBER);
			FOnDelMember(pDelMsg);		// virtual function call
			}
			break;

		case CSMSG_TYPE_DELCHANNEL:
			{
			PCS_MSGCHANNEL	pMsgChan = MSGBASE_TO_MSG(pcsMsg, PCS_MSGCHANNEL);
			FOnDelChannel(pMsgChan);	// virtual function call
			}
			break;

		case CSMSG_TYPE_MODEMEMBER:
			{
			PCS_MSGMEMBER	pModeMsg = MSGBASE_TO_MSG(pcsMsg, PCS_MSGMEMBER);
			FOnMemberModeChange(pModeMsg);	// virtual function call
			}
			break;
		
		case CSMSG_TYPE_MODECHANNEL:
			FOnChannelModeChange();			// virtual function call
			break;
		
		case CSMSG_TYPE_TEXT_A:
			{
			PCS_MSG pMsgText = MSGBASE_TO_MSG(pcsMsg, PCS_MSG);
			FOnAnsiTextMsg(pMsgText);		// virtual function call
			}
			break;
		
		case CSMSG_TYPE_DATA:
			{
			PCS_MSG pMsgData = MSGBASE_TO_MSG(pcsMsg, PCS_MSG);
			FOnDataMsg(pMsgData);			// virtual function call
			}
			break;

		case CSMSG_TYPE_WHISPERTEXT_A:
			{
			PCS_MSGWHISPER pMsgWhisper = MSGBASE_TO_MSG(pcsMsg, PCS_MSGWHISPER);
			FOnAnsiWhisperTextMsg(pMsgWhisper);	// virtual function call
			}
			break;

		case CSMSG_TYPE_WHISPERDATA:
			{
			PCS_MSGWHISPER	pMsgWhisperData = MSGBASE_TO_MSG(pcsMsg, PCS_MSGWHISPER);
			FOnAnsiWhisperDataMsg(pMsgWhisperData);	// virtual function call
			}
			break;

		case CSMSG_TYPE_NEWTOPIC:
			FOnNewTopic();			// virtual function call
			break;

		case CSMSG_TYPE_NEWNICK:
			{
			PCS_NEWNICK pNickMsg = MSGBASE_TO_MSG(pcsMsg, PCS_NEWNICK);
			FOnNewNick(pNickMsg);	// virtual function call
			}
			break;
		}
		// Free the msg
		::HrFreeMsg(pcsMsg);
	}
	m_pChannel->Release();
	return FALSE;
}

BOOL CBaseChannel::FStartMessageThread()
{
	_ASSERT(!m_hthread);
	
	DWORD dwID;
	m_hthread= ::CreateThread(NULL, 0, DwChannelThreadProc, this, 0, &dwID);

	return (NULL != m_hthread);
}

DWORD __stdcall DwChannelThreadProc(PVOID pvData)
{
	_ASSERT(pvData);

	CBaseChannel* pbasechannel = (CBaseChannel*)pvData;

	return pbasechannel->FWaitForMessage();
}
