/*--------------------------------------------------------------------------
	ccmd.cpp
	
		CParser class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

//--------------------------------------------------------------------------+
// Notes
// 
// The parser understands commands in the following pseudo-BNF format:
//
//	<expression>	:= 	<command> <params>
//	<command>		:=	[<spaces>] <sz_nospaces>
//	<params>		:=	<spaces> <param> <params> | <nothing>
//	<param>			:=	<sz_nospaces> | <sz_spaces>
//	<spaces>		:=	<space>+
//	<sz_nospaces>	:=	Any string, but with NO space
//	<sz_spaces>		:=	<quote>	Any string <quote>
//	<quote>			:=	'"'
//	<space>			:=	' '
//	<nothing>		:=
//
// NOTE: <command>s are case-insensitive.

#include "stdafx.h"
#include "ccmd.h"

//--------------------------------------------------------------------------+
// class CParser
//
// CParser is a simple command parser.  All user-typed commands from
// ConChat are routed through CParser for processing.

CParser::CParser()
{
	m_mpcmd			= NULL;
	m_ccmd			= 0;
	m_pfnHelp		= NULL;
	m_pfnError		= NULL;
	m_pfnDefault	= NULL;
}

CParser::~CParser()
{
}

// Initialize the parser.  The caller provides callback functions that
// HrParseAndExecute() will use to perform the commands.  The mpcmd parameter
// is a table of CMD structs that map command strings to functions.
HRESULT CParser::HrInit(PCMD			mpcmd,
						int				ccmd,
						PFNHELP			pfnHelp,
						PFNDEFAULT		pfnDefault,
						PFNERROR		pfnError)
{
	_ASSERT(mpcmd);
	_ASSERT(ccmd > 0);
	_ASSERT(pfnError);
	_ASSERT(pfnDefault);
	_ASSERT(pfnHelp);

	// Save away parameters.
	m_mpcmd			= mpcmd;
	m_ccmd			= ccmd;
	m_pfnHelp		= pfnHelp;
	m_pfnDefault	= pfnDefault;
	m_pfnError		= pfnError;

	return NOERROR;
}

// Parses the given string, looking for commands.  If the string matches
// a command from the command table m_mpcmd, the specified routine will be
// called.  If there's an error parsing the string, m_pfnError will be
// called.  If the command is a request for help on a given command (i.e,
// if the string is of the form "<command> /?" or "<command> -?"), m_pfnHelp
// will be called.  Otherwise, m_pfnDefault will be called.
HRESULT CParser::HrParseAndExecute(char* sz)
{
	// First, we look for a command at the beginning of the string.
	// HrGetCommand simply breaks out the first word, putting its start
	// and end points into pchCmdStart/pchCmdEnd.
	char*	pchCmdStart;
	char*	pchCmdEnd;
	HRESULT hr = this->HrGetCommand(sz, &pchCmdStart, &pchCmdEnd);
	if (FAILED(hr))
	{
		m_pfnError(hr, sz);
		goto LDone;
	}
		
	// Any following text must be params.
	char*	pchParamsStart;
	hr = this->HrGetParams(pchCmdEnd, &pchParamsStart);
	if (FAILED(hr))
	{
		m_pfnError(hr, sz);
		goto LDone;
	}
		
	// Try to match the command against our command table.
	PCMD	pcmd;
	hr = this->HrFindCmd(pchCmdStart, pchCmdEnd, &pcmd);
	if (CMD_E_UNKNOWNCMD == hr)
	{
		m_pfnDefault(sz);
		hr = NOERROR;
		goto LDone;
	}
	if (FAILED(hr))
	{
		m_pfnError(hr, sz);
		goto LDone;
	}
		
	// Okay, we found a command.  Look for the give-me-help flags:
	if (::lstrcmpi("-?", pchParamsStart) && ::lstrcmpi("/?", pchParamsStart))
	{
		// Regular command.  Execute it.
		pcmd->pfnCmd(pcmd, pchParamsStart);
	}
	else
	{
		// Show help.
		(*m_pfnHelp)(pcmd);
	}
	
	hr = NOERROR;
LDone:
	return hr;
}

// Matches the given string (from pchCmdStart to pchCmdEnd) against
// our command table.
HRESULT CParser::HrFindCmd(char* pchCmdStart, char* pchCmdEnd, PCMD* ppcmd)
{
	PCMD pcmd = m_mpcmd;
	for (int i = 0; i < m_ccmd; i++)
	{
		if (this->FCompareRgchSz(pchCmdStart, pchCmdEnd - pchCmdStart, pcmd->szCmd))
		{
			*ppcmd = pcmd;
			return NOERROR;
		}
		pcmd++;
	}
	return CMD_E_UNKNOWNCMD;
}

// Helper function.
BOOL CParser::FCompareRgchSz(char* rgch, int cch, char* sz)
{
	if (cch != lstrlen(sz))
		return FALSE;
		
	while (*sz)
	{
		if (CharLower((char*)*sz) != CharLower((char*)*rgch))
			return FALSE;
		sz++;
		rgch++;
	}
	return TRUE;
}

// Returns pointers to the beginning and end of the command
// (the first space-delimited word in sz).
HRESULT CParser::HrGetCommand(char* sz, char** ppchCmdStart, char** ppchCmdEnd)
{
	// Skip leading blanks.
	this->SkipSpaces(&sz);
	
	*ppchCmdStart = sz;
	this->SkipTillSpace(&sz);
	*ppchCmdEnd = sz;

	return (*ppchCmdEnd > *ppchCmdStart) ? NOERROR : CMD_E_MISSINGCMD;
}

// Returns a pointer to the start of the first parameter
// (the first word after the command).
HRESULT CParser::HrGetParams(char* pchCmdEnd, char** ppchParamsStart)
{
	SkipSpaces(&pchCmdEnd);
	*ppchParamsStart = pchCmdEnd;
	return NOERROR;
}

// Makes *pszNextParam point to the beginning of the next param in the param list.
// Updates *pszParams to point to the next param after this param.
// WARNING!  This function modifies the buffer pointed to by *pszParams
// in order to null-terminate each param string!
BOOL CParser::FGetNextParam(char** pszParams, char** pszNextParam)
{
	char*	szEndParam;
	char	ch;
//	BOOL	fLast;
	
	char* szParam = *pszParams;
	
	if (!*szParam)
		return FALSE;

	if ('"' == *szParam)
	{
		// Skip till next quote
		szParam++;
		szEndParam = szParam;
		while ((ch = *szEndParam) && ch != '"')
			szEndParam++;
		if (ch != '"')
		{
			m_pfnError(CMD_E_MISSINGQUOTE, *pszParams);
			return FALSE;
		}
		// null-terminate
		*szEndParam++ = 0;
	}
	else
	{
		szEndParam = szParam;
		while ((ch = *szEndParam) && ch != ' ')
			szEndParam++;
		// null-terminate
		if (*szEndParam)
			*szEndParam++ = 0;
	}

	*pszNextParam = szParam;
	
	SkipSpaces(&szEndParam);
	*pszParams = szEndParam;
	if (!*szParam)
		return FALSE;
	return TRUE;
}

// Updates *psz to point to the first occurence of ch in the string,
// or to the null-terminator if ch does not occur.
void CParser::SkipTillChar(char** psz, char ch)
{
	char* sz = *psz;

	while (*sz && (*sz != ch))
		sz++;
	*psz = sz;
}

// Updates *psz to point to the first non-space character in the string.
void CParser::SkipSpaces(char** psz)
{
	char* sz = *psz;

	while (*sz && (*sz == ' '))
		sz++;
	*psz = sz;
}

// Converts a numeric string (base 10) to a DWORD.
DWORD CParser::SzToDw(char* sz)
{
	DWORD dw = 0;
	int ch;

	while (((ch = *sz) >= '0') && (ch <= '9'))
	{
		dw *= 10;
		dw += (ch - '0');
		sz++;
	}
	return dw;
}
