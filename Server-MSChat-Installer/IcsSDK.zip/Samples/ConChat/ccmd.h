/*--------------------------------------------------------------------------
	ccmd.h
	
		CParser class

    Copyright (C) 1996 Microsoft Corporation
    All rights reserved.

  --------------------------------------------------------------------------*/

#ifndef _CCMD_H
#define _CCMD_H

//--------------------------------------------------------------------------+
// Notes
/*
** The parser understands commands in the following pseudo-BNF format:
**
**	<expression>	:= 	<command> <params>
**	<command>		:=	[<spaces>] <sz_nospaces>
**	<params>		:=	<spaces> <param> <params> | <nothing>
**	<param>			:=	<sz_nospaces> | <sz_spaces>
**	<spaces>		:=	<space>+
**	<sz_nospaces>	:=	Any string, but with NO space
**	<sz_spaces>		:=	<quote>	Any string <quote>
**	<quote>			:=	'"'
**	<space>			:=	' '
**	<nothing>		:=
**
** NOTE: <command>s are case-insensitive.
*/

// Forward def of PCMD...
typedef struct _command CMD, *PCMD;

// Callback function definitions:
typedef HRESULT (*PFNEXECUTECMD)(PCMD pcmd, char* szParams);
typedef HRESULT (*PFNHELP)(PCMD pcmd);
typedef HRESULT (*PFNDEFAULT)(char* sz);
typedef HRESULT (*PFNERROR)(HRESULT hr, char* sz);

// Command-table entry:
typedef struct _command
{
	char*			szCmd;
	char*			szDescription;
  	PFNEXECUTECMD	pfnCmd;
} CMD, *PCMD;

//--------------------------------------------------------------------------+
// Errors
#define CMD_ERROR(e)	MAKE_SCODE(SEVERITY_ERROR, FACILITY_ITF, 0x7000 + e)

const HRESULT CMD_E_UNKNOWNCMD			= CMD_ERROR(0x0001);
const HRESULT CMD_E_MISSINGPREFIX		= CMD_ERROR(0x0002);
const HRESULT CMD_E_MISSINGCMD			= CMD_ERROR(0x0003);
const HRESULT CMD_E_MISSINGPARAMS		= CMD_ERROR(0x0004); 
const HRESULT CMD_E_MISSINGQUOTE		= CMD_ERROR(0x0005);

//--------------------------------------------------------------------------+
// class CParser

// CParser is a simple command parser.  All user-typed commands from
// ConChat are routed through CParser for processing.
class CParser
{
public:
	CParser();
	~CParser();

	HRESULT			HrInit(PCMD			mpcmd,
						   int			ccmd, 
						   PFNHELP		pfnHelp,
						   PFNDEFAULT	pfnDefault,
						   PFNERROR		pfnError);

	HRESULT			HrParseAndExecute(char* sz);
	BOOL			FGetNextParam(char** pszParams, char** pszNextParam);
	DWORD			SzToDw(char* sz);

private:
	HRESULT			HrFindCmd(char* pchCmdStart, char* pchCmdEnd, PCMD* ppcmd);
	BOOL			FCompareRgchSz(char* rgch, int cch, char* sz);
	void			SkipTillChar(char** psz, char ch);
	void			SkipTillSpace(char** psz)	{ SkipTillChar(psz, ' '); }
	void			SkipSpaces(char** psz);

	HRESULT			HrGetCommand(char* sz, char** ppchCmdStart, char** ppchCmdEnd);
	HRESULT			HrGetParams(char* pchCmdEnd, char** ppchParamsStart);

	PCMD			m_mpcmd;
	int				m_ccmd;

	PFNHELP			m_pfnHelp;
	PFNERROR		m_pfnError;
	PFNDEFAULT		m_pfnDefault;
};

#endif
