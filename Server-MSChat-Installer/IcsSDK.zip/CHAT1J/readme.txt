------------------------------------------------------------------
             Microsoft Chat SDK 1.1 Readme File
                         August 1997            
------------------------------------------------------------------

             (c) Copyright Microsoft Corporation, 1997


HOW TO USE THIS DOCUMENT
========================

To view Readme.txt on screen in Windows Notepad, maximize the Notepad 
window.

To print Readme.txt, open the file in Notepad or another word processor,
and then on the File menu, click Print.

SETTING UP MICROSOFT CHAT 1.0J ON A CHAT AND WEB SERVER
=======================================================
These are the steps to get the samples and Microsoft Chat 1.0 j to work with your chat server.

1) You will need to setup a web server and IRC chat server on the same computer to use Microsoft Chat 1.0j. 
2) After you setup the web server and chat server, then you should copy mschat1j.exe in the chat1j directory
   to your web server. 
3) You will need to unzip the selfextracting exe mschat1j.exe by running the program mschat1j.exe. 
4) To use Microsoft Chat 1.0 j you will need to use these files after running the program mschat1j.exe: 
   all *.class, *.gif, *.cab, *.zip, *.properties and *.jar files. You will also need a html file that points to the applet, you 
   can either use the sample html files or create your own.


